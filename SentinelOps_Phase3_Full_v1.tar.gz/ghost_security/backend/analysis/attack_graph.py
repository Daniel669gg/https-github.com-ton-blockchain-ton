"""
backend/analysis/attack_graph.py
Attack Graph Engine: Source → Vulnerability → Reachability → Asset → Exploit Path.

Constructs a directed property graph from findings and entrypoints, identifies
critical attack paths via DFS, computes a composite risk score, and can render
the graph as Graphviz DOT or JSON.
"""
from __future__ import annotations

import json
import logging
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

from pydantic import BaseModel, Field

from backend.core.confidence import Finding

logger = logging.getLogger("ghost.attack_graph")


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class NodeType(str, Enum):
    SOURCE = "source"           # attacker entry
    VULNERABILITY = "vuln"      # CVE/finding
    ASSET = "asset"             # protected resource
    CONTROL = "control"         # security control (auth, WAF)
    EXPLOIT = "exploit"         # exploit technique


class GraphNode(BaseModel):
    node_id: str
    type: NodeType
    label: str
    properties: Dict[str, Any] = Field(default_factory=dict)


class GraphEdge(BaseModel):
    from_id: str
    to_id: str
    label: str = ""             # "triggers", "leads_to", "bypasses", "exposes"
    probability: float = 1.0    # 0.0–1.0


class AttackGraph(BaseModel):
    nodes: List[GraphNode] = Field(default_factory=list)
    edges: List[GraphEdge] = Field(default_factory=list)
    critical_paths: List[List[str]] = Field(default_factory=list)  # list of node_id paths
    risk_score: float = 0.0


# ---------------------------------------------------------------------------
# Severity weights
# ---------------------------------------------------------------------------

_SEVERITY_WEIGHTS: Dict[str, float] = {
    "CRITICAL": 1.0,
    "HIGH": 0.75,
    "MEDIUM": 0.5,
    "LOW": 0.25,
    "INFO": 0.1,
}

# CWE IDs that map to "database" or "credential" assets
_DB_CWES: Set[str] = {"CWE-89", "CWE-564", "CWE-943"}
_AUTH_CWES: Set[str] = {"CWE-306", "CWE-862", "CWE-863", "CWE-284"}
_DATA_CWES: Set[str] = {"CWE-200", "CWE-359", "CWE-312", "CWE-313"}

# Rule-ID prefixes that imply specific assets
_SQLI_PREFIXES = ("SQLI", "SQL_INJ", "CWE-89")
_AUTH_PREFIXES = ("AUTH", "AUTHZ", "AUTHN", "IDOR")
_DATA_PREFIXES = ("SSRF", "PATH_TRAV", "LFI", "RFI", "IDOR")


def _asset_for_finding(finding: Finding) -> Optional[str]:
    """Infer an asset node ID from a finding's rule and CWE."""
    rid = finding.rule_id.upper()
    cwe = finding.cwe_id.upper()

    if any(rid.startswith(p) for p in _SQLI_PREFIXES) or cwe in _DB_CWES:
        return "asset:database"
    if any(rid.startswith(p) for p in _AUTH_PREFIXES) or cwe in _AUTH_CWES:
        return "asset:auth_system"
    if any(rid.startswith(p) for p in _DATA_PREFIXES) or cwe in _DATA_CWES:
        return "asset:sensitive_data"
    # Default: generic application data asset
    return "asset:application_data"


def _finding_node_id(finding: Finding) -> str:
    return f"vuln:{finding.rule_id}:{finding.file}:{finding.line}"


def _entry_node_id(entry: Any) -> str:
    """Deterministic node ID for an entrypoint (duck-typed)."""
    ep_file = getattr(entry, "file", "unknown")
    ep_name = getattr(entry, "name", "unknown")
    return f"source:{ep_file}:{ep_name}"


# ---------------------------------------------------------------------------
# AttackGraphBuilder
# ---------------------------------------------------------------------------

class AttackGraphBuilder:
    """
    Builds an :py:class:`AttackGraph` from findings and optional entrypoints.

    The graph structure is::

        SOURCE (entrypoint)
          └─[triggers]─► VULNERABILITY (finding)
               └─[exposes]─► ASSET
               └─[leads_to]─► VULNERABILITY (chained taint)

    A generic Internet SOURCE node is always included.
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build(
        self,
        findings: List[Finding],
        entrypoints: List[Any],
        cve_records: Optional[List[Any]] = None,
    ) -> AttackGraph:
        """
        Build the attack graph.

        Parameters
        ----------
        findings:
            List of :py:class:`~backend.core.confidence.Finding` objects.
        entrypoints:
            List of :py:class:`~backend.analysis.reachability.EntryPoint`-like
            objects (must have ``file``, ``name``, ``type``, and ``method``
            attributes/fields).
        cve_records:
            Optional list of CVE metadata dicts (currently unused; reserved for
            future enrichment).
        """
        graph = AttackGraph()

        # ── Internet source node ────────────────────────────────────────────────
        internet_node = GraphNode(
            node_id="source:internet",
            type=NodeType.SOURCE,
            label="Internet / Attacker",
            properties={"description": "Unauthenticated internet attacker"},
        )
        graph.nodes.append(internet_node)

        # ── Entrypoint nodes ────────────────────────────────────────────────────
        seen_node_ids: Set[str] = {"source:internet"}

        for ep in entrypoints:
            ep_id = _entry_node_id(ep)
            if ep_id in seen_node_ids:
                continue
            seen_node_ids.add(ep_id)
            ep_type = getattr(ep, "type", "UNKNOWN")
            ep_method = getattr(ep, "method", "")
            ep_path = getattr(ep, "path", "")
            label = (
                f"{ep_type}: {ep_method} {ep_path}".strip()
                if ep_path
                else f"{ep_type}: {getattr(ep, 'name', ep_id)}"
            )
            graph.nodes.append(
                GraphNode(
                    node_id=ep_id,
                    type=NodeType.SOURCE,
                    label=label,
                    properties={
                        "file": getattr(ep, "file", ""),
                        "line": getattr(ep, "line", 0),
                        "ep_type": ep_type,
                        "method": ep_method,
                        "path": ep_path,
                    },
                )
            )
            # Internet → entrypoint edge
            graph.edges.append(
                GraphEdge(
                    from_id="source:internet",
                    to_id=ep_id,
                    label="reaches",
                    probability=0.9 if ep_method == "GET" else 0.8,
                )
            )

        # ── Vulnerability nodes ─────────────────────────────────────────────────
        # Build a set of finding node IDs for taint-chain detection
        finding_node_map: Dict[str, Finding] = {}
        for finding in findings:
            fid = _finding_node_id(finding)
            if fid in seen_node_ids:
                continue
            seen_node_ids.add(fid)
            sev = finding.severity.upper()
            graph.nodes.append(
                GraphNode(
                    node_id=fid,
                    type=NodeType.VULNERABILITY,
                    label=f"{sev}: {finding.rule_id}",
                    properties={
                        "rule_id": finding.rule_id,
                        "file": finding.file,
                        "line": finding.line,
                        "severity": sev,
                        "confidence": finding.confidence,
                        "cwe_id": finding.cwe_id,
                        "description": finding.description,
                    },
                )
            )
            finding_node_map[fid] = finding

        # ── Asset nodes ─────────────────────────────────────────────────────────
        asset_labels: Dict[str, str] = {
            "asset:database": "Database",
            "asset:auth_system": "Authentication System",
            "asset:sensitive_data": "Sensitive Data Store",
            "asset:application_data": "Application Data",
        }
        used_assets: Set[str] = set()
        for finding in findings:
            asset_id = _asset_for_finding(finding)
            if asset_id and asset_id not in used_assets:
                used_assets.add(asset_id)
                if asset_id not in seen_node_ids:
                    seen_node_ids.add(asset_id)
                    graph.nodes.append(
                        GraphNode(
                            node_id=asset_id,
                            type=NodeType.ASSET,
                            label=asset_labels.get(asset_id, asset_id),
                            properties={},
                        )
                    )

        # ── Edges: entrypoint → finding ─────────────────────────────────────────
        # For each finding, connect the "nearest" entrypoint
        ep_ids = [_entry_node_id(ep) for ep in entrypoints]

        for finding in findings:
            fid = _finding_node_id(finding)
            asset_id = _asset_for_finding(finding)
            conf = finding.confidence

            # Connect from an entrypoint (or internet if no entrypoints)
            source_id = self._best_source_for_finding(finding, entrypoints, ep_ids)
            graph.edges.append(
                GraphEdge(
                    from_id=source_id,
                    to_id=fid,
                    label="triggers",
                    probability=round(conf * 0.9, 4),
                )
            )

            # Connect finding → asset
            if asset_id:
                graph.edges.append(
                    GraphEdge(
                        from_id=fid,
                        to_id=asset_id,
                        label="exposes",
                        probability=round(conf, 4),
                    )
                )

        # ── Taint chains: finding → finding ─────────────────────────────────────
        # Heuristic: findings in the same file with taint-related rule IDs chain
        # in line-number order.
        taint_prefixes = ("TAINT", "XSS", "SQLI", "INJECTION", "SSRF")
        taint_findings = [
            (fid, f)
            for fid, f in finding_node_map.items()
            if any(f.rule_id.upper().startswith(p) for p in taint_prefixes)
        ]
        # Group by file
        by_file: Dict[str, List[Tuple[str, Finding]]] = {}
        for fid, f in taint_findings:
            by_file.setdefault(f.file, []).append((fid, f))
        for file_findings in by_file.values():
            file_findings.sort(key=lambda x: x[1].line)
            for (fid_a, fa), (fid_b, fb) in zip(file_findings, file_findings[1:]):
                graph.edges.append(
                    GraphEdge(
                        from_id=fid_a,
                        to_id=fid_b,
                        label="leads_to",
                        probability=round((fa.confidence + fb.confidence) / 2, 4),
                    )
                )

        # ── Risk score ──────────────────────────────────────────────────────────
        graph.risk_score = self._compute_risk_score(findings)

        # ── Critical paths ──────────────────────────────────────────────────────
        graph.critical_paths = self.find_critical_paths(graph)

        logger.info(
            "build: %d nodes, %d edges, risk_score=%.4f, %d critical paths",
            len(graph.nodes),
            len(graph.edges),
            graph.risk_score,
            len(graph.critical_paths),
        )
        return graph

    @staticmethod
    def _best_source_for_finding(
        finding: Finding,
        entrypoints: List[Any],
        ep_ids: List[str],
    ) -> str:
        """Pick the closest entrypoint to *finding* by file path similarity."""
        if not entrypoints:
            return "source:internet"
        best_ep = None
        best_common = -1
        for ep, ep_id in zip(entrypoints, ep_ids):
            ep_file = getattr(ep, "file", "")
            if ep_file == finding.file:
                return ep_id
            # Count common path segments
            finding_parts = finding.file.split("/")
            ep_parts = ep_file.split("/")
            common = sum(1 for a, b in zip(finding_parts, ep_parts) if a == b)
            if common > best_common:
                best_common = common
                best_ep = ep_id
        return best_ep or "source:internet"

    @staticmethod
    def _compute_risk_score(findings: List[Finding]) -> float:
        """
        Weighted risk score = sum(severity_weight × confidence) / total count.
        Returns 0.0 if there are no findings.
        """
        if not findings:
            return 0.0
        total_weight = sum(
            _SEVERITY_WEIGHTS.get(f.severity.upper(), 0.5) * f.confidence
            for f in findings
        )
        return round(total_weight / len(findings), 4)

    # ------------------------------------------------------------------
    # Critical paths
    # ------------------------------------------------------------------

    def find_critical_paths(
        self,
        graph: AttackGraph,
        max_paths: int = 10,
    ) -> List[List[str]]:
        """
        DFS from every SOURCE node to every ASSET node.

        Returns up to *max_paths* paths, ranked by the product of edge
        probabilities along the path (highest probability first).
        """
        # Build adjacency map and edge probability map
        adj: Dict[str, List[str]] = {}
        prob_map: Dict[Tuple[str, str], float] = {}
        for edge in graph.edges:
            adj.setdefault(edge.from_id, []).append(edge.to_id)
            prob_map[(edge.from_id, edge.to_id)] = edge.probability

        source_ids = {n.node_id for n in graph.nodes if n.type == NodeType.SOURCE}
        asset_ids = {n.node_id for n in graph.nodes if n.type == NodeType.ASSET}

        if not source_ids or not asset_ids:
            return []

        all_paths: List[Tuple[float, List[str]]] = []

        for src in source_ids:
            self._dfs_paths(
                src, asset_ids, adj, prob_map,
                [src], {src}, 1.0, all_paths, max_paths * 5,
            )

        # Sort descending by probability product, keep top max_paths
        all_paths.sort(key=lambda x: x[0], reverse=True)
        return [path for _, path in all_paths[:max_paths]]

    def _dfs_paths(
        self,
        node: str,
        targets: Set[str],
        adj: Dict[str, List[str]],
        prob_map: Dict[Tuple[str, str], float],
        current_path: List[str],
        visited: Set[str],
        current_prob: float,
        results: List[Tuple[float, List[str]]],
        limit: int,
    ) -> None:
        """Recursive DFS helper for critical path finding."""
        if len(results) >= limit:
            return
        if node in targets:
            results.append((current_prob, list(current_path)))
            # Continue searching (the path might extend further)
        for neighbor in adj.get(node, []):
            if neighbor in visited:
                continue
            edge_prob = prob_map.get((node, neighbor), 1.0)
            new_prob = current_prob * edge_prob
            visited.add(neighbor)
            current_path.append(neighbor)
            self._dfs_paths(
                neighbor, targets, adj, prob_map,
                current_path, visited, new_prob, results, limit,
            )
            current_path.pop()
            visited.discard(neighbor)

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    @staticmethod
    def to_dot(graph: AttackGraph) -> str:
        """
        Render the attack graph as a Graphviz DOT string.

        Color coding:
        - SOURCE → red
        - VULNERABILITY → orange
        - ASSET → green
        - CONTROL → blue
        - EXPLOIT → purple
        """
        color_map = {
            NodeType.SOURCE: "red",
            NodeType.VULNERABILITY: "orange",
            NodeType.ASSET: "green",
            NodeType.CONTROL: "blue",
            NodeType.EXPLOIT: "purple",
        }

        lines = [
            "digraph AttackGraph {",
            "    rankdir=LR;",
            '    node [shape=box, style=filled, fontsize=10];',
            "",
        ]

        for node in graph.nodes:
            color = color_map.get(node.type, "grey")
            safe_label = node.label.replace('"', '\\"').replace("\n", "\\n")
            lines.append(
                f'    "{node.node_id}" [label="{safe_label}", fillcolor="{color}", fontcolor="white"];'
            )

        lines.append("")

        for edge in graph.edges:
            safe_label = edge.label.replace('"', '\\"')
            prob_str = f"{edge.probability:.2f}"
            lines.append(
                f'    "{edge.from_id}" -> "{edge.to_id}" '
                f'[label="{safe_label} ({prob_str})"];'
            )

        # Highlight critical paths
        if graph.critical_paths:
            lines.append("")
            lines.append("    // Critical paths highlighted with bold edges")
            crit_edges: Set[Tuple[str, str]] = set()
            for path in graph.critical_paths:
                for a, b in zip(path, path[1:]):
                    crit_edges.add((a, b))
            for a, b in crit_edges:
                lines.append(
                    f'    "{a}" -> "{b}" [style=bold, color=red, penwidth=2];'
                )

        lines.append("}")
        return "\n".join(lines)

    @staticmethod
    def to_json(graph: AttackGraph) -> str:
        """Serialise the attack graph to a JSON string."""
        return graph.model_dump_json(indent=2)


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------

def build_attack_graph(
    findings: List[Finding],
    entrypoints: Optional[List[Any]] = None,
) -> AttackGraph:
    """
    Convenience wrapper: construct an :py:class:`AttackGraphBuilder` and build
    the graph in one call.
    """
    builder = AttackGraphBuilder()
    return builder.build(findings, entrypoints or [])
