"""Ghost Security Platform — agents"""
