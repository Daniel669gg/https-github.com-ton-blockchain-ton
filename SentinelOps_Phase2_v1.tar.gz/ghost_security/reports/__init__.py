"""Ghost Security Platform — reports"""
