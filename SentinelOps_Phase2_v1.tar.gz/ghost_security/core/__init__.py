"""Ghost Security Platform — core"""
