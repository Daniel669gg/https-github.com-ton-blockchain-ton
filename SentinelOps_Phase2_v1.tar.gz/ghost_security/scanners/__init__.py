"""Ghost Security Platform — scanners"""
