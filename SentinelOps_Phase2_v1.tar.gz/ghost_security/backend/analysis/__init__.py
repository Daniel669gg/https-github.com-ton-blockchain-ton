"""Ghost Security — analysis modules."""
