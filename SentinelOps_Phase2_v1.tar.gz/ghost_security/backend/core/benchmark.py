"""
backend/core/benchmark.py — BenchmarkRunner
Computes precision, recall, FP, FN for scanner output vs ground truth.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from pydantic import BaseModel, Field

from backend.core.confidence import Finding

logger = logging.getLogger("ghost.benchmark")


# ─────────────────────────────────────────────────────────────────────────────
# Ground-truth item
# ─────────────────────────────────────────────────────────────────────────────

class GroundTruthItem(BaseModel):
    rule_id: str
    file: str
    line: int = 0
    severity: str = "MEDIUM"
    description: str = ""

    def match_key(self) -> Tuple[str, str, int]:
        return (self.rule_id, self.file, self.line)


# ─────────────────────────────────────────────────────────────────────────────
# Benchmark report
# ─────────────────────────────────────────────────────────────────────────────

class BenchmarkReport(BaseModel):
    precision: float = Field(ge=0.0, le=1.0)
    recall: float = Field(ge=0.0, le=1.0)
    f1: float = Field(ge=0.0, le=1.0)
    true_positives: int
    false_positives: int
    false_negatives: int
    total_ground_truth: int
    total_predicted: int
    passed: bool
    precision_threshold: float
    recall_threshold: float
    scanner_name: str = ""
    module_name: str = ""
    duration_s: float = 0.0
    details: Dict[str, Any] = Field(default_factory=dict)

    def summary(self) -> str:
        status = "PASS" if self.passed else "FAIL"
        return (
            f"[{status}] {self.module_name or self.scanner_name} | "
            f"Precision={self.precision:.3f} (≥{self.precision_threshold:.2f}) | "
            f"Recall={self.recall:.3f} (≥{self.recall_threshold:.2f}) | "
            f"TP={self.true_positives} FP={self.false_positives} FN={self.false_negatives} | "
            f"F1={self.f1:.3f}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Match logic
# ─────────────────────────────────────────────────────────────────────────────

def _finding_key(f: Finding, line_tolerance: int = 2) -> Tuple[str, str, int]:
    """Normalise key for matching. Line is rounded to tolerance bucket."""
    bucketed_line = (f.line // max(line_tolerance, 1)) * max(line_tolerance, 1)
    return (f.rule_id, f.file, bucketed_line)


def _gt_key(gt: GroundTruthItem, line_tolerance: int = 2) -> Tuple[str, str, int]:
    bucketed = (gt.line // max(line_tolerance, 1)) * max(line_tolerance, 1)
    return (gt.rule_id, gt.file, bucketed)


# ─────────────────────────────────────────────────────────────────────────────
# Runner
# ─────────────────────────────────────────────────────────────────────────────

class BenchmarkRunner:
    """
    Evaluates scanner precision / recall / F1 against a ground-truth corpus.

    Usage::

        runner = BenchmarkRunner(precision_threshold=0.85, recall_threshold=0.80)
        report = runner.evaluate(
            predicted=findings_list,
            ground_truth=gt_list,
            module_name="taint_analyzer",
        )
        print(report.summary())
    """

    def __init__(
        self,
        precision_threshold: float = 0.85,
        recall_threshold: float = 0.80,
        line_tolerance: int = 2,
    ) -> None:
        self.precision_threshold = precision_threshold
        self.recall_threshold = recall_threshold
        self.line_tolerance = line_tolerance

    # ── Public API ─────────────────────────────────────────────────────────────

    def evaluate(
        self,
        predicted: Sequence[Finding],
        ground_truth: Sequence[GroundTruthItem],
        module_name: str = "",
        scanner_name: str = "",
    ) -> BenchmarkReport:
        t0 = time.time()

        gt_keys = {_gt_key(g, self.line_tolerance) for g in ground_truth}
        pred_keys = [_finding_key(f, self.line_tolerance) for f in predicted]

        tp = sum(1 for k in pred_keys if k in gt_keys)
        fp = sum(1 for k in pred_keys if k not in gt_keys)
        fn = len(gt_keys) - tp

        precision = tp / (tp + fp) if (tp + fp) > 0 else 1.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 1.0
        f1 = (2 * precision * recall / (precision + recall)
               if (precision + recall) > 0 else 0.0)

        passed = (
            precision >= self.precision_threshold
            and recall >= self.recall_threshold
        )

        # Identify which GT items were missed
        matched_pred_keys = {k for k in pred_keys if k in gt_keys}
        missed_gt = [
            g for g in ground_truth
            if _gt_key(g, self.line_tolerance) not in matched_pred_keys
        ]
        extra_preds = [
            f for f, k in zip(predicted, pred_keys)
            if k not in gt_keys
        ]

        report = BenchmarkReport(
            precision=round(precision, 4),
            recall=round(recall, 4),
            f1=round(f1, 4),
            true_positives=tp,
            false_positives=fp,
            false_negatives=fn,
            total_ground_truth=len(ground_truth),
            total_predicted=len(predicted),
            passed=passed,
            precision_threshold=self.precision_threshold,
            recall_threshold=self.recall_threshold,
            scanner_name=scanner_name,
            module_name=module_name,
            duration_s=round(time.time() - t0, 4),
            details={
                "missed_findings": [
                    {"rule_id": g.rule_id, "file": g.file, "line": g.line}
                    for g in missed_gt
                ],
                "false_positive_findings": [
                    {"rule_id": f.rule_id, "file": f.file, "line": f.line}
                    for f in extra_preds
                ],
            },
        )

        if passed:
            logger.info(report.summary())
        else:
            logger.warning(report.summary())

        return report

    def run_suite(
        self,
        cases: List[Dict[str, Any]],
    ) -> Dict[str, BenchmarkReport]:
        """
        Run multiple benchmark cases.

        Each case dict::
            {
                "name": str,
                "predicted": List[Finding],
                "ground_truth": List[GroundTruthItem],
            }
        """
        results: Dict[str, BenchmarkReport] = {}
        for case in cases:
            name = case["name"]
            report = self.evaluate(
                predicted=case["predicted"],
                ground_truth=case["ground_truth"],
                module_name=name,
            )
            results[name] = report
        return results

    # ── Helpers ────────────────────────────────────────────────────────────────

    @staticmethod
    def from_raw_dicts(
        raw_findings: List[Dict[str, Any]],
        raw_gt: List[Dict[str, Any]],
    ) -> Tuple[List[Finding], List[GroundTruthItem]]:
        """Convert raw dicts to typed objects."""
        findings = []
        for d in raw_findings:
            try:
                findings.append(Finding(**d))
            except Exception:
                pass
        gt_items = []
        for d in raw_gt:
            try:
                gt_items.append(GroundTruthItem(**d))
            except Exception:
                pass
        return findings, gt_items
