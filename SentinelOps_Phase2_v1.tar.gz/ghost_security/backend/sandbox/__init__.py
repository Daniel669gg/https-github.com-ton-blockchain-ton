"""Ghost Security — sandbox analysis modules."""
