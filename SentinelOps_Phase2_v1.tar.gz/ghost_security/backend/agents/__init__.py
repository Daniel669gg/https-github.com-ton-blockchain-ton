"""Ghost Security — agent modules."""
