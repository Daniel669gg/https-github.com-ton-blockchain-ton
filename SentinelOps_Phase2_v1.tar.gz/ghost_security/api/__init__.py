"""Ghost Security Platform — api"""
