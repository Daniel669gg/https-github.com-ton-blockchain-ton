"""Ghost Security Platform — config"""
