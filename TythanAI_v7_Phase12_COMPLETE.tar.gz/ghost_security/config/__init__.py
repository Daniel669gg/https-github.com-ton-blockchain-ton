"""TythanAI Platform — config"""
