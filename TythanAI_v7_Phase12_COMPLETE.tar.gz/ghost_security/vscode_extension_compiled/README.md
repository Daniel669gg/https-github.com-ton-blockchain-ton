# TythanAI — VS Code Extension

Real-time AI security scanning for TON/Web3 and all major languages.

## Features
- 🔍 Scan on save — instant security feedback
- 🔴 Inline diagnostics for CRITICAL/HIGH findings  
- 💰 TON Bug Bounty self-check
- 📊 Findings panel with severity grouping
- 🌍 Python, JS/TS, Go, Java, PHP, Ruby, Rust, Solidity, FunC/Tact

## Setup
1. Install extension
2. Open Settings → TythanAI
3. Set `ghost.serverUrl` to your TythanAI Platform instance
4. Enable `ghost.scanOnSave` (default: on)

## Commands
- `Ghost: Scan Current File`
- `Ghost: Scan Workspace` 
- `Ghost: TON Bug Bounty Self-Check`

## Requirements
TythanAI Platform running locally or remotely.
Quick start: `pip install tythanai && ghost serve`

## Links
- [TythanAI Platform](https://tythanai.io)
- [Documentation](https://docs.tythanai.io)
- [Bug Bounty Guide](https://github.com/tythanai/platform)
