"""TythanAI Platform — scanners"""
