"""
Ownership and Access Control Checker for TON smart contracts.

Detects TON-specific ownership attack patterns:
- Missing init() protection
- Single-step ownership transfer without confirmation
- Admin functions missing msg_sender verification
- External message handlers missing signature checks
- DAO governance without timelock
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List


@dataclass
class OwnershipFinding:
    finding_type: str        # "MISSING_INIT_PROTECTION", "SINGLE_STEP_TRANSFER",
                              # "MISSING_AUTH", "MISSING_SIG_CHECK", "DAO_NO_TIMELOCK"
    severity: str            # "CRITICAL", "HIGH", "MEDIUM"
    description: str
    line: int
    evidence: str            # line of code that triggered this finding
    recommendation: str
    cwe_id: str              # CWE-284, CWE-285, CWE-287, CWE-362 etc.


class OwnershipChecker:
    """Checks FunC and Tact contracts for ownership/access control issues."""

    def check(self, source: str, language: str = "func") -> List[OwnershipFinding]:
        """Run all ownership/access-control sub-checks and return combined findings."""
        lines = source.splitlines()
        findings: List[OwnershipFinding] = []
        findings.extend(self._check_init_protection(source, lines))
        findings.extend(self._check_ownership_transfer(source, lines))
        findings.extend(self._check_admin_auth(source, lines, language))
        findings.extend(self._check_signature_checks(source, lines, language))
        findings.extend(self._check_dao_timelock(source, lines))
        return findings

    # ------------------------------------------------------------------ sub-checks

    def _check_init_protection(
        self, source: str, lines: List[str]
    ) -> List[OwnershipFinding]:
        """
        Detect missing initialization guard.

        FunC: handler for op::init or op==0 that writes state without
              first calling throw_unless(already_inited, ...).
        Tact: init() function that writes self.* without checking deployment state.
        """
        result: List[OwnershipFinding] = []

        # FunC: look for op::init or op == 0 handling blocks
        _init_op_re = re.compile(
            r"op\s*==\s*op::init|op\s*==\s*0\b", re.IGNORECASE
        )
        _throw_guard_re = re.compile(
            r"throw_unless\s*\(\s*\w*[Ii]nit\w*|throw_if\s*\(\s*\w*[Ii]nit\w*",
            re.IGNORECASE,
        )
        _store_re = re.compile(r"store_|save_data\s*\(", re.IGNORECASE)

        in_init_block = False
        brace_depth = 0
        init_line_no = 0
        has_guard = False
        has_store = False
        evidence_line = ""

        for i, line in enumerate(lines, start=1):
            if _init_op_re.search(line):
                in_init_block = True
                brace_depth = 0
                init_line_no = i
                has_guard = False
                has_store = False
                evidence_line = line.strip()

            if in_init_block:
                brace_depth += line.count("{") - line.count("}")
                if _throw_guard_re.search(line):
                    has_guard = True
                if _store_re.search(line):
                    has_store = True
                # end of block
                if brace_depth < 0 or (brace_depth == 0 and i > init_line_no):
                    if has_store and not has_guard:
                        result.append(
                            OwnershipFinding(
                                finding_type="MISSING_INIT_PROTECTION",
                                severity="CRITICAL",
                                description=(
                                    "Contract initialisation handler writes state without "
                                    "checking whether the contract is already initialised. "
                                    "An attacker can re-initialise the contract and hijack ownership."
                                ),
                                line=init_line_no,
                                evidence=evidence_line,
                                recommendation=(
                                    "Add `throw_unless(error::already_initialized, storage::initialized == 0);` "
                                    "at the top of the init handler before any state writes."
                                ),
                                cwe_id="CWE-665",
                            )
                        )
                    in_init_block = False

        # Tact: init() writing self.* without deployment guard
        _tact_init_re = re.compile(r"\binit\s*\(", re.IGNORECASE)
        _tact_self_write_re = re.compile(r"\bself\.\w+\s*=", re.IGNORECASE)
        _tact_deploy_check_re = re.compile(
            r"contractAddress\s*\(|deployed\s*\(|self\.initialized", re.IGNORECASE
        )

        in_tact_init = False
        tact_brace = 0
        tact_line_no = 0
        tact_evidence = ""
        tact_has_write = False
        tact_has_check = False

        for i, line in enumerate(lines, start=1):
            if _tact_init_re.search(line) and not in_tact_init:
                in_tact_init = True
                tact_brace = 0
                tact_line_no = i
                tact_evidence = line.strip()
                tact_has_write = False
                tact_has_check = False

            if in_tact_init:
                tact_brace += line.count("{") - line.count("}")
                if _tact_self_write_re.search(line):
                    tact_has_write = True
                if _tact_deploy_check_re.search(line):
                    tact_has_check = True
                if tact_brace < 0 or (tact_brace == 0 and i > tact_line_no):
                    if tact_has_write and not tact_has_check:
                        result.append(
                            OwnershipFinding(
                                finding_type="MISSING_INIT_PROTECTION",
                                severity="CRITICAL",
                                description=(
                                    "Tact init() function writes contract state without verifying "
                                    "that the contract has not already been deployed. "
                                    "This allows re-initialization attacks."
                                ),
                                line=tact_line_no,
                                evidence=tact_evidence,
                                recommendation=(
                                    "Check self.initialized or use require(!self.initialized, ...) "
                                    "before writing state in init()."
                                ),
                                cwe_id="CWE-665",
                            )
                        )
                    in_tact_init = False

        return result

    def _check_ownership_transfer(
        self, source: str, lines: List[str]
    ) -> List[OwnershipFinding]:
        """
        Detect single-step ownership transfer.

        FunC: store_slice(new_owner) or save_data(new_owner, ...) without
              a pending_owner / proposed_owner two-phase pattern nearby.
        """
        result: List[OwnershipFinding] = []

        # Positive signal: writes 'owner' to storage
        _owner_write_re = re.compile(
            r"(store_slice|save_data)\s*\([^)]*owner", re.IGNORECASE
        )
        # Negative signal: pending / proposed pattern (two-phase commit)
        _pending_re = re.compile(r"pending_owner|proposed_owner", re.IGNORECASE)

        has_pending = bool(_pending_re.search(source))

        for i, line in enumerate(lines, start=1):
            if _owner_write_re.search(line):
                if not has_pending:
                    result.append(
                        OwnershipFinding(
                            finding_type="SINGLE_STEP_TRANSFER",
                            severity="HIGH",
                            description=(
                                "Ownership is transferred in a single step without a "
                                "two-phase commit (pending_owner confirmation). "
                                "A typo or phishing attack can permanently lock out the legitimate owner."
                            ),
                            line=i,
                            evidence=line.strip(),
                            recommendation=(
                                "Implement a two-step ownership transfer: set pending_owner in step 1, "
                                "and require pending_owner to call accept_ownership() in step 2."
                            ),
                            cwe_id="CWE-284",
                        )
                    )
                    break  # one report per contract is sufficient

        return result

    def _check_admin_auth(
        self, source: str, lines: List[str], language: str = "func"
    ) -> List[OwnershipFinding]:
        """
        Detect admin/privileged operations lacking authentication checks.

        FunC: op::admin_*, op::update_*, op::set_* without throw_unless shortly after.
        Tact: fun methods writing self.* without require(sender() == self.owner, ...).
        """
        result: List[OwnershipFinding] = []

        if language == "func":
            _admin_op_re = re.compile(
                r"op\s*==\s*op::(admin|update|set|upgrade|change|modify)_\w+",
                re.IGNORECASE,
            )
            _throw_auth_re = re.compile(
                r"throw_unless\s*\(|throw_if\s*\(", re.IGNORECASE
            )

            for i, line in enumerate(lines, start=1):
                if _admin_op_re.search(line):
                    # Check within the next 10 lines for an auth check
                    window = lines[i : min(i + 10, len(lines))]
                    has_auth = any(_throw_auth_re.search(wl) for wl in window)
                    if not has_auth:
                        result.append(
                            OwnershipFinding(
                                finding_type="MISSING_AUTH",
                                severity="CRITICAL",
                                description=(
                                    "Admin/privileged operation handler does not perform "
                                    "sender authentication (throw_unless) within the first 10 lines. "
                                    "Any caller can invoke privileged operations."
                                ),
                                line=i,
                                evidence=line.strip(),
                                recommendation=(
                                    "Add `throw_unless(error::unauthorized, equal_slices(sender, owner));` "
                                    "as the first statement inside the privileged op handler."
                                ),
                                cwe_id="CWE-285",
                            )
                        )
        else:
            # Tact
            _tact_fun_re = re.compile(r"\bfun\s+\w+\s*\(", re.IGNORECASE)
            _tact_self_write_re = re.compile(r"\bself\.\w+\s*=", re.IGNORECASE)
            _tact_require_owner_re = re.compile(
                r"require\s*\(\s*sender\s*\(\s*\)\s*==\s*self\.\w*owner",
                re.IGNORECASE,
            )

            in_fun = False
            fun_brace = 0
            fun_line_no = 0
            fun_evidence = ""
            fun_has_write = False
            fun_has_auth = False

            for i, line in enumerate(lines, start=1):
                if _tact_fun_re.search(line) and not in_fun:
                    in_fun = True
                    fun_brace = 0
                    fun_line_no = i
                    fun_evidence = line.strip()
                    fun_has_write = False
                    fun_has_auth = False

                if in_fun:
                    fun_brace += line.count("{") - line.count("}")
                    if _tact_self_write_re.search(line):
                        fun_has_write = True
                    if _tact_require_owner_re.search(line):
                        fun_has_auth = True
                    if fun_brace < 0 or (fun_brace == 0 and i > fun_line_no):
                        if fun_has_write and not fun_has_auth:
                            result.append(
                                OwnershipFinding(
                                    finding_type="MISSING_AUTH",
                                    severity="CRITICAL",
                                    description=(
                                        "Tact function modifies contract state without verifying "
                                        "that the caller is the owner. Any sender can alter contract state."
                                    ),
                                    line=fun_line_no,
                                    evidence=fun_evidence,
                                    recommendation=(
                                        "Add `require(sender() == self.owner, \"Unauthorized\");` "
                                        "as the first statement in privileged functions."
                                    ),
                                    cwe_id="CWE-285",
                                )
                            )
                        in_fun = False

        return result

    def _check_signature_checks(
        self, source: str, lines: List[str], language: str = "func"
    ) -> List[OwnershipFinding]:
        """
        Detect external message handlers without signature verification.

        FunC: recv_external() function body missing check_signature( call.
        """
        result: List[OwnershipFinding] = []

        _recv_ext_re = re.compile(r"\brecv_external\s*\(", re.IGNORECASE)
        _check_sig_re = re.compile(r"check_signature\s*\(", re.IGNORECASE)

        in_recv = False
        recv_brace = 0
        recv_line_no = 0
        recv_evidence = ""
        has_check_sig = False

        for i, line in enumerate(lines, start=1):
            if _recv_ext_re.search(line) and not in_recv:
                in_recv = True
                recv_brace = 0
                recv_line_no = i
                recv_evidence = line.strip()
                has_check_sig = False

            if in_recv:
                recv_brace += line.count("{") - line.count("}")
                if _check_sig_re.search(line):
                    has_check_sig = True
                if recv_brace < 0 or (recv_brace == 0 and i > recv_line_no):
                    if not has_check_sig:
                        result.append(
                            OwnershipFinding(
                                finding_type="MISSING_SIG_CHECK",
                                severity="CRITICAL",
                                description=(
                                    "recv_external() handler does not call check_signature(). "
                                    "Any party can send external messages that the contract will process "
                                    "without verifying the sender's identity."
                                ),
                                line=recv_line_no,
                                evidence=recv_evidence,
                                recommendation=(
                                    "Call `check_signature(slice_hash(in_msg), signature, public_key)` "
                                    "at the start of recv_external() before any state changes."
                                ),
                                cwe_id="CWE-287",
                            )
                        )
                    in_recv = False

        return result

    def _check_dao_timelock(
        self, source: str, lines: List[str]
    ) -> List[OwnershipFinding]:
        """
        Detect DAO governance execution without timelock.

        Look for op::execute / op::apply / vote/proposal/execute patterns
        without a `now() - proposal_time > timelock_period` check nearby.
        """
        result: List[OwnershipFinding] = []

        _dao_op_re = re.compile(
            r"op\s*==\s*op::(execute|apply|finalize|enact)\b"
            r"|execute_proposal\s*\(|apply_vote\s*\(",
            re.IGNORECASE,
        )
        _timelock_re = re.compile(
            r"now\s*\(\s*\)\s*[-–]\s*\w*\s*>\s*\w*(timelock|delay|period|lock_time)",
            re.IGNORECASE,
        )

        # Also detect the combination of vote/proposal + execute keywords without timelock
        # Use broader patterns that match inside compound identifiers (e.g. load_proposal,
        # execute_proposal) as well as standalone words.
        _vote_re = re.compile(r"(vote|proposal|governance)", re.IGNORECASE)
        _execute_re = re.compile(r"(execute|apply|enact)", re.IGNORECASE)

        has_timelock = bool(_timelock_re.search(source))
        # Either a dedicated DAO op pattern, or vote + execute keywords co-occurring in source
        has_dao_ops = bool(_dao_op_re.search(source))
        has_dao_keywords = bool(_vote_re.search(source)) and bool(
            _execute_re.search(source)
        )

        if (has_dao_ops or has_dao_keywords) and not has_timelock:
            # Find the first execute-like line to attach the finding to
            for i, line in enumerate(lines, start=1):
                if _dao_op_re.search(line) or (
                    _vote_re.search(line) and _execute_re.search(line)
                ):
                    result.append(
                        OwnershipFinding(
                            finding_type="DAO_NO_TIMELOCK",
                            severity="MEDIUM",
                            description=(
                                "DAO governance contract executes proposals without a timelock delay. "
                                "This allows flash-loan governance attacks where an attacker borrows "
                                "voting tokens, passes a malicious proposal, and executes it "
                                "within a single transaction or very short window."
                            ),
                            line=i,
                            evidence=line.strip(),
                            recommendation=(
                                "Add a timelock: require `now() - proposal.created_at > TIMELOCK_PERIOD` "
                                "(e.g. 48-72 hours) before executing any governance proposal."
                            ),
                            cwe_id="CWE-362",
                        )
                    )
                    break

        return result
