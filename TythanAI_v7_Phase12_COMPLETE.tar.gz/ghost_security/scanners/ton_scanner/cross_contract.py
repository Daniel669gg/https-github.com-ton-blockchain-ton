"""
Cross-Contract Analyzer for TON smart contracts.

TON contracts interact via messages. This analyzer tracks:
- Message flows between contracts (who calls whom)
- Trust relationships (which contracts accept messages from which senders)
- Attack paths: attacker → contract_A → contract_B → funds
- Reentrancy via multi-contract message cycles
- Jetton (token) flows and potential abuse
- Governance attack paths (vote manipulation → treasury drain)

Analyzes multiple contract files together to find cross-contract vulnerabilities
that single-contract analysis cannot detect.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class OutgoingCall:
    """An outgoing message from one contract to another."""
    from_contract: str
    from_handler: str
    to_address: str                     # "owner", "jetton_master", symbolic address
    op_code: str
    value_sent: str                     # "msg_value", "0", "all_balance", symbolic
    line: int
    can_be_triggered_by_attacker: bool  # can external user trigger this call chain?


@dataclass
class ContractInterface:
    """Extracted interface of a single contract."""
    name: str
    file: str
    language: str                       # "func", "tact", "tlb"
    receive_handlers: List[str]         # op-codes or message types handled
    outgoing_calls: List[OutgoingCall]
    storage_vars: List[str]
    auth_requirements: Dict[str, str]   # handler → required_sender pattern
    source: str = ""                    # original source code (cached to avoid re-reading)
    is_wallet: bool = False
    is_jetton_master: bool = False
    is_jetton_wallet: bool = False
    is_dao: bool = False
    is_proxy: bool = False


@dataclass
class CrossContractPath:
    """A discovered cross-contract vulnerability path."""
    path: List[str]                     # contract names in order
    messages: List[OutgoingCall]
    risk: str                           # "HIGH", "MEDIUM", "LOW"
    attack_description: str
    finding_type: str                   # "REENTRANCY", "FUND_DRAIN", "OWNERSHIP_TAKEOVER", etc.


@dataclass
class CrossContractResult:
    """Aggregated result from cross-contract analysis."""
    contracts_analyzed: int
    call_graph_edges: int
    reentrancy_paths: List[CrossContractPath] = field(default_factory=list)
    fund_drain_paths: List[CrossContractPath] = field(default_factory=list)
    ownership_takeover_paths: List[CrossContractPath] = field(default_factory=list)
    jetton_abuse_paths: List[CrossContractPath] = field(default_factory=list)
    governance_attack_paths: List[CrossContractPath] = field(default_factory=list)
    all_findings: List[Dict] = field(default_factory=list)
    risk_summary: str = ""


# ---------------------------------------------------------------------------
# Pattern constants
# ---------------------------------------------------------------------------

_SUPPORTED_EXT = {".fc", ".func", ".tact"}

# FunC op-code extraction
_FUNC_OP_RE = re.compile(r"op\s*==\s*(0x[0-9a-fA-F]+|\d+)")
# Tact receive message type
_TACT_MSG_TYPE_RE = re.compile(r"receive\s*\(\s*(?:msg\s*:\s*)?(\w+)")

# Send patterns
_SEND_RAW_RE = re.compile(r"send_raw_message\s*\([^,]+,\s*(\d+)\s*\)")
_TACT_SEND_RE = re.compile(
    r"send\s*\(\s*SendParameters\s*\{([^}]+)\}",
    re.DOTALL,
)
_TACT_REPLY_RE = re.compile(r"self\.reply\s*\(|reply\s*\(")

# Value / mode extraction
_MODE_128_RE = re.compile(r"send_raw_message\s*\([^,]+,\s*128")
_MODE_64_RE = re.compile(r"send_raw_message\s*\([^,]+,\s*64")
_ALL_BALANCE_RE = re.compile(r"all_balance|mode\s*:\s*128|SendRemainingBalance")

# Auth patterns
_AUTH_RE = re.compile(
    r"throw_unless\s*\(\s*4\d\d|equal_slices\s*\(|sender\s*\(\s*\)\s*=="
    r"|check_signature\s*\(|require\s*\(\s*sender\s*\(\s*\)|require\s*\(\s*self\.owner"
)

# Contract type fingerprints
_WALLET_FINGERPRINT_RE = re.compile(
    r"seqno|check_signature.*recv_external|recv_external.*check_signature"
    r"|wallet_id|subwallet_id", re.IGNORECASE
)
_JETTON_MASTER_RE = re.compile(
    r"op::mint|op::burn_notification|jetton_wallet_code|total_supply"
    r"|mint_tokens|jetton_content", re.IGNORECASE
)
_JETTON_WALLET_RE = re.compile(
    r"op::transfer|op::internal_transfer|op::burn|jetton_master"
    r"|op::transfer_notification|jetton_amount", re.IGNORECASE
)
_DAO_RE = re.compile(
    r"vote|proposal|quorum|governance|treasury|dao|nft_collection"
    r"|voting_power|execute_proposal", re.IGNORECASE
)
_PROXY_RE = re.compile(r"forward|delegate|proxy|pass_message|forward_message", re.IGNORECASE)

# Storage write
_STORE_RE = re.compile(r"set_data\s*\(|\.store_(?:uint|int|slice|ref|coins)\s*\(|self\.\w+\s*=\s*")

# To-address extraction from send_raw_message
_TO_ADDR_RE = re.compile(
    r"to\s*=\s*(\w[\w.]*)|send_raw_message\s*\(begin_cell\s*\(\s*\)\s*"
    r"|send_raw_message\s*\(\s*(\w+)"
)


# ---------------------------------------------------------------------------
# CrossContractAnalyzer
# ---------------------------------------------------------------------------

class CrossContractAnalyzer:
    """
    Analyzes multiple TON contracts together to find cross-contract
    vulnerabilities invisible to single-contract analysis.
    """

    def __init__(self) -> None:
        self._interfaces: List[ContractInterface] = []

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze_directory(self, path: str) -> CrossContractResult:
        """
        Recursively discover all FunC/Tact files under `path`,
        parse them, and run cross-contract analysis.
        """
        contracts: List[Tuple[str, str]] = []
        for root, _dirs, files in os.walk(path):
            for fname in files:
                fpath = os.path.join(root, fname)
                if Path(fpath).suffix.lower() in _SUPPORTED_EXT:
                    try:
                        source = Path(fpath).read_text(encoding="utf-8", errors="replace")
                        contracts.append((source, fpath))
                    except OSError:
                        pass
        return self.analyze_contracts(contracts)

    def analyze_contracts(
        self, contracts: List[Tuple[str, str]]
    ) -> CrossContractResult:
        """
        contracts: list of (source_code, filename).
        Parse all, build call graph, detect cross-contract vulnerabilities.
        """
        interfaces: List[ContractInterface] = []
        for source, filename in contracts:
            iface = self._build_interface(source, filename)
            interfaces.append(iface)
        self._interfaces = interfaces

        call_graph = self._build_call_graph(interfaces)
        edge_count = sum(len(v) for v in call_graph.values())

        reentrancy = self._find_reentrancy_cycles(call_graph)
        fund_drain = self._find_fund_drain_paths(interfaces, call_graph)
        ownership  = self._find_ownership_takeover(interfaces)
        jetton     = self._find_jetton_abuse(interfaces, call_graph)
        governance = self._find_governance_attacks(interfaces, call_graph)

        all_paths = reentrancy + fund_drain + ownership + jetton + governance
        all_findings = [self._path_to_finding(p) for p in all_paths]

        risk_summary = self._compute_risk_summary(all_paths, interfaces)

        return CrossContractResult(
            contracts_analyzed=len(interfaces),
            call_graph_edges=edge_count,
            reentrancy_paths=reentrancy,
            fund_drain_paths=fund_drain,
            ownership_takeover_paths=ownership,
            jetton_abuse_paths=jetton,
            governance_attack_paths=governance,
            all_findings=all_findings,
            risk_summary=risk_summary,
        )

    # ------------------------------------------------------------------
    # Interface builder
    # ------------------------------------------------------------------

    def _build_interface(self, source: str, filename: str) -> ContractInterface:
        """Extract contract interface from source text."""
        lang = "tact" if filename.endswith(".tact") else "func"
        name = Path(filename).stem

        receive_handlers: List[str] = []
        outgoing_calls: List[OutgoingCall] = []
        storage_vars: List[str] = []
        auth_requirements: Dict[str, str] = {}

        if lang == "func":
            # Op codes handled
            for m in _FUNC_OP_RE.finditer(source):
                receive_handlers.append(m.group(1))

            # Storage variables
            global_re = re.compile(r"^\s*global\s+(?:\w+\s+)?(\w+)\s*;", re.MULTILINE)
            storage_vars = global_re.findall(source)

            # Outgoing calls
            outgoing_calls = self._extract_func_outgoing_calls(source, name)

            # Auth requirements (map handler op-code → auth pattern)
            for m in _FUNC_OP_RE.finditer(source):
                op = m.group(1)
                # Look within 300 chars after op== for an auth check
                after = source[m.start(): m.start() + 300]
                if _AUTH_RE.search(after):
                    auth_requirements[op] = "throw_unless/equal_slices"
                else:
                    auth_requirements[op] = "NONE"

        else:  # tact
            # Message types handled
            for m in _TACT_MSG_TYPE_RE.finditer(source):
                receive_handlers.append(m.group(1))

            # Contract fields
            field_re = re.compile(r"^\s+(\w+)\s*:\s*\w+", re.MULTILINE)
            storage_vars = field_re.findall(source)

            outgoing_calls = self._extract_tact_outgoing_calls(source, name)

            # Auth requirements
            for m in _TACT_MSG_TYPE_RE.finditer(source):
                msg_type = m.group(1)
                block_start = m.end()
                brace = source.find("{", block_start)
                if brace == -1:
                    continue
                depth, idx = 1, brace + 1
                while idx < len(source) and depth > 0:
                    if source[idx] == "{":
                        depth += 1
                    elif source[idx] == "}":
                        depth -= 1
                    idx += 1
                block_body = source[brace:idx]
                if _AUTH_RE.search(block_body):
                    auth_requirements[msg_type] = "require(sender==owner)"
                else:
                    auth_requirements[msg_type] = "NONE"

        return ContractInterface(
            name=name,
            file=filename,
            language=lang,
            receive_handlers=receive_handlers,
            outgoing_calls=outgoing_calls,
            storage_vars=storage_vars,
            auth_requirements=auth_requirements,
            source=source,
            is_wallet=bool(_WALLET_FINGERPRINT_RE.search(source)),
            is_jetton_master=bool(_JETTON_MASTER_RE.search(source)),
            is_jetton_wallet=bool(_JETTON_WALLET_RE.search(source)),
            is_dao=bool(_DAO_RE.search(source)),
            is_proxy=bool(_PROXY_RE.search(source)),
        )

    def _extract_func_outgoing_calls(
        self, source: str, contract_name: str
    ) -> List[OutgoingCall]:
        """Extract outgoing message calls from FunC source."""
        calls: List[OutgoingCall] = []
        lines = source.splitlines()

        for m in _SEND_RAW_RE.finditer(source):
            lineno = source[:m.start()].count("\n") + 1
            mode = m.group(1)
            value_sent = "all_balance" if mode == "128" else ("msg_value" if mode == "64" else "fixed")

            # Best-effort to extract target address from surrounding context
            before = source[max(0, m.start() - 200): m.start()]
            to_addr = "unknown"
            addr_hint = re.search(r"(owner|jetton_master|admin|treasury|destination)\s*[,;)]", before)
            if addr_hint:
                to_addr = addr_hint.group(1)

            # Determine which handler we're in
            handler = self._find_enclosing_handler(source, m.start())

            # Can attacker trigger this? — If no auth in handler, yes
            auth_before = source[max(0, m.start() - 400): m.start()]
            can_trigger = not bool(_AUTH_RE.search(auth_before))

            calls.append(OutgoingCall(
                from_contract=contract_name,
                from_handler=handler,
                to_address=to_addr,
                op_code="unknown",
                value_sent=value_sent,
                line=lineno,
                can_be_triggered_by_attacker=can_trigger,
            ))
        return calls

    def _extract_tact_outgoing_calls(
        self, source: str, contract_name: str
    ) -> List[OutgoingCall]:
        """Extract outgoing message calls from Tact source."""
        calls: List[OutgoingCall] = []

        # send(SendParameters{...})
        for m in _TACT_SEND_RE.finditer(source):
            lineno = source[:m.start()].count("\n") + 1
            body = m.group(1)
            # Extract 'to' field
            to_m = re.search(r"to\s*:\s*(\w[\w.]*)", body)
            to_addr = to_m.group(1) if to_m else "unknown"
            # Extract value
            val_m = re.search(r"value\s*:\s*(\w+)", body)
            value_sent = val_m.group(1) if val_m else "unknown"
            if _ALL_BALANCE_RE.search(body):
                value_sent = "all_balance"

            handler = self._find_enclosing_handler(source, m.start())
            auth_before = source[max(0, m.start() - 400): m.start()]
            can_trigger = not bool(_AUTH_RE.search(auth_before))

            calls.append(OutgoingCall(
                from_contract=contract_name,
                from_handler=handler,
                to_address=to_addr,
                op_code="unknown",
                value_sent=value_sent,
                line=lineno,
                can_be_triggered_by_attacker=can_trigger,
            ))

        # self.reply(...)
        for m in _TACT_REPLY_RE.finditer(source):
            lineno = source[:m.start()].count("\n") + 1
            handler = self._find_enclosing_handler(source, m.start())
            auth_before = source[max(0, m.start() - 300): m.start()]
            can_trigger = not bool(_AUTH_RE.search(auth_before))
            calls.append(OutgoingCall(
                from_contract=contract_name,
                from_handler=handler,
                to_address="msg_sender",
                op_code="reply",
                value_sent="msg_value",
                line=lineno,
                can_be_triggered_by_attacker=can_trigger,
            ))
        return calls

    def _find_enclosing_handler(self, source: str, pos: int) -> str:
        """Find the name of the function enclosing `pos` in source."""
        # Walk backwards to find the function definition
        prefix = source[:pos]
        handler_re = re.compile(
            r"(?:recv_internal|recv_external|fun\s+\w+|receive\s*\(|init\s*\()"
        )
        matches = list(handler_re.finditer(prefix))
        if matches:
            last = matches[-1]
            return last.group(0).strip().split("(")[0].strip()
        return "unknown"

    # ------------------------------------------------------------------
    # Call graph
    # ------------------------------------------------------------------

    def _build_call_graph(
        self, interfaces: List[ContractInterface]
    ) -> Dict[str, List[str]]:
        """
        Build a directed call graph: contract_name → [list of contract names it calls].
        Connections are inferred from outgoing call addresses matching contract names.
        """
        graph: Dict[str, List[str]] = {iface.name: [] for iface in interfaces}
        name_set = {iface.name for iface in interfaces}

        for iface in interfaces:
            for call in iface.outgoing_calls:
                # Direct name match
                if call.to_address in name_set and call.to_address != iface.name:
                    if call.to_address not in graph[iface.name]:
                        graph[iface.name].append(call.to_address)
                # Fuzzy match: to_address contains a contract name as substring
                for other in name_set:
                    if other != iface.name and other.lower() in call.to_address.lower():
                        if other not in graph[iface.name]:
                            graph[iface.name].append(other)

        return graph

    # ------------------------------------------------------------------
    # Vulnerability finders
    # ------------------------------------------------------------------

    def _find_reentrancy_cycles(
        self, call_graph: Dict[str, List[str]]
    ) -> List[CrossContractPath]:
        """
        Detect cycles in the message call graph.
        A cycle means: A → B → ... → A — a classic reentrancy pattern in TON.
        """
        findings: List[CrossContractPath] = []
        visited: set = set()

        def dfs(node: str, path: List[str], path_set: set) -> None:
            if node in path_set:
                # Cycle detected
                cycle_start = path.index(node)
                cycle = path[cycle_start:] + [node]
                # Only report cycles where at least one hop can be triggered by attacker
                if len(cycle) >= 2:
                    findings.append(CrossContractPath(
                        path=cycle,
                        messages=self._get_messages_for_path(cycle),
                        risk="HIGH",
                        attack_description=(
                            f"Reentrancy cycle detected: {' → '.join(cycle)}. "
                            "Messages form a cycle; if state is not committed before "
                            "sending, an attacker can exploit this to re-enter state-changing handlers."
                        ),
                        finding_type="REENTRANCY",
                    ))
                return
            if node in visited:
                return
            path_set.add(node)
            path.append(node)
            for neighbor in call_graph.get(node, []):
                dfs(neighbor, path, path_set)
            path.pop()
            path_set.remove(node)
            visited.add(node)

        for start in list(call_graph.keys()):
            dfs(start, [], set())

        # Deduplicate (same cycle different start)
        seen_cycles: set = set()
        unique: List[CrossContractPath] = []
        for fp in findings:
            key = frozenset(fp.path)
            if key not in seen_cycles:
                seen_cycles.add(key)
                unique.append(fp)
        return unique

    def _find_fund_drain_paths(
        self,
        interfaces: List[ContractInterface],
        call_graph: Dict[str, List[str]],
    ) -> List[CrossContractPath]:
        """
        Find paths where an attacker can trigger transfer of all_balance or a large value.
        Criteria:
          - Outgoing call sends 'all_balance' or mode 128
          - That call can be triggered by an attacker (no auth guard)
        """
        findings: List[CrossContractPath] = []
        for iface in interfaces:
            for call in iface.outgoing_calls:
                is_drain = (
                    call.value_sent in ("all_balance", "128")
                    or "all_balance" in call.value_sent
                )
                if is_drain and call.can_be_triggered_by_attacker:
                    findings.append(CrossContractPath(
                        path=[iface.name, call.to_address],
                        messages=[call],
                        risk="CRITICAL",
                        attack_description=(
                            f"Fund drain path: attacker calls {iface.name}.{call.from_handler} "
                            f"(no auth) → sends all_balance to '{call.to_address}' "
                            f"(line {call.line}). Full contract balance can be drained."
                        ),
                        finding_type="FUND_DRAIN",
                    ))
        return findings

    def _find_ownership_takeover(
        self, interfaces: List[ContractInterface]
    ) -> List[CrossContractPath]:
        """
        Find patterns where ownership can be changed without authorization.
        Looks for storage writes to 'owner'/'admin'/'deployer' fields with no auth.
        """
        findings: List[CrossContractPath] = []
        ownership_fields = re.compile(
            r"owner|admin|deployer|governance|manager", re.IGNORECASE
        )

        for iface in interfaces:
            # Use cached source from interface; fall back to reading file if available
            source = iface.source or ""
            if not source:
                try:
                    source = Path(iface.file).read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue

            # Find writes to ownership fields
            if iface.language == "func":
                write_re = re.compile(
                    r"\.store_slice\s*\(\s*(new_owner|owner|admin|new_admin)\s*\)"
                    r"|pack.*owner|save_data\s*\(",
                )
            else:
                write_re = re.compile(
                    r"self\s*\.\s*(owner|admin|manager)\s*=\s*"
                )

            lines = source.splitlines()
            for i, line in enumerate(lines, start=1):
                if not write_re.search(line):
                    continue
                # Check for auth in preceding 40 lines
                start_ln = max(0, i - 40)
                window = "\n".join(lines[start_ln: i])
                if not _AUTH_RE.search(window):
                    # Only report if target field sounds like ownership
                    m2 = write_re.search(line)
                    field_name = m2.group(1) if m2 and m2.lastindex else "owner"
                    if ownership_fields.search(field_name):
                        findings.append(CrossContractPath(
                            path=[iface.name],
                            messages=[],
                            risk="CRITICAL",
                            attack_description=(
                                f"Ownership takeover: {iface.name} writes to '{field_name}' "
                                f"at line {i} without prior authorization check. "
                                "Any caller can become the new owner."
                            ),
                            finding_type="OWNERSHIP_TAKEOVER",
                        ))
        return findings

    def _find_jetton_abuse(
        self,
        interfaces: List[ContractInterface],
        call_graph: Dict[str, List[str]],
    ) -> List[CrossContractPath]:
        """
        Detect Jetton master/wallet interaction vulnerabilities.
        - Jetton wallet accepts transfer without verifying sender is the real jetton master
        - Jetton master mints without auth
        """
        findings: List[CrossContractPath] = []

        for iface in interfaces:
            if not (iface.is_jetton_master or iface.is_jetton_wallet):
                continue

            source = iface.source or ""
            if not source:
                try:
                    source = Path(iface.file).read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue

            if iface.is_jetton_master:
                # Check: mint handler has no auth
                mint_re = re.compile(r"op\s*==\s*op::mint|op::mint\b", re.IGNORECASE)
                lines = source.splitlines()
                for i, line in enumerate(lines, start=1):
                    if mint_re.search(line):
                        window = "\n".join(lines[max(0, i - 5): i + 30])
                        if not _AUTH_RE.search(window):
                            findings.append(CrossContractPath(
                                path=[iface.name],
                                messages=[],
                                risk="CRITICAL",
                                attack_description=(
                                    f"Jetton master '{iface.name}' mint op at line {i} "
                                    "lacks authorization check — anyone can mint unlimited tokens."
                                ),
                                finding_type="JETTON_ABUSE",
                            ))

            if iface.is_jetton_wallet:
                # Check: internal_transfer doesn't verify sender is jetton master or sibling wallet
                transfer_re = re.compile(
                    r"op\s*==\s*op::internal_transfer|internal_transfer", re.IGNORECASE
                )
                sender_check_re = re.compile(
                    r"jetton_master|equal_slices.*master|master.*equal_slices", re.IGNORECASE
                )
                lines = source.splitlines()
                for i, line in enumerate(lines, start=1):
                    if transfer_re.search(line):
                        window = "\n".join(lines[max(0, i - 2): i + 40])
                        if not sender_check_re.search(window):
                            findings.append(CrossContractPath(
                                path=[iface.name],
                                messages=[],
                                risk="HIGH",
                                attack_description=(
                                    f"Jetton wallet '{iface.name}' internal_transfer handler "
                                    f"at line {i} does not verify sender is the jetton master "
                                    "or a sibling wallet — fake transfer_notification possible."
                                ),
                                finding_type="JETTON_ABUSE",
                            ))

        return findings

    def _find_governance_attacks(
        self,
        interfaces: List[ContractInterface],
        call_graph: Dict[str, List[str]],
    ) -> List[CrossContractPath]:
        """
        Detect DAO / governance attack paths:
        - Proposal execution without quorum check
        - Vote weight manipulation (voting with tokens not yet locked)
        - Treasury drain via proposal execution
        """
        findings: List[CrossContractPath] = []

        dao_interfaces = [i for i in interfaces if i.is_dao]
        if not dao_interfaces:
            return findings

        for iface in dao_interfaces:
            source = iface.source or ""
            if not source:
                try:
                    source = Path(iface.file).read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
            lines = source.splitlines()

            # Pattern 1: execute_proposal without quorum/threshold check
            exec_re = re.compile(r"execute_proposal|execute\s*\(|finalize_vote", re.IGNORECASE)
            quorum_re = re.compile(r"quorum|threshold|min_votes|majority", re.IGNORECASE)
            for i, line in enumerate(lines, start=1):
                if exec_re.search(line):
                    window = "\n".join(lines[max(0, i - 20): i + 5])
                    if not quorum_re.search(window):
                        findings.append(CrossContractPath(
                            path=[iface.name],
                            messages=[],
                            risk="CRITICAL",
                            attack_description=(
                                f"Governance attack: '{iface.name}' executes proposal "
                                f"at line {i} without checking quorum/threshold. "
                                "An attacker with minimal voting power can execute arbitrary proposals."
                            ),
                            finding_type="GOVERNANCE_ATTACK",
                        ))

            # Pattern 2: treasury send without vote result validation
            treasury_re = re.compile(r"treasury|withdraw|send_ton|transfer_ton", re.IGNORECASE)
            vote_check_re = re.compile(r"vote_count|approve|yes_votes|passed", re.IGNORECASE)
            for i, line in enumerate(lines, start=1):
                if treasury_re.search(line) and _SEND_RAW_RE.search(line):
                    window = "\n".join(lines[max(0, i - 30): i])
                    if not vote_check_re.search(window):
                        findings.append(CrossContractPath(
                            path=[iface.name],
                            messages=[],
                            risk="HIGH",
                            attack_description=(
                                f"Governance treasury drain: '{iface.name}' sends funds "
                                f"at line {i} without confirming vote result. "
                                "Proposal may be executed without proper approval."
                            ),
                            finding_type="GOVERNANCE_ATTACK",
                        ))

            # Pattern 3: cross-contract — DAO calls treasury in another contract
            for neighbor in call_graph.get(iface.name, []):
                neighbor_iface = next(
                    (ii for ii in interfaces if ii.name == neighbor), None
                )
                if neighbor_iface is None:
                    continue
                neighbor_source = neighbor_iface.source or ""
                if not neighbor_source:
                    try:
                        neighbor_source = Path(neighbor_iface.file).read_text(
                            encoding="utf-8", errors="replace"
                        )
                    except OSError:
                        continue
                if _ALL_BALANCE_RE.search(neighbor_source):
                    findings.append(CrossContractPath(
                        path=[iface.name, neighbor],
                        messages=self._get_messages_for_path([iface.name, neighbor]),
                        risk="HIGH",
                        attack_description=(
                            f"Governance attack path: DAO '{iface.name}' → treasury '{neighbor}'. "
                            "If DAO voting can be manipulated, attacker can drain treasury balance."
                        ),
                        finding_type="GOVERNANCE_ATTACK",
                    ))

        return findings

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _get_messages_for_path(self, path: List[str]) -> List[OutgoingCall]:
        """Return outgoing calls along the given contract path."""
        messages: List[OutgoingCall] = []
        for i in range(len(path) - 1):
            src = path[i]
            dst = path[i + 1]
            for iface in self._interfaces:
                if iface.name == src:
                    for call in iface.outgoing_calls:
                        if dst.lower() in call.to_address.lower() or call.to_address == dst:
                            messages.append(call)
        return messages

    @staticmethod
    def _path_to_finding(path: CrossContractPath) -> dict:
        """Convert a CrossContractPath to a platform-compatible finding dict."""
        return {
            "type": "TON_CROSS_CONTRACT",
            "id": f"CC-{path.finding_type}",
            "rule_id": f"CC-{path.finding_type}",
            "severity": path.risk,
            "description": path.attack_description,
            "message": path.attack_description,
            "evidence": " → ".join(path.path),
            "source": "cross_contract_analyzer",
            "category": "Cross-Contract Security",
            "finding_type": path.finding_type,
            "contracts_involved": path.path,
            "line": path.messages[0].line if path.messages else 0,
            "file": "",
        }

    @staticmethod
    def _compute_risk_summary(
        paths: List[CrossContractPath],
        interfaces: List[ContractInterface],
    ) -> str:
        """Produce a human-readable risk summary."""
        if not paths:
            return (
                f"No cross-contract vulnerabilities found across "
                f"{len(interfaces)} contract(s)."
            )
        critical = sum(1 for p in paths if p.risk == "CRITICAL")
        high = sum(1 for p in paths if p.risk == "HIGH")
        medium = sum(1 for p in paths if p.risk == "MEDIUM")
        types = list({p.finding_type for p in paths})
        return (
            f"Cross-contract analysis of {len(interfaces)} contracts: "
            f"{critical} CRITICAL, {high} HIGH, {medium} MEDIUM findings. "
            f"Vulnerability types: {', '.join(types)}."
        )
