"""
TVM State Machine Simulator for TON smart contract analysis.

Simulates TVM (TON Virtual Machine) execution state to detect:
- Storage modification without authorization
- Gas drain through infinite loops
- Integer overflow/underflow in financial calculations
- Reentrancy via message sending during state changes
- Access control violations
- Message bounce handling errors

The simulator works on FunC/Tact contract TEXT (not bytecode).
It uses symbolic values and constraint solving to explore execution paths.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Core Value & Storage types
# ---------------------------------------------------------------------------

@dataclass
class TVMValue:
    """Symbolic or concrete TVM value."""
    kind: str                           # "int","cell","slice","builder","tuple","null","symbolic"
    concrete: Optional[int] = None      # if concrete integer
    symbol: Optional[str] = None        # symbolic variable name e.g. "msg_sender", "msg_value"
    constraints: List[str] = field(default_factory=list)  # e.g. [">=0", "<=2^64"]
    is_tainted: bool = False            # came from external message
    taint_source: str = ""              # "msg.sender", "msg.body", "msg.value"

    @classmethod
    def symbolic(cls, name: str, kind: str = "int",
                 constraints: Optional[List[str]] = None,
                 tainted: bool = False, taint_source: str = "") -> "TVMValue":
        return cls(
            kind=kind,
            symbol=name,
            constraints=constraints or [],
            is_tainted=tainted,
            taint_source=taint_source,
        )

    @classmethod
    def concrete_int(cls, value: int) -> "TVMValue":
        return cls(kind="int", concrete=value)

    @classmethod
    def null(cls) -> "TVMValue":
        return cls(kind="null")

    def __repr__(self) -> str:  # pragma: no cover
        if self.concrete is not None:
            return f"TVMValue(int={self.concrete})"
        if self.symbol:
            return f"TVMValue(sym={self.symbol!r}, tainted={self.is_tainted})"
        return f"TVMValue(kind={self.kind})"


@dataclass
class TVMStorage:
    """Contract persistent storage (c4 cell)."""
    cells: Dict[str, TVMValue] = field(default_factory=dict)
    modified_without_auth: List[str] = field(default_factory=list)  # keys modified before auth
    auth_checked: bool = False
    auth_check_line: int = 0


@dataclass
class TVMMessage:
    """Incoming or outgoing TVM message."""
    msg_type: str                       # "internal", "external"
    sender: TVMValue = field(default_factory=lambda: TVMValue.symbolic("msg_sender", "slice",
                                                                        tainted=True,
                                                                        taint_source="msg.sender"))
    value: TVMValue = field(default_factory=lambda: TVMValue.symbolic("msg_value", "int",
                                                                       constraints=[">=0"],
                                                                       tainted=True,
                                                                       taint_source="msg.value"))
    body: TVMValue = field(default_factory=lambda: TVMValue.symbolic("msg_body", "slice",
                                                                      tainted=True,
                                                                      taint_source="msg.body"))
    bounce: bool = True
    is_bounced: bool = False


@dataclass
class TVMExecutionState:
    """Full execution state for one symbolic path."""
    storage: TVMStorage = field(default_factory=TVMStorage)
    stack: List[TVMValue] = field(default_factory=list)
    gas_used: int = 0
    gas_limit: int = 1_000_000
    outgoing_messages: List[TVMMessage] = field(default_factory=list)
    incoming_message: TVMMessage = field(
        default_factory=lambda: TVMMessage(msg_type="internal")
    )
    execution_path: List[str] = field(default_factory=list)  # sequence of operations
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    def clone(self) -> "TVMExecutionState":
        """Shallow-copy state for path forking."""
        return TVMExecutionState(
            storage=TVMStorage(
                cells=dict(self.storage.cells),
                modified_without_auth=list(self.storage.modified_without_auth),
                auth_checked=self.storage.auth_checked,
                auth_check_line=self.storage.auth_check_line,
            ),
            stack=list(self.stack),
            gas_used=self.gas_used,
            gas_limit=self.gas_limit,
            outgoing_messages=list(self.outgoing_messages),
            incoming_message=self.incoming_message,
            execution_path=list(self.execution_path),
            warnings=list(self.warnings),
            errors=list(self.errors),
        )


# ---------------------------------------------------------------------------
# Lightweight AST representation
# ---------------------------------------------------------------------------

@dataclass
class FunctionDef:
    name: str
    params: List[str]
    body_start: int          # character offset
    body_end: int
    is_impure: bool
    line: int


@dataclass
class ContractAST:
    language: str                            # "func" or "tact"
    global_vars: List[str]                   # storage variable names
    functions: List[FunctionDef]
    recv_internal: Optional[FunctionDef]
    recv_external: Optional[FunctionDef]
    auth_check_lines: List[int]              # line numbers of auth checks
    storage_write_lines: List[Tuple[int, str]]   # (line, var_name)
    send_call_lines: List[int]               # line numbers of send_raw_message / send()
    source_lines: List[str]                  # original lines for reference


# ---------------------------------------------------------------------------
# TVMStateExplorer — main engine
# ---------------------------------------------------------------------------

# Auth-check patterns for FunC
_FUNC_AUTH_RE = re.compile(
    r"""
    throw_unless\s*\(\s*4\d\d            # throw_unless(401, ...)
    | throw_if\s*\(                      # throw_if(...)
    | equal_slices\s*\(                  # equal_slices(sender, owner)
    | sender\s*\(\s*\)\s*==             # sender() == owner
    | check_signature\s*\(              # check_signature(...)
    | is_signature_valid\s*\(           # is_signature_valid(...)
    """,
    re.VERBOSE,
)
# Auth-check patterns for Tact
_TACT_AUTH_RE = re.compile(
    r"""
    require\s*\(\s*sender\s*\(\s*\)     # require(sender() == ...
    | require\s*\(\s*context\s*\(\s*\)\s*\.sender  # require(context().sender ...
    | require\s*\(\s*self\s*\.\s*owner  # require(self.owner == ...
    """,
    re.VERBOSE,
)

# Storage write patterns for FunC
_FUNC_STORE_RE = re.compile(r"set_data\s*\(|\.store_(?:uint|int|slice|ref|coins|bits)\s*\(")
# Storage write patterns for Tact
_TACT_STORE_RE = re.compile(r"self\s*\.\s*(\w+)\s*=\s*")

# send_raw_message / Tact send
_SEND_RE = re.compile(r"\bsend_raw_message\s*\(|\bsend\s*\(|\bself\s*\.\s*reply\s*\(")

# Global storage vars in FunC (global keyword)
_FUNC_GLOBAL_RE = re.compile(r"^\s*global\s+(?:\w+\s+)?(\w+)\s*;", re.MULTILINE)
# FunC function def
_FUNC_FUNDEF_RE = re.compile(
    r"^[ \t]*(?:[\w<>]+[ \t]+){1,4}(\w+)\s*\([^)]*\)\s*(impure\s*)?(inline\s*)?",
    re.MULTILINE,
)
# Tact contract field
_TACT_FIELD_RE = re.compile(r"^\s+(\w+)\s*:\s*\w+", re.MULTILINE)


class TVMStateExplorer:
    """
    Symbolic state-machine explorer for TON smart contracts.
    Works on FunC and Tact source text to detect common vulnerability classes.
    """

    def __init__(self, contract_source: str, language: str = "func") -> None:
        self.source = contract_source
        self.language = language.lower()
        self.lines: List[str] = contract_source.splitlines()
        self._ast: Optional[ContractAST] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def explore(self, max_paths: int = 100) -> List[TVMExecutionState]:
        """
        Symbolically explore execution paths and return annotated states.

        Paths explored:
          1. Unauthenticated storage write
          2. Integer overflow (arithmetic without bounds)
          3. Gas drain (loops with external conditions)
          4. Reentrancy (send before state update)
          5. Unhandled bounce
        """
        if self.language == "func":
            self._ast = self._parse_func_contract(self.source)
        else:
            self._ast = self._parse_tact_contract(self.source)

        states: List[TVMExecutionState] = []

        # Path 1 — Unauthenticated storage write
        state1 = self._explore_unauth_storage_write()
        if state1:
            states.append(state1)

        # Path 2 — Integer overflow
        state2 = self._explore_integer_overflow()
        if state2:
            states.append(state2)

        # Path 3 — Gas drain via loop
        state3 = self._explore_gas_drain()
        if state3:
            states.append(state3)

        # Path 4 — Reentrancy (send before set_data)
        state4 = self._explore_reentrancy()
        if state4:
            states.append(state4)

        # Path 5 — Unhandled bounce
        state5 = self._explore_unhandled_bounce()
        if state5:
            states.append(state5)

        return states[:max_paths]

    # ------------------------------------------------------------------
    # Path explorers
    # ------------------------------------------------------------------

    def _explore_unauth_storage_write(self) -> Optional[TVMExecutionState]:
        """Explore path where storage is written before auth check."""
        warnings = self._check_storage_write_before_auth_from_ast()
        if not warnings:
            return None
        state = TVMExecutionState(
            incoming_message=TVMMessage(msg_type="internal"),
        )
        state.execution_path.append("recv_internal()")
        state.execution_path.append("load_storage()")
        for w in warnings:
            state.warnings.append(w)
            state.execution_path.append(f"STORAGE_WRITE_WITHOUT_AUTH: {w}")
        return state

    def _explore_integer_overflow(self) -> Optional[TVMExecutionState]:
        """Explore path with user-controlled arithmetic without bounds check."""
        findings = self._find_overflow_paths()
        if not findings:
            return None
        state = TVMExecutionState(
            incoming_message=TVMMessage(msg_type="internal"),
        )
        state.incoming_message.body = TVMValue.symbolic(
            "attacker_amount", "int", constraints=[">=0"], tainted=True, taint_source="msg.body"
        )
        state.execution_path.append("recv_internal()")
        state.execution_path.append("load_uint(amount_from_body)")
        for line, var, op in findings:
            state.warnings.append(
                f"Line {line}: user-controlled '{var}' used in '{op}' without bounds check — integer overflow possible"
            )
            state.execution_path.append(f"OVERFLOW_PATH: {var} {op} (line {line})")
        return state

    def _explore_gas_drain(self) -> Optional[TVMExecutionState]:
        """Explore path where unbounded loops drain gas."""
        loop_lines = self._find_unbounded_loops()
        if not loop_lines:
            return None
        state = TVMExecutionState(
            incoming_message=TVMMessage(msg_type="external"),
        )
        state.gas_used = state.gas_limit  # symbolic: gas exhausted
        state.execution_path.append("recv_external()")
        state.execution_path.append("accept_message()")
        for ln, evidence in loop_lines:
            state.warnings.append(
                f"Line {ln}: unbounded loop — attacker can exhaust gas: {evidence}"
            )
            state.execution_path.append(f"GAS_DRAIN_LOOP: line {ln}")
        return state

    def _explore_reentrancy(self) -> Optional[TVMExecutionState]:
        """Explore path where outgoing message is sent before state update."""
        issues = self._find_reentrancy_issues()
        if not issues:
            return None
        state = TVMExecutionState(
            incoming_message=TVMMessage(msg_type="internal"),
        )
        outgoing = TVMMessage(
            msg_type="internal",
            sender=TVMValue.symbolic("this_contract", "slice"),
            value=TVMValue.symbolic("msg_value", "int", constraints=[">=0"]),
        )
        state.outgoing_messages.append(outgoing)
        state.execution_path.append("recv_internal()")
        for ln, desc in issues:
            state.warnings.append(f"Line {ln}: {desc}")
            state.execution_path.append(f"REENTRANCY: send_before_state_update (line {ln})")
        return state

    def _explore_unhandled_bounce(self) -> Optional[TVMExecutionState]:
        """Explore path where bounced messages are not handled."""
        issues = self._find_bounce_issues()
        if not issues:
            return None
        state = TVMExecutionState(
            incoming_message=TVMMessage(msg_type="internal", bounce=True, is_bounced=True),
        )
        state.execution_path.append("recv_internal() [bounced message]")
        for desc in issues:
            state.warnings.append(desc)
            state.execution_path.append(f"BOUNCE_UNHANDLED: {desc}")
        return state

    # ------------------------------------------------------------------
    # AST Parsers
    # ------------------------------------------------------------------

    def _parse_func_contract(self, source: str) -> ContractAST:
        """Parse FunC contract source into ContractAST."""
        lines = source.splitlines()

        # Global variables
        global_vars: List[str] = _FUNC_GLOBAL_RE.findall(source)

        # Function definitions
        functions: List[FunctionDef] = []
        recv_internal: Optional[FunctionDef] = None
        recv_external: Optional[FunctionDef] = None

        func_def_re = re.compile(
            r"(?:^|\n)[ \t]*(?:[\w<>*]+[ \t]+){0,4}(\w+)\s*\([^)]*\)\s*(impure\s*)?(inline\s*)?[ \t]*\{",
            re.MULTILINE,
        )
        for m in func_def_re.finditer(source):
            fname = m.group(1)
            if fname in ("if", "else", "while", "repeat", "do", "return", "until"):
                continue
            is_impure = bool(m.group(2))
            brace_pos = m.end() - 1
            depth, idx = 1, brace_pos + 1
            while idx < len(source) and depth > 0:
                if source[idx] == "{":
                    depth += 1
                elif source[idx] == "}":
                    depth -= 1
                idx += 1
            line_num = source[:m.start()].count("\n") + 1
            fdef = FunctionDef(
                name=fname,
                params=[],
                body_start=brace_pos + 1,
                body_end=idx - 1,
                is_impure=is_impure,
                line=line_num,
            )
            functions.append(fdef)
            if fname == "recv_internal":
                recv_internal = fdef
            elif fname == "recv_external":
                recv_external = fdef

        auth_check_lines = self._find_auth_patterns(source)
        storage_write_lines = self._find_storage_writes(source)
        send_call_lines = self._find_send_calls(source)

        return ContractAST(
            language="func",
            global_vars=global_vars,
            functions=functions,
            recv_internal=recv_internal,
            recv_external=recv_external,
            auth_check_lines=auth_check_lines,
            storage_write_lines=storage_write_lines,
            send_call_lines=send_call_lines,
            source_lines=lines,
        )

    def _parse_tact_contract(self, source: str) -> ContractAST:
        """Parse Tact contract source into ContractAST."""
        lines = source.splitlines()

        # Contract fields (storage)
        global_vars: List[str] = _TACT_FIELD_RE.findall(source)

        # Function definitions (init, receive, get fun)
        functions: List[FunctionDef] = []
        recv_internal: Optional[FunctionDef] = None
        recv_external: Optional[FunctionDef] = None

        fn_re = re.compile(
            r"(?:receive|fun|get\s+fun|init)\s*\(([^)]*)\)\s*\{",
            re.MULTILINE,
        )
        for m in fn_re.finditer(source):
            fname_raw = m.group(0).split("(")[0].strip()
            fname = fname_raw.replace("get fun", "get_fun").replace(" ", "_")
            brace_pos = m.end() - 1
            depth, idx = 1, brace_pos + 1
            while idx < len(source) and depth > 0:
                if source[idx] == "{":
                    depth += 1
                elif source[idx] == "}":
                    depth -= 1
                idx += 1
            line_num = source[:m.start()].count("\n") + 1
            fdef = FunctionDef(
                name=fname,
                params=[m.group(1)],
                body_start=brace_pos + 1,
                body_end=idx - 1,
                is_impure=True,
                line=line_num,
            )
            functions.append(fdef)
            if "receive" in fname_raw.lower():
                if recv_internal is None:
                    recv_internal = fdef
            if "external" in fname_raw.lower():
                recv_external = fdef

        auth_check_lines = self._find_auth_patterns(source)
        storage_write_lines = self._find_storage_writes(source)
        send_call_lines = self._find_send_calls(source)

        return ContractAST(
            language="tact",
            global_vars=global_vars,
            functions=functions,
            recv_internal=recv_internal,
            recv_external=recv_external,
            auth_check_lines=auth_check_lines,
            storage_write_lines=storage_write_lines,
            send_call_lines=send_call_lines,
            source_lines=lines,
        )

    # ------------------------------------------------------------------
    # Pattern finders
    # ------------------------------------------------------------------

    def _find_auth_patterns(self, source: str) -> List[int]:
        """
        Return line numbers (1-based) where auth checks occur.

        FunC: throw_unless(401,...), throw_if(...), equal_slices(...),
              check_signature(...), is_signature_valid(...)
        Tact: require(sender() == ...), require(context().sender == ...)
        """
        auth_re = _FUNC_AUTH_RE if self.language == "func" else _TACT_AUTH_RE
        lines = source.splitlines()
        result: List[int] = []
        for i, line in enumerate(lines, start=1):
            stripped = line.strip()
            if stripped.startswith(";;") or stripped.startswith("//"):
                continue
            if auth_re.search(line):
                result.append(i)
        return result

    def _find_storage_writes(self, source: str) -> List[Tuple[int, str]]:
        """
        Return (line_number, variable_hint) for all storage write operations.

        FunC: set_data(...), .store_uint/int/slice/ref/coins/bits(...)
        Tact: self.field = ...
        """
        if self.language == "func":
            write_re = _FUNC_STORE_RE
        else:
            write_re = _TACT_STORE_RE

        lines = source.splitlines()
        result: List[Tuple[int, str]] = []
        for i, line in enumerate(lines, start=1):
            stripped = line.strip()
            if stripped.startswith(";;") or stripped.startswith("//"):
                continue
            m = write_re.search(line)
            if m:
                var = m.group(1) if m.lastindex and m.lastindex >= 1 else "storage"
                result.append((i, var))
        return result

    def _find_send_calls(self, source: str) -> List[int]:
        """Return line numbers of send_raw_message / send() / self.reply() calls."""
        lines = source.splitlines()
        result: List[int] = []
        for i, line in enumerate(lines, start=1):
            stripped = line.strip()
            if stripped.startswith(";;") or stripped.startswith("//"):
                continue
            if _SEND_RE.search(line):
                result.append(i)
        return result

    # ------------------------------------------------------------------
    # Vulnerability checkers (operate on extracted AST data)
    # ------------------------------------------------------------------

    def _check_storage_write_before_auth(self, state: TVMExecutionState) -> List[str]:
        """
        Return warning strings for storage keys modified before the first auth check.
        Uses the state's storage.modified_without_auth list.
        """
        return [
            f"Storage field '{key}' modified before authorization check"
            for key in state.storage.modified_without_auth
        ]

    def _check_storage_write_before_auth_from_ast(self) -> List[str]:
        """
        Derive warnings from AST data: find storage writes that appear before
        the first auth check line, within recv_internal / receive handlers.
        """
        if self._ast is None:
            return []

        auth_lines = sorted(self._ast.auth_check_lines)
        warnings: List[str] = []

        # Determine the relevant handler body
        handler = self._ast.recv_internal
        if handler is None:
            return []

        handler_source_start = handler.line
        handler_source_end = self.lines.index(
            self.lines[handler.line - 1], handler.line - 1
        ) if handler.line <= len(self.lines) else len(self.lines)

        # First auth check inside the handler body
        first_auth = None
        for al in auth_lines:
            if al >= handler.line:
                first_auth = al
                break

        for write_line, var_name in self._ast.storage_write_lines:
            # Only consider writes inside the handler
            if write_line < handler.line:
                continue
            # If there is no auth check, or write is before auth, flag it
            if first_auth is None or write_line < first_auth:
                warnings.append(
                    f"Line {write_line}: storage write to '{var_name}' "
                    f"occurs before any authorization check (first auth at "
                    f"line {first_auth or 'N/A'})"
                )
        return warnings

    def _find_overflow_paths(self) -> List[Tuple[int, str, str]]:
        """
        Return (line, var, operator) for user-tainted variables used in
        arithmetic without a preceding bounds check.
        Returns list of (line_number, variable_name, operation_snippet).
        """
        results: List[Tuple[int, str, str]] = []
        # Find variables loaded from user message
        tainted_vars: set = set()
        load_re = re.compile(
            r"(?:int|var)\s+(\w+)\s*=\s*\w+~load_(?:uint|int|coins)\s*\(\s*\d+\s*\)"
            r"|(\w+)\s*=\s*\w+~load_(?:uint|int|coins)\s*\(\s*\d+\s*\)"
        )
        for m in load_re.finditer(self.source):
            varname = m.group(1) or m.group(2)
            if varname:
                tainted_vars.add(varname)
        # Tact: let <var> = msg.<field>
        tact_load_re = re.compile(r"let\s+(\w+)\s*=\s*msg\.\w+")
        for m in tact_load_re.finditer(self.source):
            tainted_vars.add(m.group(1))

        if not tainted_vars:
            return results

        for var in tainted_vars:
            arith_re = re.compile(
                r"\b" + re.escape(var) + r"\s*[\*\+\-/]\s*\w+"
                r"|\w+\s*[\*\+\-/]\s*" + re.escape(var) + r"\b"
            )
            for m in arith_re.finditer(self.source):
                pos = m.start()
                lineno = self.source[:pos].count("\n") + 1
                before = self.source[max(0, pos - 250):pos]
                has_bounds = bool(re.search(
                    rf"throw.*{re.escape(var)}|{re.escape(var)}\s*<=|{re.escape(var)}\s*<\s*\d"
                    rf"|assert.*{re.escape(var)}|require.*{re.escape(var)}",
                    before,
                ))
                if not has_bounds:
                    results.append((lineno, var, m.group(0).strip()[:60]))
        return results

    def _find_unbounded_loops(self) -> List[Tuple[int, str]]:
        """Return (line, evidence) for loops with no upper-bound guard."""
        results: List[Tuple[int, str]] = []
        loop_re = re.compile(r"\b(while|repeat)\s*\(")
        bound_re = re.compile(r"<\s*\d+")
        lines = self.source.splitlines()
        for i, line in enumerate(lines, start=1):
            stripped = line.strip()
            if stripped.startswith(";;") or stripped.startswith("//"):
                continue
            if loop_re.search(line):
                window = line
                for lookahead in range(1, 4):
                    if i - 1 + lookahead < len(lines):
                        window += " " + lines[i - 1 + lookahead]
                if not bound_re.search(window):
                    # Check for repeat(<literal>) — that's safe
                    if re.search(r"\brepeat\s*\(\s*\d+\s*\)", window):
                        continue
                    results.append((i, stripped[:80]))
        return results

    def _find_reentrancy_issues(self) -> List[Tuple[int, str]]:
        """
        Return (line, description) for send calls that appear before
        set_data/storage-commit within the same handler.
        """
        results: List[Tuple[int, str]] = []
        if self._ast is None:
            return results

        handler = self._ast.recv_internal
        if handler is None:
            return results

        send_lines_in_handler = sorted(
            ln for ln in self._ast.send_call_lines if ln >= handler.line
        )
        write_lines_in_handler = sorted(
            ln for ln, _ in self._ast.storage_write_lines if ln >= handler.line
        )

        for send_ln in send_lines_in_handler:
            # Check if there is a storage write AFTER this send (state not committed)
            writes_after_send = [wl for wl in write_lines_in_handler if wl > send_ln]
            if writes_after_send:
                results.append((
                    send_ln,
                    f"send_raw_message/send (line {send_ln}) occurs before "
                    f"set_data/storage commit (line {writes_after_send[0]}) — "
                    "reentrancy window: state is not saved before outgoing message"
                ))
        return results

    def _find_bounce_issues(self) -> List[str]:
        """
        Return descriptions of bounce-handling issues.
        Specifically: recv_internal exists but no bounce flag check is found.
        """
        issues: List[str] = []
        has_recv_internal = bool(re.search(r"\brecv_internal\s*\(", self.source))
        if not has_recv_internal:
            return issues

        # Check for bounce flag handling
        has_bounce_check = bool(re.search(
            r"is_bounced|\.load_uint\s*\(\s*1\s*\)|0xFFFFFFFF|op\s*==\s*0xffffffff"
            r"|bounce.*msg|msg.*bounce",
            self.source, re.IGNORECASE,
        ))
        # Check for outgoing messages (if none, bounce handling is moot)
        has_outgoing = bool(re.search(r"\bsend_raw_message\s*\(", self.source))

        if has_outgoing and not has_bounce_check:
            issues.append(
                "recv_internal with outgoing messages but no bounce flag check detected. "
                "If a sent message bounces, the contract will re-enter recv_internal without "
                "recognizing the bounce — potential double-spend or inconsistent state."
            )
        return issues

    # ------------------------------------------------------------------
    # Convenience: run all checks and return flat finding dicts
    # ------------------------------------------------------------------

    def get_findings(self) -> List[dict]:
        """
        High-level entry point: explore all paths, collect warnings/errors,
        return list of finding dicts compatible with the rest of the platform.
        """
        states = self.explore()
        findings: List[dict] = []
        seen: set = set()

        severity_map = {
            "STORAGE_WRITE_WITHOUT_AUTH": "HIGH",
            "OVERFLOW_PATH": "HIGH",
            "GAS_DRAIN_LOOP": "HIGH",
            "REENTRANCY": "CRITICAL",
            "BOUNCE_UNHANDLED": "MEDIUM",
        }

        for state in states:
            for warn in state.warnings:
                if warn in seen:
                    continue
                seen.add(warn)

                # Determine category from execution path keywords
                cat = "UNKNOWN"
                sev = "MEDIUM"
                for op in state.execution_path:
                    for key in severity_map:
                        if key in op:
                            cat = key
                            sev = severity_map[key]
                            break

                findings.append({
                    "type": "TON_TVM_STATE",
                    "id": f"TVM-{cat}",
                    "rule_id": f"TVM-{cat}",
                    "severity": sev,
                    "description": warn,
                    "evidence": warn,
                    "message": warn,
                    "source": "tvm_state_explorer",
                    "category": "TVM State Analysis",
                    "file": "",
                    "line": 0,
                    "execution_path": state.execution_path,
                })
        return findings
