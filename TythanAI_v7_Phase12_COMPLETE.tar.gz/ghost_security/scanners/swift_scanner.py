# TythanAI Security Platform
# Copyright (c) 2026 TythanAI Labs
# Licensed under the Business Source License 1.1 (see LICENSE).

"""
TythanAI — SwiftScanner
Static-analysis scanner for Swift source code.

Detects 8 vulnerability classes via regex patterns.
Results follow the standard TythanAI finding dict format.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("tythanai.swift_scanner")

# ── Vulnerability rule definitions ────────────────────────────────────────────


class _Rule:
    """Internal representation of a Swift security rule."""

    __slots__ = (
        "rule_id", "severity", "category", "title", "description",
        "pattern", "cwe", "remediation",
    )

    def __init__(
        self,
        rule_id:     str,
        severity:    str,
        category:    str,
        title:       str,
        description: str,
        pattern:     str,
        cwe:         str,
        remediation: str,
    ) -> None:
        self.rule_id     = rule_id
        self.severity    = severity
        self.category    = category
        self.title       = title
        self.description = description
        self.pattern     = re.compile(pattern, re.IGNORECASE | re.MULTILINE)
        self.cwe         = cwe
        self.remediation = remediation


# Each rule has a compiled regex.  A match on any line triggers a finding.

_RULES: List[_Rule] = [
    _Rule(
        rule_id="SWIFT-001",
        severity="CRITICAL",
        category="secrets",
        title="Hardcoded Credentials",
        description=(
            "A credential (password, API key, or secret) appears to be "
            "hardcoded as a string literal in source code."
        ),
        pattern=r'(?:password|apiKey|api_key|secret)\s*=\s*"[^"]{1,}"',
        cwe="CWE-798",
        remediation=(
            "Remove the hardcoded credential and load it at runtime from the "
            "iOS Keychain, an environment variable, or a secrets management "
            "service such as AWS Secrets Manager or HashiCorp Vault."
        ),
    ),
    _Rule(
        rule_id="SWIFT-002",
        severity="HIGH",
        category="storage",
        title="Keychain Data Without kSecAttrAccessible",
        description=(
            "Sensitive data is stored in the iOS Keychain without specifying "
            "a kSecAttrAccessible policy.  The default policy "
            "(kSecAttrAccessibleAlways) exposes the data even when the device "
            "is locked."
        ),
        pattern=(
            r'SecItemAdd\s*\([^)]*?\)(?![\s\S]*?kSecAttrAccessible)'
            r'|kSecValueData(?![\s\S]{0,300}kSecAttrAccessible)'
        ),
        cwe="CWE-312",
        remediation=(
            "Always include kSecAttrAccessible in the query dictionary, "
            "typically kSecAttrAccessibleWhenUnlockedThisDeviceOnly for "
            "maximum security."
        ),
    ),
    _Rule(
        rule_id="SWIFT-003",
        severity="HIGH",
        category="network",
        title="Disabled TLS Validation",
        description=(
            "The URLSession delegate returns .useCredential for all challenges, "
            "effectively disabling TLS certificate validation and making the "
            "app vulnerable to man-in-the-middle attacks."
        ),
        pattern=(
            r'didReceive\s+challenge[\s\S]{0,300}?'
            r'completionHandler\s*\(\s*\.useCredential'
        ),
        cwe="CWE-295",
        remediation=(
            "Only call completionHandler(.useCredential, ...) for challenges "
            "your app explicitly trusts (e.g. after pinning the certificate "
            "fingerprint).  Use SecTrustEvaluateWithError for all server "
            "trust challenges."
        ),
    ),
    _Rule(
        rule_id="SWIFT-004",
        severity="HIGH",
        category="injection",
        title="SQL Injection via String Interpolation in SQLite",
        description=(
            "User-controlled data is interpolated directly into a raw SQLite "
            "statement using Swift string interpolation (\\(...)), allowing an "
            "attacker to manipulate the query structure."
        ),
        pattern=r'sqlite3_exec\s*\([^)]*?"[^"]*\\\([^)]+\)[^"]*"',
        cwe="CWE-89",
        remediation=(
            "Use sqlite3_prepare_v2 with ? placeholders and bind user-supplied "
            "values with sqlite3_bind_* functions, or migrate to a safe ORM "
            "such as GRDB or Core Data."
        ),
    ),
    _Rule(
        rule_id="SWIFT-005",
        severity="HIGH",
        category="cryptography",
        title="Weak Cryptographic Algorithm (DES/3DES)",
        description=(
            "CommonCrypto is used with the deprecated DES or 3DES cipher "
            "algorithm.  These algorithms are cryptographically weak and "
            "should not be used for new development."
        ),
        pattern=r'kCCAlgorithmDES|kCCAlgorithm3DES',
        cwe="CWE-327",
        remediation=(
            "Replace kCCAlgorithmDES / kCCAlgorithm3DES with "
            "kCCAlgorithmAES (AES-256-GCM via CryptoKit is preferred).  "
            "Migrate all existing encrypted data as part of the upgrade."
        ),
    ),
    _Rule(
        rule_id="SWIFT-006",
        severity="MEDIUM",
        category="logging",
        title="Logging Sensitive Data",
        description=(
            "A password, token, or secret may be written to the system log, "
            "which can be read by other applications or extracted from a "
            "device backup."
        ),
        pattern=(
            r'NSLog\s*\([^)]*password'
            r'|print\s*\([^)]*token'
            r'|debugPrint\s*\([^)]*secret'
        ),
        cwe="CWE-532",
        remediation=(
            "Never log credentials or tokens.  Use #if DEBUG guards for any "
            "diagnostic output that might reveal sensitive state, and strip "
            "all such logging before release builds."
        ),
    ),
    _Rule(
        rule_id="SWIFT-007",
        severity="MEDIUM",
        category="integrity",
        title="Missing Jailbreak Detection",
        description=(
            "No jailbreak detection logic was found in this file.  Security-"
            "critical applications should detect a jailbroken environment and "
            "refuse to run or limit functionality accordingly."
        ),
        # A missing-pattern rule: the rule fires when the pattern is ABSENT.
        # We use a sentinel that never matches real code; absence is handled
        # in _scan_source_lines() by checking the _JAILBREAK_DETECT_RE.
        pattern=r"__SWIFT007_SENTINEL_NEVER_MATCHES__",
        cwe="CWE-693",
        remediation=(
            "Add jailbreak detection using a library such as IOSSecuritySuite "
            "or implement manual checks (e.g. cydia:// URL, write to "
            "/Applications, file existence of /etc/apt)."
        ),
    ),
    _Rule(
        rule_id="SWIFT-008",
        severity="MEDIUM",
        category="storage",
        title="Insecure Data Storage via UserDefaults",
        description=(
            "Sensitive data (password, token, secret, or key) appears to be "
            "stored in UserDefaults, which is unencrypted and readable by any "
            "process with access to the app's container."
        ),
        pattern=(
            r'UserDefaults\.standard\.set\s*\([^,]+,\s*forKey\s*:\s*"'
            r'[^"]*(?:password|token|secret|key|credential)[^"]*"'
        ),
        cwe="CWE-312",
        remediation=(
            "Store sensitive values in the iOS Keychain instead of "
            "UserDefaults.  Use SecItemAdd / SecItemCopyMatching with "
            "kSecAttrAccessibleWhenUnlockedThisDeviceOnly."
        ),
    ),
]

# Regex that signals jailbreak detection IS present (used for SWIFT-007)
_JAILBREAK_DETECT_RE = re.compile(
    r'(?:canOpenURL|FileManager|cydia|jailbreak|JailbreakDetect'
    r'|IOSSecuritySuite|/Applications|/private/var/lib/apt)',
    re.IGNORECASE,
)

# ── Scanner class ──────────────────────────────────────────────────────────────


class SwiftScanner:
    """
    Static-analysis scanner for Swift (.swift) source files.

    Detects 8 vulnerability classes using regex patterns.
    All results follow the TythanAI standard finding dict format.
    """

    # ── Public API ─────────────────────────────────────────────────────────────

    def scan_file(self, file_path: str) -> List[dict]:
        """
        Scan a single Swift source file.

        Parameters
        ----------
        file_path:
            Absolute or relative path to the .swift file.

        Returns
        -------
        list[dict]
            Zero or more finding dicts.
        """
        p = Path(file_path)
        if not p.exists():
            logger.warning("SwiftScanner.scan_file: file not found: %s", file_path)
            return []
        try:
            source = p.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            logger.warning("SwiftScanner.scan_file: cannot read %s: %s", file_path, exc)
            return []
        return self.scan_source(source, virtual_path=str(p))

    def scan_directory(self, directory: str) -> dict:
        """
        Recursively scan all .swift files under *directory*.

        Returns
        -------
        dict
            ``{"findings": [...], "files_scanned": N, "errors": [...]}``
        """
        root   = Path(directory)
        all_findings: List[dict] = []
        errors: List[str]        = []
        files_scanned            = 0

        for swift_file in root.rglob("*.swift"):
            files_scanned += 1
            try:
                findings = self.scan_file(str(swift_file))
                all_findings.extend(findings)
            except Exception as exc:
                errors.append(f"{swift_file}: {exc}")
                logger.warning("SwiftScanner: error scanning %s: %s", swift_file, exc)

        return {
            "findings":      all_findings,
            "files_scanned": files_scanned,
            "errors":        errors,
        }

    def scan_source(
        self,
        source: str,
        virtual_path: str = "<input>",
    ) -> List[dict]:
        """
        Scan Swift source provided as a string.

        Parameters
        ----------
        source:
            Swift source code.
        virtual_path:
            Path label used in findings (default ``"<input>"``).

        Returns
        -------
        list[dict]
            Zero or more finding dicts.
        """
        return _scan_source_lines(source, virtual_path)


# ── Core scanning logic ────────────────────────────────────────────────────────

def _build_finding(
    rule: _Rule,
    file_path: str,
    line_no: int,
    evidence: str,
) -> dict:
    """Build a standard finding dict from a rule match."""
    return {
        "rule_id":     rule.rule_id,
        "severity":    rule.severity,
        "category":    rule.category,
        "title":       rule.title,
        "description": rule.description,
        "file":        file_path,
        "line":        line_no,
        "evidence":    evidence.strip()[:300],
        "cwe":         rule.cwe,
        "remediation": rule.remediation,
    }


def _scan_source_lines(source: str, file_path: str) -> List[dict]:
    """
    Core scanning routine.

    For most rules: search each line with the compiled regex and emit a
    finding for every match.

    For SWIFT-007 (missing jailbreak detection): emit a single finding at
    line 1 if no jailbreak-detection token is found anywhere in the file.
    """
    lines    = source.splitlines()
    findings: List[dict] = []

    # Rules that match positively line-by-line
    positive_rules = [r for r in _RULES if r.rule_id != "SWIFT-007"]

    for rule in positive_rules:
        # Some patterns (SWIFT-002, SWIFT-003) are multi-line; match on full source
        if rule.rule_id in ("SWIFT-002", "SWIFT-003"):
            for m in rule.pattern.finditer(source):
                # Determine line number of the match start
                line_no = source[: m.start()].count("\n") + 1
                evidence = source[m.start(): m.end()].strip()[:300]
                findings.append(_build_finding(rule, file_path, line_no, evidence))
        else:
            for i, line in enumerate(lines, start=1):
                if rule.pattern.search(line):
                    findings.append(_build_finding(rule, file_path, i, line))

    # SWIFT-007: absence check — only flag if source looks security-critical
    # (heuristic: file contains "URLSession", "SecItem", "Auth", "Login", "password")
    _security_critical_re = re.compile(
        r'URLSession|SecItem|Auth|Login|password|token|keychain',
        re.IGNORECASE,
    )
    if _security_critical_re.search(source) and not _JAILBREAK_DETECT_RE.search(source):
        swift007 = next((r for r in _RULES if r.rule_id == "SWIFT-007"), None)
        if swift007:
            findings.append(
                _build_finding(swift007, file_path, 1, "<no jailbreak detection found>")
            )

    return findings
