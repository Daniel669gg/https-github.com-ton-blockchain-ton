"""002_phase12_tables

Phase 12 database schema additions:
  - webhooks
  - webhook_deliveries
  - community_rules (marketplace)
  - onboarding_sessions

Revision ID: 002_phase12_tables
Revises: 001_initial_schema
Create Date: 2026-06-03
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

revision = "002_phase12_tables"
down_revision = "001_initial_schema"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "webhooks",
        sa.Column("id",           sa.String(64),  primary_key=True),
        sa.Column("account_id",   sa.String(64),  nullable=False, index=True),
        sa.Column("url",          sa.Text(),       nullable=False),
        sa.Column("events",       sa.Text(),       nullable=False, comment="JSON array"),
        sa.Column("secret_hash",  sa.String(128),  nullable=True),
        sa.Column("active",       sa.Boolean(),    nullable=False, default=True),
        sa.Column("created_at",   sa.DateTime(),   nullable=False, server_default=sa.func.now()),
    )

    op.create_table(
        "webhook_deliveries",
        sa.Column("id",           sa.String(64),  primary_key=True),
        sa.Column("webhook_id",   sa.String(64),  sa.ForeignKey("webhooks.id"), nullable=False, index=True),
        sa.Column("event",        sa.String(64),  nullable=False),
        sa.Column("payload",      sa.Text(),       nullable=False, comment="JSON"),
        sa.Column("status_code",  sa.Integer(),    nullable=True),
        sa.Column("success",      sa.Boolean(),    nullable=False, default=False),
        sa.Column("attempts",     sa.Integer(),    nullable=False, default=0),
        sa.Column("delivered_at", sa.DateTime(),   nullable=True),
        sa.Column("error",        sa.Text(),       nullable=True),
    )

    op.create_table(
        "community_rules",
        sa.Column("id",            sa.String(128), primary_key=True),
        sa.Column("name",          sa.String(256), nullable=False),
        sa.Column("description",   sa.Text(),       nullable=True),
        sa.Column("severity",      sa.String(16),  nullable=False),
        sa.Column("language",      sa.String(32),  nullable=False),
        sa.Column("content",       sa.Text(),       nullable=False, comment="YAML rule body"),
        sa.Column("author",        sa.String(128), nullable=True),
        sa.Column("version",       sa.String(32),  nullable=False, default="1.0.0"),
        sa.Column("installed",     sa.Boolean(),   nullable=False, default=False),
        sa.Column("downloads",     sa.Integer(),   nullable=False, default=0),
        sa.Column("created_at",    sa.DateTime(),  nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at",    sa.DateTime(),  nullable=True),
    )
    op.create_index("ix_community_rules_language", "community_rules", ["language"])
    op.create_index("ix_community_rules_severity", "community_rules", ["severity"])

    op.create_table(
        "onboarding_sessions",
        sa.Column("session_id",   sa.String(64),  primary_key=True),
        sa.Column("account_id",   sa.String(64),  nullable=False, index=True),
        sa.Column("api_key",      sa.String(128), nullable=False),
        sa.Column("project_id",   sa.String(64),  nullable=False),
        sa.Column("email",        sa.String(256), nullable=False),
        sa.Column("repo_url",     sa.Text(),       nullable=False),
        sa.Column("plan",         sa.String(32),  nullable=False, default="free"),
        sa.Column("status",       sa.String(32),  nullable=False, default="active"),
        sa.Column("scan_summary", sa.Text(),       nullable=False, default="{}",
                  comment="JSON scan summary"),
        sa.Column("created_at",   sa.DateTime(),  nullable=False, server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("onboarding_sessions")
    op.drop_index("ix_community_rules_severity", "community_rules")
    op.drop_index("ix_community_rules_language", "community_rules")
    op.drop_table("community_rules")
    op.drop_table("webhook_deliveries")
    op.drop_table("webhooks")
