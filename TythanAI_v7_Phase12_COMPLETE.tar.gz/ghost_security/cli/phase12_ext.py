"""
cli/phase12_ext.py — TythanAI Phase 12 CLI extension commands.

New flags added by Phase 12 (run alongside tythanai_cli.py):
    --dast URL          Run DAST passive scan against URL
    --auto-fix          Auto-generate fix PRs for HIGH/CRITICAL findings
    --quality           Include code quality analysis (complexity, duplication)
    --swift PATH        Run Swift scanner on PATH
    --rules QUERY       Search rules marketplace
    --rules-install ID  Install a marketplace rule
    --multichain PATH   Run Solana+CosmWasm auditor on PATH

Usage (standalone):
    python -m cli.phase12_ext scan /path/to/project --quality --dast http://localhost:8000
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))


# ─── helpers ─────────────────────────────────────────────────────────────────

def _run_dast(url: str, active: bool = False) -> list:
    try:
        from backend.scanners.dast_scanner import DASTScanner
        scanner = DASTScanner()
        if active:
            return scanner.scan_url(url)
        return scanner.passive_scan(url)
    except Exception as e:
        print(f"[DAST] Error: {e}", file=sys.stderr)
        return []


def _run_quality(path: str) -> list:
    try:
        from backend.scanners.code_quality import CodeQualityScanner
        scanner = CodeQualityScanner()
        reports = scanner.scan_directory(path)
        findings = []
        for r in reports:
            if r.grade in ("D", "F"):
                findings.append({
                    "rule_id": "CQ-GRADE",
                    "severity": "MEDIUM" if r.grade == "D" else "HIGH",
                    "file": r.file,
                    "message": f"Code quality grade {r.grade} — debt {r.technical_debt_hours:.1f}h",
                    "cyclomatic_complexity": r.cyclomatic_complexity,
                    "cognitive_complexity": r.cognitive_complexity,
                    "duplication_ratio": r.duplication_ratio,
                })
        return findings
    except Exception as e:
        print(f"[Quality] Error: {e}", file=sys.stderr)
        return []


def _run_swift(path: str) -> list:
    try:
        from scanners.swift_scanner import SwiftScanner
        scanner = SwiftScanner()
        result = scanner.scan_directory(path)
        return result.get("findings", [])
    except Exception as e:
        print(f"[Swift] Error: {e}", file=sys.stderr)
        return []


def _run_auto_pr(findings: list, repo: str, token: str, dry_run: bool = True) -> dict:
    try:
        from backend.agents.auto_pr_agent import AutoPRAgent
        agent = AutoPRAgent(github_token=token, repo=repo)
        result = agent.create_fix_prs(findings, dry_run=dry_run)
        return result.__dict__
    except Exception as e:
        print(f"[AutoPR] Error: {e}", file=sys.stderr)
        return {"error": str(e)}


def _run_multichain(path: str) -> dict:
    try:
        from blockchain.multichain_auditor import MultiChainAuditor
        auditor = MultiChainAuditor()
        return auditor.audit_directory(path)
    except Exception as e:
        print(f"[MultiChain] Error: {e}", file=sys.stderr)
        return {"findings": [], "error": str(e)}


def _rules_search(query: str) -> list:
    try:
        from integrations.rules_marketplace import RulesMarketplace
        mp = RulesMarketplace()
        return mp.search(query)
    except Exception as e:
        print(f"[Marketplace] Error: {e}", file=sys.stderr)
        return []


def _rules_install(rule_id: str) -> bool:
    try:
        from integrations.rules_marketplace import RulesMarketplace
        mp = RulesMarketplace()
        return mp.install(rule_id)
    except Exception as e:
        print(f"[Marketplace] Error: {e}", file=sys.stderr)
        return False


# ─── CLI ─────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tythanai-p12",
        description="TythanAI Phase 12 CLI — extended security analysis",
    )
    sub = parser.add_subparsers(dest="command")

    # scan command
    scan_p = sub.add_parser("scan", help="Scan a directory with Phase 12 engines")
    scan_p.add_argument("target", help="Target directory to scan")
    scan_p.add_argument("--dast", metavar="URL", help="Run DAST passive scan against URL")
    scan_p.add_argument("--dast-active", metavar="URL", help="Run DAST active scan (requires ZAP)")
    scan_p.add_argument("--quality", action="store_true", help="Include code quality analysis")
    scan_p.add_argument("--swift", action="store_true", help="Include Swift scanner")
    scan_p.add_argument("--multichain", action="store_true", help="Include Solana+CosmWasm auditor")
    scan_p.add_argument("--auto-fix", action="store_true",
                        help="Auto-generate fix PRs (dry-run unless --github-token set)")
    scan_p.add_argument("--github-token", default="", help="GitHub token for AutoPR")
    scan_p.add_argument("--repo", default="", help="GitHub repo (owner/name) for AutoPR")
    scan_p.add_argument("--out", default="-", help="Output file (default: stdout)")
    scan_p.add_argument("--format", choices=["json", "text"], default="text")

    # rules commands
    rules_p = sub.add_parser("rules", help="Rules marketplace commands")
    rules_p.add_argument("action", choices=["search", "install", "list"],
                         help="Marketplace action")
    rules_p.add_argument("query", nargs="?", default="", help="Search query or rule ID")

    return parser


def cmd_scan(args: argparse.Namespace) -> int:
    target = args.target
    all_findings: list = []

    print(f"[TythanAI] Scanning: {target}", file=sys.stderr)

    if args.quality:
        print("[TythanAI] Running code quality analysis...", file=sys.stderr)
        all_findings.extend(_run_quality(target))

    if args.swift:
        print("[TythanAI] Running Swift scanner...", file=sys.stderr)
        all_findings.extend(_run_swift(target))

    if args.multichain:
        print("[TythanAI] Running multi-chain auditor...", file=sys.stderr)
        mc = _run_multichain(target)
        all_findings.extend(mc.get("findings", []))

    if args.dast:
        print(f"[TythanAI] Running DAST passive scan: {args.dast}", file=sys.stderr)
        all_findings.extend(_run_dast(args.dast, active=False))

    if getattr(args, "dast_active", None):
        print(f"[TythanAI] Running DAST active scan: {args.dast_active}", file=sys.stderr)
        all_findings.extend(_run_dast(args.dast_active, active=True))

    critical = sum(1 for f in all_findings if f.get("severity") == "CRITICAL")
    high = sum(1 for f in all_findings if f.get("severity") == "HIGH")

    if args.auto_fix and all_findings:
        dry = not bool(args.github_token)
        if dry:
            print("[TythanAI] AutoPR dry-run (no --github-token provided)", file=sys.stderr)
        result = _run_auto_pr(all_findings, args.repo, args.github_token, dry_run=dry)
        print(f"[TythanAI] AutoPR result: {result}", file=sys.stderr)

    output = {
        "target": target,
        "total": len(all_findings),
        "critical": critical,
        "high": high,
        "findings": all_findings,
    }

    text = json.dumps(output, indent=2) if args.format == "json" else _to_text(output)

    if args.out == "-":
        print(text)
    else:
        Path(args.out).write_text(text)
        print(f"[TythanAI] Report written to {args.out}", file=sys.stderr)

    return 1 if critical > 0 else 0


def _to_text(output: dict) -> str:
    lines = [
        f"TythanAI Phase 12 Scan — {output['target']}",
        f"Total: {output['total']}  Critical: {output['critical']}  High: {output['high']}",
        "",
    ]
    for f in output["findings"]:
        sev = f.get("severity", "INFO")
        rid = f.get("rule_id", "")
        msg = f.get("message") or f.get("title", "")
        fp = f.get("file", "")
        lines.append(f"  [{sev:8s}] {rid:20s} {msg}  ({fp})")
    return "\n".join(lines)


def cmd_rules(args: argparse.Namespace) -> int:
    if args.action == "search":
        results = _rules_search(args.query)
        for r in results:
            print(f"  {r.get('id','?'):30s} {r.get('name','')}")
    elif args.action == "install":
        ok = _rules_install(args.query)
        print("Installed." if ok else "Not found.")
    elif args.action == "list":
        try:
            from integrations.rules_marketplace import RulesMarketplace
            for r in RulesMarketplace().list_installed():
                print(f"  {r.get('id','?'):30s} {r.get('name','')}")
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
    return 0


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "scan":
        return cmd_scan(args)
    elif args.command == "rules":
        return cmd_rules(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
