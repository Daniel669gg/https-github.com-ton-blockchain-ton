"""Backward-compatibility shim — use cli.tythanai_cli instead."""
from cli.tythanai_cli import *  # noqa: F401, F403
from cli.tythanai_cli import main

if __name__ == "__main__":
    main()
