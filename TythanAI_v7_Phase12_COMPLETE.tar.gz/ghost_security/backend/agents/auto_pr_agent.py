"""
TythanAI — AutoPRAgent
Automatically patches security findings and opens a GitHub Pull Request.

Dry-run mode prints a unified diff and returns without making any GitHub
API calls.  Real mode uses only Python stdlib (urllib) to interact with
the GitHub REST API.

Rate limiting: at most 5 PRs per hour per process instance (in-memory).
"""
from __future__ import annotations

import base64
import difflib
import json
import logging
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Local imports — resolved relative to the ghost_security package root
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from backend.agents.reasoning.patch_agent import PatchAgent  # noqa: E402
from backend.core.confidence import Finding                   # noqa: E402
from remediation.dependency_fixer import DependencyFixer      # noqa: E402

logger = logging.getLogger("tythanai.auto_pr_agent")

# ── Rate limiter (in-memory, per process) ─────────────────────────────────────

_PR_TIMESTAMPS: deque = deque()   # timestamps of recent PR creations
_MAX_PRS_PER_HOUR = 5
_ONE_HOUR = 3600


def _check_rate_limit() -> None:
    """Raise RuntimeError if more than 5 PRs have been created in the last hour."""
    now = time.time()
    # Purge timestamps older than 1 hour
    while _PR_TIMESTAMPS and now - _PR_TIMESTAMPS[0] > _ONE_HOUR:
        _PR_TIMESTAMPS.popleft()
    if len(_PR_TIMESTAMPS) >= _MAX_PRS_PER_HOUR:
        raise RuntimeError(
            f"Rate limit exceeded: at most {_MAX_PRS_PER_HOUR} PRs per hour."
        )


def _record_pr() -> None:
    _PR_TIMESTAMPS.append(time.time())


# ── Data classes ───────────────────────────────────────────────────────────────

@dataclass
class AutoPRResult:
    pr_url:           str       = ""
    branch:           str       = ""
    commits:          List[str] = field(default_factory=list)
    fixed_count:      int       = 0
    regression_count: int       = 0
    dry_run:          bool      = False


# ── GitHub REST API helpers ────────────────────────────────────────────────────

def _gh_request(
    method: str,
    url: str,
    token: str,
    payload: Optional[dict] = None,
) -> dict:
    """Make a GitHub REST API call using only stdlib urllib."""
    data = json.dumps(payload).encode("utf-8") if payload else None
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept":        "application/vnd.github+json",
        "Content-Type":  "application/json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent":    "TythanAI-AutoPR/1.0",
    }
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(
            f"GitHub API {method} {url} → HTTP {exc.code}: {body}"
        ) from exc


def _gh_get_default_branch(owner: str, repo: str, token: str) -> str:
    """Return the default branch name of a GitHub repo."""
    data = _gh_request("GET", f"https://api.github.com/repos/{owner}/{repo}", token)
    return data.get("default_branch", "main")


def _gh_get_ref_sha(owner: str, repo: str, token: str, branch: str) -> str:
    """Return the SHA of the tip of *branch*."""
    data = _gh_request(
        "GET",
        f"https://api.github.com/repos/{owner}/{repo}/git/refs/heads/{branch}",
        token,
    )
    return data["object"]["sha"]


def _gh_create_branch(
    owner: str, repo: str, token: str, new_branch: str, sha: str
) -> None:
    """Create a new branch pointing at *sha*."""
    _gh_request(
        "POST",
        f"https://api.github.com/repos/{owner}/{repo}/git/refs",
        token,
        {"ref": f"refs/heads/{new_branch}", "sha": sha},
    )


def _gh_get_file_sha(
    owner: str, repo: str, token: str, path: str, branch: str
) -> Optional[str]:
    """Return the blob SHA for an existing file (needed for updates), or None."""
    try:
        data = _gh_request(
            "GET",
            f"https://api.github.com/repos/{owner}/{repo}/contents/{urllib.parse.quote(path)}?ref={branch}",
            token,
        )
        return data.get("sha")
    except RuntimeError:
        return None


def _gh_put_file(
    owner: str,
    repo: str,
    token: str,
    path: str,
    content: str,
    message: str,
    branch: str,
    blob_sha: Optional[str] = None,
) -> str:
    """Create or update a file via the GitHub Contents API. Returns commit SHA."""
    payload: dict = {
        "message": message,
        "content": base64.b64encode(content.encode("utf-8")).decode("ascii"),
        "branch":  branch,
    }
    if blob_sha:
        payload["sha"] = blob_sha
    data = _gh_request(
        "PUT",
        f"https://api.github.com/repos/{owner}/{repo}/contents/{urllib.parse.quote(path)}",
        token,
        payload,
    )
    return data.get("commit", {}).get("sha", "")


def _gh_create_pr(
    owner: str,
    repo: str,
    token: str,
    head: str,
    base: str,
    title: str,
    body: str,
) -> str:
    """Open a PR and return its HTML URL."""
    data = _gh_request(
        "POST",
        f"https://api.github.com/repos/{owner}/{repo}/pulls",
        token,
        {
            "title": title,
            "body":  body,
            "head":  head,
            "base":  base,
        },
    )
    return data.get("html_url", "")


# ── PR body builder ────────────────────────────────────────────────────────────

def _build_pr_body(
    findings: List[dict],
    fixed_count: int,
    remaining_count: int,
) -> str:
    """Render the PR description from the template."""
    rows: List[str] = []
    for f in findings:
        severity = f.get("severity", "?")
        rule     = f.get("rule_id", f.get("cwe_id", "?"))
        file_    = f.get("file", "?")
        line     = f.get("line", 0)
        rows.append(f"| {severity} | {rule} | {file_} | {line} |")

    rows_md = "\n".join(rows) if rows else "| — | — | — | — |"

    return (
        "## TythanAI Auto-Fix\n"
        f"### Fixed {len(findings)} vulnerabilities\n"
        "| Severity | Rule | File | Line |\n"
        "|----------|------|------|------|\n"
        f"{rows_md}\n"
        "### Verification\n"
        f"Post-patch scan: {fixed_count} fixed, {remaining_count} remaining\n"
    )


# ── Patch helpers ──────────────────────────────────────────────────────────────

def _finding_to_Finding(f: dict) -> Optional[Finding]:
    """Convert a raw finding dict to a Finding model, best-effort."""
    try:
        return Finding(
            rule_id=f.get("rule_id", "UNKNOWN"),
            file=f.get("file", ""),
            line=int(f.get("line", 0)),
            severity=f.get("severity", "MEDIUM"),
            cwe_id=f.get("cwe", f.get("cwe_id", "")),
            description=f.get("description", ""),
            recommendation=f.get("recommendation", ""),
        )
    except Exception as exc:
        logger.debug("Could not convert finding to Finding model: %s", exc)
        return None


def _is_dependency_finding(f: dict) -> bool:
    source = f.get("source", "")
    return source in ("osv_scanner", "dependency_scanner", "dependency_scanner_static")


# ── Main agent ─────────────────────────────────────────────────────────────────

class AutoPRAgent:
    """
    Patches security findings and opens a GitHub Pull Request.

    Parameters
    ----------
    patch_agent:
        Optional PatchAgent instance.  A new one is created if not provided.
    """

    def __init__(self, patch_agent: Optional[PatchAgent] = None) -> None:
        self._patch_agent = patch_agent or PatchAgent()

    # ── Public ────────────────────────────────────────────────────────────────

    def run(
        self,
        findings:      List[dict],
        project_path:  str,
        github_token:  str,
        owner:         str,
        repo:          str,
        dry_run:       bool = False,
        scan_id:       Optional[str] = None,
    ) -> AutoPRResult:
        """
        Entry point.  Patches all findings and either prints a diff (dry_run)
        or opens a real GitHub PR.

        Parameters
        ----------
        findings:
            List of finding dicts from any TythanAI scanner.
        project_path:
            Absolute path to the local project root.
        github_token:
            GitHub personal access token with ``repo`` scope.
        owner:
            GitHub organisation or user name.
        repo:
            Repository name.
        dry_run:
            If True, print unified diff and return without any GitHub calls.
        scan_id:
            Optional scan identifier used in the branch name.

        Returns
        -------
        AutoPRResult
        """
        if not findings:
            logger.info("AutoPRAgent.run: no findings — nothing to do")
            return AutoPRResult(dry_run=dry_run)

        proj = Path(project_path)

        # ── 1. Group findings by file ─────────────────────────────────────────
        by_file: Dict[str, List[dict]] = {}
        dep_findings: List[dict] = []
        for f in findings:
            if _is_dependency_finding(f):
                dep_findings.append(f)
                continue
            file_path = f.get("file", "")
            if file_path:
                by_file.setdefault(file_path, []).append(f)

        # ── 2. Patch each file via PatchAgent ─────────────────────────────────
        # patched_files: {relative_path: new_content}
        patched_files: Dict[str, str] = {}
        diffs: List[str] = []
        fixed_count = 0

        for rel_path, file_findings in by_file.items():
            abs_path = proj / rel_path
            if not abs_path.exists():
                logger.debug("AutoPRAgent: file not found: %s", abs_path)
                continue

            try:
                original = abs_path.read_text(encoding="utf-8", errors="replace")
            except Exception as exc:
                logger.warning("AutoPRAgent: cannot read %s: %s", abs_path, exc)
                continue

            current = original
            for finding_dict in file_findings:
                model = _finding_to_Finding(finding_dict)
                if model is None:
                    continue
                try:
                    patched, explanation = self._patch_agent.generate(model, current)
                    if patched != current:
                        logger.debug(
                            "Patched %s line %d: %s",
                            rel_path, model.line, explanation[:80],
                        )
                        current = patched
                        fixed_count += 1
                except Exception as exc:
                    logger.warning(
                        "AutoPRAgent: patch failed for %s: %s", rel_path, exc
                    )

            if current != original:
                patched_files[rel_path] = current
                diff = "".join(
                    difflib.unified_diff(
                        original.splitlines(keepends=True),
                        current.splitlines(keepends=True),
                        fromfile=f"a/{rel_path}",
                        tofile=f"b/{rel_path}",
                    )
                )
                diffs.append(diff)

        # ── 3. Handle dependency findings ─────────────────────────────────────
        if dep_findings:
            try:
                fixer = DependencyFixer(str(proj))
                dep_fixes = fixer.compute_fixes(dep_findings)
                if dep_fixes and not dry_run:
                    fixer.apply_fixes(dep_fixes, backup=True)
                    for fix in dep_fixes:
                        fixed_count += 1
                        rel = str(Path(fix.file).relative_to(proj))
                        try:
                            patched_files[rel] = Path(fix.file).read_text(
                                encoding="utf-8", errors="replace"
                            )
                        except Exception:
                            pass
            except Exception as exc:
                logger.warning("AutoPRAgent: dependency fixer error: %s", exc)

        # ── 4. Dry-run — print diff, no GitHub calls ─────────────────────────
        if dry_run:
            for diff in diffs:
                print(diff)
            return AutoPRResult(
                fixed_count=fixed_count,
                dry_run=True,
            )

        # ── 5. Real mode — create branch + commits + PR ───────────────────────
        _check_rate_limit()

        sid    = scan_id or str(int(time.time()))
        branch = f"tythanai/auto-fix-{sid}"

        try:
            default_branch = _gh_get_default_branch(owner, repo, github_token)
            base_sha       = _gh_get_ref_sha(owner, repo, github_token, default_branch)
            _gh_create_branch(owner, repo, github_token, branch, base_sha)
        except RuntimeError as exc:
            logger.error("AutoPRAgent: failed to create branch: %s", exc)
            return AutoPRResult(fixed_count=fixed_count, dry_run=False)

        commit_shas: List[str] = []
        for rel_path, new_content in patched_files.items():
            try:
                blob_sha = _gh_get_file_sha(owner, repo, github_token, rel_path, branch)
                commit_sha = _gh_put_file(
                    owner=owner,
                    repo=repo,
                    token=github_token,
                    path=rel_path,
                    content=new_content,
                    message=f"fix(security): auto-patch {rel_path}",
                    branch=branch,
                    blob_sha=blob_sha,
                )
                if commit_sha:
                    commit_shas.append(commit_sha)
            except RuntimeError as exc:
                logger.warning(
                    "AutoPRAgent: failed to commit %s: %s", rel_path, exc
                )

        if not commit_shas:
            logger.warning("AutoPRAgent: no files committed — skipping PR creation")
            return AutoPRResult(branch=branch, fixed_count=fixed_count, dry_run=False)

        body  = _build_pr_body(findings, fixed_count, len(findings) - fixed_count)
        title = f"[TythanAI] Auto-fix {fixed_count} security finding(s) (scan {sid})"

        try:
            pr_url = _gh_create_pr(
                owner=owner,
                repo=repo,
                token=github_token,
                head=branch,
                base=default_branch,
                title=title,
                body=body,
            )
        except RuntimeError as exc:
            logger.error("AutoPRAgent: failed to create PR: %s", exc)
            return AutoPRResult(
                branch=branch,
                commits=commit_shas,
                fixed_count=fixed_count,
                dry_run=False,
            )

        _record_pr()

        return AutoPRResult(
            pr_url=pr_url,
            branch=branch,
            commits=commit_shas,
            fixed_count=fixed_count,
            regression_count=0,
            dry_run=False,
        )
