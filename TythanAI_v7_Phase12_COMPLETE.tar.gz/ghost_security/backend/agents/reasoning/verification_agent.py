"""
VerificationAgent — Assesses whether a finding is actually exploitable.

Reduces false positives by analyzing:
  - Data flow completeness (source → sink without sanitization)
  - Sanitization function presence
  - Context (authenticated endpoint, internal-only, etc.)
  - Reachability (is the vulnerable code actually reachable?)

Returns: CONFIRMED | LIKELY | POSSIBLE | UNLIKELY
"""
from __future__ import annotations

import logging
import re
from typing import Dict, List, Optional, Tuple

from backend.core.confidence import Finding

logger = logging.getLogger("tythanai.reasoning.verification")


# ---------------------------------------------------------------------------
# Status constants
# ---------------------------------------------------------------------------

STATUS_CONFIRMED = "CONFIRMED"
STATUS_LIKELY    = "LIKELY"
STATUS_POSSIBLE  = "POSSIBLE"
STATUS_UNLIKELY  = "UNLIKELY"

# ---------------------------------------------------------------------------
# Sanitization patterns per CWE family
# Each pattern, if found in the context, reduces exploitability confidence
# ---------------------------------------------------------------------------

_SANITIZATION_PATTERNS: Dict[str, List[str]] = {
    "CWE-89": [
        r"\bparamstyle\b",
        r"\.execute\s*\(\s*[\"'][^\"']*%s",           # ?,  %s placeholders
        r"\.execute\s*\(\s*[\"'][^\"']*\?",
        r"cursor\.execute\s*\([^,]+,\s*\(",            # execute(sql, (params,))
        r"\bprepare\s*\(",
        r"SQLAlchemy|sqlalchemy",
        r"django\.db|from django",
        r"peewee\.|tortoise\.",
        r"session\.query\(",
        r"\.filter\s*\(",                              # ORM filter
    ],
    "CWE-79": [
        r"html\.escape\s*\(",
        r"markupsafe\.escape",
        r"bleach\.clean\s*\(",
        r"cgi\.escape\s*\(",
        r"jinja2.*autoescape\s*=\s*True",
        r"\|safe\b",                                   # Jinja2 |safe (intentional, not a fix)
        r"escape\s*\(",
        r"DOMPurify\.sanitize",
        r"encodeURIComponent\s*\(",
        r"textContent\s*=",                            # DOM assignment, not innerHTML
    ],
    "CWE-78": [
        r"shlex\.quote\s*\(",
        r"shlex\.split\s*\(",
        r"subprocess\.run\s*\(\s*\[",                  # list-form (shell=False implied)
        r"subprocess\.Popen\s*\(\s*\[",
        r"shell\s*=\s*False",
        r"pipes\.quote\s*\(",
    ],
    "CWE-22": [
        r"os\.path\.realpath\s*\(",
        r"os\.path\.abspath\s*\(",
        r"Path\s*\([^)]*\)\.resolve\s*\(",
        r"startswith\s*\(",                            # startswith(BASE_DIR)
        r"\.resolve\(\)\.is_relative_to\s*\(",
        r"send_from_directory\s*\(",                   # Flask safe file send
    ],
    "CWE-798": [
        r"os\.environ\.get\s*\(",
        r"os\.environ\[",
        r"getenv\s*\(",
        r"dotenv|python-decouple",
        r"SecretStr\s*\(",                              # pydantic SecretStr
        r"vault\.|hvac\.",
    ],
    "CWE-327": [
        r"hashlib\.sha256\s*\(",
        r"hashlib\.sha3_",
        r"hashlib\.sha512\s*\(",
        r"hashlib\.blake2",
        r"bcrypt\.",
        r"argon2\.",
        r"scrypt\s*\(",
        r"pbkdf2_hmac\s*\(",
    ],
    "CWE-502": [
        r"json\.loads?\s*\(",
        r"msgpack\.",
        r"hmac\.compare_digest",
        r"itsdangerous\.",
        r"signed_pickle",
        r"cryptography\.",
    ],
    "CWE-918": [
        r"allowlist|allow_list|ALLOWED_HOSTS",
        r"urllib\.parse\.urlparse",
        r"tldextract\.",
        r"validators\.url\s*\(",
        r"ipaddress\.",
        r"socket\.getaddrinfo",
    ],
}

# Patterns indicating the data source is actually user-controlled
# (higher = more directly user-controlled)
_USER_TAINT_SOURCES = [
    (r"request\.(args|form|json|data|files|values|cookies|headers)\b",  0.95),
    (r"request\.get\s*\(",                                               0.95),
    (r"flask\.request|django\.http\.HttpRequest",                        0.90),
    (r"os\.environ\.get\s*\(",                                           0.60),
    (r"sys\.argv\b",                                                     0.70),
    (r"input\s*\(",                                                      0.85),
    (r"fileinput\.|sys\.stdin",                                          0.75),
]

# Patterns that suggest the code path may not be reachable / is restricted
_REACHABILITY_PENALTIES = [
    (r"@login_required",                   -0.20),
    (r"@requires_auth",                    -0.20),
    (r"@jwt_required",                     -0.20),
    (r"permission_classes\s*=",            -0.15),
    (r"if\s+request\.user\.is_staff\b",   -0.25),
    (r"if\s+request\.user\.is_superuser", -0.30),
    (r"INTERNAL_IPS|ALLOWED_HOSTS",        -0.10),
    (r"127\.0\.0\.1|localhost",            -0.10),
]


def _get_context_window(source: str, lineno: int, window: int = 5) -> str:
    """Return ±window lines around lineno as a single string."""
    if not source:
        return ""
    lines = source.splitlines()
    start = max(0, lineno - 1 - window)
    end   = min(len(lines), lineno - 1 + window + 1)
    return "\n".join(lines[start:end])


def _check_sanitization(context: str, cwe: str) -> Tuple[bool, List[str]]:
    """
    Check whether sanitization patterns are present in the context window.

    Returns (sanitized, [matched_patterns]).
    """
    matched = []
    for cwe_key, patterns in _SANITIZATION_PATTERNS.items():
        if cwe_key not in cwe:
            continue
        for pattern in patterns:
            if re.search(pattern, context, re.IGNORECASE):
                matched.append(pattern)
    return bool(matched), matched


def _check_user_taint(context: str, sources: List[str]) -> float:
    """
    Compute a taint source confidence score.

    Returns a float 0–1 indicating how likely the data is user-controlled.
    """
    # Check source annotations from the finding first
    for src in sources:
        if any(kw in src for kw in ("request", "user", "input", "form", "param")):
            return 0.95

    if not context:
        return 0.5  # unknown

    for pattern, confidence in _USER_TAINT_SOURCES:
        if re.search(pattern, context, re.IGNORECASE):
            return confidence

    return 0.4  # no obvious user-controlled source detected


def _check_reachability_modifiers(context: str) -> float:
    """
    Scan context for auth decorators or restriction indicators.

    Returns a signed float penalty (negative = reduces exploitability).
    """
    total = 0.0
    for pattern, penalty in _REACHABILITY_PENALTIES:
        if re.search(pattern, context, re.IGNORECASE):
            total += penalty
    return total


class VerificationAgent:
    """
    Verifies whether a finding is actually exploitable by analyzing
    sanitization presence, taint source reachability, and context.
    """

    def verify(
        self, finding: Finding, source_code: str = ""
    ) -> Tuple[str, float, str]:
        """
        Assess exploitability of the finding.

        Parameters
        ----------
        finding:
            The security finding to verify.
        source_code:
            Full source code of the affected file.

        Returns
        -------
        Tuple[status, confidence, rationale]
            status: CONFIRMED | LIKELY | POSSIBLE | UNLIKELY
            confidence: 0.0–1.0
            rationale: human-readable explanation of the decision
        """
        cwe = finding.cwe_id or ""

        # Extract context window around the finding line
        context = _get_context_window(source_code, finding.line) if source_code else ""
        if not context and finding.context_lines:
            context = "\n".join(finding.context_lines)

        # Base confidence from the finding itself
        base_confidence = finding.confidence

        # 1. Check if finding confidence already places it at CONFIRMED threshold
        high_confidence = base_confidence >= 0.8

        # 2. Check for sanitization in context
        sanitized, sanitization_matches = _check_sanitization(context, cwe)

        # 3. Check taint source is user-controlled
        taint_confidence = _check_user_taint(context, finding.sources)

        # 4. Check reachability modifiers (auth decorators, etc.)
        reach_modifier = _check_reachability_modifiers(context)

        # 5. Compute adjusted confidence
        adjusted_confidence = base_confidence * taint_confidence
        adjusted_confidence = max(0.0, min(1.0, adjusted_confidence + reach_modifier))

        # 6. Determine status
        if sanitized:
            # Sanitization present: reduce confidence significantly
            adjusted_confidence *= 0.3
            if adjusted_confidence < 0.2:
                status = STATUS_UNLIKELY
            elif adjusted_confidence < 0.4:
                status = STATUS_POSSIBLE
            else:
                status = STATUS_POSSIBLE
        elif high_confidence and taint_confidence >= 0.8 and reach_modifier >= -0.1:
            status = STATUS_CONFIRMED
        elif adjusted_confidence >= 0.65:
            status = STATUS_LIKELY
        elif adjusted_confidence >= 0.35:
            status = STATUS_POSSIBLE
        else:
            status = STATUS_UNLIKELY

        # 7. Build rationale
        rationale = self._build_rationale(
            finding, status, adjusted_confidence,
            sanitized, sanitization_matches,
            taint_confidence, reach_modifier, context,
        )

        logger.debug(
            "verify %s:%d cwe=%s status=%s confidence=%.2f",
            finding.file, finding.line, cwe, status, adjusted_confidence,
        )

        return status, round(adjusted_confidence, 3), rationale

    @staticmethod
    def _build_rationale(
        finding: Finding,
        status: str,
        confidence: float,
        sanitized: bool,
        sanitization_matches: List[str],
        taint_confidence: float,
        reach_modifier: float,
        context: str,
    ) -> str:
        parts = []

        parts.append(
            f"Verification result: {status} (adjusted confidence: {confidence:.0%}). "
            f"Scanner reported initial confidence of {finding.confidence:.0%} "
            f"for {finding.rule_id} at {finding.file}:{finding.line}."
        )

        if sanitized:
            sanitization_names = ", ".join(
                re.sub(r"\\b|\\s.*", "", p).strip("(").strip()
                for p in sanitization_matches[:3]
            )
            parts.append(
                f"Sanitization indicators detected in the code context "
                f"({sanitization_names}), suggesting a defensive control may already "
                "be in place. However, the control's completeness and correctness "
                "have not been fully verified — a bypass may still be possible."
            )
        else:
            parts.append(
                "No sanitization or neutralization functions were detected "
                f"in the {len(context.splitlines())}-line context window around the finding."
            )

        if taint_confidence >= 0.85:
            parts.append(
                "The data source is directly user-controlled (HTTP request parameters, "
                "form data, or JSON body), providing a clear taint path from attacker "
                "input to the vulnerable sink."
            )
        elif taint_confidence >= 0.60:
            parts.append(
                "The data source appears to be externally influenced but the exact "
                "taint path could not be confirmed from the available context window."
            )
        else:
            parts.append(
                "The taint source was not clearly identified in the visible context. "
                "The input may originate from environment variables or configuration "
                "rather than direct user input, reducing exploitability."
            )

        if reach_modifier < -0.15:
            parts.append(
                "Authentication or authorization decorators were detected near the "
                "vulnerable code, indicating this path may require elevated privileges "
                "to reach — reducing the effective attack surface."
            )
        elif reach_modifier < 0:
            parts.append(
                "Minor access restrictions were detected in the code context, "
                "suggesting the vulnerability may not be reachable by all attackers."
            )

        return " ".join(parts)
