"""Shared data models for the reasoning agent system."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class RootCause:
    summary: str                    # One-sentence root cause
    vulnerable_construct: str       # e.g. "string concatenation in SQL query"
    introduced_at: str              # file:line
    trust_boundary_violated: str    # what trust assumption is broken
    cwe_explanation: str            # why this matches the CWE


@dataclass
class ExploitScenario:
    scenario_id: str
    title: str
    attacker_type: str              # "remote unauthenticated", "authenticated user", etc.
    preconditions: List[str]
    attack_steps: List[str]         # numbered steps attacker takes
    payload_example: str            # actual payload string
    impact: str                     # what damage results
    exploitability: str             # HIGH/MEDIUM/LOW
    cvss_vector: str
    cvss_score: float


@dataclass
class PatchAssessment:
    is_correct: bool
    is_complete: bool
    introduces_new_issues: bool
    new_issues: List[str]
    correctness_explanation: str
    security_guarantee: str         # what security property the fix provides
    confidence: float               # 0.0-1.0


@dataclass
class RiskAssessment:
    business_impact: str            # "Data breach of all user records"
    likelihood: str                 # HIGH/MEDIUM/LOW
    exploitability: str
    affected_assets: List[str]
    blast_radius: str               # scope of damage
    regulatory_implications: List[str]   # GDPR, PCI-DSS, SOC2, etc.
    risk_score: float               # 0-100
    priority: str                   # IMMEDIATE/HIGH/MEDIUM/LOW
    sla_hours: int                  # recommended fix SLA in hours


@dataclass
class ReasoningResult:
    finding_id: str
    root_cause: RootCause
    exploit_scenario: ExploitScenario
    verification_status: str        # "CONFIRMED" | "LIKELY" | "POSSIBLE" | "UNLIKELY"
    verification_confidence: float
    verification_rationale: str
    patch_code: str
    patch_explanation: str
    patch_assessment: PatchAssessment
    risk_assessment: RiskAssessment
    full_narrative: str             # Complete human-readable explanation
    agent_chain: List[str]          # Which agents ran and in what order
