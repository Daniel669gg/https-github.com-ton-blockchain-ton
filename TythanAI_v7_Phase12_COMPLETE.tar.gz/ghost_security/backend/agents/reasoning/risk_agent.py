"""
RiskAgent — Computes business risk and prioritization for a finding.

Considers exploitability, asset criticality, regulatory exposure,
blast radius, and CVSS to produce a risk score and SLA recommendation.
"""
from __future__ import annotations

import logging
from typing import Dict, List

from backend.core.confidence import Finding
from backend.agents.reasoning.models import ExploitScenario, RiskAssessment

logger = logging.getLogger("tythanai.reasoning.risk")


# ---------------------------------------------------------------------------
# Business impact descriptions per CWE
# ---------------------------------------------------------------------------

_BUSINESS_IMPACT: Dict[str, str] = {
    "CWE-89": (
        "Complete database compromise: exfiltration of all user records, PII, credentials, "
        "and financial data; authentication bypass enabling account takeover"
    ),
    "CWE-79": (
        "Session hijacking enabling full account takeover; credential harvesting via phishing pages; "
        "malware distribution to all users visiting the page"
    ),
    "CWE-78": (
        "Full server compromise: arbitrary command execution as application user; "
        "lateral movement to internal network; data destruction capability"
    ),
    "CWE-22": (
        "Arbitrary file read enabling disclosure of configuration files, SSH keys, "
        ".env secrets, and source code; potential file write leading to RCE"
    ),
    "CWE-798": (
        "Direct credential exposure: API key abuse, service impersonation, cloud account takeover, "
        "unauthorized data access at the authenticated tier"
    ),
    "CWE-327": (
        "Cryptographic protection bypass: offline brute-forcing of hashed passwords, "
        "integrity forgery, certificate spoofing"
    ),
    "CWE-502": (
        "Arbitrary code execution via deserialization gadget chains; "
        "complete server compromise with persistence"
    ),
    "CWE-918": (
        "Internal network scanning, SSRF to cloud metadata service (AWS IMDS) for IAM credential theft; "
        "pivot to S3, RDS, internal APIs"
    ),
}

_DEFAULT_BUSINESS_IMPACT = (
    "Security control bypass enabling unauthorized access to application data or functionality"
)

# ---------------------------------------------------------------------------
# Affected assets by sink type keywords in rule_id
# ---------------------------------------------------------------------------

_SINK_ASSETS: Dict[str, List[str]] = {
    "sql":     ["database", "user records", "authentication data", "PII"],
    "cmd":     ["operating system", "server filesystem", "network"],
    "shell":   ["operating system", "server filesystem", "network"],
    "path":    ["filesystem", "configuration files", "secrets files"],
    "file":    ["filesystem", "configuration files", "secrets files"],
    "ssrf":    ["internal network", "cloud metadata", "IAM credentials"],
    "http":    ["internal network", "cloud metadata", "IAM credentials"],
    "secret":  ["external APIs", "cloud services", "third-party systems"],
    "hardcod": ["external APIs", "cloud services", "third-party systems"],
}

_DEFAULT_ASSETS = ["application data", "user sessions", "backend services"]

# ---------------------------------------------------------------------------
# Regulatory implications per CWE
# ---------------------------------------------------------------------------

_REGULATORY: Dict[str, List[str]] = {
    "CWE-89":  ["GDPR Art.32 (data security)", "PCI-DSS Req.6.3 (injection)", "SOC2 CC6.1"],
    "CWE-79":  ["GDPR Art.32 (data security)", "PCI-DSS Req.6.3 (injection)", "SOC2 CC6.1"],
    "CWE-798": ["GDPR Art.32 (data security)", "PCI-DSS Req.6.3 (injection)", "SOC2 CC6.1"],
    "CWE-78":  ["PCI-DSS Req.6.3", "SOC2 CC6.6 (logical access)", "ISO 27001 A.14.2"],
    "CWE-918": ["PCI-DSS Req.1.3 (network access)", "SOC2 CC6.6", "GDPR Art.25 (privacy by design)"],
    "CWE-327": ["PCI-DSS Req.4.2 (strong cryptography)", "FIPS 140-2", "SOC2 CC6.7"],
    "CWE-502": ["PCI-DSS Req.6.3", "SOC2 CC6.1", "ISO 27001 A.14.2"],
}

_DEFAULT_REGULATORY = ["SOC2 CC6.1", "ISO 27001 A.14.2"]

# ---------------------------------------------------------------------------
# Blast radius descriptions per vuln type keyword
# ---------------------------------------------------------------------------

_BLAST_RADIUS: Dict[str, str] = {
    "cmd":      "Full server compromise: all data, processes, network access",
    "shell":    "Full server compromise: all data, processes, network access",
    "command":  "Full server compromise: all data, processes, network access",
    "sql":      "All database tables accessible to the application user",
    "sqli":     "All database tables accessible to the application user",
    "path":     "All files readable by the application user on the server",
    "traversal": "All files readable by the application user on the server",
    "ssrf":     "All internal services reachable from the server; cloud metadata if cloud-hosted",
    "http":     "All internal services reachable from the server; cloud metadata if cloud-hosted",
    "secret":   "All systems using the exposed credential",
    "hardcod":  "All systems using the exposed credential",
}

_DEFAULT_BLAST_RADIUS = "Application tier and its directly accessible resources"


def _get_blast_radius(finding: Finding) -> str:
    """Determine blast radius based on rule_id and CWE."""
    rule_lower = finding.rule_id.lower()
    cwe_lower = (finding.cwe_id or "").lower()
    combined = rule_lower + " " + cwe_lower

    for keyword, blast in _BLAST_RADIUS.items():
        if keyword in combined:
            return blast

    # CWE-78 always full server
    if "cwe-78" in cwe_lower:
        return "Full server compromise: all data, processes, network access"

    return _DEFAULT_BLAST_RADIUS


def _get_affected_assets(finding: Finding) -> List[str]:
    """Determine affected assets from rule_id and CWE."""
    rule_lower = finding.rule_id.lower()
    cwe_lower = (finding.cwe_id or "").lower()
    combined = rule_lower + " " + cwe_lower

    for keyword, assets in _SINK_ASSETS.items():
        if keyword in combined:
            return list(assets)

    return list(_DEFAULT_ASSETS)


def _get_business_impact(finding: Finding) -> str:
    """Look up business impact by CWE."""
    cwe = finding.cwe_id or ""
    for cwe_key, impact in _BUSINESS_IMPACT.items():
        if cwe_key in cwe:
            return impact
    return _DEFAULT_BUSINESS_IMPACT


def _get_regulatory_implications(finding: Finding) -> List[str]:
    """Look up regulatory implications by CWE."""
    cwe = finding.cwe_id or ""
    for cwe_key, regs in _REGULATORY.items():
        if cwe_key in cwe:
            return list(regs)
    return list(_DEFAULT_REGULATORY)


def _compute_risk_score(
    cvss_score: float,
    exploit_exploitability: str,
    finding_severity: str,
) -> float:
    """
    Compute risk score 0-100.

    base_score = cvss_score * 10
    exploit_multiplier: HIGH=1.2, MEDIUM=1.0, LOW=0.7
    finding_severity_multiplier: CRITICAL=1.2, HIGH=1.0, MEDIUM=0.7, LOW=0.4
    risk_score = min(100.0, base_score * exploit_multiplier * finding_severity_multiplier)
    """
    base_score = cvss_score * 10.0

    exploit_multipliers = {"HIGH": 1.2, "MEDIUM": 1.0, "LOW": 0.7}
    exploit_mul = exploit_multipliers.get(exploit_exploitability.upper(), 1.0)

    severity_multipliers = {"CRITICAL": 1.2, "HIGH": 1.0, "MEDIUM": 0.7, "LOW": 0.4}
    sev_mul = severity_multipliers.get(finding_severity.upper(), 0.7)

    return min(100.0, base_score * exploit_mul * sev_mul)


def _compute_sla_hours(finding_severity: str, verification_exploitability: str) -> int:
    """
    Determine fix SLA in hours.

    CRITICAL + CONFIRMED/LIKELY → 4h
    CRITICAL + POSSIBLE → 24h
    HIGH + CONFIRMED/LIKELY → 24h
    HIGH + POSSIBLE → 72h
    MEDIUM → 168h (1 week)
    LOW → 720h (30 days)
    """
    # Note: verification_exploitability here is the exploit_scenario.exploitability
    severity = finding_severity.upper()
    exploit = verification_exploitability.upper()

    if severity == "CRITICAL":
        if exploit in ("HIGH",):
            return 4
        return 24
    if severity == "HIGH":
        if exploit in ("HIGH",):
            return 24
        return 72
    if severity == "MEDIUM":
        return 168
    return 720


def _compute_priority(risk_score: float) -> str:
    """Map risk score to priority tier."""
    if risk_score >= 85.0:
        return "IMMEDIATE"
    if risk_score >= 65.0:
        return "HIGH"
    if risk_score >= 40.0:
        return "MEDIUM"
    return "LOW"


class RiskAgent:
    """
    Computes business risk and prioritization for a security finding.

    Combines CVSS score, exploit scenario exploitability, finding severity,
    CWE-based business impact, regulatory exposure, and blast radius to
    produce a structured RiskAssessment with a numeric risk score and SLA.
    """

    def assess(
        self,
        finding: Finding,
        exploit_scenario: ExploitScenario,
    ) -> RiskAssessment:
        """
        Compute business risk for a finding.

        Parameters
        ----------
        finding:
            The security finding to assess.
        exploit_scenario:
            The exploit scenario produced by ExploitAgent, providing
            exploitability rating and CVSS score.

        Returns
        -------
        RiskAssessment
            Structured risk assessment with score, priority, SLA, and
            business impact context.
        """
        cvss_score = exploit_scenario.cvss_score
        exploitability = exploit_scenario.exploitability  # HIGH/MEDIUM/LOW

        business_impact = _get_business_impact(finding)
        affected_assets = _get_affected_assets(finding)
        regulatory_implications = _get_regulatory_implications(finding)
        blast_radius = _get_blast_radius(finding)

        risk_score = _compute_risk_score(cvss_score, exploitability, finding.severity)
        sla_hours = _compute_sla_hours(finding.severity, exploitability)
        priority = _compute_priority(risk_score)

        # Likelihood mirrors exploitability
        likelihood = exploitability  # HIGH/MEDIUM/LOW

        logger.debug(
            "risk_agent: %s:%d cwe=%s cvss=%.1f risk=%.1f priority=%s sla=%dh",
            finding.file, finding.line, finding.cwe_id,
            cvss_score, risk_score, priority, sla_hours,
        )

        return RiskAssessment(
            business_impact=business_impact,
            likelihood=likelihood,
            exploitability=exploitability,
            affected_assets=affected_assets,
            blast_radius=blast_radius,
            regulatory_implications=regulatory_implications,
            risk_score=round(risk_score, 1),
            priority=priority,
            sla_hours=sla_hours,
        )
