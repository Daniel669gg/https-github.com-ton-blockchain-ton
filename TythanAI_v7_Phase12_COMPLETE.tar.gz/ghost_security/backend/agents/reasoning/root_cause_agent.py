"""
RootCauseAgent — Traces a security finding back to its root cause.

Analyzes the finding's rule_id, CWE, code context, and source/sink
information to explain WHY the vulnerability exists, not just WHAT it is.
"""
from __future__ import annotations

import logging
import re
from typing import Dict, List, Optional, Tuple

from backend.core.confidence import Finding
from backend.agents.reasoning.models import RootCause

logger = logging.getLogger("tythanai.reasoning.root_cause")


# ---------------------------------------------------------------------------
# CWE family dispatch table
# Each entry: (construct_template, trust_boundary, cwe_explanation_template)
# ---------------------------------------------------------------------------

_CWE_KNOWLEDGE: Dict[str, Tuple[str, str, str]] = {
    "CWE-89": (
        "string concatenation or format interpolation in SQL query construction",
        "User-supplied input is embedded directly into a SQL statement without "
        "being treated as a data parameter, violating the trust boundary between "
        "untrusted HTTP input and the privileged database tier",
        "CWE-89 (SQL Injection) applies because user-controlled data is concatenated "
        "into a SQL string that is passed to a database execute() call. The database "
        "parser cannot distinguish between the query structure (trusted) and the "
        "injected data (untrusted), allowing an attacker to alter query semantics. "
        "Parameterized queries solve this by sending data and structure separately.",
    ),
    "CWE-79": (
        "unsanitized user input reflected or stored into an HTML response context",
        "User-supplied strings cross from the untrusted HTTP request into the "
        "trusted HTML document model without HTML-entity encoding, allowing browser "
        "script execution in another user's session context",
        "CWE-79 (Cross-Site Scripting) applies because user-controlled data reaches "
        "an HTML output sink without escaping angle brackets, quotes, or script "
        "characters. The browser parses the injected content as markup, executing "
        "attacker-supplied JavaScript in the victim's authenticated session.",
    ),
    "CWE-78": (
        "shell metacharacter injection via unsanitized string passed to a shell interpreter",
        "Untrusted user input is interpolated into an OS command string that is "
        "evaluated by a shell (/bin/sh), violating the boundary between HTTP request "
        "data and OS-level command execution privileges",
        "CWE-78 (OS Command Injection) applies because user-controlled data is "
        "concatenated into a command string executed with shell=True or via os.system(). "
        "The shell expands metacharacters (;, &&, |, $(), backticks) in attacker-supplied "
        "input, allowing arbitrary command execution with the server process's privileges.",
    ),
    "CWE-22": (
        "unsanitized ../ sequences in a user-supplied file path passed to open() or file system APIs",
        "User-supplied path components cross from the untrusted HTTP layer into the "
        "file system without being canonicalized against the intended base directory, "
        "allowing traversal outside the authorized directory tree",
        "CWE-22 (Path Traversal) applies because user input containing ../ sequences "
        "is used directly in file system operations. os.path.join() does not prevent "
        "traversal when the user-supplied segment is absolute or contains multiple ../ "
        "components. The resolved path must be verified to remain within BASE_DIR after "
        "calling os.path.realpath().",
    ),
    "CWE-798": (
        "hardcoded string literal assigned to a credential-bearing variable in source code",
        "A secret (password, API key, token) is embedded in version-controlled source "
        "rather than being sourced from a runtime secrets store, violating the boundary "
        "between code (public/team-visible) and credentials (need-to-know)",
        "CWE-798 (Use of Hard-coded Credentials) applies because a credential value "
        "is a string literal in source code. This means the secret appears in git "
        "history permanently, in build artefacts, and in any code review. Rotation "
        "requires a code change and re-deployment. Environment variables or a secrets "
        "manager decouple the secret lifetime from the code lifecycle.",
    ),
    "CWE-327": (
        "use of a cryptographically broken hash algorithm (MD5 or SHA-1) for security-sensitive operations",
        "Security-sensitive data (passwords, integrity checks, signatures) is processed "
        "with an algorithm that the cryptographic community has demonstrated to be "
        "vulnerable to collision and preimage attacks, breaking the trust guarantee "
        "that identical digests imply identical inputs",
        "CWE-327 (Use of a Broken or Risky Cryptographic Algorithm) applies because "
        "MD5 (broken since 2004) and SHA-1 (collision-vulnerable since 2017) are used "
        "in a context requiring collision resistance. Attackers can craft two different "
        "inputs with the same digest, undermining integrity checks and allowing "
        "hash-based authentication to be bypassed.",
    ),
    "CWE-502": (
        "deserialization of untrusted data using pickle or a similarly expressive serializer",
        "Data from an untrusted source crosses into the deserialization layer without "
        "signature verification, allowing the serialized object graph to reconstruct "
        "arbitrary Python objects including those with __reduce__ exploit payloads",
        "CWE-502 (Deserialization of Untrusted Data) applies because Python's pickle "
        "protocol supports arbitrary object reconstruction via the __reduce__ dunder. "
        "An attacker who controls the serialized bytes can craft a payload that calls "
        "os.system(), subprocess, or any other callable during unpickling, achieving "
        "remote code execution before any application-level validation runs.",
    ),
    "CWE-918": (
        "user-controlled URL passed to an outbound HTTP request function without allowlist validation",
        "A URL supplied by the user crosses from the HTTP request layer into an "
        "outbound network call made by the server, allowing the attacker to direct "
        "server-side requests to internal network resources that are unreachable from "
        "the public internet",
        "CWE-918 (Server-Side Request Forgery) applies because the server constructs "
        "and executes an HTTP request using an attacker-supplied URL. This allows "
        "scanning of internal network ranges (10.x, 172.16.x, 192.168.x), access to "
        "cloud instance metadata endpoints (169.254.169.254), and pivoting to internal "
        "services that rely on network-level isolation rather than authentication.",
    ),
}


def _extract_context_window(source: str, lineno: int, window: int = 5) -> List[str]:
    """Return ±window lines around lineno from source (1-indexed)."""
    if not source:
        return []
    lines = source.splitlines()
    start = max(0, lineno - 1 - window)
    end = min(len(lines), lineno - 1 + window + 1)
    return lines[start:end]


def _detect_vulnerable_construct(source_lines: List[str], cwe: str) -> Optional[str]:
    """Scan source lines for the specific vulnerable construct pattern."""
    joined = "\n".join(source_lines)

    if "CWE-89" in cwe:
        if re.search(r'execute\s*\(\s*f["\']', joined):
            return "f-string interpolation in cursor.execute()"
        if re.search(r'execute\s*\(.*["\'].*\+', joined):
            return "string concatenation in cursor.execute()"
        if re.search(r'execute\s*\(.*%\s*', joined):
            return "%-format string in cursor.execute()"
        return "string concatenation in SQL query construction"

    if "CWE-79" in cwe:
        if re.search(r'render_template_string\s*\(', joined):
            return "render_template_string() with unsanitized input"
        if re.search(r'Markup\s*\(', joined):
            return "Markup() wrapping of unsanitized input"
        if re.search(r'\.format\s*\(|f["\'].*{', joined):
            return "format string interpolation into HTML output"
        return "direct reflection of user input into HTML response"

    if "CWE-78" in cwe:
        if re.search(r'shell\s*=\s*True', joined):
            return "subprocess call with shell=True and user-controlled argument"
        if re.search(r'os\.system\s*\(', joined):
            return "os.system() call with user-controlled string"
        if re.search(r'os\.popen\s*\(', joined):
            return "os.popen() call with user-controlled string"
        return "shell command construction with unsanitized user input"

    if "CWE-22" in cwe:
        if re.search(r'open\s*\(.*\+', joined):
            return "string concatenation in open() path argument"
        if re.search(r'os\.path\.join\s*\(', joined):
            return "os.path.join() with user input lacking realpath() guard"
        return "unsanitized user path in file system operation"

    if "CWE-798" in cwe:
        if re.search(r'password\s*=\s*["\'][^"\']{4,}["\']', joined, re.IGNORECASE):
            return "hardcoded password string literal"
        if re.search(r'(api_key|token|secret)\s*=\s*["\'][^"\']{4,}["\']', joined, re.IGNORECASE):
            return "hardcoded API key or secret token"
        return "hardcoded credential as string literal"

    if "CWE-327" in cwe:
        if re.search(r'hashlib\.md5\s*\(', joined, re.IGNORECASE):
            return "hashlib.md5() for security-sensitive hashing"
        if re.search(r'hashlib\.sha1\s*\(', joined, re.IGNORECASE):
            return "hashlib.sha1() for security-sensitive hashing"
        return "broken cryptographic algorithm in security operation"

    if "CWE-502" in cwe:
        if re.search(r'pickle\.loads?\s*\(', joined):
            return "pickle.loads() on untrusted input"
        if re.search(r'yaml\.load\s*\((?!.*Loader)', joined):
            return "yaml.load() without safe Loader on untrusted input"
        return "unsafe deserialization of untrusted bytes"

    if "CWE-918" in cwe:
        if re.search(r'requests\.(get|post|put|delete)\s*\(', joined):
            return "requests.get/post() with user-supplied URL"
        if re.search(r'urllib\.request\.urlopen\s*\(', joined):
            return "urllib.request.urlopen() with user-supplied URL"
        return "outbound HTTP request with user-controlled target URL"

    return None


class RootCauseAgent:
    """
    Analyzes a Finding to determine the root cause of the vulnerability.

    Uses CWE family knowledge, source code pattern analysis, and source/sink
    context to produce a structured RootCause explanation.
    """

    def analyze(self, finding: Finding, source_code: str = "") -> RootCause:
        """
        Trace the finding back to its root cause.

        Parameters
        ----------
        finding:
            The security finding to analyze.
        source_code:
            Full source code of the affected file, used for context extraction.

        Returns
        -------
        RootCause
            Structured root cause explanation.
        """
        cwe = finding.cwe_id or ""
        introduced_at = f"{finding.file}:{finding.line}"

        # Extract source context for construct detection
        context_lines = (
            _extract_context_window(source_code, finding.line)
            if source_code
            else finding.context_lines
        )

        # Identify the specific vulnerable construct from source
        detected_construct = _detect_vulnerable_construct(context_lines, cwe)

        # Look up CWE family knowledge
        matched_cwe_key = None
        for cwe_key in _CWE_KNOWLEDGE:
            if cwe_key in cwe:
                matched_cwe_key = cwe_key
                break

        if matched_cwe_key:
            default_construct, trust_boundary, cwe_explanation = _CWE_KNOWLEDGE[matched_cwe_key]
            vulnerable_construct = detected_construct or default_construct
            summary = self._build_summary(finding, matched_cwe_key, vulnerable_construct)
        else:
            # Generic fallback
            vulnerable_construct = (
                detected_construct
                or finding.description
                or f"insecure pattern in {finding.rule_id}"
            )
            trust_boundary = (
                "Untrusted external input reaches a privileged internal operation "
                "without adequate validation or sanitization"
            )
            cwe_explanation = (
                f"{cwe} identifies a weakness where {finding.description or 'a security-sensitive operation'} "
                f"is performed without sufficient safeguards. The rule {finding.rule_id!r} flagged this "
                "pattern because the data flow from an external source reaches a sensitive sink "
                "without an intervening validation or sanitization step."
            )
            summary = (
                f"A {finding.severity.lower()}-severity vulnerability exists at {introduced_at} "
                f"where {vulnerable_construct} creates an exploitable security weakness."
            )

        return RootCause(
            summary=summary,
            vulnerable_construct=vulnerable_construct,
            introduced_at=introduced_at,
            trust_boundary_violated=trust_boundary,
            cwe_explanation=cwe_explanation,
        )

    @staticmethod
    def _build_summary(finding: Finding, cwe_key: str, construct: str) -> str:
        """Build a one-sentence root cause summary."""
        severity = finding.severity.lower()
        location = f"{finding.file}:{finding.line}"

        summaries = {
            "CWE-89": (
                f"A {severity} SQL injection exists at {location} because "
                f"{construct} allows attacker-controlled data to alter the "
                "structure of the SQL query sent to the database."
            ),
            "CWE-79": (
                f"A {severity} XSS vulnerability exists at {location} because "
                f"{construct} places unescaped user input into the HTML document "
                "where the browser will execute it as script."
            ),
            "CWE-78": (
                f"A {severity} command injection vulnerability exists at {location} "
                f"because {construct} passes user input through a shell interpreter "
                "that expands metacharacters into arbitrary OS commands."
            ),
            "CWE-22": (
                f"A {severity} path traversal vulnerability exists at {location} "
                f"because {construct} allows ../ sequences to escape the intended "
                "directory boundary and access arbitrary file system paths."
            ),
            "CWE-798": (
                f"A {severity} hardcoded credential exists at {location} where "
                f"{construct} embeds a secret in source code, permanently exposing "
                "it in version control history and build artefacts."
            ),
            "CWE-327": (
                f"A {severity} cryptographic weakness exists at {location} because "
                f"{construct} is collision-vulnerable and provides insufficient "
                "security guarantees for integrity-sensitive operations."
            ),
            "CWE-502": (
                f"A {severity} insecure deserialization vulnerability exists at {location} "
                f"because {construct} reconstructs arbitrary Python object graphs from "
                "attacker-controlled bytes, enabling remote code execution."
            ),
            "CWE-918": (
                f"A {severity} SSRF vulnerability exists at {location} because "
                f"{construct} allows an attacker to direct server-side requests to "
                "internal network resources and cloud metadata endpoints."
            ),
        }

        return summaries.get(
            cwe_key,
            (
                f"A {severity} security vulnerability ({cwe_key}) exists at {location} "
                f"where {construct} creates an exploitable condition."
            ),
        )
