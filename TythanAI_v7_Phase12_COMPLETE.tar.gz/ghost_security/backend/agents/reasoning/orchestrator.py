"""
ReasoningOrchestrator — Coordinates all reasoning agents for a finding.

Pipeline: RootCause → Exploit → Verify → Patch → Critique → Risk
Assembles a complete ReasoningResult with a human-readable narrative.
"""
from __future__ import annotations

import logging
from typing import List

from backend.core.confidence import Finding
from backend.agents.reasoning.models import ReasoningResult
from backend.agents.reasoning.root_cause_agent import RootCauseAgent
from backend.agents.reasoning.exploit_agent import ExploitAgent
from backend.agents.reasoning.verification_agent import VerificationAgent
from backend.agents.reasoning.patch_agent import PatchAgent
from backend.agents.reasoning.critic_agent import CriticAgent
from backend.agents.reasoning.risk_agent import RiskAgent

logger = logging.getLogger("tythanai.reasoning.orchestrator")


class ReasoningOrchestrator:
    """
    Coordinates all reasoning agents for a complete security finding analysis.

    Pipeline (in order):
      1. RootCauseAgent  — WHY the vulnerability exists
      2. ExploitAgent    — HOW an attacker would exploit it
      3. VerificationAgent — IS it actually exploitable?
      4. PatchAgent      — HOW to fix it
      5. CriticAgent     — IS the fix correct?
      6. RiskAgent       — WHAT is the business risk?
      7. Narrative       — Human-readable synthesis

    All agents are stateless; the orchestrator holds no mutable state between
    calls so it is safe to use from multiple threads.
    """

    def __init__(self) -> None:
        self._root_cause_agent = RootCauseAgent()
        self._exploit_agent = ExploitAgent()
        self._verification_agent = VerificationAgent()
        self._patch_agent = PatchAgent()
        self._critic_agent = CriticAgent()
        self._risk_agent = RiskAgent()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def reason(self, finding: Finding, source_code: str = "") -> ReasoningResult:
        """
        Run the full reasoning pipeline for a single finding.

        Parameters
        ----------
        finding:
            The security finding to analyze.
        source_code:
            Full source code of the affected file (optional but improves quality).

        Returns
        -------
        ReasoningResult
            Complete analysis with root cause, exploit scenario, patch,
            risk assessment, and human-readable narrative.
        """
        logger.info(
            "reasoning pipeline: start %s:%d rule=%s cwe=%s",
            finding.file, finding.line, finding.rule_id, finding.cwe_id,
        )

        # Step 1: Root cause analysis
        root_cause = self._root_cause_agent.analyze(finding, source_code)
        logger.debug("reasoning pipeline: root_cause done — %s", root_cause.summary[:80])

        # Step 2: Exploit scenario
        exploit_scenario = self._exploit_agent.build_scenario(finding, root_cause)
        logger.debug(
            "reasoning pipeline: exploit done — %s cvss=%.1f",
            exploit_scenario.title, exploit_scenario.cvss_score,
        )

        # Step 3: Verification
        verification_status, verification_confidence, verification_rationale = (
            self._verification_agent.verify(finding, source_code)
        )
        logger.debug(
            "reasoning pipeline: verify done — status=%s conf=%.2f",
            verification_status, verification_confidence,
        )

        # Step 4: Patch generation
        patched_code, patch_explanation = self._patch_agent.generate(finding, source_code)
        logger.debug("reasoning pipeline: patch done")

        # Step 5: Patch critique
        patch_assessment = self._critic_agent.critique(
            finding, source_code, patched_code, patch_explanation
        )
        logger.debug(
            "reasoning pipeline: critique done — correct=%s complete=%s conf=%.2f",
            patch_assessment.is_correct, patch_assessment.is_complete, patch_assessment.confidence,
        )

        # Step 6: Risk assessment
        risk_assessment = self._risk_agent.assess(finding, exploit_scenario)
        logger.debug(
            "reasoning pipeline: risk done — score=%.1f priority=%s sla=%dh",
            risk_assessment.risk_score, risk_assessment.priority, risk_assessment.sla_hours,
        )

        # Step 7: Build full narrative
        full_narrative = self._build_narrative(
            root_cause=root_cause,
            exploit_scenario=exploit_scenario,
            risk_assessment=risk_assessment,
            patch_explanation=patch_explanation,
            patch_assessment=patch_assessment,
            verification_status=verification_status,
            verification_confidence=verification_confidence,
            verification_rationale=verification_rationale,
        )

        logger.info(
            "reasoning pipeline: complete %s:%d risk=%.1f priority=%s",
            finding.file, finding.line, risk_assessment.risk_score, risk_assessment.priority,
        )

        return ReasoningResult(
            finding_id=finding.fingerprint(),
            root_cause=root_cause,
            exploit_scenario=exploit_scenario,
            verification_status=verification_status,
            verification_confidence=verification_confidence,
            verification_rationale=verification_rationale,
            patch_code=patched_code,
            patch_explanation=patch_explanation,
            patch_assessment=patch_assessment,
            risk_assessment=risk_assessment,
            full_narrative=full_narrative,
            agent_chain=[
                "RootCauseAgent",
                "ExploitAgent",
                "VerificationAgent",
                "PatchAgent",
                "CriticAgent",
                "RiskAgent",
            ],
        )

    def batch_reason(
        self,
        findings: List[Finding],
        source_code: str = "",
    ) -> List[ReasoningResult]:
        """
        Run the reasoning pipeline on a list of findings.

        Never raises — exceptions are caught per-finding so a single bad
        finding does not abort the entire batch.

        Parameters
        ----------
        findings:
            Security findings to analyze.
        source_code:
            Source code shared across all findings (e.g. the same file).

        Returns
        -------
        List[ReasoningResult]
            One result per successfully processed finding (failed findings
            are logged and skipped).
        """
        results: List[ReasoningResult] = []
        total = len(findings)

        for idx, finding in enumerate(findings, start=1):
            try:
                logger.debug(
                    "batch_reason: processing %d/%d %s:%d",
                    idx, total, finding.file, finding.line,
                )
                result = self.reason(finding, source_code)
                results.append(result)
            except Exception as exc:
                logger.error(
                    "batch_reason: failed for %s:%d rule=%s — %s",
                    finding.file, finding.line, finding.rule_id, exc,
                    exc_info=True,
                )

        logger.info(
            "batch_reason: completed %d/%d findings successfully",
            len(results), total,
        )
        return results

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_narrative(
        *,
        root_cause,
        exploit_scenario,
        risk_assessment,
        patch_explanation: str,
        patch_assessment,
        verification_status: str,
        verification_confidence: float,
        verification_rationale: str,
    ) -> str:
        """Assemble the multi-section human-readable narrative."""

        # Format numbered attack steps
        steps_text = "\n".join(
            f"  {i}. {step}"
            for i, step in enumerate(exploit_scenario.attack_steps, start=1)
        )

        regulatory_text = ", ".join(risk_assessment.regulatory_implications)

        narrative = (
            "## Root Cause\n"
            f"{root_cause.summary}\n"
            "\n"
            f"The vulnerability stems from {root_cause.vulnerable_construct}. "
            f"{root_cause.cwe_explanation}\n"
            "\n"
            "## Exploitation\n"
            f"An {exploit_scenario.attacker_type} attacker can exploit this vulnerability by:\n"
            f"{steps_text}\n"
            "\n"
            f"Example payload: {exploit_scenario.payload_example}\n"
            "\n"
            "## Real Risk\n"
            f"{risk_assessment.business_impact}\n"
            "\n"
            f"Regulatory exposure: {regulatory_text}\n"
            f"Blast radius: {risk_assessment.blast_radius}\n"
            f"Risk score: {risk_assessment.risk_score}/100 — "
            f"Fix SLA: {risk_assessment.sla_hours} hours\n"
            "\n"
            "## Remediation\n"
            f"{patch_explanation}\n"
            "\n"
            f"{patch_assessment.security_guarantee}\n"
            "\n"
            "## Verification Status\n"
            f"Status: {verification_status} "
            f"(confidence: {verification_confidence:.0%})\n"
            f"{verification_rationale}"
        )

        return narrative
