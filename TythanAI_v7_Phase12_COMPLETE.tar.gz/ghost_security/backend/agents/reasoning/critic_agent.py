"""
CriticAgent — Critically reviews a proposed patch for correctness and completeness.

Checks for:
  - Does the patch actually fix the vulnerability?
  - Does the patch introduce new vulnerabilities?
  - Is the patch complete (all code paths covered)?
  - Are there edge cases not handled?
"""
from __future__ import annotations

import logging
import re
from typing import Dict, List, Optional, Tuple

from backend.core.confidence import Finding
from backend.agents.reasoning.models import PatchAssessment

logger = logging.getLogger("tythanai.reasoning.critic")


# ---------------------------------------------------------------------------
# Correctness checks per CWE
# ---------------------------------------------------------------------------

def _critique_sql_injection(
    original: str, patched: str
) -> Tuple[bool, bool, List[str]]:
    """
    CWE-89: Is ALL user input parameterized?
    - Check patched code uses %s / ? placeholders with parameter tuples
    - Check there are no remaining f-strings or concatenations in execute()
    """
    issues = []

    # Bad patterns that indicate incomplete fixes
    remaining_fstring = re.search(r'\.execute\s*\(\s*f["\']', patched)
    remaining_concat  = re.search(r'\.execute\s*\(.*["\'].*\+', patched)
    # Only flag % injection when it's "% variable" (format-injection), NOT "%s" (parameterized placeholder)
    remaining_percent = re.search(r'\.execute\s*\(.*["\'].*%\s+[A-Za-z_]|\.execute\s*\(.*%\([A-Za-z_]', patched)

    if remaining_fstring:
        issues.append(
            "f-string interpolation still present in at least one execute() call — "
            "the patch is incomplete."
        )
    if remaining_concat:
        issues.append(
            "String concatenation still detected in an execute() call — "
            "not all injection points are covered by this patch."
        )
    if remaining_percent:
        issues.append(
            "%-format string injection still detected in an execute() call."
        )

    # Positive signals: parameterized form
    has_params = bool(
        re.search(r'\.execute\s*\([^,]+,\s*\(', patched)
        or re.search(r'\.execute\s*\("[^"]*%s[^"]*",', patched)
        or re.search(r'\.execute\s*\("[^"]*\?[^"]*",', patched)
    )

    is_correct  = has_params and not issues
    is_complete = is_correct and not remaining_fstring and not remaining_concat

    if not has_params:
        issues.append(
            "No parameterized query pattern (%s/? with tuple) detected in the patched code."
        )

    return is_correct, is_complete, issues


def _critique_xss(
    original: str, patched: str
) -> Tuple[bool, bool, List[str]]:
    """CWE-79: Is html.escape() applied to all outputs?"""
    issues = []

    has_escape = bool(
        re.search(r'html\.escape\s*\(', patched)
        or re.search(r'markupsafe\.escape\s*\(', patched)
        or re.search(r'bleach\.clean\s*\(', patched)
    )

    # Check for |safe in Jinja2 templates (bypasses autoescape)
    unsafe_marker = re.search(r'\|\s*safe\b', patched)
    if unsafe_marker:
        issues.append(
            "Jinja2 '|safe' filter detected in patched code — this explicitly disables "
            "autoescaping for that value and may reintroduce XSS if user input reaches it."
        )

    # Check if innerHTML assignment is used (DOM-based XSS risk)
    innerhtml = re.search(r'innerHTML\s*=', patched)
    if innerhtml:
        issues.append(
            "innerHTML assignment detected — use textContent or DOMPurify.sanitize() "
            "for DOM-based XSS prevention."
        )

    is_correct  = has_escape and not issues
    is_complete = is_correct

    if not has_escape:
        issues.append(
            "No html.escape(), markupsafe.escape(), or bleach.clean() call detected "
            "in the patched output context."
        )

    return is_correct, is_complete, issues


def _critique_command_injection(
    original: str, patched: str
) -> Tuple[bool, bool, List[str]]:
    """CWE-78: Is shell=False? Are args in a list? No string formatting?"""
    issues = []

    shell_true = re.search(r'\bshell\s*=\s*True\b', patched)
    if shell_true:
        issues.append(
            "shell=True is still present in the patched code — the fix is ineffective."
        )

    # Check list-form arguments (subprocess(['cmd', 'arg']))
    has_list_args = bool(re.search(r'subprocess\s*\.\s*\w+\s*\(\s*\[', patched))
    has_shlex     = bool(re.search(r'shlex\s*\.\s*(split|quote)\s*\(', patched))

    if not has_list_args and not has_shlex:
        issues.append(
            "Command arguments are not in list form and shlex.split/quote is not used. "
            "Without list-form arguments and shell=False, injection risk may persist."
        )

    # Detect f-string or % format in the command argument
    fstring_in_cmd = re.search(r'subprocess\s*\.\s*\w+\s*\(\s*\[.*f["\']', patched, re.DOTALL)
    if fstring_in_cmd:
        issues.append(
            "f-string formatting detected inside subprocess list arguments — "
            "ensure user input is not interpolated into any list element."
        )

    is_correct  = not shell_true and (has_list_args or has_shlex) and not fstring_in_cmd
    is_complete = is_correct and not issues

    return is_correct, is_complete, issues


def _critique_path_traversal(
    original: str, patched: str
) -> Tuple[bool, bool, List[str]]:
    """CWE-22: Is realpath check on the RESOLVED path? Not just the input?"""
    issues = []

    has_realpath = bool(
        re.search(r'os\.path\.realpath\s*\(', patched)
        or re.search(r'Path\s*\([^)]+\)\.resolve\s*\(', patched)
    )

    has_startswith = bool(re.search(r'\.startswith\s*\(', patched))

    if not has_realpath:
        issues.append(
            "os.path.realpath() or Path.resolve() not found in patched code — "
            "symlink traversal and ../ sequences are not neutralized."
        )

    if not has_startswith:
        issues.append(
            "No startswith() boundary check detected — the resolved path is not "
            "verified to remain within the intended base directory."
        )

    # Check that the check is on the RESOLVED variable, not the raw input
    # Heuristic: resolved var name appears in startswith() call
    realpath_m  = re.search(r'(\w+)\s*=\s*os\.path\.realpath\s*\(', patched)
    startswith_m = re.search(r'(\w+)\.startswith\s*\(', patched)

    if realpath_m and startswith_m:
        resolved_var = realpath_m.group(1)
        checked_var  = startswith_m.group(1)
        if resolved_var != checked_var:
            issues.append(
                f"startswith() is called on '{checked_var}' but realpath() result is stored "
                f"in '{resolved_var}' — ensure the boundary check is on the resolved path."
            )

    is_correct  = has_realpath and has_startswith and not issues
    is_complete = is_correct

    return is_correct, is_complete, issues


def _critique_hardcoded_secret(
    original: str, patched: str
) -> Tuple[bool, bool, List[str]]:
    """CWE-798: Is the env var name sensible? Is there a secure default?"""
    issues = []

    has_environ = bool(
        re.search(r'os\.environ\.get\s*\(', patched)
        or re.search(r'os\.environ\[', patched)
        or re.search(r'os\.getenv\s*\(', patched)
    )

    if not has_environ:
        issues.append(
            "No os.environ.get() or equivalent found — the secret may still be "
            "hardcoded in the patched code."
        )

    # Check that no literal secret-looking string remains
    secret_literal = re.search(
        r"""(password|passwd|secret|token|api_key|auth_key)\s*=\s*["'][^"']{8,}["']""",
        patched,
        re.IGNORECASE,
    )
    if secret_literal:
        issues.append(
            "A hardcoded secret-looking string literal is still present in the patched code."
        )

    # Check that env var default is empty string, not a fallback secret
    bad_default = re.search(
        r"""os\.environ\.get\s*\([^)]+,\s*["'][^"']{8,}["']\s*\)""",
        patched,
    )
    if bad_default:
        issues.append(
            "os.environ.get() default value is a non-empty string — this may itself "
            "be a hardcoded fallback secret. Use an empty string or raise ValueError."
        )

    is_correct  = has_environ and not secret_literal
    is_complete = is_correct and not issues

    return is_correct, is_complete, issues


def _critique_weak_crypto(
    original: str, patched: str
) -> Tuple[bool, bool, List[str]]:
    """CWE-327: Is the weak algorithm fully replaced?"""
    issues = []

    still_md5  = bool(re.search(r'\bhashlib\s*\.\s*md5\s*\(', patched, re.IGNORECASE))
    still_sha1 = bool(re.search(r'\bhashlib\s*\.\s*sha1\s*\(', patched, re.IGNORECASE))

    if still_md5:
        issues.append("hashlib.md5() is still present in the patched code.")
    if still_sha1:
        issues.append("hashlib.sha1() is still present in the patched code.")

    has_strong = bool(
        re.search(r'hashlib\s*\.\s*sha256\s*\(', patched)
        or re.search(r'hashlib\s*\.\s*sha3_', patched)
        or re.search(r'hashlib\s*\.\s*sha512\s*\(', patched)
        or re.search(r'hashlib\s*\.\s*blake2', patched)
    )

    if not has_strong:
        issues.append(
            "No strong hash algorithm (sha256, sha3, sha512, blake2) detected "
            "in the patched code."
        )

    is_correct  = has_strong and not still_md5 and not still_sha1
    is_complete = is_correct and not issues

    return is_correct, is_complete, issues


def _critique_deserialization(
    original: str, patched: str
) -> Tuple[bool, bool, List[str]]:
    """CWE-502: Is pickle.loads fully removed?"""
    issues = []

    still_pickle = bool(re.search(r'\bpickle\s*\.\s*loads?\s*\(', patched, re.IGNORECASE))
    still_yaml_unsafe = bool(re.search(r'\byaml\s*\.\s*load\s*\((?!.*Loader)', patched))

    if still_pickle:
        issues.append("pickle.loads() is still present in the patched code.")
    if still_yaml_unsafe:
        issues.append(
            "yaml.load() without a safe Loader is still present — use yaml.safe_load()."
        )

    has_safe = bool(
        re.search(r'\bjson\s*\.\s*loads?\s*\(', patched)
        or re.search(r'yaml\s*\.\s*safe_load\s*\(', patched)
        or re.search(r'itsdangerous\s*\.', patched)
        or re.search(r'msgpack\s*\.', patched)
    )

    if not has_safe:
        issues.append(
            "No safe deserialization alternative (json.loads, yaml.safe_load, itsdangerous) "
            "detected in the patched code."
        )

    is_correct  = has_safe and not still_pickle and not still_yaml_unsafe
    is_complete = is_correct and not issues

    return is_correct, is_complete, issues


def _critique_ssrf(
    original: str, patched: str
) -> Tuple[bool, bool, List[str]]:
    """CWE-918: Is there an allowlist check before the outbound request?"""
    issues = []

    has_allowlist = bool(
        re.search(r'ALLOWED_HOSTS|allowlist|allow_list', patched, re.IGNORECASE)
    )
    has_urlparse = bool(re.search(r'urlparse\s*\(', patched))
    has_scheme_check = bool(re.search(r"scheme.*in\s*\(", patched))

    if not has_allowlist:
        issues.append(
            "No ALLOWED_HOSTS or allowlist variable detected — SSRF is not mitigated."
        )
    if not has_urlparse:
        issues.append(
            "No URL parsing (urlparse) detected — the hostname is not being validated."
        )

    # Check for empty allowlist (frozenset() with no entries)
    empty_allowlist = re.search(r'ALLOWED_HOSTS\s*=\s*frozenset\(\)', patched)
    if empty_allowlist:
        issues.append(
            "ALLOWED_HOSTS is an empty frozenset() — populate it with the permitted "
            "hostnames before deploying."
        )

    is_correct  = has_allowlist and has_urlparse and not issues
    is_complete = is_correct and not empty_allowlist

    return is_correct, is_complete, issues


# ---------------------------------------------------------------------------
# New issue detection — patterns that might be introduced by a patch
# ---------------------------------------------------------------------------

_NEW_ISSUE_PATTERNS = [
    (r'\beval\s*\(',                "eval() introduced in patched code (CWE-95 risk)"),
    (r'\bexec\s*\(',                "exec() introduced in patched code (CWE-95 risk)"),
    (r'shell\s*=\s*True',           "shell=True introduced in patched code (CWE-78 risk)"),
    (r'\bpickle\b',                 "pickle usage introduced in patched code (CWE-502 risk)"),
    (r'__reduce__',                 "__reduce__ method introduced (deserialization risk)"),
    (r'os\.system\s*\(',           "os.system() introduced (CWE-78 risk)"),
    (r'open\s*\(.*\+',             "String concatenation in open() introduced (CWE-22 risk)"),
]


def _detect_new_issues(original: str, patched: str) -> List[str]:
    """Find patterns in patched code that were not in the original."""
    new_issues = []
    for pattern, message in _NEW_ISSUE_PATTERNS:
        in_original = bool(re.search(pattern, original, re.IGNORECASE))
        in_patched  = bool(re.search(pattern, patched,  re.IGNORECASE))
        if in_patched and not in_original:
            new_issues.append(message)
    return new_issues


# ---------------------------------------------------------------------------
# CWE → critic dispatch
# ---------------------------------------------------------------------------

_CRITIC_DISPATCH = {
    "CWE-89":  _critique_sql_injection,
    "CWE-79":  _critique_xss,
    "CWE-78":  _critique_command_injection,
    "CWE-22":  _critique_path_traversal,
    "CWE-798": _critique_hardcoded_secret,
    "CWE-327": _critique_weak_crypto,
    "CWE-328": _critique_weak_crypto,
    "CWE-502": _critique_deserialization,
    "CWE-918": _critique_ssrf,
}


class CriticAgent:
    """
    Reviews a proposed patch for correctness, completeness, and
    whether it introduces new security issues.
    """

    def critique(
        self,
        finding: Finding,
        original_code: str,
        patched_code: str,
        explanation: str,
    ) -> PatchAssessment:
        """
        Critically assess the proposed patch.

        Parameters
        ----------
        finding:
            The security finding the patch addresses.
        original_code:
            The original (unpatched) source code.
        patched_code:
            The source code after applying the patch.
        explanation:
            The PatchAgent's explanation of what was changed and why.

        Returns
        -------
        PatchAssessment
        """
        cwe = finding.cwe_id or ""

        # Resolve the correctness checker
        checker = None
        for cwe_key, fn in _CRITIC_DISPATCH.items():
            if cwe_key in cwe:
                checker = fn
                break

        if checker:
            is_correct, is_complete, correctness_issues = checker(original_code, patched_code)
        else:
            # Generic: did anything change?
            is_correct  = patched_code != original_code
            is_complete = is_correct
            correctness_issues = (
                [] if is_correct
                else [f"No changes detected for {cwe or finding.rule_id} — patch may not have applied."]
            )

        # Check for newly introduced issues
        new_issues = _detect_new_issues(original_code, patched_code)
        introduces_new = bool(new_issues)

        # Build correctness explanation
        correctness_explanation = self._build_correctness_explanation(
            finding, is_correct, is_complete, correctness_issues, cwe,
        )

        # Security guarantee
        security_guarantee = self._build_security_guarantee(cwe, is_correct)

        # Confidence: penalize for issues found
        confidence = self._compute_confidence(
            is_correct, is_complete, introduces_new, len(correctness_issues), len(new_issues)
        )

        return PatchAssessment(
            is_correct=is_correct,
            is_complete=is_complete,
            introduces_new_issues=introduces_new,
            new_issues=new_issues,
            correctness_explanation=correctness_explanation,
            security_guarantee=security_guarantee,
            confidence=confidence,
        )

    @staticmethod
    def _build_correctness_explanation(
        finding: Finding,
        is_correct: bool,
        is_complete: bool,
        issues: List[str],
        cwe: str,
    ) -> str:
        if is_correct and is_complete and not issues:
            return (
                f"The patch correctly addresses {cwe or finding.rule_id}. "
                "All relevant patterns were transformed to use the secure alternative, "
                "and no incomplete fixe patterns were detected in the patched code."
            )
        parts = []
        if not is_correct:
            parts.append(
                f"The patch does not fully correct {cwe or finding.rule_id}."
            )
        elif not is_complete:
            parts.append(
                f"The patch is partially correct for {cwe or finding.rule_id} "
                "but may not cover all code paths."
            )
        for issue in issues:
            parts.append(f"Issue: {issue}")
        return " ".join(parts) if parts else "Patch assessment inconclusive — manual review recommended."

    @staticmethod
    def _build_security_guarantee(cwe: str, is_correct: bool) -> str:
        if not is_correct:
            return (
                "The security guarantee cannot be established because the patch does not "
                "fully correct the identified vulnerability. Manual remediation is required."
            )

        guarantees = {
            "CWE-89": (
                "Parameterized queries guarantee that user-supplied values are transmitted "
                "as bound parameters, never parsed as SQL syntax by the database engine. "
                "UNION injection, boolean/time-based blind injection, and stacked queries "
                "are all neutralized by this fix."
            ),
            "CWE-79": (
                "html.escape() guarantees that the five HTML special characters are replaced "
                "with entities before browser parsing. The browser renders injected content "
                "as visible text, never as executable script or markup."
            ),
            "CWE-78": (
                "List-form subprocess arguments with shell=False guarantee that the OS "
                "executes the specified binary directly via execve(), bypassing the shell "
                "interpreter. Metacharacters in any argument are treated as literals."
            ),
            "CWE-22": (
                "os.path.realpath() + startswith(BASE_DIR) guarantees that all ../ sequences "
                "and symlinks are resolved before the boundary check. Any path that resolves "
                "outside BASE_DIR is rejected before any file system operation occurs."
            ),
            "CWE-798": (
                "os.environ.get() guarantees the secret is sourced from the process environment "
                "at runtime and never embedded in source code or build artefacts. "
                "The secret is not recoverable from the repository after this change "
                "(rotate immediately for any previously committed secrets)."
            ),
            "CWE-327": (
                "SHA-256 provides 128-bit collision resistance, meeting current NIST SP 800-131A "
                "requirements. It is computationally infeasible to find two inputs with the "
                "same digest using current hardware."
            ),
            "CWE-502": (
                "json.loads() can only construct strings, numbers, lists, and dicts — it cannot "
                "invoke arbitrary callables during parsing. Remote code execution via deserialization "
                "is eliminated by this fix."
            ),
            "CWE-918": (
                "The allowlist check guarantees that only pre-approved hostnames can be the "
                "target of server-side requests. Cloud metadata endpoints, RFC-1918 addresses, "
                "and localhost cannot be reached because they are not in the allowlist."
            ),
        }

        for cwe_key, guarantee in guarantees.items():
            if cwe_key in cwe:
                return guarantee

        return (
            "The patch applies a security control appropriate for the identified vulnerability. "
            "Verify the fix using a security-focused code review and targeted penetration testing."
        )

    @staticmethod
    def _compute_confidence(
        is_correct: bool,
        is_complete: bool,
        introduces_new: bool,
        n_correctness_issues: int,
        n_new_issues: int,
    ) -> float:
        base = 0.90
        if not is_correct:
            base -= 0.40
        if not is_complete:
            base -= 0.10
        if introduces_new:
            base -= 0.15
        base -= n_correctness_issues * 0.05
        base -= n_new_issues * 0.10
        return round(max(0.0, min(1.0, base)), 3)
