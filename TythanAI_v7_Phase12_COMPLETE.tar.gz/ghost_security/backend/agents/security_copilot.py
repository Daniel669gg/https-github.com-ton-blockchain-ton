"""
backend/agents/security_copilot.py — Autonomous Security Copilot (TythanAI)

Orchestrates the full Scan → Analyze → Verify → Explain → Patch → Report cycle.

PatchGenerator produces real code transformations using AST + regex:
  - SQL injection      → parameterized queries
  - Command injection  → list-based subprocess (no shell=True)
  - Path traversal     → os.path.realpath + directory prefix validation
  - Weak crypto        → MD5/SHA1 replaced with SHA256
  - Hardcoded secrets  → os.environ.get() substitution

SecurityCopilot coordinates TaintAnalyzer + RuleDSL and returns structured
reports consumed by downstream dashboards and PR-comment integrations.
"""
from __future__ import annotations

import ast
import hashlib
import logging
import os
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from backend.core.confidence import Finding
from backend.scanners.taint_analyzer import TaintAnalyzer
from backend.core.rule_dsl import RuleDSL

logger = logging.getLogger("tythanai.security_copilot")

# ─────────────────────────────────────────────────────────────────────────────
# OWASP Top-10 (2021) category mapping by CWE
# ─────────────────────────────────────────────────────────────────────────────

_CWE_TO_OWASP: Dict[str, str] = {
    "CWE-89":  "A03:2021 – Injection",
    "CWE-78":  "A03:2021 – Injection",
    "CWE-77":  "A03:2021 – Injection",
    "CWE-95":  "A03:2021 – Injection",
    "CWE-22":  "A01:2021 – Broken Access Control",
    "CWE-23":  "A01:2021 – Broken Access Control",
    "CWE-35":  "A01:2021 – Broken Access Control",
    "CWE-327": "A02:2021 – Cryptographic Failures",
    "CWE-328": "A02:2021 – Cryptographic Failures",
    "CWE-330": "A02:2021 – Cryptographic Failures",
    "CWE-798": "A07:2021 – Identification and Authentication Failures",
    "CWE-259": "A07:2021 – Identification and Authentication Failures",
    "CWE-502": "A08:2021 – Software and Data Integrity Failures",
    "CWE-117": "A09:2021 – Security Logging and Monitoring Failures",
    "CWE-20":  "A03:2021 – Injection",
}

_SEVERITY_ORDER: Dict[str, int] = {
    "CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0,
}


# ─────────────────────────────────────────────────────────────────────────────
# Patch data structure
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PatchResult:
    """A concrete code patch for a single finding."""
    finding_fingerprint: str
    rule_id: str
    file: str
    line: int
    vuln_type: str
    original_snippet: str
    patched_snippet: str
    explanation: str
    confidence: float
    applied: bool = False


# ─────────────────────────────────────────────────────────────────────────────
# AST helpers shared by PatchGenerator
# ─────────────────────────────────────────────────────────────────────────────

def _get_source_line(source: str, lineno: int) -> str:
    """Return the 1-indexed source line (empty string if out-of-range)."""
    lines = source.splitlines()
    if 1 <= lineno <= len(lines):
        return lines[lineno - 1]
    return ""


def _indent_of(line: str) -> str:
    """Return the leading whitespace of *line*."""
    return line[: len(line) - len(line.lstrip())]


def _replace_line(source: str, lineno: int, new_line: str) -> str:
    """Replace 1-indexed *lineno* in *source* with *new_line*."""
    lines = source.splitlines(keepends=True)
    if 1 <= lineno <= len(lines):
        # Preserve original line ending
        ending = "\n" if lines[lineno - 1].endswith("\n") else ""
        lines[lineno - 1] = new_line.rstrip("\n") + ending
    return "".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# PatchGenerator
# ─────────────────────────────────────────────────────────────────────────────

# Regex: detect string concatenation / f-string fed into execute(...)
# e.g.   cursor.execute("SELECT * FROM users WHERE id=" + user_id)
# e.g.   cursor.execute(f"SELECT ... {user_input}")
# e.g.   cursor.execute("SELECT ... %s" % value)
_SQL_CONCAT_RE = re.compile(
    r"""(?x)
    (?:cursor|conn|db|connection|session)\s*\.\s*execute\s*\(   # sink
    \s*
    (?:
        f["'].*?["']                   # f-string
      | ["'].*?["']\s*\+              # string concat start
      | ["'].*?["']\s*%\s*            # %-format
    )
    """,
    re.DOTALL,
)

# Regex: detect subprocess.run/call/Popen with shell=True
_SHELL_TRUE_RE = re.compile(
    r"""(?x)
    (?:subprocess\s*\.\s*(?:run|call|Popen|check_output|check_call))
    \s*\(
    (?P<args>[^)]+)
    \)\s*$
    """,
    re.DOTALL,
)

# Matches shell=True anywhere in argument list
_SHELL_TRUE_FLAG_RE = re.compile(r"\bshell\s*=\s*True\b")

# Regex: detect open(user_path, ...) without realpath guard
_OPEN_PATH_RE = re.compile(
    r"""(?x)
    \bopen\s*\(\s*
    (?P<path_arg>[A-Za-z_]\w*(?:\s*\+\s*[A-Za-z_]\w*)*)  # variable(s) as path
    (?:\s*,\s*["'][rwab+]+["'])?                          # optional mode
    \s*\)
    """
)

# Regex: detect hashlib.md5 / hashlib.sha1
_WEAK_HASH_RE = re.compile(
    r"""(?x)
    \bhashlib\s*\.\s*(?P<alg>md5|sha1)\s*\(
    """,
    re.IGNORECASE,
)

# Regex: detect hardcoded string literals assigned to credential variables
_HARDCODED_SECRET_RE = re.compile(
    r"""(?x)
    (?P<var>[A-Za-z_]\w*)
    \s*=\s*
    (?P<quote>["'])(?P<value>[^"']{8,})(?P=quote)
    """,
)

# Keywords that indicate the variable is a credential
_SECRET_KEYWORDS = (
    "password", "passwd", "secret", "token", "api_key", "api_secret",
    "auth_key", "access_key", "private_key", "secret_key", "aws_secret",
)


class PatchGenerator:
    """
    Generates real, runnable code patches for common vulnerability classes.

    Each ``patch_*`` method receives the raw source text of the file and the
    1-indexed line number of the finding, and returns a PatchResult describing
    the original snippet and its corrected replacement.  The replacement is
    always syntactically valid Python.
    """

    # ------------------------------------------------------------------
    # SQL Injection (CWE-89)
    # ------------------------------------------------------------------

    def patch_sql_injection(
        self, source: str, lineno: int, fingerprint: str
    ) -> Optional[PatchResult]:
        """Replace string-interpolated execute() with a parameterized query."""
        line = _get_source_line(source, lineno)
        indent = _indent_of(line)

        # Try to parse the execute() call via AST to extract the query string
        # and the tainted variables.
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return None

        target_node: Optional[ast.Call] = None
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if getattr(node, "lineno", -1) != lineno:
                continue
            if isinstance(node.func, ast.Attribute) and node.func.attr in (
                "execute", "executemany"
            ):
                target_node = node
                break

        if target_node is None or not target_node.args:
            return None

        query_arg = target_node.args[0]

        # Case 1: f-string  →  extract placeholders and build params tuple
        if isinstance(query_arg, ast.JoinedStr):
            param_vars: List[str] = []
            static_parts: List[str] = []
            for segment in query_arg.values:
                if isinstance(segment, ast.Constant):
                    static_parts.append(segment.value)
                elif isinstance(segment, ast.FormattedValue):
                    placeholder = "?"
                    static_parts.append(placeholder)
                    if isinstance(segment.value, ast.Name):
                        param_vars.append(segment.value.id)
                    elif isinstance(segment.value, ast.Attribute):
                        param_vars.append(
                            ast.unparse(segment.value)
                        )
                    else:
                        param_vars.append(ast.unparse(segment.value))

            if not param_vars:
                return None

            new_query = "".join(static_parts)
            params_str = ", ".join(param_vars)
            # Reconstruct the method call with cursor/conn name
            obj_src = ast.unparse(target_node.func.value)
            method = target_node.func.attr
            new_line = (
                f'{indent}{obj_src}.{method}("{new_query}", ({params_str},))'
            )
            explanation = (
                "Replaced f-string SQL interpolation with a parameterized query "
                "using '?' placeholders. User-supplied values are now passed as "
                "a tuple, preventing SQL injection (CWE-89)."
            )

        # Case 2: binary concatenation or %-format  →  conservative placeholder
        elif isinstance(query_arg, (ast.BinOp, ast.Call)):
            # Extract all Name nodes from the query argument as tainted params
            param_vars = [
                node.id
                for node in ast.walk(query_arg)
                if isinstance(node, ast.Name)
            ]
            if not param_vars:
                return None

            obj_src = ast.unparse(target_node.func.value)
            method = target_node.func.attr
            # Reconstruct query string with placeholders by unparsing the
            # concatenation and replacing variable references with '?'
            raw_query = ast.unparse(query_arg)
            # Build a sanitised constant query part if we can isolate it
            const_parts = [
                n.value
                for n in ast.walk(query_arg)
                if isinstance(n, ast.Constant) and isinstance(n.value, str)
            ]
            if const_parts:
                # Simplistic: use first string constant as base and append ?
                # for each tainted var detected.
                base_query = const_parts[0].rstrip() + " " + " ".join(
                    "?" for _ in param_vars
                )
            else:
                base_query = "/* parameterized query */ " + " ".join(
                    "?" for _ in param_vars
                )

            params_str = ", ".join(param_vars)
            new_line = (
                f'{indent}{obj_src}.{method}("{base_query}", ({params_str},))'
            )
            explanation = (
                "Replaced string-concatenated SQL query with a parameterized "
                "execute() call. '?' placeholders prevent injection of "
                "user-controlled values into the SQL statement (CWE-89)."
            )
        else:
            return None

        return PatchResult(
            finding_fingerprint=fingerprint,
            rule_id="TAINT-SQL_INJECTION",
            file="",
            line=lineno,
            vuln_type="sql_injection",
            original_snippet=line.rstrip(),
            patched_snippet=new_line,
            explanation=explanation,
            confidence=0.88,
        )

    # ------------------------------------------------------------------
    # Command Injection (CWE-78)
    # ------------------------------------------------------------------

    def patch_command_injection(
        self, source: str, lineno: int, fingerprint: str
    ) -> Optional[PatchResult]:
        """Replace shell=True subprocess calls with list-argument form."""
        line = _get_source_line(source, lineno)
        indent = _indent_of(line)

        if not _SHELL_TRUE_FLAG_RE.search(line):
            return None

        # Remove shell=True from the argument list
        patched_line = _SHELL_TRUE_FLAG_RE.sub("", line)
        # Clean up any trailing comma artifacts:  , )  →  )
        patched_line = re.sub(r",\s*\)", ")", patched_line)
        patched_line = re.sub(r"\(\s*,", "(", patched_line)

        # If the first argument is a plain string command, convert to shlex split
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return None

        target_node: Optional[ast.Call] = None
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Call)
                and getattr(node, "lineno", -1) == lineno
                and isinstance(node.func, ast.Attribute)
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == "subprocess"
            ):
                target_node = node
                break

        if target_node and target_node.args:
            first_arg = target_node.args[0]
            if isinstance(first_arg, ast.Constant) and isinstance(
                first_arg.value, str
            ):
                # Split the command string into a list
                import shlex
                try:
                    parts = shlex.split(first_arg.value)
                    list_repr = repr(parts)
                    # Replace the string literal with its list form in the line
                    old_str = ast.unparse(first_arg)
                    patched_line = patched_line.replace(old_str, list_repr, 1)
                except ValueError:
                    pass  # shlex parse failed, keep the removal of shell=True only

        # If first arg is a Name (variable holding the command string), wrap it
        # with shlex.split() to hint that the caller should split it.
        elif target_node and target_node.args:
            first_arg = target_node.args[0]
            if isinstance(first_arg, (ast.Name, ast.JoinedStr, ast.BinOp)):
                old_str = ast.unparse(first_arg)
                patched_line = patched_line.replace(
                    old_str, f"shlex.split({old_str})", 1
                )

        explanation = (
            "Removed 'shell=True' and converted the command to a list of "
            "arguments. When shell=True is absent, the OS executes the binary "
            "directly without passing through /bin/sh, eliminating shell "
            "metacharacter injection (CWE-78). Add 'import shlex' if "
            "shlex.split() was introduced."
        )

        return PatchResult(
            finding_fingerprint=fingerprint,
            rule_id="TAINT-SHELL_INJECTION",
            file="",
            line=lineno,
            vuln_type="command_injection",
            original_snippet=line.rstrip(),
            patched_snippet=patched_line.rstrip(),
            explanation=explanation,
            confidence=0.90,
        )

    # ------------------------------------------------------------------
    # Path Traversal (CWE-22)
    # ------------------------------------------------------------------

    def patch_path_traversal(
        self, source: str, lineno: int, fingerprint: str
    ) -> Optional[PatchResult]:
        """Insert os.path.realpath guard and base-directory validation."""
        line = _get_source_line(source, lineno)
        indent = _indent_of(line)

        m = _OPEN_PATH_RE.search(line)
        if not m:
            return None

        path_expr = m.group("path_arg").strip()

        # Build the safe replacement:
        # 1. Resolve symlinks and normalise: os.path.realpath(path_expr)
        # 2. Check the result starts within an allowed base directory.
        #
        # We emit TWO lines: the guard assignment + the open() call.
        safe_path_var = f"_safe_{path_expr.split('_')[0] if '_' in path_expr else path_expr[:8]}"
        safe_path_var = re.sub(r"[^A-Za-z0-9_]", "_", safe_path_var)

        guard_lines = [
            f"{indent}{safe_path_var} = os.path.realpath(os.path.join(BASE_DIR, {path_expr}))",
            f"{indent}if not {safe_path_var}.startswith(os.path.realpath(BASE_DIR)):",
            f"{indent}    raise PermissionError(f\"Path traversal blocked: {{{path_expr}!r}}\")",
        ]
        patched_open = line.replace(path_expr, safe_path_var, 1).rstrip()
        patched_snippet = "\n".join(guard_lines + [patched_open])

        explanation = (
            f"Introduced os.path.realpath() to canonicalise '{path_expr}' "
            "before the open() call, then verified the resolved path starts "
            "within BASE_DIR. This prevents directory traversal attacks "
            "(CWE-22) via '../' sequences or symlinks. Define BASE_DIR as the "
            "intended root (e.g. BASE_DIR = '/var/app/uploads')."
        )

        return PatchResult(
            finding_fingerprint=fingerprint,
            rule_id="TAINT-PATH_TRAVERSAL",
            file="",
            line=lineno,
            vuln_type="path_traversal",
            original_snippet=line.rstrip(),
            patched_snippet=patched_snippet,
            explanation=explanation,
            confidence=0.85,
        )

    # ------------------------------------------------------------------
    # Weak Cryptography (CWE-327/CWE-328)
    # ------------------------------------------------------------------

    def patch_weak_crypto(
        self, source: str, lineno: int, fingerprint: str
    ) -> Optional[PatchResult]:
        """Replace hashlib.md5 / hashlib.sha1 with hashlib.sha256."""
        line = _get_source_line(source, lineno)

        m = _WEAK_HASH_RE.search(line)
        if not m:
            return None

        old_alg = m.group("alg")  # 'md5' or 'sha1'
        patched_line = _WEAK_HASH_RE.sub("hashlib.sha256(", line)

        explanation = (
            f"Replaced hashlib.{old_alg}() with hashlib.sha256(). "
            f"{old_alg.upper()} is cryptographically broken and must not be "
            "used for security-sensitive operations such as password hashing, "
            "HMAC computation, or digital signatures (CWE-327). "
            "For passwords, prefer hashlib.scrypt() or bcrypt."
        )

        return PatchResult(
            finding_fingerprint=fingerprint,
            rule_id="TAINT-WEAK_CRYPTO",
            file="",
            line=lineno,
            vuln_type="weak_crypto",
            original_snippet=line.rstrip(),
            patched_snippet=patched_line.rstrip(),
            explanation=explanation,
            confidence=0.95,
        )

    # ------------------------------------------------------------------
    # Hardcoded Secrets (CWE-798)
    # ------------------------------------------------------------------

    def patch_hardcoded_secret(
        self, source: str, lineno: int, fingerprint: str
    ) -> Optional[PatchResult]:
        """Replace string-literal credential assignment with os.environ.get()."""
        line = _get_source_line(source, lineno)
        indent = _indent_of(line)

        # Identify assignment with credential-name variable
        m = _HARDCODED_SECRET_RE.search(line)
        if not m:
            return None

        var_name = m.group("var")
        literal_value = m.group("value")

        # Only patch if the variable name looks like a credential
        var_lower = var_name.lower()
        if not any(kw in var_lower for kw in _SECRET_KEYWORDS):
            return None

        # Derive a sensible env-var name: uppercase with prefix
        env_var = var_name.upper()
        # Default fallback preserves the type (str); do not embed the real value
        patched_line = (
            f"{indent}{var_name} = os.environ.get(\"{env_var}\", \"\")"
        )

        explanation = (
            f"Replaced hardcoded credential for '{var_name}' with "
            f"os.environ.get(\"{env_var}\", \"\"). "
            "Hard-coded secrets in source code are exposed in version control "
            "and build artefacts (CWE-798). Store secrets in environment "
            "variables, a secrets manager (HashiCorp Vault, AWS Secrets "
            "Manager), or a .env file excluded from version control. "
            "Add 'import os' at the top of the file if not already present."
        )

        return PatchResult(
            finding_fingerprint=fingerprint,
            rule_id="HARDCODED-SECRET-001",
            file="",
            line=lineno,
            vuln_type="hardcoded_secret",
            original_snippet=line.rstrip(),
            patched_snippet=patched_line,
            explanation=explanation,
            confidence=0.92,
        )

    # ------------------------------------------------------------------
    # Dispatcher
    # ------------------------------------------------------------------

    # Maps rule_id prefixes / CWE IDs to patch methods
    _VULN_DISPATCH: Dict[str, str] = {
        "sql_injection":     "patch_sql_injection",
        "TAINT-SQL":         "patch_sql_injection",
        "CWE-89":            "patch_sql_injection",
        "shell_injection":   "patch_command_injection",
        "command_injection": "patch_command_injection",
        "TAINT-SHELL":       "patch_command_injection",
        "CWE-78":            "patch_command_injection",
        "path_traversal":    "patch_path_traversal",
        "TAINT-PATH":        "patch_path_traversal",
        "CWE-22":            "patch_path_traversal",
        "weak_crypto":       "patch_weak_crypto",
        "TAINT-WEAK":        "patch_weak_crypto",
        "CWE-327":           "patch_weak_crypto",
        "CWE-328":           "patch_weak_crypto",
        "hardcoded_secret":  "patch_hardcoded_secret",
        "HARDCODED-SECRET":  "patch_hardcoded_secret",
        "CWE-798":           "patch_hardcoded_secret",
    }

    def generate(
        self, finding: Finding, source: str
    ) -> Optional[PatchResult]:
        """
        Select and invoke the appropriate patch method for *finding*.

        Resolution order: rule_id prefix → CWE ID → description keyword.
        Returns None when no patch strategy applies.
        """
        fingerprint = finding.fingerprint()
        method_name: Optional[str] = None

        # Try rule_id prefix
        for key, method in self._VULN_DISPATCH.items():
            if finding.rule_id.startswith(key) or key in finding.rule_id:
                method_name = method
                break

        # Try CWE
        if method_name is None and finding.cwe_id:
            for cwe in finding.cwe_id.split(","):
                cwe = cwe.strip()
                if cwe in self._VULN_DISPATCH:
                    method_name = self._VULN_DISPATCH[cwe]
                    break

        if method_name is None:
            logger.debug(
                "No patch strategy for rule=%s cwe=%s",
                finding.rule_id, finding.cwe_id,
            )
            return None

        patch_fn = getattr(self, method_name, None)
        if patch_fn is None:
            return None

        try:
            result = patch_fn(source, finding.line, fingerprint)
        except Exception as exc:
            logger.warning(
                "PatchGenerator.%s raised for %s:%d: %s",
                method_name, finding.file, finding.line, exc,
            )
            return None

        if result is not None:
            result.file = finding.file
        return result


# ─────────────────────────────────────────────────────────────────────────────
# Severity grouper helper
# ─────────────────────────────────────────────────────────────────────────────

def _severity_breakdown(findings: List[Finding]) -> Dict[str, int]:
    counts: Dict[str, int] = {
        "CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0,
    }
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1
    return counts


# ─────────────────────────────────────────────────────────────────────────────
# SecurityCopilot
# ─────────────────────────────────────────────────────────────────────────────

# Built-in DSL rules added programmatically (no YAML file dependency at runtime)
_BUILTIN_DSL_YAML = """
version: "1.0"
rules:
  - id: copilot-weak-hash
    name: Weak Hash Algorithm (MD5/SHA1)
    language: python
    severity: HIGH
    cwe: [CWE-327]
    owasp: [A02:2021]
    patterns:
      - "hashlib.md5("
      - "hashlib.sha1("
    message: "Use of cryptographically broken hash function"
    confidence: 0.90
    dataflow: false

  - id: copilot-path-open
    name: Unsanitized Path in open()
    language: python
    severity: HIGH
    cwe: [CWE-22]
    owasp: [A01:2021]
    sources:
      - flask.request.args
      - flask.request.form
      - os.environ.get
    sinks:
      - builtins.open
      - pathlib.Path
    message: "User-controlled path passed to open() without realpath validation"
    confidence: 0.80
    dataflow: true

  - id: copilot-eval-exec
    name: Dynamic Code Execution
    language: python
    severity: CRITICAL
    cwe: [CWE-95]
    owasp: [A03:2021]
    patterns:
      - "eval("
      - "exec("
    message: "Dynamic code execution via eval()/exec() is dangerous"
    confidence: 0.85
    dataflow: false
"""


class SecurityCopilot:
    """
    Autonomous Security Copilot — orchestrates the full security analysis
    lifecycle for a Python source path.

    Workflow:
        scan()  →  analyze()  →  generate_patches()

    Or use full_cycle() to run all stages and return a single structured report.
    """

    def __init__(
        self,
        confidence_threshold: float = 0.65,
        rules_dir: Optional[str] = None,
    ) -> None:
        self._threshold = confidence_threshold
        self._taint = TaintAnalyzer(confidence_threshold=confidence_threshold)
        self._dsl = RuleDSL()
        self._patcher = PatchGenerator()

        # Load built-in DSL rules from the inline YAML string
        import io
        import yaml
        try:
            data = yaml.safe_load(_BUILTIN_DSL_YAML)
            for raw_rule in data.get("rules", []):
                rule, err = self._dsl._parse_rule(raw_rule, "<builtin>", 0)
                if rule:
                    self._dsl.add_rule(rule)
                    logger.debug("Loaded built-in rule: %s", rule.rule_id)
                elif err:
                    logger.warning("Built-in rule parse error: %s", err)
        except Exception as exc:
            logger.warning("Could not load built-in DSL rules: %s", exc)

        # Optionally load additional YAML rules from a user-supplied directory
        if rules_dir and os.path.isdir(rules_dir):
            result = self._dsl.load_directory(rules_dir, recursive=True)
            logger.info(
                "Loaded %d user DSL rules from %s (%d errors)",
                result.rules_count, rules_dir, len(result.errors),
            )

    # ------------------------------------------------------------------
    # scan
    # ------------------------------------------------------------------

    def scan(self, path: str) -> List[Finding]:
        """
        Run TaintAnalyzer + DSL rules against *path* (file or directory).

        Returns a deduplicated, confidence-filtered list of Finding objects
        sorted by severity (CRITICAL first).
        """
        if not os.path.exists(path):
            raise FileNotFoundError(f"Scan target not found: {path!r}")

        taint_findings: List[Finding] = []
        dsl_findings: List[Finding] = []

        if os.path.isdir(path):
            taint_findings = self._taint.analyze_directory(path)
            # Also run DSL rules on every .py file in the directory
            for root, dirs, files in os.walk(path):
                dirs[:] = [d for d in dirs if d not in {"__pycache__", ".venv", ".git"}]
                for fname in files:
                    if fname.endswith(".py"):
                        fpath = os.path.join(root, fname)
                        try:
                            code = open(fpath, encoding="utf-8", errors="replace").read()
                            dsl_findings.extend(self._dsl.execute_all(fpath, code))
                        except OSError:
                            pass
        else:
            taint_findings = self._taint.analyze_file(path)
            try:
                code = open(path, encoding="utf-8", errors="replace").read()
                dsl_findings = self._dsl.execute_all(path, code)
            except OSError:
                pass

        # Combine and deduplicate by fingerprint
        all_findings: List[Finding] = taint_findings + dsl_findings
        seen: Dict[str, Finding] = {}
        for f in all_findings:
            key = f.fingerprint()
            if key not in seen or _SEVERITY_ORDER.get(f.severity, 0) > _SEVERITY_ORDER.get(
                seen[key].severity, 0
            ):
                seen[key] = f

        # Filter by confidence and sort by severity
        result = [
            f for f in seen.values()
            if not f.is_suppressed and f.confidence >= self._threshold
        ]
        result.sort(
            key=lambda f: (
                -_SEVERITY_ORDER.get(f.severity, 0),
                -f.confidence,
            )
        )

        logger.info(
            "scan(%s): %d taint + %d DSL → %d unique findings above threshold",
            path, len(taint_findings), len(dsl_findings), len(result),
        )
        return result

    # ------------------------------------------------------------------
    # analyze
    # ------------------------------------------------------------------

    def analyze(self, findings: List[Finding]) -> List[Dict[str, Any]]:
        """
        Enrich and group findings by severity bucket.

        Each entry in the returned list represents one finding augmented with:
        - owasp_category: OWASP Top-10 2021 category for the CWE
        - severity_rank: integer 0–4 for sorting
        - group: severity bucket label

        Returns: sorted list (CRITICAL first), each element is a dict.
        """
        enriched: List[Dict[str, Any]] = []

        for f in findings:
            # Resolve OWASP category from CWE ID
            owasp_category = "A00:2021 – Unknown"
            for cwe in f.cwe_id.split(","):
                cwe = cwe.strip()
                if cwe in _CWE_TO_OWASP:
                    owasp_category = _CWE_TO_OWASP[cwe]
                    break

            sev_rank = _SEVERITY_ORDER.get(f.severity, 0)

            enriched.append({
                "fingerprint":     f.fingerprint(),
                "rule_id":         f.rule_id,
                "file":            f.file,
                "line":            f.line,
                "severity":        f.severity,
                "severity_rank":   sev_rank,
                "confidence":      f.confidence,
                "cwe_id":          f.cwe_id,
                "owasp_category":  owasp_category,
                "description":     f.description,
                "recommendation":  f.recommendation,
                "group":           f.severity,
                "context_lines":   f.context_lines,
                "sources":         f.sources,
            })

        # Sort: severity desc, then confidence desc
        enriched.sort(key=lambda d: (-d["severity_rank"], -d["confidence"]))
        return enriched

    # ------------------------------------------------------------------
    # generate_patches
    # ------------------------------------------------------------------

    def generate_patches(
        self, findings: List[Finding], source: str
    ) -> List[Dict[str, Any]]:
        """
        Attempt to generate a real code patch for each finding.

        *source* is the full text of the scanned file.  For multi-file scans
        the caller should group findings by file and call this once per file.

        Returns: list of dicts (one per finding that has a patch), each with
        keys: finding_fingerprint, rule_id, file, line, vuln_type,
              original_snippet, patched_snippet, explanation, confidence.
        """
        patches: List[Dict[str, Any]] = []
        for finding in findings:
            result = self._patcher.generate(finding, source)
            if result is None:
                continue
            patches.append({
                "finding_fingerprint": result.finding_fingerprint,
                "rule_id":            result.rule_id,
                "file":               result.file or finding.file,
                "line":               result.line,
                "vuln_type":          result.vuln_type,
                "original_snippet":   result.original_snippet,
                "patched_snippet":    result.patched_snippet,
                "explanation":        result.explanation,
                "patch_confidence":   result.confidence,
            })

        logger.info(
            "generate_patches: %d/%d findings have patches",
            len(patches), len(findings),
        )
        return patches

    # ------------------------------------------------------------------
    # full_cycle
    # ------------------------------------------------------------------

    def full_cycle(self, path: str) -> Dict[str, Any]:
        """
        Execute the complete Scan → Analyze → Patch cycle and return a
        structured report.

        Return schema:
            {
              "path": str,
              "scan_id": str,           # UUID-4 short
              "timestamp": str,         # ISO-8601 UTC
              "findings_count": int,
              "severity_breakdown": {CRITICAL, HIGH, MEDIUM, LOW, INFO: int},
              "analyzed_findings": List[Dict],
              "patches": List[Dict],
              "patches_count": int,
              "patch_coverage_pct": float,
              "recommendations": List[str],
              "overall_risk": str,      # CRITICAL / HIGH / MEDIUM / LOW / CLEAR
            }
        """
        scan_id = str(uuid.uuid4())[:8].upper()
        timestamp = datetime.now(tz=timezone.utc).isoformat()

        # ── Stage 1: Scan ──────────────────────────────────────────────────
        findings = self.scan(path)

        # ── Stage 2: Analyze ───────────────────────────────────────────────
        analyzed = self.analyze(findings)

        # ── Stage 3: Patch (per-file) ──────────────────────────────────────
        all_patches: List[Dict[str, Any]] = []

        if os.path.isfile(path):
            try:
                source_text = open(path, encoding="utf-8", errors="replace").read()
                all_patches = self.generate_patches(findings, source_text)
            except OSError:
                pass
        else:
            # Group findings by file and patch each file individually
            from itertools import groupby
            sorted_by_file = sorted(findings, key=lambda f: f.file)
            for file_path, file_findings in groupby(sorted_by_file, key=lambda f: f.file):
                file_findings_list = list(file_findings)
                try:
                    src = open(file_path, encoding="utf-8", errors="replace").read()
                    all_patches.extend(self.generate_patches(file_findings_list, src))
                except OSError:
                    continue

        # ── Stage 4: Recommendations ───────────────────────────────────────
        sev_breakdown = _severity_breakdown(findings)
        recommendations = self._build_recommendations(findings, all_patches)
        overall_risk = self._overall_risk(sev_breakdown)

        patch_coverage = (
            round(len(all_patches) / len(findings) * 100, 1)
            if findings else 0.0
        )

        report: Dict[str, Any] = {
            "path":              path,
            "scan_id":           scan_id,
            "timestamp":         timestamp,
            "findings_count":    len(findings),
            "severity_breakdown": sev_breakdown,
            "analyzed_findings": analyzed,
            "patches":           all_patches,
            "patches_count":     len(all_patches),
            "patch_coverage_pct": patch_coverage,
            "recommendations":   recommendations,
            "overall_risk":      overall_risk,
        }

        logger.info(
            "full_cycle scan_id=%s path=%s findings=%d patches=%d risk=%s",
            scan_id, path, len(findings), len(all_patches), overall_risk,
        )
        return report

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _overall_risk(sev_breakdown: Dict[str, int]) -> str:
        """Derive overall risk label from severity counts."""
        if sev_breakdown.get("CRITICAL", 0) > 0:
            return "CRITICAL"
        if sev_breakdown.get("HIGH", 0) > 0:
            return "HIGH"
        if sev_breakdown.get("MEDIUM", 0) > 0:
            return "MEDIUM"
        if sev_breakdown.get("LOW", 0) > 0:
            return "LOW"
        return "CLEAR"

    @staticmethod
    def _build_recommendations(
        findings: List[Finding], patches: List[Dict[str, Any]]
    ) -> List[str]:
        """Generate actionable, deduplicated recommendations from findings."""
        recs: Dict[str, str] = {}

        for f in findings:
            if "CWE-89" in f.cwe_id or "sql_injection" in f.rule_id.lower():
                recs["sql"] = (
                    "Migrate all SQL execute() calls to parameterized queries. "
                    "Consider using an ORM (SQLAlchemy, Django ORM) to eliminate "
                    "raw SQL construction."
                )
            if "CWE-78" in f.cwe_id or "shell" in f.rule_id.lower():
                recs["shell"] = (
                    "Eliminate shell=True from all subprocess calls. Pass command "
                    "arguments as a list and validate each element against an "
                    "allowlist before execution."
                )
            if "CWE-22" in f.cwe_id or "path" in f.rule_id.lower():
                recs["path"] = (
                    "Apply os.path.realpath() to all user-controlled file paths "
                    "and verify the resolved path is within the intended base "
                    "directory before opening or writing."
                )
            if "CWE-327" in f.cwe_id or "CWE-328" in f.cwe_id or "crypto" in f.rule_id.lower():
                recs["crypto"] = (
                    "Replace MD5 and SHA-1 with SHA-256 or SHA-3 for all "
                    "security-relevant hashing. For password storage use "
                    "hashlib.scrypt() or bcrypt with an appropriate cost factor."
                )
            if "CWE-798" in f.cwe_id or "HARDCODED" in f.rule_id:
                recs["secrets"] = (
                    "Remove all hard-coded secrets from source code. Rotate any "
                    "exposed credentials immediately. Store secrets in environment "
                    "variables or a dedicated secrets manager and add them to "
                    ".gitignore / secret-scanning pre-commit hooks."
                )
            if "CWE-502" in f.cwe_id or "pickle" in f.description.lower():
                recs["pickle"] = (
                    "Replace pickle.loads() with a safe serialization format "
                    "(json, msgpack) for any data that crosses a trust boundary."
                )

        # Universal best practices appended once
        recs["dep_scan"] = (
            "Run dependency vulnerability scanning (pip-audit, safety) in CI "
            "and pin all direct dependencies to known-good versions."
        )

        if patches:
            pct = round(len(patches) / max(len(findings), 1) * 100)
            recs["patches"] = (
                f"Auto-patches were generated for {len(patches)} finding(s) "
                f"({pct}% coverage). Review each patch in a dedicated branch, "
                "run the full test suite, and open a PR for human review before "
                "merging."
            )

        return list(recs.values())
