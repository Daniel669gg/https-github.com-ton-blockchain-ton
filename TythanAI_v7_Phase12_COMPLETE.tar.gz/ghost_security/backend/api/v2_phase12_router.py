"""
backend/api/v2_phase12_router.py — TythanAI Phase 12 API endpoints.

Mount with:
    from backend.api.v2_phase12_router import router as phase12_router
    app.include_router(phase12_router, prefix="/api/v2/phase12")

Endpoints:
    POST /scan/quality           — Code quality scan
    POST /scan/dast              — DAST passive/active scan
    POST /scan/swift             — Swift scanner
    POST /scan/multichain        — Solana+CosmWasm auditor
    POST /autopr                 — Generate fix PRs (dry-run by default)
    GET  /rules/search           — Search marketplace
    POST /rules/install          — Install a marketplace rule
    GET  /saas/onboarding/status — Onboarding session status
    POST /saas/webhooks          — Register webhook
    GET  /saas/dashboard/{id}    — Account usage dashboard
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

try:
    from fastapi import APIRouter, HTTPException
    from pydantic import BaseModel
    _FASTAPI_AVAILABLE = True
except ImportError:
    _FASTAPI_AVAILABLE = False

if _FASTAPI_AVAILABLE:
    router = APIRouter(tags=["phase12"])

    # ─── Request / Response models ────────────────────────────────────────────

    class QualityScanRequest(BaseModel):
        target: str
        min_grade: str = "C"

    class DASTScanRequest(BaseModel):
        url: str
        active: bool = False
        timeout: int = 120

    class SwiftScanRequest(BaseModel):
        target: str

    class MultiChainScanRequest(BaseModel):
        target: str

    class AutoPRRequest(BaseModel):
        findings: List[Dict[str, Any]]
        repo: str
        github_token: str = ""
        dry_run: bool = True

    class RulesSearchRequest(BaseModel):
        query: str
        limit: int = 10

    class RulesInstallRequest(BaseModel):
        rule_id: str

    class WebhookRegisterRequest(BaseModel):
        account_id: str
        url: str
        events: List[str]
        secret: str = ""

    # ─── Code quality ─────────────────────────────────────────────────────────

    @router.post("/scan/quality")
    async def scan_quality(req: QualityScanRequest):
        try:
            from backend.scanners.code_quality import CodeQualityScanner
            scanner = CodeQualityScanner()
            reports = scanner.scan_directory(req.target)
            return {
                "target": req.target,
                "files": len(reports),
                "reports": [r.__dict__ for r in reports],
                "grades": {r.file: r.grade for r in reports},
            }
        except Exception as e:
            raise HTTPException(500, str(e))

    # ─── DAST ─────────────────────────────────────────────────────────────────

    @router.post("/scan/dast")
    async def scan_dast(req: DASTScanRequest):
        try:
            from backend.scanners.dast_scanner import DASTScanner
            scanner = DASTScanner()
            if req.active:
                findings = scanner.scan_url(req.url, timeout=req.timeout)
            else:
                findings = scanner.passive_scan(req.url, timeout=req.timeout)
            return {"url": req.url, "findings": findings, "total": len(findings)}
        except Exception as e:
            raise HTTPException(500, str(e))

    # ─── Swift scanner ────────────────────────────────────────────────────────

    @router.post("/scan/swift")
    async def scan_swift(req: SwiftScanRequest):
        try:
            from scanners.swift_scanner import SwiftScanner
            scanner = SwiftScanner()
            result = scanner.scan_directory(req.target)
            return result
        except Exception as e:
            raise HTTPException(500, str(e))

    # ─── Multi-chain auditor ──────────────────────────────────────────────────

    @router.post("/scan/multichain")
    async def scan_multichain(req: MultiChainScanRequest):
        try:
            from blockchain.multichain_auditor import MultiChainAuditor
            auditor = MultiChainAuditor()
            return auditor.audit_directory(req.target)
        except Exception as e:
            raise HTTPException(500, str(e))

    # ─── AutoPR ───────────────────────────────────────────────────────────────

    @router.post("/autopr")
    async def auto_pr(req: AutoPRRequest):
        try:
            from backend.agents.auto_pr_agent import AutoPRAgent
            agent = AutoPRAgent(github_token=req.github_token, repo=req.repo)
            result = agent.create_fix_prs(req.findings, dry_run=req.dry_run)
            return result.__dict__
        except Exception as e:
            raise HTTPException(500, str(e))

    # ─── Rules marketplace ────────────────────────────────────────────────────

    @router.get("/rules/search")
    async def rules_search(q: str = "", limit: int = 10):
        try:
            from integrations.rules_marketplace import RulesMarketplace
            mp = RulesMarketplace()
            return {"results": mp.search(q, limit=limit)}
        except Exception as e:
            raise HTTPException(500, str(e))

    @router.post("/rules/install")
    async def rules_install(req: RulesInstallRequest):
        try:
            from integrations.rules_marketplace import RulesMarketplace
            mp = RulesMarketplace()
            ok = mp.install(req.rule_id)
            if not ok:
                raise HTTPException(404, f"Rule {req.rule_id} not found")
            return {"installed": req.rule_id}
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(500, str(e))

    # ─── SaaS: onboarding ─────────────────────────────────────────────────────

    @router.get("/saas/onboarding/status/{session_id}")
    async def onboarding_status(session_id: str):
        try:
            from backend.saas.onboarding import OnboardingFlow
            flow = OnboardingFlow()
            status = flow.get_status(session_id)
            if not status:
                raise HTTPException(404, "Session not found")
            return status
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(500, str(e))

    # ─── SaaS: webhooks ───────────────────────────────────────────────────────

    @router.post("/saas/webhooks")
    async def register_webhook(req: WebhookRegisterRequest):
        try:
            from backend.saas.webhook_manager import WebhookManager
            wm = WebhookManager()
            webhook_id = wm.register(
                account_id=req.account_id,
                url=req.url,
                events=req.events,
                secret=req.secret or None,
            )
            return {"webhook_id": webhook_id}
        except Exception as e:
            raise HTTPException(500, str(e))

    # ─── SaaS: dashboard ─────────────────────────────────────────────────────

    @router.get("/saas/dashboard/{account_id}")
    async def usage_dashboard(account_id: str):
        try:
            from backend.saas.usage_dashboard import UsageDashboard
            dash = UsageDashboard(account_id=account_id)
            return dash.get_account_stats()
        except Exception as e:
            raise HTTPException(500, str(e))

    # ─── Transitive reachability ──────────────────────────────────────────────

    @router.post("/scan/reachability")
    async def scan_reachability(target: str, findings: Optional[List[Dict[str, Any]]] = None):
        try:
            from backend.scanners.transitive_reachability import TransitiveReachabilityAnalyzer
            analyzer = TransitiveReachabilityAnalyzer()
            graph = analyzer.build_import_graph(target)
            enriched = analyzer.generate_vex(findings or [], graph)
            return {"import_graph_size": len(graph), "findings": enriched}
        except Exception as e:
            raise HTTPException(500, str(e))

else:
    # Stub when FastAPI is not installed
    class router:  # type: ignore
        pass
