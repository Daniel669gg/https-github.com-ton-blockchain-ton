"""
VulnerabilityVerifier — Main verification pipeline.

Orchestrates: SanitizationChecker → PayloadSimulator → Status determination.
Upgrades findings from POSSIBLE → REPRODUCED → CONFIRMED based on evidence.
"""
from __future__ import annotations

import logging
from typing import List, Optional

from backend.core.confidence import Finding
from .models import (
    VerificationResult,
    VerificationStatus,
    PayloadTest,
    SanitizationCheck,
)
from .sanitization_checker import SanitizationChecker
from .payload_simulator import PayloadSimulator, _DEFAULT_PAYLOADS

logger = logging.getLogger("tythanai.verifier")

# ---------------------------------------------------------------------------
# Known taint sources — if code_snippet contains these, taint path starts here
# ---------------------------------------------------------------------------

_TAINT_SOURCES = [
    "request.args",
    "request.form",
    "request.json",
    "request.get_json",
    "request.data",
    "request.values",
    "request.cookies",
    "input(",
    "sys.argv",
    "os.environ",
    "environ.get",
    "flask.request",
    "django.request",
    "GET.get(",
    "POST.get(",
]

_TAINT_SINKS: dict[str, list[str]] = {
    "CWE-89": ["cursor.execute", "execute(", "raw(", "rawSQL", ".query(", "db.execute"],
    "CWE-79": ["render_template", "render_template_string", "Markup(", "Response(", "return "],
    "CWE-78": ["os.system", "subprocess", "os.popen", "Popen(", "commands."],
    "CWE-22": ["open(", "send_file(", "send_from_directory(", "Path(", "os.path.join"],
    "CWE-798": ["password =", "secret =", "api_key =", "token =", "passwd ="],
    "CWE-502": ["pickle.loads", "yaml.load", "marshal.loads", "jsonpickle.decode"],
    "CWE-918": ["requests.get", "requests.post", "urlopen(", "httpx.get", "aiohttp"],
}


class VulnerabilityVerifier:
    """
    Orchestrates sanitization checking and payload simulation to determine
    the true exploitability of a finding.
    """

    def __init__(self) -> None:
        self._san_checker = SanitizationChecker()
        self._sim = PayloadSimulator()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def verify(self, finding: Finding, source_code: str) -> VerificationResult:
        """
        Run the full verification pipeline for a single finding.

        Steps:
        1. Sanitization check
        2. Taint path analysis
        3. Payload simulation (if no sanitization)
        4. Status and score computation
        """
        finding_id = finding.fingerprint()

        # --- Step 1: Sanitization check ---
        san_check = self._san_checker.check(
            cwe_id=finding.cwe_id,
            source_code=source_code,
            finding_line=finding.line,
        )

        # --- Step 2: Taint path analysis ---
        taint_path, taint_complete = self._analyze_taint_path(finding, source_code)

        # --- Step 3: Payload simulation ---
        payload_tests: List[PayloadTest] = []
        if not (san_check.sanitizer_found and san_check.covers_all_paths):
            snippet = self._extract_snippet(source_code, finding.line)
            payload_tests = self._run_payload_simulations(finding.cwe_id, snippet)

        # --- Step 4: Determine status ---
        any_triggered = any(pt.triggered for pt in payload_tests)
        status, rationale = self._determine_status(
            finding=finding,
            san_check=san_check,
            taint_complete=taint_complete,
            any_triggered=any_triggered,
        )

        # --- Step 5: Compute scores ---
        exploit_score = self._compute_exploit_score(
            finding=finding,
            san_check=san_check,
            taint_complete=taint_complete,
            any_triggered=any_triggered,
        )
        fp_prob = self._compute_fp_probability(
            finding=finding,
            san_check=san_check,
            any_triggered=any_triggered,
        )

        evidence = self._build_evidence_summary(
            finding=finding,
            san_check=san_check,
            taint_complete=taint_complete,
            payload_tests=payload_tests,
            status=status,
        )

        logger.info(
            "verified finding %s → %s (exploit_score=%.1f fp_prob=%.2f)",
            finding_id, status.value, exploit_score, fp_prob,
        )

        return VerificationResult(
            finding_id=finding_id,
            status=status,
            confidence=round(finding.confidence, 4),
            rationale=rationale,
            sanitization_check=san_check,
            taint_path_complete=taint_complete,
            taint_path=taint_path,
            payload_tests=payload_tests,
            exploit_score=round(exploit_score, 2),
            false_positive_probability=round(fp_prob, 4),
            evidence_summary=evidence,
        )

    def verify_batch(
        self, findings: List[Finding], source_code: str
    ) -> List[VerificationResult]:
        """Verify a list of findings against the same source code."""
        results: List[VerificationResult] = []
        for finding in findings:
            try:
                results.append(self.verify(finding, source_code))
            except Exception as exc:
                logger.error("error verifying finding %s: %s", finding.fingerprint(), exc)
                # Produce a minimal fallback result rather than crashing the batch
                results.append(
                    VerificationResult(
                        finding_id=finding.fingerprint(),
                        status=VerificationStatus.POSSIBLE,
                        confidence=finding.confidence,
                        rationale=f"Verification error: {exc}",
                        sanitization_check=SanitizationCheck(
                            sanitizer_found=False,
                            explanation="Verification error — could not complete check.",
                        ),
                        taint_path_complete=False,
                        taint_path=[],
                        payload_tests=[],
                        exploit_score=0.0,
                        false_positive_probability=0.5,
                        evidence_summary=f"Error during verification: {exc}",
                    )
                )
        return results

    def filter_false_positives(
        self,
        findings: List[Finding],
        source_code: str,
        threshold: float = 0.7,
    ) -> List[Finding]:
        """
        Returns only findings whose false_positive_probability is below *threshold*.

        A threshold of 0.7 means: discard findings more likely than 70% to be FPs.
        """
        results = self.verify_batch(findings, source_code)
        kept: List[Finding] = []
        for finding, vr in zip(findings, results):
            if vr.false_positive_probability < threshold:
                kept.append(finding)
            else:
                logger.debug(
                    "filtered likely false-positive %s (fp_prob=%.2f >= %.2f)",
                    vr.finding_id, vr.false_positive_probability, threshold,
                )
        return kept

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _analyze_taint_path(
        self, finding: Finding, source_code: str
    ) -> tuple[List[str], bool]:
        """
        Build a simplified taint path list and decide if it's complete
        (source → sink with no obvious gap).

        Returns (path_labels, is_complete).
        """
        path: List[str] = []
        source_lines = source_code.splitlines()

        # Find taint source lines
        source_found = False
        source_line_no = 0
        for i, line in enumerate(source_lines, start=1):
            for src in _TAINT_SOURCES:
                if src in line:
                    source_found = True
                    source_line_no = i
                    path.append(f"{finding.file}:{i}:taint_source({src.strip()})")
                    break

        # The sink is at the finding line
        if finding.line > 0 and finding.line <= len(source_lines):
            sink_line = source_lines[finding.line - 1].strip()
            path.append(f"{finding.file}:{finding.line}:sink({sink_line[:60]})")

        # Check the sink is one we recognise for the CWE
        cwe_sinks = _TAINT_SINKS.get(finding.cwe_id, [])
        sink_recognised = False
        if finding.line > 0 and finding.line <= len(source_lines):
            sink_code = source_lines[finding.line - 1]
            for sk in cwe_sinks:
                if sk in sink_code:
                    sink_recognised = True
                    break

        complete = (
            source_found
            and source_line_no < finding.line
            and sink_recognised
        )
        return path, complete

    def _run_payload_simulations(
        self, cwe_id: str, snippet: str
    ) -> List[PayloadTest]:
        """Run all registered payloads for the CWE against the snippet."""
        results: List[PayloadTest] = []
        for payload, expected in _DEFAULT_PAYLOADS.get(cwe_id, []):
            try:
                pt = self._sim.simulate(cwe_id, snippet, payload)
                results.append(pt)
            except Exception as exc:
                logger.debug("payload sim failed for %s: %s", cwe_id, exc)
                results.append(
                    PayloadTest(
                        payload=payload,
                        cwe_id=cwe_id,
                        expected_pattern=expected,
                        triggered=False,
                        evidence=f"Simulation error: {exc}",
                    )
                )
        return results

    def _determine_status(
        self,
        finding: Finding,
        san_check: SanitizationCheck,
        taint_complete: bool,
        any_triggered: bool,
    ) -> tuple[VerificationStatus, str]:
        """
        Apply the escalation ladder:
          CONFIRMED  → conf ≥ 0.9  AND no sanitization AND payload triggered
          REPRODUCED → conf ≥ 0.85 AND no sanitization AND taint path complete
          LIKELY     → conf ≥ 0.7  AND no sanitization
          POSSIBLE   → conf ≥ 0.5  OR sanitization found but incomplete
          UNLIKELY   → sanitization found AND covers all paths
        """
        no_sanitization = not san_check.sanitizer_found
        incomplete_sanitization = (
            san_check.sanitizer_found and not san_check.covers_all_paths
        )
        full_sanitization = (
            san_check.sanitizer_found and san_check.covers_all_paths
        )

        if full_sanitization:
            return (
                VerificationStatus.UNLIKELY,
                (
                    f"Sanitization '{san_check.sanitizer_name}' found at line "
                    f"{san_check.sanitizer_line} and covers all paths. "
                    f"Likely a false positive."
                ),
            )

        if finding.confidence >= 0.9 and no_sanitization and any_triggered:
            return (
                VerificationStatus.CONFIRMED,
                (
                    f"High confidence ({finding.confidence:.0%}), no sanitization found, "
                    f"and at least one payload triggered — dynamic proof of exploitability."
                ),
            )

        if finding.confidence >= 0.85 and no_sanitization and taint_complete:
            return (
                VerificationStatus.REPRODUCED,
                (
                    f"Confidence {finding.confidence:.0%}, no sanitization, and complete "
                    f"taint path from source to sink — static proof of exploitability."
                ),
            )

        if finding.confidence >= 0.7 and (no_sanitization or incomplete_sanitization):
            return (
                VerificationStatus.LIKELY,
                (
                    f"Confidence {finding.confidence:.0%} with "
                    + ("no sanitization found." if no_sanitization else
                       f"incomplete sanitization ('{san_check.sanitizer_name}' may not cover all paths).")
                ),
            )

        if finding.confidence >= 0.5 or incomplete_sanitization:
            return (
                VerificationStatus.POSSIBLE,
                (
                    f"Confidence {finding.confidence:.0%} — context unclear or sanitization "
                    f"present but possibly incomplete."
                ),
            )

        return (
            VerificationStatus.UNLIKELY,
            (
                f"Low confidence ({finding.confidence:.0%}) — likely a false positive."
            ),
        )

    def _compute_exploit_score(
        self,
        finding: Finding,
        san_check: SanitizationCheck,
        taint_complete: bool,
        any_triggered: bool,
    ) -> float:
        """
        Produce a 0–10 exploit score analogous to CVSS exploitability.

        Base: severity maps to 2/4/6/8/10
        Modifiers: −2 for sanitization present, +1 for triggered payload,
                   +1 for complete taint path
        """
        severity_base = {
            "CRITICAL": 9.0,
            "HIGH": 7.0,
            "MEDIUM": 5.0,
            "LOW": 3.0,
            "INFO": 1.0,
        }
        score = severity_base.get(finding.severity.upper(), 5.0)

        # Scale by confidence
        score *= finding.confidence

        # Modifiers
        if san_check.sanitizer_found:
            if san_check.covers_all_paths:
                score *= 0.2  # nearly moot
            else:
                score *= 0.6  # partial mitigation
        if any_triggered:
            score = min(10.0, score + 1.0)
        if taint_complete:
            score = min(10.0, score + 0.5)

        return min(10.0, max(0.0, score))

    def _compute_fp_probability(
        self,
        finding: Finding,
        san_check: SanitizationCheck,
        any_triggered: bool,
    ) -> float:
        """
        Estimate false positive probability.

        Base = 1 − confidence.
        If full sanitization found: multiply by 3 (much more likely FP).
        If partial sanitization: multiply by 1.5.
        If payload triggered: multiply by 0.3 (much less likely FP).
        Clamped to [0, 1].
        """
        base = 1.0 - finding.confidence

        if san_check.sanitizer_found and san_check.covers_all_paths:
            base = min(1.0, base * 3.0)
        elif san_check.sanitizer_found:
            base = min(1.0, base * 1.5)

        if any_triggered:
            base *= 0.3

        return round(min(1.0, max(0.0, base)), 4)

    def _build_evidence_summary(
        self,
        finding: Finding,
        san_check: SanitizationCheck,
        taint_complete: bool,
        payload_tests: List[PayloadTest],
        status: VerificationStatus,
    ) -> str:
        parts: List[str] = [
            f"Status: {status.value}",
            f"CWE: {finding.cwe_id} | Severity: {finding.severity} | "
            f"Confidence: {finding.confidence:.0%}",
        ]

        if san_check.sanitizer_found:
            parts.append(
                f"Sanitization: '{san_check.sanitizer_name}' at line "
                f"{san_check.sanitizer_line} — "
                + ("covers all paths." if san_check.covers_all_paths
                   else "may not cover all paths.")
            )
        else:
            parts.append("Sanitization: none detected.")

        if taint_complete:
            parts.append("Taint path: complete (source → sink traced).")
        else:
            parts.append("Taint path: incomplete or source not identified.")

        triggered = [pt for pt in payload_tests if pt.triggered]
        if triggered:
            parts.append(
                f"Payload simulation: {len(triggered)}/{len(payload_tests)} payloads triggered."
            )
            parts.append(f"Evidence: {triggered[0].evidence[:200]}")
        elif payload_tests:
            parts.append(
                f"Payload simulation: 0/{len(payload_tests)} payloads triggered."
            )

        return "  ".join(parts)

    @staticmethod
    def _extract_snippet(source_code: str, finding_line: int, window: int = 20) -> str:
        """Extract lines around finding_line for simulation."""
        lines = source_code.splitlines()
        start = max(0, finding_line - 1 - window)
        end = min(len(lines), finding_line - 1 + window + 1)
        return "\n".join(lines[start:end])
