"""Verification result models."""
from __future__ import annotations

from enum import Enum
from dataclasses import dataclass, field
from typing import List, Optional, Dict


class VerificationStatus(str, Enum):
    CONFIRMED = "CONFIRMED"      # Dynamic proof of exploitability
    REPRODUCED = "REPRODUCED"    # Static proof of full taint path
    LIKELY = "LIKELY"            # Strong static evidence, no sanitization found
    POSSIBLE = "POSSIBLE"        # Pattern match, context unclear
    UNLIKELY = "UNLIKELY"        # Sanitization found or unreachable


@dataclass
class PayloadTest:
    payload: str
    cwe_id: str
    expected_pattern: str        # what to look for in output
    triggered: bool = False
    evidence: str = ""


@dataclass
class SanitizationCheck:
    sanitizer_found: bool
    sanitizer_name: str = ""
    sanitizer_line: int = 0
    covers_all_paths: bool = False
    explanation: str = ""


@dataclass
class VerificationResult:
    finding_id: str
    status: VerificationStatus
    confidence: float                    # 0.0-1.0
    rationale: str
    sanitization_check: SanitizationCheck
    taint_path_complete: bool            # Source → Sink with no gaps
    taint_path: List[str]                # ["file:line:var", ...]
    payload_tests: List[PayloadTest]
    exploit_score: float                 # 0.0-10.0 (like CVSS)
    false_positive_probability: float    # 0.0-1.0
    evidence_summary: str
