"""
PayloadSimulator — Simulates payload execution in an isolated context.

Uses Python's exec() in a sandboxed namespace to test whether payloads
trigger expected behaviors. Only tests safe, non-destructive payloads
(no actual system calls, no network, no file writes).

For dangerous CWEs (CMDi, Path traversal), uses static analysis simulation
only — never executes actual OS commands.
"""
from __future__ import annotations

import re
import logging
import traceback
from typing import Any, Dict, List, Optional

from .models import PayloadTest

logger = logging.getLogger("tythanai.payload_simulator")

# ---------------------------------------------------------------------------
# Default payloads per CWE
# ---------------------------------------------------------------------------

_DEFAULT_PAYLOADS: dict[str, list[tuple[str, str]]] = {
    # (payload, expected_pattern)
    "CWE-89": [
        ("' OR '1'='1", "OR '1'='1"),
        ("'; DROP TABLE users; --", "DROP TABLE"),
        ("1 UNION SELECT * FROM users--", "UNION SELECT"),
    ],
    "CWE-79": [
        ("<script>alert(1)</script>", "<script>"),
        ("<img src=x onerror=alert(1)>", "onerror="),
        ("javascript:alert(1)", "javascript:"),
    ],
    "CWE-78": [
        ("; cat /etc/passwd", "/etc/passwd"),
        ("| id", "| id"),
        ("`id`", "`id`"),
        ("$(id)", "$(id)"),
    ],
    "CWE-22": [
        ("../../../etc/passwd", "/etc/passwd"),
        ("..%2F..%2Fetc%2Fpasswd", "%2F"),
        ("/etc/passwd", "/etc/passwd"),
    ],
    "CWE-798": [
        ("hardcoded_secret_check", "password|secret|key|token"),
    ],
    "CWE-502": [
        ("__import__('os').system('id')", "os.system"),
    ],
    "CWE-918": [
        ("http://internal-metadata/latest/meta-data/", "169.254.169.254"),
        ("file:///etc/passwd", "file://"),
        ("http://localhost/admin", "localhost"),
    ],
}


class _MockRequest:
    """Safe mock of a Flask/Django request object."""

    def __init__(self, payload: str) -> None:
        self._payload = payload
        self.args = _MockDict(payload)
        self.form = _MockDict(payload)
        self.json = {"data": payload, "input": payload, "query": payload}
        self.method = "POST"
        self.data = payload.encode()

    def get_json(self) -> dict:
        return self.json


class _MockDict(dict):
    """Dict that returns the payload for any key."""

    def __init__(self, payload: str) -> None:
        super().__init__()
        self._payload = payload

    def __getitem__(self, key: str) -> str:
        return self._payload

    def get(self, key: str, default: Any = None) -> str:  # type: ignore[override]
        return self._payload


class _MockCursor:
    """Mock DB cursor that records executed queries."""

    def __init__(self) -> None:
        self.executed: list[tuple] = []
        self.last_query: str = ""
        self.last_params: Any = None

    def execute(self, query: str, params: Any = None) -> None:
        self.executed.append((query, params))
        self.last_query = query
        self.last_params = params

    def fetchall(self) -> list:
        return []

    def fetchone(self) -> Optional[tuple]:
        return None


class _MockConnection:
    """Mock DB connection."""

    def __init__(self) -> None:
        self.cursor_obj = _MockCursor()

    def cursor(self) -> _MockCursor:
        return self.cursor_obj

    def execute(self, query: str, params: Any = None) -> _MockCursor:
        self.cursor_obj.execute(query, params)
        return self.cursor_obj


class _OutputCapture:
    """Captures print() output during exec."""

    def __init__(self) -> None:
        self._lines: list[str] = []

    def write(self, text: str) -> None:
        self._lines.append(text)

    def flush(self) -> None:
        pass

    def getvalue(self) -> str:
        return "".join(self._lines)


class PayloadSimulator:
    """
    Safely simulates payload execution in a restricted namespace.

    Dangerous CWEs (CWE-78, CWE-22) use static analysis only.
    CWE-89 and CWE-79 execute code in a mocked namespace with no real I/O.
    """

    def simulate(
        self,
        cwe_id: str,
        code_snippet: str,
        payload: str,
    ) -> PayloadTest:
        """Run the appropriate simulation strategy for the given CWE."""
        default_expected = self._default_expected(cwe_id)

        if cwe_id == "CWE-89":
            return self._simulate_sqli(code_snippet, payload, default_expected)
        elif cwe_id == "CWE-79":
            return self._simulate_xss(code_snippet, payload, default_expected)
        elif cwe_id in ("CWE-78", "CWE-22"):
            return self._simulate_static(cwe_id, code_snippet, payload, default_expected)
        elif cwe_id == "CWE-798":
            return self._simulate_hardcoded_secret(code_snippet, payload)
        elif cwe_id == "CWE-502":
            return self._simulate_static(cwe_id, code_snippet, payload, default_expected)
        elif cwe_id == "CWE-918":
            return self._simulate_static(cwe_id, code_snippet, payload, default_expected)
        else:
            return self._simulate_static(cwe_id, code_snippet, payload, default_expected)

    def simulate_all(
        self,
        cwe_id: str,
        code_snippet: str,
    ) -> list[PayloadTest]:
        """Run all default payloads for the CWE and return results."""
        results: list[PayloadTest] = []
        for payload, expected in _DEFAULT_PAYLOADS.get(cwe_id, []):
            results.append(self.simulate(cwe_id, code_snippet, payload))
        return results

    # ------------------------------------------------------------------
    # CWE-89: SQL Injection
    # ------------------------------------------------------------------

    def _simulate_sqli(
        self, code_snippet: str, payload: str, expected_pattern: str
    ) -> PayloadTest:
        """
        Inject payload via mock request and check if constructed SQL
        embeds it without parameterization.
        """
        ns = self.create_mock_namespace(payload)
        capture = _OutputCapture()
        ns["print"] = capture.write

        constructed_sql: list[str] = []

        # Monkey-patch cursor to capture raw SQL
        real_execute = ns["cursor"].execute

        def capturing_execute(query: str, params: Any = None) -> None:
            real_execute(query, params)
            if params is None:
                # Un-parameterized — the payload may be embedded
                constructed_sql.append(query)

        ns["cursor"].execute = capturing_execute
        ns["conn"].cursor_obj.execute = capturing_execute

        try:
            exec(compile(code_snippet, "<sqli_sim>", "exec"), ns)  # noqa: S102
        except Exception:
            logger.debug("sqli sim exec error: %s", traceback.format_exc())

        output = capture.getvalue()
        # Also check the namespace for any sql/query variable built as a string
        sql_vars = [
            str(v) for k, v in ns.items()
            if k.lower() in ("sql", "query", "stmt", "statement", "q")
            and isinstance(v, str)
        ]
        all_text = output + " ".join(constructed_sql) + " ".join(sql_vars)

        triggered = payload in all_text or bool(re.search(re.escape(payload), all_text))
        evidence = (
            f"Payload found in constructed SQL: {all_text[:200]!r}" if triggered
            else "Payload not detected in constructed SQL — may be parameterized or not reached."
        )
        return PayloadTest(
            payload=payload,
            cwe_id="CWE-89",
            expected_pattern=expected_pattern,
            triggered=triggered,
            evidence=evidence,
        )

    # ------------------------------------------------------------------
    # CWE-79: XSS
    # ------------------------------------------------------------------

    def _simulate_xss(
        self, code_snippet: str, payload: str, expected_pattern: str
    ) -> PayloadTest:
        """
        Inject XSS payload via mock render context and check if it appears
        unescaped in any returned string.
        """
        ns = self.create_mock_namespace(payload)
        rendered_outputs: list[str] = []

        # Mock render_template / render functions
        def mock_render_template(template: str, **kwargs: Any) -> str:
            result = f"<html>{' '.join(str(v) for v in kwargs.values())}</html>"
            rendered_outputs.append(result)
            return result

        def mock_render_template_string(template: str, **kwargs: Any) -> str:
            # Simulate rendering: substitute variables naively
            result = template
            for k, v in kwargs.items():
                result = result.replace("{{ " + k + " }}", str(v))
                result = result.replace("{{" + k + "}}", str(v))
            rendered_outputs.append(result)
            return result

        ns["render_template"] = mock_render_template
        ns["render_template_string"] = mock_render_template_string

        returned_values: list[Any] = []
        original_return = None  # we capture via exec result variable

        capture = _OutputCapture()
        ns["print"] = capture.write

        try:
            exec(compile(code_snippet, "<xss_sim>", "exec"), ns)  # noqa: S102
        except Exception:
            logger.debug("xss sim exec error: %s", traceback.format_exc())

        all_output = capture.getvalue() + " ".join(rendered_outputs)
        # Check namespace for string variables containing unescaped payload
        for k, v in ns.items():
            if isinstance(v, str) and payload in v:
                all_output += v

        triggered = payload in all_output
        evidence = (
            f"Unescaped payload '{payload[:60]}' found in rendered output."
            if triggered else
            "Payload not found unescaped in output — may be escaped or template not reached."
        )
        return PayloadTest(
            payload=payload,
            cwe_id="CWE-79",
            expected_pattern=expected_pattern,
            triggered=triggered,
            evidence=evidence,
        )

    # ------------------------------------------------------------------
    # Static simulation (CWE-78, CWE-22, CWE-502, CWE-918)
    # ------------------------------------------------------------------

    def _simulate_static(
        self,
        cwe_id: str,
        code_snippet: str,
        payload: str,
        expected_pattern: str,
    ) -> PayloadTest:
        """
        Static taint analysis: does the payload value flow into a dangerous call?

        Looks for string concatenation / f-string patterns that would embed the
        user-controlled value into the dangerous function argument.
        """
        triggered = False
        evidence = ""

        # Patterns that indicate unsafe string construction reaching a sink
        sink_patterns: dict[str, list[re.Pattern]] = {
            "CWE-78": [
                re.compile(r"os\.system\s*\(.*[\+\%f]"),           # concatenation into system()
                re.compile(r"subprocess\.(run|call|Popen)\s*\(.*[\"\'].*\+"),
                re.compile(r"os\.popen\s*\("),
                re.compile(r"commands\.getoutput\s*\("),
            ],
            "CWE-22": [
                re.compile(r"open\s*\(.*\+"),                      # open(base + user_input)
                re.compile(r"Path\s*\(.*\+"),
                re.compile(r"os\.path\.join\s*\("),
            ],
            "CWE-502": [
                re.compile(r"pickle\.loads\s*\("),
                re.compile(r"yaml\.load\s*\([^,)]*\)"),            # yaml.load without Loader
                re.compile(r"marshal\.loads\s*\("),
            ],
            "CWE-918": [
                re.compile(r"requests\.(get|post|put|patch|delete)\s*\(.*\+"),
                re.compile(r"urllib\.request\.urlopen\s*\(.*\+"),
                re.compile(r"httpx\.(get|post)\s*\(.*\+"),
            ],
        }

        patterns_to_check = sink_patterns.get(cwe_id, [])
        for pattern in patterns_to_check:
            if pattern.search(code_snippet):
                triggered = True
                evidence = (
                    f"Static analysis: sink pattern {pattern.pattern!r} matched in code snippet. "
                    f"Payload '{payload[:60]}' would flow into dangerous function."
                )
                break

        if not triggered:
            # Broader check: payload-carrying variable concatenated anywhere near a sink keyword
            sink_keywords = {
                "CWE-78": ["os.system", "subprocess", "os.popen", "Popen"],
                "CWE-22": ["open(", "Path(", "os.path.join", "send_file"],
                "CWE-502": ["pickle.loads", "yaml.load", "marshal.loads"],
                "CWE-918": ["requests.get", "requests.post", "urlopen", "httpx.get"],
            }
            for kw in sink_keywords.get(cwe_id, []):
                if kw in code_snippet:
                    # Sink is present — check for string concatenation nearby
                    idx = code_snippet.find(kw)
                    surrounding = code_snippet[max(0, idx - 100): idx + 200]
                    if "+" in surrounding or "%" in surrounding or "f\"" in surrounding or "f'" in surrounding:
                        triggered = True
                        evidence = (
                            f"Static analysis: sink '{kw}' found with string concatenation — "
                            f"payload '{payload[:60]}' likely reaches the sink."
                        )
                        break

        if not triggered:
            evidence = (
                f"Static analysis: no direct taint path from payload to sink detected for {cwe_id}."
            )

        return PayloadTest(
            payload=payload,
            cwe_id=cwe_id,
            expected_pattern=expected_pattern,
            triggered=triggered,
            evidence=evidence,
        )

    # ------------------------------------------------------------------
    # CWE-798: Hardcoded secrets
    # ------------------------------------------------------------------

    def _simulate_hardcoded_secret(
        self, code_snippet: str, payload: str
    ) -> PayloadTest:
        """
        Check if the code snippet contains patterns matching hardcoded secrets.
        """
        secret_patterns = [
            re.compile(r'(password|passwd|pwd)\s*=\s*["\'][^"\']{4,}["\']', re.IGNORECASE),
            re.compile(r'(secret|api_key|apikey|token|auth_token)\s*=\s*["\'][^"\']{4,}["\']', re.IGNORECASE),
            re.compile(r'(private_key|access_key|secret_key)\s*=\s*["\'][^"\']{4,}["\']', re.IGNORECASE),
            re.compile(r'["\'][A-Za-z0-9+/]{32,}={0,2}["\']'),  # base64-like long strings
            re.compile(r'(AWS|GITHUB|STRIPE|TWILIO).*["\'][A-Za-z0-9_\-]{16,}["\']'),
        ]
        triggered = False
        evidence = ""
        for pat in secret_patterns:
            m = pat.search(code_snippet)
            if m:
                triggered = True
                evidence = f"Hardcoded secret pattern detected: {m.group()[:80]!r}"
                break

        if not triggered:
            evidence = "No hardcoded secret pattern matched in snippet."

        return PayloadTest(
            payload=payload,
            cwe_id="CWE-798",
            expected_pattern="password|secret|key|token",
            triggered=triggered,
            evidence=evidence,
        )

    # ------------------------------------------------------------------
    # Mock namespace construction
    # ------------------------------------------------------------------

    def create_mock_namespace(self, payload: str = "TEST_PAYLOAD") -> dict:
        """
        Build a safe execution namespace that mocks common web-framework objects.

        - request: mock Flask/Django request with payload in all fields
        - cursor / conn: mock DB cursor/connection
        - Blocked: os, sys, subprocess, open, __import__
        """
        mock_request = _MockRequest(payload)
        mock_cursor = _MockCursor()
        mock_conn = _MockConnection()
        mock_conn.cursor_obj = mock_cursor

        def _blocked_import(name: str, *args: Any, **kwargs: Any) -> Any:
            allowed = {"re", "html", "json", "urllib.parse", "collections", "functools"}
            if name in allowed:
                import importlib
                return importlib.import_module(name)
            raise ImportError(f"Import of '{name}' is blocked in simulation namespace.")

        ns: dict = {
            "__builtins__": {
                # Safe builtins only
                "print": print,
                "len": len,
                "str": str,
                "int": int,
                "float": float,
                "bool": bool,
                "list": list,
                "dict": dict,
                "tuple": tuple,
                "set": set,
                "range": range,
                "enumerate": enumerate,
                "zip": zip,
                "map": map,
                "filter": filter,
                "isinstance": isinstance,
                "issubclass": issubclass,
                "hasattr": hasattr,
                "getattr": getattr,
                "setattr": setattr,
                "repr": repr,
                "format": format,
                "type": type,
                "Exception": Exception,
                "ValueError": ValueError,
                "KeyError": KeyError,
                "TypeError": TypeError,
                "__import__": _blocked_import,
            },
            # Mock objects
            "request": mock_request,
            "cursor": mock_cursor,
            "conn": mock_conn,
            "db": mock_conn,
            # Common variable names scanners might reference
            "user_input": payload,
            "data": payload,
            "query": "",
            "sql": "",
            "name": payload,
            "username": payload,
            "search": payload,
            "url": payload,
        }
        return ns

    # ------------------------------------------------------------------
    # Helper
    # ------------------------------------------------------------------

    @staticmethod
    def _default_expected(cwe_id: str) -> str:
        defaults = {
            "CWE-89": "SQL injection pattern",
            "CWE-79": "<script>",
            "CWE-78": "command separator",
            "CWE-22": "path traversal",
            "CWE-798": "hardcoded credential",
            "CWE-502": "unsafe deserialization",
            "CWE-918": "internal URL",
        }
        return defaults.get(cwe_id, "exploit pattern")
