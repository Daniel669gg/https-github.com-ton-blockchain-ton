"""
Checks source code for sanitization functions that would neutralize a taint.

For each CWE, knows which functions/patterns constitute adequate sanitization.
"""
from __future__ import annotations

import re
import logging
from typing import List, Optional, Tuple

from .models import SanitizationCheck

logger = logging.getLogger("tythanai.sanitization_checker")

# ---------------------------------------------------------------------------
# Per-CWE sanitizer pattern registry
# Each entry: (pattern_regex, human_readable_name)
# ---------------------------------------------------------------------------

_SANITIZERS: dict[str, list[tuple[re.Pattern, str]]] = {
    # SQL Injection — parameterized queries, ORMs
    "CWE-89": [
        (re.compile(r"cursor\.execute\s*\([^,]+,\s*[\(\[\{]"), "parameterized cursor.execute"),
        (re.compile(r"\$\d+|\?(?!\s*\))"), "positional query parameter"),
        (re.compile(r"session\.query\s*\("), "SQLAlchemy session.query ORM"),
        (re.compile(r"db\.session\.execute\s*\(\s*text\s*\("), "SQLAlchemy text() with execute"),
        (re.compile(r"\.objects\.(filter|get|exclude|all)\s*\("), "Django ORM queryset"),
        (re.compile(r"(prepare|parameterize)\s*\("), "prepare/parameterize call"),
        (re.compile(r"\.filter\s*\("), "ORM .filter() call"),
        (re.compile(r"execute\s*\([^)]*%s[^)]*,\s*\("), "%-style parameterized query"),
    ],
    # XSS — output encoding / escaping
    "CWE-79": [
        (re.compile(r"html\.escape\s*\("), "html.escape()"),
        (re.compile(r"(?<!\w)escape\s*\("), "escape()"),
        (re.compile(r"markupsafe"), "MarkupSafe"),
        (re.compile(r"bleach\.clean\s*\("), "bleach.clean()"),
        (re.compile(r"autoescape\s*=\s*True"), "Jinja2 autoescape=True"),
        (re.compile(r"flask\.escape\s*\("), "flask.escape()"),
        (re.compile(r"Markup\s*\("), "Markup() safe wrapper"),
        (re.compile(r"jinja2\.Environment.*autoescape"), "Jinja2 autoescape env"),
    ],
    # Command Injection — argument list, shell quoting
    "CWE-78": [
        (re.compile(r"shlex\.quote\s*\("), "shlex.quote()"),
        (re.compile(r"subprocess\.(run|call|check_output|Popen)\s*\(\s*\["), "subprocess with list args"),
        (re.compile(r"shlex\.split\s*\("), "shlex.split()"),
        (re.compile(r"pipes\.quote\s*\("), "pipes.quote()"),
    ],
    # Path Traversal — path normalization / containment
    "CWE-22": [
        (re.compile(r"os\.path\.abspath\s*\("), "os.path.abspath()"),
        (re.compile(r"os\.path\.realpath\s*\("), "os.path.realpath()"),
        (re.compile(r"\.resolve\s*\(\s*\)"), "pathlib Path.resolve()"),
        (re.compile(r"\.startswith\s*\("), ".startswith() base-path check"),
        (re.compile(r"os\.path\.commonpath\s*\("), "os.path.commonpath()"),
        (re.compile(r"os\.path\.commonprefix\s*\("), "os.path.commonprefix()"),
    ],
    # Hardcoded Secrets — no sanitization possible, always flag
    "CWE-798": [],
    # Weak Cryptography — no sanitization, always flag
    "CWE-327": [],
    # Unsafe Deserialization — safe alternatives
    "CWE-502": [
        (re.compile(r"json\.loads\s*\("), "json.loads() safe alternative"),
        (re.compile(r"ast\.literal_eval\s*\("), "ast.literal_eval() safe alternative"),
        (re.compile(r"json\.load\s*\("), "json.load() safe alternative"),
    ],
    # SSRF — URL allowlist / validation
    "CWE-918": [
        (re.compile(r"urllib\.parse\.urlparse\s*\("), "urllib.parse.urlparse() URL parsing"),
        (re.compile(r"allowlist|allow_list|whitelist"), "URL allowlist check"),
        (re.compile(r"\.netloc\s*(==|in)\s*"), "netloc domain check"),
        (re.compile(r"ALLOWED_HOSTS|ALLOWED_URLS|SAFE_DOMAINS"), "allowed hosts constant"),
    ],
}

# CWEs where no mitigation pattern can make the code safe — always a real finding
_ALWAYS_FLAG: set[str] = {"CWE-798", "CWE-327"}


class SanitizationChecker:
    """
    Detects sanitization functions in source code around a finding line.

    Uses a context window of ±30 lines centred on the finding to locate
    sanitizers, then verifies whether the sanitizer is on the execution path
    leading to the sink.
    """

    CONTEXT_WINDOW: int = 30

    def check(
        self,
        cwe_id: str,
        source_code: str,
        finding_line: int,          # 1-based line number
    ) -> SanitizationCheck:
        """
        Returns a SanitizationCheck describing whether sanitization is present
        and whether it plausibly covers the path to the vulnerable sink.
        """
        if cwe_id in _ALWAYS_FLAG:
            return SanitizationCheck(
                sanitizer_found=False,
                explanation=f"{cwe_id}: no sanitization can make this safe — always a real finding.",
            )

        patterns = _SANITIZERS.get(cwe_id, [])
        if not patterns:
            return SanitizationCheck(
                sanitizer_found=False,
                explanation=f"No sanitization patterns registered for {cwe_id}.",
            )

        source_lines: List[str] = source_code.splitlines()
        total_lines = len(source_lines)

        # Build context window (0-based indices)
        start_idx = max(0, finding_line - 1 - self.CONTEXT_WINDOW)
        end_idx = min(total_lines, finding_line - 1 + self.CONTEXT_WINDOW + 1)
        context_lines = source_lines[start_idx:end_idx]
        context_text = "\n".join(context_lines)

        for pattern, name in patterns:
            match = pattern.search(context_text)
            if match:
                # Compute absolute line number of the match
                preceding_text = context_text[: match.start()]
                relative_line = preceding_text.count("\n")
                sanitizer_line_1based = start_idx + relative_line + 1

                covers = self._covers_all_paths(
                    sanitizer_line_1based, finding_line, source_lines
                )
                explanation = (
                    f"Found '{name}' at line {sanitizer_line_1based}. "
                    + ("Appears to cover path to sink." if covers else
                       "May not cover all paths to sink — verify manually.")
                )
                logger.debug(
                    "sanitizer '%s' found at line %d for %s (covers=%s)",
                    name, sanitizer_line_1based, cwe_id, covers,
                )
                return SanitizationCheck(
                    sanitizer_found=True,
                    sanitizer_name=name,
                    sanitizer_line=sanitizer_line_1based,
                    covers_all_paths=covers,
                    explanation=explanation,
                )

        return SanitizationCheck(
            sanitizer_found=False,
            explanation=f"No sanitization found for {cwe_id} within {self.CONTEXT_WINDOW} lines of finding.",
        )

    # ------------------------------------------------------------------
    # Path coverage heuristic
    # ------------------------------------------------------------------

    def _covers_all_paths(
        self,
        sanitizer_line: int,        # 1-based
        finding_line: int,           # 1-based
        source_lines: List[str],
    ) -> bool:
        """
        Heuristic: the sanitizer covers the path if it appears BEFORE the sink
        (finding_line) without an intervening branch that bypasses it.

        Simple model:
        - Sanitizer must be before the finding line.
        - No bare `else:` or `except:` between sanitizer and finding that
          could create an unsanitized code-path.
        - The sanitizer must be at the same or lower indentation level as
          the sink (i.e. not inside an isolated branch).
        """
        if sanitizer_line > finding_line:
            # Sanitizer appears strictly after the sink — cannot protect it
            return False

        # Special case: sanitizer IS on the sink line (e.g. parameterized execute)
        # This means the sink itself is the safe form — always covers all paths
        if sanitizer_line == finding_line:
            return True

        san_idx = sanitizer_line - 1
        sink_idx = finding_line - 1

        # Indentation of sanitizer line
        san_indent = self._indent(source_lines[san_idx])
        sink_indent = self._indent(source_lines[sink_idx])

        # If the sanitizer is nested deeper than the sink it's in a branch
        if san_indent > sink_indent:
            return False

        # Look for naked else/except between sanitizer and sink that would
        # create an alternative path without sanitization
        bypass_re = re.compile(r"^\s*(else\s*:|except\s*:)")
        between = source_lines[san_idx + 1: sink_idx]
        for ln in between:
            if bypass_re.match(ln):
                # Could indicate an unprotected alternate path
                return False

        return True

    @staticmethod
    def _indent(line: str) -> int:
        """Return number of leading spaces (tabs count as 4)."""
        count = 0
        for ch in line:
            if ch == " ":
                count += 1
            elif ch == "\t":
                count += 4
            else:
                break
        return count
