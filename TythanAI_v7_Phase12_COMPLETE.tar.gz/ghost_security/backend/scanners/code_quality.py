# TythanAI Security Platform
# Copyright (c) 2026 TythanAI Labs
# Licensed under the Business Source License 1.1 (see LICENSE).

"""
backend/scanners/code_quality.py — TythanAI Code Quality Scanner
Regex-based code quality analysis for Python and JavaScript files.
"""
from __future__ import annotations

import hashlib
import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("tythanai.code_quality")

# ─── Keyword patterns ──────────────────────────────────────────────────────────

_PY_COMPLEXITY_KW = re.compile(
    r'\b(if|elif|else|for|while|try|except|with|case)\b|(\band\b|\bor\b)'
)
_PY_FUNCTION_DEF = re.compile(r'^\s*def\s+(\w+)\s*\(', re.MULTILINE)
_PY_FUNCTION_CALL = re.compile(r'\b(\w+)\s*\(')
_PY_IMPORT_RE = re.compile(r'^\s*(import\s+(\S+)|from\s+(\S+)\s+import)', re.MULTILINE)
_PY_COMMENT_RE = re.compile(r'^\s*#')
_PY_BLANK_RE = re.compile(r'^\s*$')

_JS_COMPLEXITY_KW = re.compile(
    r'\b(function|if|else|for|while|switch|case|catch)\b|(\&\&|\|\|)'
)
_JS_COMMENT_RE = re.compile(r'^\s*(//|/\*|\*)')

_NESTING_KW_PY = re.compile(r'\b(if|elif|for|while|with|try|except)\b')
_NESTING_KW_JS = re.compile(r'\b(if|for|while|switch|catch|function)\b|\{')

# ─── Data model ───────────────────────────────────────────────────────────────

@dataclass
class CodeQualityReport:
    file: str
    language: str
    cyclomatic_complexity: int
    cognitive_complexity: int
    loc: int
    comment_ratio: float
    duplication_score: float        # 0.0 – 1.0
    dead_code_count: int
    technical_debt_minutes: int
    grade: str                      # A – F


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _detect_language(file_path: str) -> str:
    ext = Path(file_path).suffix.lower()
    if ext == ".py":
        return "python"
    if ext in (".js", ".jsx", ".mjs", ".cjs"):
        return "javascript"
    return "unknown"


def _compute_loc_comments(lines: List[str], language: str) -> Tuple[int, int, int]:
    """Return (total_lines, loc, comment_lines)."""
    total = len(lines)
    comment_re = _PY_COMMENT_RE if language == "python" else _JS_COMMENT_RE
    loc = 0
    comments = 0
    for ln in lines:
        if _PY_BLANK_RE.match(ln):
            continue
        if comment_re.match(ln):
            comments += 1
        else:
            loc += 1
    return total, loc, comments


def _cyclomatic_complexity(lines: List[str], language: str) -> int:
    """Compute overall cyclomatic complexity (sum across all functions + 1 base)."""
    kw_re = _PY_COMPLEXITY_KW if language == "python" else _JS_COMPLEXITY_KW
    count = 1  # base
    for ln in lines:
        # strip strings to avoid false positives inside string literals
        stripped = re.sub(r'(["\'])(?:(?!\1).)*\1', '', ln)
        count += len(kw_re.findall(stripped))
    return count


def _cognitive_complexity(lines: List[str], language: str) -> int:
    """Estimate cognitive complexity with exponential nesting weight."""
    nesting_re = _NESTING_KW_PY if language == "python" else _NESTING_KW_JS
    depth = 0
    total = 0
    indent_stack: List[int] = []

    for ln in lines:
        if _PY_BLANK_RE.match(ln):
            continue
        stripped_line = ln.rstrip()
        # Track Python indentation for nesting depth
        if language == "python":
            indent = len(ln) - len(ln.lstrip())
            # pop stack to current indent
            while indent_stack and indent_stack[-1] >= indent:
                indent_stack.pop()
                depth = max(0, depth - 1)
            matches = nesting_re.findall(stripped_line)
            if matches:
                weight = (depth + 1) ** 2  # exponential by depth
                total += len(matches) * weight
                indent_stack.append(indent)
                depth += 1
        else:
            # For JS, count opening braces to estimate nesting
            opens = stripped_line.count('{')
            closes = stripped_line.count('}')
            matches = nesting_re.findall(stripped_line)
            if matches:
                weight = (depth + 1) ** 2
                total += len(matches) * weight
            depth = max(0, depth + opens - closes)

    return total


def _duplication_score(lines: List[str], window: int = 6) -> float:
    """Hash 6-line sliding windows; return fraction of duplicate windows."""
    non_blank = [ln.strip() for ln in lines if ln.strip()]
    if len(non_blank) < window:
        return 0.0

    hashes: Dict[str, int] = {}
    total_windows = len(non_blank) - window + 1
    for i in range(total_windows):
        chunk = "\n".join(non_blank[i : i + window])
        h = hashlib.md5(chunk.encode()).hexdigest()
        hashes[h] = hashes.get(h, 0) + 1

    duplicated = sum(v - 1 for v in hashes.values() if v > 1)
    return min(1.0, duplicated / max(total_windows, 1))


def _dead_code_count(content: str, language: str) -> int:
    """Count functions defined but never called within the same file."""
    if language == "python":
        defined = set(re.findall(r'^\s*def\s+(\w+)\s*\(', content, re.MULTILINE))
        calls = set(re.findall(r'\b(\w+)\s*\(', content))
        # remove the definitions themselves from 'calls' — we want call *sites*
        # A function is dead if there's no call to it (other than its own def line)
        dead = 0
        for fn in defined:
            # Count occurrences of the function name followed by '(' in the file
            # excluding the def line itself
            call_count = len(re.findall(r'(?<!def\s)\b' + re.escape(fn) + r'\s*\(', content))
            if call_count == 0:
                dead += 1
        return dead
    elif language == "javascript":
        defined = set(re.findall(
            r'\bfunction\s+(\w+)\s*\(|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\(',
            content
        ))
        # flatten tuples
        fn_names: set = set()
        for m in defined:
            for name in m:
                if name:
                    fn_names.add(name)
        dead = 0
        for fn in fn_names:
            # Look for any call site
            call_count = len(re.findall(r'\b' + re.escape(fn) + r'\s*\(', content)) - 1
            if call_count <= 0:
                dead += 1
        return dead
    return 0


def _technical_debt(cc: int, dup: float, dead: int) -> int:
    """Calculate technical debt in minutes."""
    return int(cc * 5 + dup * 60 + dead * 15)


def _grade(debt: int, cc: int) -> str:
    """Assign grade A-F based on debt and cyclomatic complexity."""
    if debt < 30 and cc < 5:
        return "A"
    elif debt < 60 and cc < 8:
        return "B"
    elif debt < 120 and cc < 12:
        return "C"
    elif debt < 240:
        return "D"
    else:
        return "F"


# ─── Scanner ──────────────────────────────────────────────────────────────────

class CodeQualityScanner:
    """Regex-based code quality scanner supporting Python and JavaScript files."""

    def scan_file(self, file_path: str) -> CodeQualityReport:
        """Analyse a single file and return a CodeQualityReport."""
        path = Path(file_path)
        language = _detect_language(file_path)

        try:
            content = path.read_text(errors="replace")
        except (OSError, IOError) as exc:
            logger.warning("Cannot read %s: %s", file_path, exc)
            return CodeQualityReport(
                file=file_path,
                language=language,
                cyclomatic_complexity=0,
                cognitive_complexity=0,
                loc=0,
                comment_ratio=0.0,
                duplication_score=0.0,
                dead_code_count=0,
                technical_debt_minutes=0,
                grade="A",
            )

        lines = content.splitlines()
        total_lines, loc, comment_lines = _compute_loc_comments(lines, language)
        comment_ratio = (comment_lines / total_lines) if total_lines > 0 else 0.0

        cc = _cyclomatic_complexity(lines, language)
        cog = _cognitive_complexity(lines, language)
        dup = _duplication_score(lines)
        dead = _dead_code_count(content, language)
        debt = _technical_debt(cc, dup, dead)
        grade = _grade(debt, cc)

        return CodeQualityReport(
            file=file_path,
            language=language,
            cyclomatic_complexity=cc,
            cognitive_complexity=cog,
            loc=loc,
            comment_ratio=round(comment_ratio, 4),
            duplication_score=round(dup, 4),
            dead_code_count=dead,
            technical_debt_minutes=debt,
            grade=grade,
        )

    def scan_directory(self, directory: str) -> dict:
        """Scan all Python and JavaScript files in a directory recursively."""
        results: dict = {}
        base = Path(directory)
        if not base.exists():
            logger.warning("Directory does not exist: %s", directory)
            return results

        for root, _dirs, files in os.walk(str(base)):
            for fname in files:
                fpath = os.path.join(root, fname)
                lang = _detect_language(fpath)
                if lang in ("python", "javascript"):
                    try:
                        report = self.scan_file(fpath)
                        results[fpath] = report
                    except Exception as exc:
                        logger.warning("Error scanning %s: %s", fpath, exc)

        return results
