"""
TythanAI — DASTScanner
High-level wrapper around ZAPClient for active/passive/OpenAPI scanning.

Provides graceful degradation: if ZAP is unreachable the caller gets an
empty list and a warning log instead of an exception.
"""
from __future__ import annotations

import logging
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

# Allow importing from the project root so that sibling package
# scanners.dast.zap_integration is on sys.path regardless of how
# this module is imported.
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from scanners.dast.zap_integration import ZAPClient, ZAPFinding  # noqa: E402

logger = logging.getLogger("tythanai.dast_scanner")

# ── Risk → severity mapping (int risk level from ZAP alert dict) ──────────────
_RISK_INT_TO_SEVERITY: Dict[int, str] = {
    0: "INFO",
    1: "LOW",
    2: "MEDIUM",
    3: "HIGH",
    4: "CRITICAL",
}

# When ZAP returns risk as a string label
_RISK_STR_TO_SEVERITY: Dict[str, str] = {
    "Informational": "INFO",
    "Low":           "LOW",
    "Medium":        "MEDIUM",
    "High":          "HIGH",
}

# confidence strings that are too low to include
_SKIP_CONFIDENCES = {"Low", "False Positive"}


def _confidence_ok(confidence: str) -> bool:
    """Return True if confidence is at least 'Medium'."""
    return confidence not in _SKIP_CONFIDENCES


def _zap_finding_to_dict(finding: ZAPFinding) -> dict:
    """Convert a ZAPFinding dataclass to TythanAI internal dict format."""
    # Determine severity from the risk string label
    severity = _RISK_STR_TO_SEVERITY.get(finding.risk, "INFO")
    return {
        "type":           "DAST_FINDING",
        "source":         "zap_scanner",
        "rule_id":        f"ZAP-{finding.plugin_id}" if finding.plugin_id else "ZAP-UNKNOWN",
        "title":          finding.name,
        "severity":       severity,
        "description":    finding.description,
        "evidence":       finding.evidence or f"{finding.method} {finding.url}",
        "recommendation": finding.solution,
        "cwe":            finding.cwe_id,
        "file":           "",
        "line":           0,
        "url":            finding.url,
        "method":         finding.method,
        "param":          finding.param,
        "attack":         finding.attack,
        "confidence":     finding.confidence,
        "category":       "DAST",
        "tags":           ["dast", "zap", finding.risk.lower()],
        "references":     [finding.reference] if finding.reference else [],
    }


def _alert_dict_to_finding_dict(alert: dict) -> Optional[dict]:
    """
    Convert a raw ZAP alert dict (from get_alerts()) to TythanAI finding dict.

    Risk mapping: int 0→INFO, 1→LOW, 2→MEDIUM, 3→HIGH, 4→CRITICAL.
    Confidence filter: skip anything below 'Medium'.
    Returns None if the alert should be skipped.
    """
    confidence = alert.get("confidence", "Low")
    if not _confidence_ok(confidence):
        return None

    # Risk can arrive as an integer or a string label
    risk_raw = alert.get("risk", 0)
    if isinstance(risk_raw, int):
        severity = _RISK_INT_TO_SEVERITY.get(risk_raw, "INFO")
    else:
        # Try to parse as integer first
        try:
            severity = _RISK_INT_TO_SEVERITY.get(int(risk_raw), "INFO")
        except (TypeError, ValueError):
            severity = _RISK_STR_TO_SEVERITY.get(str(risk_raw), "INFO")

    plugin_id = str(alert.get("pluginId", alert.get("plugin_id", "")))
    name      = alert.get("alert", alert.get("name", ""))
    method    = alert.get("method", "GET")
    url       = alert.get("url", "")
    reference = alert.get("reference", "")

    # CWE normalisation
    cwe_raw = str(alert.get("cweid", ""))
    if cwe_raw and cwe_raw.isdigit() and cwe_raw != "0":
        cwe = f"CWE-{cwe_raw}"
    elif cwe_raw and cwe_raw.upper().startswith("CWE-"):
        cwe = cwe_raw.upper()
    else:
        cwe = ""

    return {
        "type":           "DAST_FINDING",
        "source":         "zap_scanner",
        "rule_id":        f"ZAP-{plugin_id}" if plugin_id else "ZAP-UNKNOWN",
        "title":          name,
        "severity":       severity,
        "description":    alert.get("description", ""),
        "evidence":       (alert.get("evidence", "") or "")[:500] or f"{method} {url}",
        "recommendation": alert.get("solution", ""),
        "cwe":            cwe,
        "file":           "",
        "line":           0,
        "url":            url,
        "method":         method,
        "param":          alert.get("param", ""),
        "attack":         (alert.get("attack", "") or "")[:200],
        "confidence":     confidence,
        "category":       "DAST",
        "tags":           ["dast", "zap"],
        "references":     [reference] if reference else [],
    }


class DASTScanner:
    """
    High-level DAST scanning interface wrapping OWASP ZAP.

    All public methods return a list of finding dicts on success and an
    empty list on ZAP connectivity failures (with a warning log).

    Parameters
    ----------
    zap_url:
        Base URL for the ZAP REST API (default ``http://localhost:8080``).
    api_key:
        ZAP API key (empty string disables authentication).
    """

    def __init__(
        self,
        zap_url: str = "http://localhost:8080",
        api_key: str = "",
    ) -> None:
        self._zap_url = zap_url
        self._api_key = api_key
        self._client  = ZAPClient(zap_url=zap_url, api_key=api_key)

    # ── Public API ─────────────────────────────────────────────────────────────

    def scan_url(
        self,
        target_url: str,
        auth_config: Optional[dict] = None,
        timeout: int = 300,
    ) -> List[dict]:
        """
        Active scan of *target_url* via ZAP (spider + active scan).

        Returns
        -------
        list[dict]
            List of finding dicts (empty on ZAP unreachable).
        """
        try:
            if not self._client.is_alive():
                logger.warning(
                    "DASTScanner.scan_url: ZAP not reachable at %s — skipping active scan",
                    self._zap_url,
                )
                return []

            self._client.new_session(f"tythan_active_{int(time.time())}")

            # Spider first
            spider_id = self._client.start_spider(target_url, max_depth=5)
            self._poll_spider(spider_id, timeout=min(timeout, 120))

            # Active scan
            scan_id = self._client.start_active_scan(target_url)
            self._client.wait_active_scan(scan_id, timeout=timeout)

            return self._collect_alerts(target_url)

        except (ConnectionError, TimeoutError, OSError) as exc:
            logger.warning(
                "DASTScanner.scan_url: ZAP unreachable (%s) — returning empty results", exc
            )
            return []
        except Exception as exc:  # pragma: no cover — safety net
            logger.warning(
                "DASTScanner.scan_url: unexpected error (%s) — returning empty results", exc
            )
            return []

    def passive_scan(
        self,
        target_url: str,
        timeout: int = 60,
    ) -> List[dict]:
        """
        Passive-only scan of *target_url* (no active probing).

        Returns
        -------
        list[dict]
            List of finding dicts (empty on ZAP unreachable).
        """
        try:
            if not self._client.is_alive():
                logger.warning(
                    "DASTScanner.passive_scan: ZAP not reachable at %s — skipping passive scan",
                    self._zap_url,
                )
                return []

            self._client.new_session(f"tythan_passive_{int(time.time())}")

            # Spider to populate ZAP's site tree without active probing
            spider_id = self._client.start_spider(target_url, max_depth=3)
            self._poll_spider(spider_id, timeout=min(timeout, 60))

            # Wait for passive scan queue to drain
            self._client.wait_passive_scan(timeout=timeout)

            return self._collect_alerts(target_url)

        except (ConnectionError, TimeoutError, OSError) as exc:
            logger.warning(
                "DASTScanner.passive_scan: ZAP unreachable (%s) — returning empty results", exc
            )
            return []
        except Exception as exc:  # pragma: no cover
            logger.warning(
                "DASTScanner.passive_scan: unexpected error (%s) — returning empty results", exc
            )
            return []

    def scan_openapi(self, spec_url: str) -> List[dict]:
        """
        Import an OpenAPI specification and run an active scan against the
        endpoints defined in it.

        Parameters
        ----------
        spec_url:
            URL to the OpenAPI/Swagger spec (JSON or YAML).

        Returns
        -------
        list[dict]
            List of finding dicts (empty on ZAP unreachable).
        """
        try:
            if not self._client.is_alive():
                logger.warning(
                    "DASTScanner.scan_openapi: ZAP not reachable at %s", self._zap_url
                )
                return []

            self._client.new_session(f"tythan_openapi_{int(time.time())}")
            self._client.import_openapi_url(spec_url)

            # Active scan against everything ZAP now knows about
            scan_id = self._client.start_active_scan(spec_url)
            self._client.wait_active_scan(scan_id, timeout=300)

            return self._collect_alerts()

        except (ConnectionError, TimeoutError, OSError) as exc:
            logger.warning(
                "DASTScanner.scan_openapi: ZAP unreachable (%s) — returning empty results", exc
            )
            return []
        except Exception as exc:  # pragma: no cover
            logger.warning(
                "DASTScanner.scan_openapi: unexpected error (%s) — returning empty results", exc
            )
            return []

    def spider(self, target_url: str, max_depth: int = 5) -> List[str]:
        """
        Discover URLs via ZAP's spider (no active attack).

        Returns
        -------
        list[str]
            Discovered URLs (empty on ZAP unreachable).
        """
        try:
            if not self._client.is_alive():
                logger.warning(
                    "DASTScanner.spider: ZAP not reachable at %s", self._zap_url
                )
                return []

            scan_id = self._client.start_spider(target_url, max_depth=max_depth)
            self._poll_spider(scan_id, timeout=120)
            return self._client.spider_results(scan_id)

        except (ConnectionError, TimeoutError, OSError) as exc:
            logger.warning(
                "DASTScanner.spider: ZAP unreachable (%s) — returning empty results", exc
            )
            return []
        except Exception as exc:  # pragma: no cover
            logger.warning(
                "DASTScanner.spider: unexpected error (%s) — returning empty results", exc
            )
            return []

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _collect_alerts(self, base_url: str = "") -> List[dict]:
        """Fetch all alerts from ZAP and convert to TythanAI finding dicts."""
        raw_alerts = self._client.get_alerts(base_url=base_url)
        findings: List[dict] = []
        for alert in raw_alerts:
            finding = _alert_dict_to_finding_dict(alert)
            if finding is not None:
                findings.append(finding)
        return findings

    def _poll_spider(self, scan_id: str, timeout: int = 120) -> None:
        """Block until ZAP spider reaches 100 % or timeout expires."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                progress = self._client.spider_progress(scan_id)
                if progress >= 100:
                    return
            except Exception:
                return
            time.sleep(2)
