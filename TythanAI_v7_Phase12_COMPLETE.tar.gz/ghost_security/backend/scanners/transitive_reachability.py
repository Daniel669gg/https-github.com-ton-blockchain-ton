"""
backend/scanners/transitive_reachability.py — TythanAI Transitive Reachability Analyzer
BFS-based import graph analysis and VEX status generation.
"""
from __future__ import annotations

import logging
import os
import re
from collections import deque
from pathlib import Path
from typing import Dict, List, Optional, Set

logger = logging.getLogger("tythanai.transitive_reachability")

# ─── Import regexes ───────────────────────────────────────────────────────────

_IMPORT_RE = re.compile(r'^\s*import\s+([\w.]+)', re.MULTILINE)
_FROM_IMPORT_RE = re.compile(r'^\s*from\s+([\w.]+)\s+import', re.MULTILINE)

# ─── Entrypoint detection ──────────────────────────────────────────────────────

_ENTRYPOINT_PATTERNS = [
    re.compile(r'if\s+__name__\s*==\s*["\']__main__["\']'),
    re.compile(r'\bdef\s+main\s*\('),
    re.compile(r'\bapp\s*=\s*FastAPI\s*\('),
    re.compile(r'\bapp\s*=\s*Flask\s*\('),
]


# ─── Analyzer ──────────────────────────────────────────────────────────────────

class TransitiveReachabilityAnalyzer:
    """BFS-based import graph builder and reachability checker."""

    def __init__(self) -> None:
        self._graph: Dict[str, List[str]] = {}
        self._directory: Optional[str] = None

    # ── Private helpers ────────────────────────────────────────────────────────

    @staticmethod
    def _file_to_module(file_path: str, base_dir: str) -> str:
        """Convert a filesystem path to a dotted module name relative to base_dir."""
        rel = os.path.relpath(file_path, base_dir)
        # strip .py extension
        if rel.endswith(".py"):
            rel = rel[:-3]
        # convert path separators to dots
        module = rel.replace(os.sep, ".").replace("/", ".")
        # strip __init__
        if module.endswith(".__init__"):
            module = module[: -len(".__init__")]
        return module

    @staticmethod
    def _parse_imports(content: str) -> List[str]:
        """Extract all imported module names from Python source."""
        imports: List[str] = []
        for m in _IMPORT_RE.finditer(content):
            imports.append(m.group(1).split(".")[0])  # top-level package
        for m in _FROM_IMPORT_RE.finditer(content):
            imports.append(m.group(1).split(".")[0])
        return imports

    @staticmethod
    def _collect_py_files(directory: str) -> List[str]:
        py_files: List[str] = []
        for root, _dirs, files in os.walk(directory):
            for fname in files:
                if fname.endswith(".py"):
                    py_files.append(os.path.join(root, fname))
        return py_files

    # ── Public API ─────────────────────────────────────────────────────────────

    def build_import_graph(self, directory: str) -> Dict[str, List[str]]:
        """
        BFS over Python files in *directory*, building {module: [imported_modules]}.
        Only intra-project imports are included in the graph values.
        """
        self._directory = directory
        base = Path(directory)
        py_files = self._collect_py_files(directory)

        # Build a set of known module names for this project
        known_modules: Set[str] = set()
        file_to_mod: Dict[str, str] = {}
        for fpath in py_files:
            mod = self._file_to_module(fpath, directory)
            known_modules.add(mod)
            # also register top-level package
            known_modules.add(mod.split(".")[0])
            file_to_mod[fpath] = mod

        graph: Dict[str, List[str]] = {}
        for fpath in py_files:
            mod = file_to_mod[fpath]
            try:
                content = Path(fpath).read_text(errors="replace")
            except OSError:
                graph[mod] = []
                continue

            raw_imports = self._parse_imports(content)
            # keep only those that resolve to known modules
            resolved: List[str] = []
            for imp in raw_imports:
                if imp in known_modules:
                    resolved.append(imp)
                # also try full module paths
                for km in known_modules:
                    if km == imp or km.startswith(imp + "."):
                        if km not in resolved:
                            resolved.append(km)
            graph[mod] = list(dict.fromkeys(resolved))  # deduplicate preserving order

        self._graph = graph
        return graph

    def is_reachable(self, from_module: str, to_module: str) -> bool:
        """Return True if *to_module* is transitively reachable from *from_module*."""
        return to_module in self.reachable_from(from_module)

    def reachable_from(self, module: str) -> Set[str]:
        """Return all modules transitively reachable from *module* via BFS."""
        visited: Set[str] = set()
        queue: deque = deque([module])

        while queue:
            current = queue.popleft()
            if current in visited:
                continue
            visited.add(current)
            for neighbour in self._graph.get(current, []):
                if neighbour not in visited:
                    queue.append(neighbour)

        visited.discard(module)  # don't include the start node itself
        return visited

    def entrypoints(self, directory: str) -> List[str]:
        """
        Return module names for files that look like entrypoints:
        - contain `if __name__ == "__main__"`
        - define `main()` function
        - create a FastAPI or Flask app
        """
        if not self._graph or self._directory != directory:
            self.build_import_graph(directory)

        py_files = self._collect_py_files(directory)
        eps: List[str] = []
        for fpath in py_files:
            try:
                content = Path(fpath).read_text(errors="replace")
            except OSError:
                continue
            for pattern in _ENTRYPOINT_PATTERNS:
                if pattern.search(content):
                    mod = self._file_to_module(fpath, directory)
                    if mod not in eps:
                        eps.append(mod)
                    break
        return eps

    def generate_vex(self, findings: List[dict], directory: str) -> List[dict]:
        """
        For each finding, if the vulnerable package is NOT reachable from any
        entrypoint, annotate with vex_status=not_affected.

        *findings* are dicts that may contain a 'package' or 'rule_id' key
        identifying the vulnerable package name.
        """
        if not self._graph or self._directory != directory:
            self.build_import_graph(directory)

        eps = self.entrypoints(directory)

        # Compute union of all reachable modules from all entrypoints
        all_reachable: Set[str] = set()
        for ep in eps:
            all_reachable.update(self.reachable_from(ep))
            all_reachable.add(ep)

        result: List[dict] = []
        for finding in findings:
            f = dict(finding)  # copy so we don't mutate caller's data
            pkg = f.get("package") or f.get("module") or f.get("rule_id", "")
            # Normalise: treat the top-level package name
            pkg_top = pkg.split(".")[0] if pkg else ""

            if pkg_top and pkg_top not in all_reachable:
                f["vex_status"] = "not_affected"
                f["justification"] = "not_reachable"
            result.append(f)

        return result
