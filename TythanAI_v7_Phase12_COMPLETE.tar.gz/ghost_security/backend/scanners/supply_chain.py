"""Forwarding shim — canonical location is scanners/supply_chain_scanner.py."""
from __future__ import annotations
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from scanners.supply_chain_scanner import (  # noqa: F401
    SupplyChainScanner as _BaseSupplyChainScanner,
    _levenshtein,
    _POPULAR_PYPI,
    _POPULAR_NPM,
)

# ─── Extended package entry with is_dev flag ──────────────────────────────────

@dataclass
class _PkgEntry:
    name: str
    version: str = ""
    ecosystem: str = "unknown"
    is_dev: bool = False


# ─── String-path accepting parsers with is_dev support ───────────────────────

def _parse_requirements_txt(path_or_str) -> List[_PkgEntry]:
    """Parse requirements.txt; accepts str or Path. Returns _PkgEntry list."""
    text = Path(path_or_str).read_text(errors="replace")
    result: List[_PkgEntry] = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^([A-Za-z0-9_.\-]+)", line)
        if m:
            name = m.group(1)
            ver_m = re.search(r"[=><~^!]+([\w.]+)", line)
            result.append(_PkgEntry(
                name=name,
                version=ver_m.group(1) if ver_m else "",
                ecosystem="pypi",
            ))
    return result


def _parse_package_json(path_or_str) -> List[_PkgEntry]:
    """Parse package.json; accepts str or Path. Returns _PkgEntry list with is_dev."""
    data = json.loads(Path(path_or_str).read_text(errors="replace"))
    result: List[_PkgEntry] = []
    for name, ver in data.get("dependencies", {}).items():
        result.append(_PkgEntry(name=name, version=str(ver), ecosystem="npm"))
    for name, ver in data.get("devDependencies", {}).items():
        result.append(_PkgEntry(
            name=name, version=str(ver), ecosystem="npm", is_dev=True))
    return result


def _parse_cargo_toml(path_or_str) -> List[_PkgEntry]:
    """Parse Cargo.toml; accepts str or Path. Returns _PkgEntry list with is_dev."""
    text = Path(path_or_str).read_text(errors="replace")
    result: List[_PkgEntry] = []
    section = "dependencies"
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("["):
            section = stripped.strip("[]").strip().lower()
            continue
        if "=" in stripped and not stripped.startswith("#"):
            parts = stripped.split("=", 1)
            name = parts[0].strip().strip('"')
            if name:
                ver_m = re.search(r'"([^"]+)"', parts[1]) if len(parts) > 1 else None
                result.append(_PkgEntry(
                    name=name,
                    version=ver_m.group(1) if ver_m else "",
                    ecosystem="cargo",
                    is_dev="dev" in section,
                ))
    return result


# ─── Typosquatting check ──────────────────────────────────────────────────────

def _check_typosquatting(
    name: str, popular: "Set[str] | dict", threshold: int = 2
) -> "Optional[str]":
    """Return the popular package name that *name* is a typosquat of, or None."""
    names_iter = popular.keys() if isinstance(popular, dict) else popular
    normalized = re.sub(r"[-_.]", "", name.lower())
    for popular_name in names_iter:
        pop_norm = re.sub(r"[-_.]", "", popular_name.lower())
        if normalized == pop_norm:
            return None  # exact match → legitimate
        if _levenshtein(normalized, pop_norm) <= threshold:
            return popular_name
    return None


# ─── Package import check ─────────────────────────────────────────────────────

def _package_imported(directory: str, package_name: str) -> bool:
    """Check whether *package_name* is imported anywhere in *directory*."""
    import os
    name = re.escape(package_name.replace("-", "_"))
    pattern = re.compile(rf"(?:^|\n)\s*(?:import\s+{name}|from\s+{name}\b)")
    for root, _, files in os.walk(directory):
        for fname in files:
            if fname.endswith(".py"):
                try:
                    text = open(
                        os.path.join(root, fname),
                        encoding="utf-8", errors="replace",
                    ).read()
                    if pattern.search(text):
                        return True
                except OSError:
                    pass
    return False


# ─── OSV lookup (replaceable via monkeypatch) ─────────────────────────────────

def _osv_lookup(packages: list) -> Dict[str, list]:
    """Query OSV for known vulnerabilities. Returns {pkg_name: [vuln_dict, ...]}."""
    return {}  # default: no network call — monkeypatched in tests


# ─── Severity helpers ─────────────────────────────────────────────────────────

_SEV_ORDER = ["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"]


def _cap_severity(severity: str, cap: str) -> str:
    idx = _SEV_ORDER.index(severity) if severity in _SEV_ORDER else 3
    cap_idx = _SEV_ORDER.index(cap) if cap in _SEV_ORDER else 3
    return _SEV_ORDER[min(idx, cap_idx)]


# ─── Extended SupplyChainScanner ──────────────────────────────────────────────

class SupplyChainScanner(_BaseSupplyChainScanner):
    """Extends the base scanner with a unified scan() method."""

    def scan(self, directory: str) -> dict:
        """Scan *directory* and return a unified result dict."""
        root = Path(directory)
        packages: List[_PkgEntry] = []

        for req_file in root.rglob("requirements*.txt"):
            if "node_modules" not in str(req_file):
                packages.extend(_parse_requirements_txt(req_file))

        for pkg_file in root.rglob("package.json"):
            if "node_modules" not in str(pkg_file):
                packages.extend(_parse_package_json(pkg_file))

        # typosquatting
        all_popular: Set[str] = _POPULAR_PYPI | _POPULAR_NPM
        typosquatting: List[dict] = []
        for pkg in packages:
            similar = _check_typosquatting(pkg.name, all_popular)
            if similar:
                typosquatting.append({
                    "package": pkg.name,
                    "similar_to": similar,
                    "severity": "HIGH",
                    "rule_id": "SC-TYPOSQUAT-001",
                    "message": f"'{pkg.name}' may be a typosquat of '{similar}'",
                })

        # vulnerability lookup
        findings: List[dict] = list(typosquatting)
        if packages:
            vuln_map = _osv_lookup(packages)
            for pkg in packages:
                vulns = vuln_map.get(pkg.name, [])
                for vuln in vulns:
                    details = (vuln.get("details") or vuln.get("summary") or "")
                    disputed = "disputed" in details.lower()
                    severity = "MEDIUM"
                    if pkg.is_dev:
                        severity = _cap_severity(severity, "MEDIUM")
                    if disputed:
                        severity = _cap_severity(severity, "MEDIUM")
                    if not _package_imported(str(root), pkg.name):
                        severity = "INFO"
                    findings.append({
                        "package": pkg.name,
                        "version": pkg.version,
                        "vuln_id": vuln.get("id", ""),
                        "severity": severity,
                        "message": vuln.get("summary", ""),
                        "is_dev": pkg.is_dev,
                        "disputed": disputed,
                    })

        return {
            "findings": findings,
            "packages_scanned": len(packages),
            "typosquatting": typosquatting,
            "total": len(findings),
        }
