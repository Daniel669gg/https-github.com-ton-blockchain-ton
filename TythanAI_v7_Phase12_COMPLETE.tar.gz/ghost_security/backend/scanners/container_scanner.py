"""
backend/scanners/container_scanner.py — Container Security Scanner

Dockerfile / docker-compose static analysis with standardised rule IDs:
  CONT-001: latest/untagged base image
  CONT-002: container runs as root (no USER directive)
  CONT-003: pipe-to-shell install (curl/wget | sh/bash)
  CONT-C-001: privileged compose service
  CONT-C-004: /var/run/docker.sock mounted in compose
"""
from __future__ import annotations
import re
import yaml
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class ContainerFinding:
    rule_id:     str
    severity:    str   # CRITICAL | HIGH | MEDIUM | LOW
    category:    str   # BASE_IMAGE | PRIVILEGE | BUILD | …
    message:     str
    description: str = ""
    file:        str = ""
    line:        int = 0
    evidence:    str = ""
    cwe:         str = ""

    def to_dict(self) -> dict:
        return {
            "rule_id":     self.rule_id,
            "severity":    self.severity,
            "category":    self.category,
            "message":     self.message,
            "description": self.description,
            "file":        self.file,
            "line":        self.line,
            "evidence":    self.evidence,
            "cwe":         self.cwe,
        }


# Backward-compat alias so old code that says .vuln_id still works
class ContainerScanResult(ContainerFinding):
    @property
    def vuln_id(self) -> str:
        return self.rule_id


# ─── Dockerfile analyzer ─────────────────────────────────────────────────────

_PIPE_SHELL = re.compile(
    r"(curl|wget)\s+[^\n]+\|\s*(sh|bash|ash|zsh|dash)",
    re.IGNORECASE,
)
_FROM_LINE = re.compile(r"^\s*FROM\s+(\S+)", re.MULTILINE | re.IGNORECASE)


def _scan_dockerfile(content: str, path: str) -> List[ContainerFinding]:
    findings: List[ContainerFinding] = []
    lines = content.splitlines()
    has_user = any(
        re.match(r"^\s*USER\s+(?!0\b|root\b)", line, re.IGNORECASE)
        for line in lines
    )

    for i, line in enumerate(lines, 1):
        # CONT-001: :latest or untagged base image
        m = re.match(r"^\s*FROM\s+(\S+)", line, re.IGNORECASE)
        if m:
            image = m.group(1).split("@")[0]  # strip digest
            if image.lower() == "scratch":
                continue
            if ":" not in image or image.endswith(":latest"):
                findings.append(ContainerFinding(
                    rule_id="CONT-001",
                    severity="MEDIUM",
                    category="BASE_IMAGE",
                    message=f"Base image '{image}' uses :latest or no tag",
                    description="Pin to an exact digest or immutable tag for reproducible builds.",
                    file=path, line=i, cwe="CWE-1188",
                    evidence=line.strip(),
                ))

        # CONT-003: pipe-to-shell
        if re.match(r"^\s*RUN\s+", line, re.IGNORECASE):
            if _PIPE_SHELL.search(line):
                findings.append(ContainerFinding(
                    rule_id="CONT-003",
                    severity="CRITICAL",
                    category="BUILD",
                    message="Pipe-to-shell install detected (curl/wget | bash/sh)",
                    description="Downloading and executing scripts without verification is dangerous.",
                    file=path, line=i, cwe="CWE-494",
                    evidence=line.strip(),
                ))

    # CONT-002: no non-root USER
    if not has_user:
        findings.append(ContainerFinding(
            rule_id="CONT-002",
            severity="HIGH",
            category="PRIVILEGE",
            message="No USER directive — container runs as root by default",
            description="Specify a non-root USER to apply least-privilege.",
            file=path, cwe="CWE-250",
            evidence="(no USER instruction)",
        ))

    return findings


# ─── Docker Compose analyzer ──────────────────────────────────────────────────

def _scan_compose(content: str, path: str) -> List[ContainerFinding]:
    findings: List[ContainerFinding] = []
    try:
        doc = yaml.safe_load(content)
    except Exception:
        return findings
    if not isinstance(doc, dict):
        return findings

    services = doc.get("services") or {}
    for svc_name, svc in services.items():
        if not isinstance(svc, dict):
            continue

        # CONT-C-001: privileged service
        if svc.get("privileged") is True:
            findings.append(ContainerFinding(
                rule_id="CONT-C-001",
                severity="CRITICAL",
                category="PRIVILEGE",
                message=f"Service '{svc_name}' runs with privileged: true",
                description="Privileged containers have full host access.",
                file=path, cwe="CWE-269",
                evidence=f"services.{svc_name}.privileged: true",
            ))

        # CONT-C-004: docker.sock mount
        for vol in (svc.get("volumes") or []):
            vol_str = vol if isinstance(vol, str) else vol.get("source", "")
            if "/var/run/docker.sock" in vol_str:
                findings.append(ContainerFinding(
                    rule_id="CONT-C-004",
                    severity="CRITICAL",
                    category="PRIVILEGE",
                    message=f"Service '{svc_name}' mounts Docker socket",
                    description="Mounting /var/run/docker.sock grants container-escape capabilities.",
                    file=path, cwe="CWE-269",
                    evidence=f"services.{svc_name}.volumes: {vol_str}",
                ))

    return findings


# ─── ContainerScanner ─────────────────────────────────────────────────────────

class ContainerScanner:
    """Container security scanner: Dockerfile + Compose static analysis."""

    def scan_dockerfile(self, file_path: str) -> List[ContainerFinding]:
        p = Path(file_path)
        if not p.exists():
            return []
        return _scan_dockerfile(p.read_text(errors="replace"), file_path)

    def scan_compose(self, file_path: str) -> List[ContainerFinding]:
        p = Path(file_path)
        if not p.exists():
            return []
        return _scan_compose(p.read_text(errors="replace"), file_path)

    def scan_image(self, image: str, timeout: int = 120) -> List[ContainerFinding]:
        return []

    def scan_directory(self, directory: str) -> dict:
        root = Path(directory)
        findings: List[ContainerFinding] = []
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            name = p.name.lower()
            if name == "dockerfile" or name.startswith("dockerfile."):
                findings.extend(self.scan_dockerfile(str(p)))
            elif name in ("docker-compose.yml", "docker-compose.yaml",
                          "compose.yml", "compose.yaml"):
                findings.extend(self.scan_compose(str(p)))
        return {
            "findings": [f.to_dict() for f in findings],
            "total": len(findings),
        }
