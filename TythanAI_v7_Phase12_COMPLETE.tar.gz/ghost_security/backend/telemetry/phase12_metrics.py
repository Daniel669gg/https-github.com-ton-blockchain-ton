# TythanAI Security Platform
# Copyright (c) 2026 TythanAI Labs
# Licensed under the Business Source License 1.1 (see LICENSE).

"""
backend/telemetry/phase12_metrics.py — TythanAI Phase 12 Prometheus metrics.

New counters and histograms for Phase 12 scanners.
Import and call register() once at app startup:

    from backend.telemetry.phase12_metrics import Phase12Metrics
    metrics = Phase12Metrics()

Then instrument scanner calls:
    metrics.dast_scans_total.inc()
    with metrics.quality_scan_duration.time():
        ...
"""
from __future__ import annotations

import time
from typing import Optional


class _NoOpCounter:
    """Fallback when prometheus_client is not installed."""
    def inc(self, amount: float = 1) -> None:
        pass
    def labels(self, **kw) -> "_NoOpCounter":
        return self


class _NoOpHistogram:
    def observe(self, amount: float) -> None:
        pass
    def labels(self, **kw) -> "_NoOpHistogram":
        return self
    def time(self):
        return _Timer()
    def __enter__(self):
        return self
    def __exit__(self, *a):
        pass


class _Timer:
    def __enter__(self):
        self._t = time.time()
        return self
    def __exit__(self, *a):
        pass


class Phase12Metrics:
    """
    Prometheus metrics for Phase 12 scanners.
    Gracefully degrades to no-ops if prometheus_client is unavailable.
    """

    def __init__(self, registry=None):
        try:
            from prometheus_client import Counter, Histogram, Gauge
            reg_kw = {"registry": registry} if registry else {}

            self.dast_scans_total = Counter(
                "tythanai_dast_scans_total",
                "Total DAST scans executed",
                ["mode"],          # passive | active
                **reg_kw,
            )
            self.dast_findings_total = Counter(
                "tythanai_dast_findings_total",
                "Total DAST findings",
                ["severity"],
                **reg_kw,
            )
            self.dast_scan_duration_seconds = Histogram(
                "tythanai_dast_scan_duration_seconds",
                "DAST scan duration in seconds",
                ["mode"],
                **reg_kw,
            )

            self.quality_scans_total = Counter(
                "tythanai_quality_scans_total",
                "Total code quality scans",
                **reg_kw,
            )
            self.quality_grade_distribution = Counter(
                "tythanai_quality_grade_total",
                "Files per quality grade",
                ["grade"],
                **reg_kw,
            )
            self.quality_scan_duration_seconds = Histogram(
                "tythanai_quality_scan_duration_seconds",
                "Code quality scan duration",
                **reg_kw,
            )

            self.swift_scans_total = Counter(
                "tythanai_swift_scans_total",
                "Total Swift scanner runs",
                **reg_kw,
            )
            self.swift_findings_total = Counter(
                "tythanai_swift_findings_total",
                "Total Swift scanner findings",
                ["severity", "rule_id"],
                **reg_kw,
            )

            self.autopr_prs_created_total = Counter(
                "tythanai_autopr_prs_created_total",
                "Total AutoPR pull requests created",
                ["dry_run"],
                **reg_kw,
            )
            self.autopr_patches_applied_total = Counter(
                "tythanai_autopr_patches_applied_total",
                "Total patches applied by AutoPR",
                **reg_kw,
            )

            self.multichain_scans_total = Counter(
                "tythanai_multichain_scans_total",
                "Total multi-chain auditor scans",
                ["chain"],
                **reg_kw,
            )
            self.multichain_findings_total = Counter(
                "tythanai_multichain_findings_total",
                "Total multi-chain findings",
                ["chain", "severity"],
                **reg_kw,
            )

            self.marketplace_installs_total = Counter(
                "tythanai_marketplace_installs_total",
                "Total rules marketplace installs",
                **reg_kw,
            )
            self.marketplace_searches_total = Counter(
                "tythanai_marketplace_searches_total",
                "Total rules marketplace searches",
                **reg_kw,
            )

            self.onboarding_sessions_total = Counter(
                "tythanai_onboarding_sessions_total",
                "Total onboarding sessions started",
                ["plan"],
                **reg_kw,
            )
            self.webhook_dispatches_total = Counter(
                "tythanai_webhook_dispatches_total",
                "Total webhook dispatch attempts",
                ["event", "status"],
                **reg_kw,
            )

            self.active_scans = Gauge(
                "tythanai_active_scans",
                "Currently running scans",
                **reg_kw,
            )

            self._enabled = True

        except ImportError:
            self._enabled = False
            for attr in [
                "dast_scans_total", "dast_findings_total", "dast_scan_duration_seconds",
                "quality_scans_total", "quality_grade_distribution", "quality_scan_duration_seconds",
                "swift_scans_total", "swift_findings_total",
                "autopr_prs_created_total", "autopr_patches_applied_total",
                "multichain_scans_total", "multichain_findings_total",
                "marketplace_installs_total", "marketplace_searches_total",
                "onboarding_sessions_total", "webhook_dispatches_total",
                "active_scans",
            ]:
                setattr(self, attr, _NoOpCounter())

    @property
    def enabled(self) -> bool:
        return self._enabled

    def record_dast_findings(self, findings: list, mode: str = "passive") -> None:
        self.dast_scans_total.labels(mode=mode).inc()
        for f in findings:
            sev = f.get("severity", "INFO")
            self.dast_findings_total.labels(severity=sev).inc()

    def record_quality_report(self, reports) -> None:
        self.quality_scans_total.inc()
        for r in reports:
            grade = getattr(r, "grade", "?")
            self.quality_grade_distribution.labels(grade=grade).inc()

    def record_swift_findings(self, findings: list) -> None:
        self.swift_scans_total.inc()
        for f in findings:
            self.swift_findings_total.labels(
                severity=f.get("severity", "INFO"),
                rule_id=f.get("rule_id", "?"),
            ).inc()

    def record_multichain_scan(self, findings: list) -> None:
        for f in findings:
            chain = f.get("chain", "UNKNOWN")
            sev = f.get("severity", "INFO")
            self.multichain_scans_total.labels(chain=chain).inc()
            self.multichain_findings_total.labels(chain=chain, severity=sev).inc()


# Module-level singleton
_default_metrics: Optional[Phase12Metrics] = None


def get_metrics() -> Phase12Metrics:
    global _default_metrics
    if _default_metrics is None:
        _default_metrics = Phase12Metrics()
    return _default_metrics
