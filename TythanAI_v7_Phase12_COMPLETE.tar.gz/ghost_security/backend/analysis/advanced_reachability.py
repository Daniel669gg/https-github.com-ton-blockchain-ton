"""
backend/analysis/advanced_reachability.py — CPG-aware reachability analysis.

Extends the existing ReachabilityAnalyzer with:
- Per-finding reachability evidence (can attacker realistically reach this sink?)
- User-controlled input reachability scoring
- Endpoint-to-sink path computation via CPG
- Attack surface mapping
- Reachability, exploitability, and path confidence scores

Uses the CPG graph for precise path analysis, not just regex heuristics.
"""
from __future__ import annotations

import logging
import re
from collections import deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

from backend.core.cpg.graph import (
    CodePropertyGraph,
    CPGEdge,
    CPGEdgeType,
    CPGNode,
    CPGNodeType,
)
from backend.core.confidence import Finding
from backend.core.patterns import (
    CWE_META,
    classify_node_as_source,
    get_sanitizers,
    get_sinks,
    get_sources,
)

logger = logging.getLogger("tythanai.advanced_reachability")

# Edge types traversed during BFS — data-flow, call-graph, and control-flow
_TRAVERSAL_EDGE_TYPES: List[CPGEdgeType] = [
    CPGEdgeType.DFG_FLOW,
    CPGEdgeType.CG_CALL,
    CPGEdgeType.CG_RETURN,
    CPGEdgeType.CFG_NEXT,
]

# Decorators/patterns that mark internet-facing (unauthenticated) HTTP routes
_ROUTE_PATTERNS: List[re.Pattern] = [
    re.compile(r"@\s*\w+\.route\s*\("),
    re.compile(r"@\s*\w+\.(get|post|put|delete|patch|options|head|websocket)\s*\(", re.IGNORECASE),
    re.compile(r"@\s*app\.(get|post|put|delete|patch)\s*\(", re.IGNORECASE),
]

# CLI entry-point markers
_CLI_PATTERNS: List[re.Pattern] = [
    re.compile(r"@\s*(?:click|typer)\s*\.\s*command\s*\("),
    re.compile(r"argparse\.ArgumentParser\s*\("),
    re.compile(r"if\s+__name__\s*==\s*['\"]__main__['\"]"),
]

# Heuristic window (lines) when no CPG path is found
_HEURISTIC_WINDOW: int = 50


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class ReachabilityHop:
    """A single node on the CPG path from an entry point to a sink."""

    node_id: str
    code: str
    file: str
    line: int
    hop_type: str  # "entry", "call", "dfg", "cfg", "sink"


@dataclass
class SinkReachabilityResult:
    """Full reachability analysis result for one Finding."""

    finding_id: str           # finding.fingerprint()
    cwe_id: str
    sink_file: str
    sink_line: int
    reachable: bool           # Can attacker reach this sink?
    user_controlled: bool     # Is the input tainted from a user source?
    requires_auth: bool       # Does path pass through auth check?
    auth_patterns_found: List[str]  # auth decorator/check names found on path
    reachability_score: float      # 0.0–1.0
    exploitability_score: float    # 0.0–1.0
    path_confidence: float         # 0.0–1.0
    shortest_path: List[ReachabilityHop]   # CPG path from entry to sink
    evidence_summary: str
    attack_surface_category: str   # "internet_facing", "authenticated", "internal", "cli"


# ---------------------------------------------------------------------------
# AdvancedReachabilityAnalyzer
# ---------------------------------------------------------------------------

class AdvancedReachabilityAnalyzer:
    """
    CPG-aware reachability analyzer that extends the existing ReachabilityAnalyzer.

    Produces per-finding SinkReachabilityResult objects with precise scores
    derived from CPG traversal rather than purely file-level heuristics.
    """

    # Auth patterns that reduce reachability score.
    # Each entry: (compiled_pattern, human_readable_name, score_penalty)
    _AUTH_PATTERNS: List[Tuple[re.Pattern, str, float]] = [
        (re.compile(r"@login_required"),                          "@login_required",            0.30),
        (re.compile(r"@requires_auth"),                           "@requires_auth",             0.30),
        (re.compile(r"@jwt_required"),                            "@jwt_required",              0.25),
        (re.compile(r"@permission_required"),                     "@permission_required",       0.25),
        (re.compile(r"permission_classes\s*="),                   "permission_classes",         0.20),
        (re.compile(r"is_authenticated"),                         "is_authenticated check",     0.15),
        (re.compile(r"current_user\.is_staff|is_superuser"),      "admin check",                0.35),
        (re.compile(r"verify_token|decode_token|verify_jwt"),     "token verification",         0.25),
    ]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze_finding(
        self,
        finding: Finding,
        cpg: CodePropertyGraph,
        source_code: str,
    ) -> SinkReachabilityResult:
        """Compute full reachability analysis for a single Finding.

        Uses CPG graph traversal as the primary strategy.  When no CPG path
        is found the method falls back to regex heuristics over the surrounding
        source lines.
        """
        finding_id = finding.fingerprint()
        cwe_id = finding.cwe_id or ""

        logger.debug(
            "analyze_finding: %s  %s:%d", finding_id, finding.file, finding.line
        )

        # 1. Locate the sink node in the CPG
        sink_node = self._find_sink_node(finding, cpg)

        # 2. Locate source nodes for this CWE
        source_nodes = self._find_source_nodes(cpg, cwe_id)

        # 3. Attempt BFS path from sources to sink
        shortest_path: Optional[List[ReachabilityHop]] = None
        if sink_node is not None and source_nodes:
            shortest_path = self._bfs_to_sink(source_nodes, sink_node, cpg)

        # 4. Determine user-controlled status
        if shortest_path is not None:
            user_controlled = True
        else:
            user_controlled = self._is_user_controlled_heuristic(finding, source_code)

        # 5. Check auth on path
        requires_auth, auth_patterns_found = self._check_auth_on_path(
            shortest_path or [], source_code
        )

        # 6. Compute scores
        reachability_score, exploitability_score, path_confidence = self._compute_scores(
            shortest_path, user_controlled, requires_auth, finding, source_code
        )

        # 7. Classify attack surface
        attack_surface_category = self._classify_attack_surface(
            source_code, shortest_path
        )

        # 8. Build evidence summary
        evidence_summary = self._build_evidence_summary(
            finding=finding,
            shortest_path=shortest_path,
            user_controlled=user_controlled,
            requires_auth=requires_auth,
            auth_patterns_found=auth_patterns_found,
            reachability_score=reachability_score,
            exploitability_score=exploitability_score,
            attack_surface_category=attack_surface_category,
        )

        return SinkReachabilityResult(
            finding_id=finding_id,
            cwe_id=cwe_id,
            sink_file=finding.file,
            sink_line=finding.line,
            reachable=reachability_score >= 0.3,
            user_controlled=user_controlled,
            requires_auth=requires_auth,
            auth_patterns_found=auth_patterns_found,
            reachability_score=round(reachability_score, 4),
            exploitability_score=round(exploitability_score, 4),
            path_confidence=round(path_confidence, 4),
            shortest_path=shortest_path or [],
            evidence_summary=evidence_summary,
            attack_surface_category=attack_surface_category,
        )

    def analyze_all_findings(
        self,
        findings: List[Finding],
        cpg: CodePropertyGraph,
        source_code: str,
    ) -> List[SinkReachabilityResult]:
        """Analyze reachability for a list of findings.

        Results are returned in descending exploitability_score order.
        Any individual failure is logged and skipped rather than crashing the
        entire batch.
        """
        results: List[SinkReachabilityResult] = []
        for finding in findings:
            try:
                result = self.analyze_finding(finding, cpg, source_code)
                results.append(result)
            except Exception as exc:
                logger.error(
                    "analyze_all_findings: error on %s:%d — %s",
                    finding.file, finding.line, exc,
                    exc_info=True,
                )

        results.sort(key=lambda r: r.exploitability_score, reverse=True)
        return results

    def map_attack_surface(
        self,
        cpg: CodePropertyGraph,
        source_code: str,
    ) -> Dict[str, float]:
        """Map CPG node IDs to attack-surface scores.

        Score reflects how close a node is to user-controlled taint sources.
        Nodes that ARE taint sources score 1.0; each hop away via
        DFG_FLOW / CG_CALL / CFG_NEXT edges decays the score by 0.15.

        Returns ``{node_id: score}`` for all reachable nodes.
        """
        surface: Dict[str, float] = {}

        # Identify source nodes across all CWEs
        all_source_nodes: List[CPGNode] = []
        seen_source_ids: Set[str] = set()
        for cwe_id in CWE_META:
            for node in self._find_source_nodes(cpg, cwe_id):
                if node.node_id not in seen_source_ids:
                    seen_source_ids.add(node.node_id)
                    all_source_nodes.append(node)

        # Additionally, check against source_code heuristics for all nodes
        for node in cpg.nodes.values():
            if node.node_id not in seen_source_ids:
                match = classify_node_as_source(node.code)
                if match is not None:
                    seen_source_ids.add(node.node_id)
                    all_source_nodes.append(node)

        if not all_source_nodes:
            return surface

        # BFS from each source node, propagating score with depth decay
        decay = 0.15
        max_hops = 20

        for src in all_source_nodes:
            # BFS queue: (node_id, current_score)
            queue: deque[Tuple[str, float, int]] = deque([(src.node_id, 1.0, 0)])
            visited: Set[str] = set()

            while queue:
                nid, score, depth = queue.popleft()
                if nid in visited or depth > max_hops:
                    continue
                visited.add(nid)

                # Update surface map: take the maximum score seen for each node
                if score > surface.get(nid, 0.0):
                    surface[nid] = round(score, 4)

                # Propagate to neighbours via traversal edge types
                next_score = score - decay
                if next_score <= 0.0:
                    continue

                for edge in cpg._adj.get(nid, []):
                    if edge.edge_type in _TRAVERSAL_EDGE_TYPES:
                        if edge.dst_id not in visited:
                            queue.append((edge.dst_id, next_score, depth + 1))

        return surface

    # ------------------------------------------------------------------
    # Internal: CPG helpers
    # ------------------------------------------------------------------

    def _find_sink_node(
        self, finding: Finding, cpg: CodePropertyGraph
    ) -> Optional[CPGNode]:
        """Find the CPG node that best corresponds to the finding's file:line.

        Searches for an exact file+line match first, then relaxes to file-only
        with the closest line number.
        """
        if not cpg.nodes:
            return None

        # First pass: exact file and line match
        for node in cpg.nodes.values():
            if node.file == finding.file and node.line == finding.line:
                return node

        # Second pass: same file, closest line (within ±5 lines)
        best_node: Optional[CPGNode] = None
        best_distance = 6  # threshold

        for node in cpg.nodes.values():
            if node.file != finding.file:
                continue
            distance = abs(node.line - finding.line)
            if distance < best_distance:
                best_distance = distance
                best_node = node

        if best_node is not None:
            logger.debug(
                "_find_sink_node: fuzzy match at %s:%d (finding line %d, delta %d)",
                best_node.file, best_node.line, finding.line, best_distance,
            )

        return best_node

    def _find_source_nodes(
        self, cpg: CodePropertyGraph, cwe_id: str
    ) -> List[CPGNode]:
        """Find CPG nodes that are taint sources for the given CWE.

        Uses compiled SOURCE_PATTERNS from the patterns registry and falls back
        to the CPGNode.is_taint_source() helper for unregistered CWEs.
        """
        source_patterns = get_sources(cwe_id)  # List[Tuple[Pattern, float]]
        sources: List[CPGNode] = []

        for node in cpg.nodes.values():
            matched = False
            if source_patterns:
                for pattern, _conf in source_patterns:
                    if pattern.search(node.code):
                        matched = True
                        break
            else:
                # Fallback: use the CPGNode's built-in heuristic
                matched = node.is_taint_source()

            if matched:
                sources.append(node)

        return sources

    def _bfs_to_sink(
        self,
        source_nodes: List[CPGNode],
        sink_node: CPGNode,
        cpg: CodePropertyGraph,
        max_depth: int = 20,
    ) -> Optional[List[ReachabilityHop]]:
        """BFS through CPG from source nodes to the sink node.

        Traverses DFG_FLOW, CG_CALL, CG_RETURN, and CFG_NEXT edges.
        Returns the shortest path as a list of ReachabilityHop objects, or
        None if no path is found within max_depth hops.
        """
        if not source_nodes or sink_node is None:
            return None

        sink_id = sink_node.node_id

        # BFS state: queue of (current_node_id, path_so_far_as_node_ids)
        # We use a separate visited set per search to avoid cross-source contamination
        # but share the initial visited set for efficiency across source nodes.

        # Pre-check: is the sink itself a source node? (degenerate case)
        for src in source_nodes:
            if src.node_id == sink_id:
                return [
                    ReachabilityHop(
                        node_id=src.node_id,
                        code=src.code,
                        file=src.file,
                        line=src.line,
                        hop_type="entry",
                    )
                ]

        # Multi-source BFS: start from all source nodes simultaneously
        # path_map[node_id] = list of node_ids from a source to this node
        path_map: Dict[str, List[str]] = {}
        visited: Set[str] = set()
        queue: deque[Tuple[str, List[str]]] = deque()

        for src in source_nodes:
            if src.node_id not in visited:
                visited.add(src.node_id)
                path_map[src.node_id] = [src.node_id]
                queue.append((src.node_id, [src.node_id]))

        found_path: Optional[List[str]] = None

        while queue:
            current_id, current_path = queue.popleft()

            if len(current_path) > max_depth:
                continue

            for edge in cpg._adj.get(current_id, []):
                if edge.edge_type not in _TRAVERSAL_EDGE_TYPES:
                    continue

                next_id = edge.dst_id
                if next_id in visited:
                    continue

                new_path = current_path + [next_id]
                visited.add(next_id)
                path_map[next_id] = new_path

                if next_id == sink_id:
                    found_path = new_path
                    break

                queue.append((next_id, new_path))

            if found_path is not None:
                break

        if found_path is None:
            return None

        # Convert node ID path to ReachabilityHop list
        hops: List[ReachabilityHop] = []
        path_length = len(found_path)

        for idx, nid in enumerate(found_path):
            node = cpg.nodes.get(nid)
            if node is None:
                continue

            # Classify the hop type based on position and edge type
            if idx == 0:
                hop_type = "entry"
            elif idx == path_length - 1:
                hop_type = "sink"
            else:
                # Determine from the edge leading into this node
                prev_id = found_path[idx - 1]
                hop_type = "dfg"  # default
                for edge in cpg._adj.get(prev_id, []):
                    if edge.dst_id == nid:
                        if edge.edge_type in (CPGEdgeType.CG_CALL, CPGEdgeType.CG_RETURN):
                            hop_type = "call"
                        elif edge.edge_type == CPGEdgeType.CFG_NEXT:
                            hop_type = "cfg"
                        else:
                            hop_type = "dfg"
                        break

            hops.append(
                ReachabilityHop(
                    node_id=nid,
                    code=node.code,
                    file=node.file,
                    line=node.line,
                    hop_type=hop_type,
                )
            )

        return hops

    def _check_auth_on_path(
        self,
        path: List[ReachabilityHop],
        source_code: str,
    ) -> Tuple[bool, List[str]]:
        """Check whether auth patterns appear on or near the path nodes.

        Strategy:
        1. Check the code of every hop node directly.
        2. For each hop, scan ±5 lines in source_code around the hop's line
           for auth decorator patterns (decorators appear above function defs).

        Returns (requires_auth, [matched_pattern_names]).
        """
        found_names: List[str] = []
        source_lines = source_code.splitlines() if source_code else []

        def _scan_text(text: str) -> None:
            for pattern, name, _penalty in self._AUTH_PATTERNS:
                if pattern.search(text) and name not in found_names:
                    found_names.append(name)

        # Scan hop node code directly
        for hop in path:
            _scan_text(hop.code)

        # Scan ±5 lines around each hop's line number in source_code
        if source_lines:
            hop_lines_seen: Set[int] = set()
            for hop in path:
                if hop.line <= 0 or hop.line in hop_lines_seen:
                    continue
                hop_lines_seen.add(hop.line)
                start = max(0, hop.line - 6)      # -5 lines (0-based)
                end = min(len(source_lines), hop.line + 5)  # +4 lines
                window = "\n".join(source_lines[start:end])
                _scan_text(window)

        # If no path, scan broader context: first 40 lines for decorators
        if not path and source_lines:
            header = "\n".join(source_lines[:40])
            _scan_text(header)

        requires_auth = bool(found_names)
        return requires_auth, found_names

    def _compute_scores(
        self,
        path: Optional[List[ReachabilityHop]],
        user_controlled: bool,
        requires_auth: bool,
        finding: Finding,
        source_code: str,
    ) -> Tuple[float, float, float]:
        """Compute reachability_score, exploitability_score, path_confidence.

        Scoring model:

        reachability_score:
          - 0.8 base if a CPG path was found
          - 0.3 base if only heuristic evidence
          - -0.3 if auth check found on path
          - Clamped to [0.0, 1.0]

        exploitability_score:
          - reachability_score * user_control_factor * (1 - auth_penalty)
          - user_control_factor: 1.0 if user_controlled, 0.4 otherwise
          - auth_penalty: 0.3 if requires_auth, 0.0 otherwise
          - Scaled by finding.confidence
          - Clamped to [0.0, 1.0]

        path_confidence:
          - 0.9 if CPG path found and has DFG hops
          - 0.75 if CPG path found (no DFG hops)
          - 0.4 if only heuristic path (no CPG)
          - Penalized by path length (longer = less confident): -0.02 per hop beyond 5
          - Clamped to [0.0, 1.0]
        """
        # --- reachability_score ---
        if path is not None:
            reachability_score = 0.8
        else:
            reachability_score = 0.3

        if requires_auth:
            reachability_score -= 0.3

        reachability_score = max(0.0, min(1.0, reachability_score))

        # --- user_control_factor ---
        user_control_factor = 1.0 if user_controlled else 0.4

        # --- auth_penalty ---
        auth_penalty = 0.3 if requires_auth else 0.0

        # --- exploitability_score ---
        exploitability_score = (
            reachability_score
            * user_control_factor
            * (1.0 - auth_penalty)
            * finding.confidence
        )
        exploitability_score = max(0.0, min(1.0, exploitability_score))

        # --- path_confidence ---
        if path is not None:
            has_dfg_hop = any(h.hop_type == "dfg" for h in path)
            if has_dfg_hop:
                path_confidence = 0.9
            else:
                path_confidence = 0.75

            # Penalize long paths
            extra_hops = max(0, len(path) - 5)
            path_confidence -= extra_hops * 0.02
        else:
            # Heuristic only
            path_confidence = 0.4
            # Boost if finding itself has high confidence
            if finding.confidence >= 0.85:
                path_confidence = min(0.55, path_confidence + 0.15)

        path_confidence = max(0.0, min(1.0, path_confidence))

        return reachability_score, exploitability_score, path_confidence

    def _classify_attack_surface(
        self,
        source_code: str,
        path: Optional[List[ReachabilityHop]],
    ) -> str:
        """Classify the attack surface category for this finding.

        Categories:
        - "internet_facing": HTTP route with no auth decorators visible
        - "authenticated": HTTP route with auth decorator on path
        - "internal": no HTTP route found, likely internal service/utility
        - "cli": CLI command entry point detected

        Decision is based on:
        1. Route decorator patterns in source_code header (first 80 lines)
        2. Auth patterns in source_code
        3. CLI patterns in source_code
        4. Path hop code if path is available
        """
        # Gather all text to scan: source header + path node code
        header_lines = source_code.splitlines()[:80] if source_code else []
        header_text = "\n".join(header_lines)

        path_code = ""
        if path:
            path_code = "\n".join(h.code for h in path)

        combined_text = header_text + "\n" + path_code

        # Check for CLI entry points first (they are not HTTP)
        for pattern in _CLI_PATTERNS:
            if pattern.search(combined_text):
                return "cli"

        # Check for HTTP route decorators
        has_route = any(p.search(combined_text) for p in _ROUTE_PATTERNS)

        if not has_route:
            return "internal"

        # Route found — check for auth decorators
        for pattern, _name, _penalty in self._AUTH_PATTERNS:
            if pattern.search(combined_text):
                return "authenticated"

        return "internet_facing"

    def _is_user_controlled_heuristic(
        self, finding: Finding, source_code: str
    ) -> bool:
        """Fallback: regex check for user input sources near the finding line.

        Scans ±_HEURISTIC_WINDOW lines around the finding's line number for
        any source pattern registered in the pattern registry.
        """
        if not source_code:
            return False

        lines = source_code.splitlines()
        line_idx = finding.line - 1  # convert 1-based to 0-based
        start = max(0, line_idx - _HEURISTIC_WINDOW)
        end = min(len(lines), line_idx + _HEURISTIC_WINDOW + 1)
        window_text = "\n".join(lines[start:end])

        cwe_id = finding.cwe_id or ""

        # If we have a specific CWE, only check that CWE's source patterns
        if cwe_id:
            for pattern, _conf in get_sources(cwe_id):
                if pattern.search(window_text):
                    return True
        else:
            # No CWE — check source patterns across all registered CWEs
            match = classify_node_as_source(window_text)
            if match is not None:
                return True

        return False

    # ------------------------------------------------------------------
    # Internal: evidence builder
    # ------------------------------------------------------------------

    def _build_evidence_summary(
        self,
        finding: Finding,
        shortest_path: Optional[List[ReachabilityHop]],
        user_controlled: bool,
        requires_auth: bool,
        auth_patterns_found: List[str],
        reachability_score: float,
        exploitability_score: float,
        attack_surface_category: str,
    ) -> str:
        """Build a human-readable 1–2 sentence evidence summary."""
        parts: List[str] = []

        if shortest_path is not None:
            hop_count = len(shortest_path)
            parts.append(
                f"CPG path found from taint source to sink at "
                f"{finding.file}:{finding.line} via {hop_count} hop(s)."
            )
        else:
            if user_controlled:
                parts.append(
                    f"No CPG path traced, but user-controlled input patterns detected "
                    f"within {_HEURISTIC_WINDOW} lines of sink at "
                    f"{finding.file}:{finding.line} (heuristic)."
                )
            else:
                parts.append(
                    f"No CPG path or user-controlled source found near sink at "
                    f"{finding.file}:{finding.line}; reachability is uncertain."
                )

        auth_clause = ""
        if requires_auth:
            auth_names = ", ".join(auth_patterns_found[:3])
            auth_clause = (
                f" Auth controls detected ({auth_names}), reducing exploitability."
            )
        else:
            auth_clause = " No authentication controls detected on path."

        surface_clause = {
            "internet_facing": "Attack surface: internet-facing (unauthenticated route).",
            "authenticated":   "Attack surface: authenticated HTTP route.",
            "internal":        "Attack surface: internal service (not directly internet-facing).",
            "cli":             "Attack surface: CLI command (requires local access).",
        }.get(attack_surface_category, "Attack surface: unknown.")

        parts.append(
            f"Reachability score: {reachability_score:.2f}, "
            f"exploitability: {exploitability_score:.2f}.{auth_clause} "
            f"{surface_clause}"
        )

        return " ".join(parts)
