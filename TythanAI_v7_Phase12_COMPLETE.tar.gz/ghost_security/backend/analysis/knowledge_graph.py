"""Security Knowledge Graph: Code → Function → DataFlow → Sink → CVE → Fix."""
from __future__ import annotations

import ast
import json
import os
import re
from collections import deque
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Import Finding from the canonical location; fall back to a local stub so the
# module remains importable in isolation (e.g. during unit tests that mock it).
# ---------------------------------------------------------------------------
try:
    from backend.core.confidence import Finding
except ImportError:  # pragma: no cover
    from pydantic import BaseModel as _BM  # type: ignore

    class Finding(_BM):  # type: ignore[no-redef]
        model_config = {"extra": "allow"}
        rule_id: str = ""
        file: str = ""
        line: int = 0
        severity: str = "MEDIUM"
        confidence: float = 0.8
        cwe_id: str = ""
        description: str = ""
        recommendation: str = ""
        sources: List[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Built-in CWE → CVE mapping (≥ 15 entries)
# ---------------------------------------------------------------------------
CWE_CVE_EXAMPLES: Dict[str, List[str]] = {
    "CWE-89":  ["CVE-2021-41773", "CVE-2021-42013"],
    "CWE-79":  ["CVE-2021-44228"],
    "CWE-78":  ["CVE-2021-41773"],
    "CWE-22":  ["CVE-2021-41773", "CVE-2020-5902"],
    "CWE-502": ["CVE-2019-20907", "CVE-2020-10029"],
    "CWE-327": ["CVE-2020-25018"],
    "CWE-798": ["CVE-2021-40539"],
    "CWE-306": ["CVE-2021-34527"],
    "CWE-434": ["CVE-2021-3156"],
    "CWE-611": ["CVE-2021-23017"],
    "CWE-918": ["CVE-2021-26855"],
    "CWE-94":  ["CVE-2021-44228"],
    "CWE-190": ["CVE-2021-3156"],
    "CWE-416": ["CVE-2021-30551"],
    "CWE-362": ["CVE-2022-0847"],
    "CWE-476": ["CVE-2021-3156"],
    "CWE-20":  ["CVE-2021-44228", "CVE-2021-41773"],
}

# Patterns that indicate security controls (decorators / function calls).
_AUTH_DECORATOR_RE = re.compile(
    r"@(login_required|require_http_methods|permission_required|"
    r"requires_auth|authenticated|jwt_required|token_required|"
    r"staff_member_required|superuser_required)",
    re.IGNORECASE,
)
_INPUT_VALIDATION_RE = re.compile(
    r"\b(validate|sanitize|escape|bleach\.clean|html\.escape|"
    r"markupsafe\.escape|wtforms|marshmallow|cerberus|jsonschema\.validate)\b",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class KGNodeType(str, Enum):
    CODE_UNIT = "code_unit"
    FUNCTION = "function"
    DATAFLOW = "dataflow"
    SINK = "sink"
    CVE = "cve"
    FIX = "fix"
    CONTROL = "control"
    # --- Phase 2 additions ---
    SOURCE = "source"
    METHOD = "method"
    CLASS = "class"
    MODULE = "module"
    PACKAGE = "package"
    ENDPOINT = "endpoint"
    API_ROUTE = "api_route"
    DEPENDENCY = "dependency"
    CWE_NODE = "cwe_node"
    CAPEC_NODE = "capec_node"
    ASSET = "asset"
    CLOUD_RESOURCE = "cloud_resource"
    FINDING = "finding"
    VERIFICATION = "verification"
    PATCH = "patch"
    VALIDATION = "validation"
    REGRESSION = "regression"
    # --- Phase 5 additions ---
    RESEARCH = "research"
    ADVISORY = "advisory"
    EXPLOIT = "exploit"
    REMEDIATION_PATTERN = "remediation_pattern"
    GENERATED_RULE = "generated_rule"
    # --- Phase 7 additions (DAST) ---
    RUNTIME_FINDING  = "runtime_finding"   # DAST-confirmed finding
    RUNTIME_EVIDENCE = "runtime_evidence"  # Raw HTTP request/response evidence
    # --- Phase 8 additions (TON Elite) ---
    SMART_CONTRACT   = "smart_contract"    # TON smart contract
    TON_WALLET       = "ton_wallet"        # TON wallet contract
    JETTON           = "jetton"            # Jetton (TEP-74 fungible token)
    NFT_COLLECTION   = "nft_collection"   # NFT Collection (TEP-62)
    TREASURY         = "treasury"          # Treasury / DAO treasury contract
    MULTISIG         = "multisig"          # Multisig contract
    TON_MESSAGE      = "ton_message"       # TON inter-contract message


class KGNode(BaseModel):
    node_id: str
    type: KGNodeType
    label: str
    properties: Dict[str, Any] = Field(default_factory=dict)


class KGEdge(BaseModel):
    from_id: str
    to_id: str
    # Original relations: CONTAINS / CALLS / FLOWS_TO / LEADS_TO / MITIGATES / FIXES / EXPLOITS
    # Phase 2 additions: IMPORTS / DEPENDS_ON / REACHES / PROPAGATES_TO / VULNERABLE_TO /
    #                    VERIFIED_BY / EXPLOITABLE_VIA / EXPOSED_THROUGH / OWNED_BY
    # Phase 3 additions: VALIDATES / INTRODUCES / REMOVES
    # Phase 5 additions: DERIVED_FROM / VALIDATED_BY / MITIGATED_BY / EXPLOITS_VIA / DETECTS
    relation: str
    weight: float = 1.0


class SecurityKnowledgeGraph(BaseModel):
    nodes: List[KGNode] = Field(default_factory=list)
    edges: List[KGEdge] = Field(default_factory=list)
    node_index: Dict[str, int] = Field(default_factory=dict)  # node_id → list index


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------


class KnowledgeGraphBuilder:
    """Constructs a SecurityKnowledgeGraph from static-analysis findings."""

    def __init__(self, _findings: Optional[List] = None) -> None:
        # Accept an optional positional list argument for convenience
        # (e.g. KnowledgeGraphBuilder(findings)) — the builder is otherwise
        # stateless; methods receive the graph as an explicit parameter.
        pass

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build(
        self,
        project_root: str,
        findings: List[Finding],
        cve_records: Optional[List] = None,
    ) -> SecurityKnowledgeGraph:
        """
        Build a complete SecurityKnowledgeGraph from a list of findings.

        Steps
        -----
        1. CODE_UNIT nodes for every unique file.
        2. FUNCTION nodes by AST-parsing each file.
        3. DATAFLOW nodes for findings that carry source information.
        4. SINK nodes for every finding (keyed rule_id + file + line).
        5. CVE nodes via CWE_CVE_EXAMPLES mapping.
        6. FIX nodes with recommendation text.
        7. CONTROL nodes for detected security controls.
        8. All edges (CONTAINS / LEADS_TO / FLOWS_TO / EXPLOITS / FIXES / MITIGATES).
        """
        graph = SecurityKnowledgeGraph()

        if not findings:
            return graph

        # ---- Step 1: CODE_UNIT nodes ----------------------------------------
        files: Set[str] = {f.file for f in findings if f.file}
        file_node_ids: Dict[str, str] = {}
        for fpath in sorted(files):
            nid = f"code_unit::{fpath}"
            node = KGNode(
                node_id=nid,
                type=KGNodeType.CODE_UNIT,
                label=os.path.basename(fpath) or fpath,
                properties={"file": fpath},
            )
            self.add_node(graph, node)
            file_node_ids[fpath] = nid

        # ---- Step 2: FUNCTION nodes (AST parsing) ----------------------------
        # Map file → list of (func_name, start_line, end_line)
        file_functions: Dict[str, List[Tuple[str, int, int]]] = {}
        for fpath in files:
            full_path = os.path.join(project_root, fpath) if project_root else fpath
            funcs = self._extract_functions(full_path)
            file_functions[fpath] = funcs
            for fname, start, end in funcs:
                nid = f"function::{fpath}::{fname}::{start}"
                node = KGNode(
                    node_id=nid,
                    type=KGNodeType.FUNCTION,
                    label=fname,
                    properties={"file": fpath, "line_start": start, "line_end": end},
                )
                self.add_node(graph, node)
                # CONTAINS edge: CODE_UNIT → FUNCTION
                if fpath in file_node_ids:
                    self.add_edge(
                        graph,
                        KGEdge(
                            from_id=file_node_ids[fpath],
                            to_id=nid,
                            relation="CONTAINS",
                        ),
                    )

        # ---- Step 3 & 4: DATAFLOW and SINK nodes ----------------------------
        # Collect raw source content for CONTROL detection later
        file_source: Dict[str, str] = {}
        for fpath in files:
            full_path = os.path.join(project_root, fpath) if project_root else fpath
            try:
                with open(full_path, "r", errors="replace") as fh:
                    file_source[fpath] = fh.read()
            except OSError:
                file_source[fpath] = ""

        sink_node_ids: List[str] = []
        # Mapping: sink_node_id → enclosing function node_id (for LEADS_TO + MITIGATES)
        sink_to_func: Dict[str, Optional[str]] = {}

        for finding in findings:
            fpath = finding.file or ""

            # DATAFLOW node (only if the finding has explicit source info)
            df_nid: Optional[str] = None
            if finding.sources:
                df_nid = f"dataflow::{fpath}::{finding.rule_id}::{finding.line}"
                df_node = KGNode(
                    node_id=df_nid,
                    type=KGNodeType.DATAFLOW,
                    label=f"taint:{finding.rule_id}",
                    properties={
                        "file": fpath,
                        "sources": finding.sources,
                        "line": finding.line,
                    },
                )
                self.add_node(graph, df_node)

            # SINK node
            sink_nid = f"sink::{finding.rule_id}::{fpath}::{finding.line}"
            sink_node = KGNode(
                node_id=sink_nid,
                type=KGNodeType.SINK,
                label=finding.rule_id,
                properties={
                    "file": fpath,
                    "line": finding.line,
                    "severity": finding.severity,
                    "cwe_id": finding.cwe_id,
                    "description": finding.description,
                },
            )
            self.add_node(graph, sink_node)
            sink_node_ids.append(sink_nid)

            # DATAFLOW → SINK: FLOWS_TO
            if df_nid:
                self.add_edge(
                    graph,
                    KGEdge(from_id=df_nid, to_id=sink_nid, relation="FLOWS_TO"),
                )

            # Determine enclosing function
            enclosing_func_nid = self._find_enclosing_function(
                fpath, finding.line, file_functions
            )
            sink_to_func[sink_nid] = enclosing_func_nid

            # FUNCTION → SINK: LEADS_TO
            if enclosing_func_nid:
                self.add_edge(
                    graph,
                    KGEdge(
                        from_id=enclosing_func_nid,
                        to_id=sink_nid,
                        relation="LEADS_TO",
                    ),
                )

        # ---- Step 5 & 6: CVE and FIX nodes ----------------------------------
        cwe_to_cve_nids: Dict[str, List[str]] = {}  # cwe_id → list of CVE node_ids
        for finding in findings:
            cwe = finding.cwe_id or ""
            if not cwe or cwe not in CWE_CVE_EXAMPLES:
                continue
            if cwe in cwe_to_cve_nids:
                continue  # already created
            cve_nids: List[str] = []
            for cve_id in CWE_CVE_EXAMPLES[cwe]:
                cve_nid = f"cve::{cve_id}"
                cve_node = KGNode(
                    node_id=cve_nid,
                    type=KGNodeType.CVE,
                    label=cve_id,
                    properties={"cve_id": cve_id, "cwe_id": cwe},
                )
                self.add_node(graph, cve_node)
                cve_nids.append(cve_nid)

                # FIX node for this CVE
                fix_nid = f"fix::{cve_id}"
                fix_text = finding.recommendation or f"Apply remediation for {cwe} ({cve_id})"
                fix_node = KGNode(
                    node_id=fix_nid,
                    type=KGNodeType.FIX,
                    label=f"Fix:{cve_id}",
                    properties={
                        "recommendation": fix_text,
                        "cve_id": cve_id,
                        "cwe_id": cwe,
                    },
                )
                self.add_node(graph, fix_node)

                # CVE → FIX: FIXES
                self.add_edge(
                    graph,
                    KGEdge(from_id=cve_nid, to_id=fix_nid, relation="FIXES"),
                )

            cwe_to_cve_nids[cwe] = cve_nids

        # SINK → CVE: EXPLOITS
        for finding in findings:
            cwe = finding.cwe_id or ""
            sink_nid = f"sink::{finding.rule_id}::{finding.file}::{finding.line}"
            if cwe in cwe_to_cve_nids:
                for cve_nid in cwe_to_cve_nids[cwe]:
                    self.add_edge(
                        graph,
                        KGEdge(from_id=sink_nid, to_id=cve_nid, relation="EXPLOITS"),
                    )

        # ---- Step 7: CONTROL nodes ------------------------------------------
        for fpath, source in file_source.items():
            funcs = file_functions.get(fpath, [])
            lines = source.splitlines()

            for fname, start, end in funcs:
                func_lines = lines[max(0, start - 1) : end]
                func_text = "\n".join(func_lines)

                controls_found: List[Tuple[str, str]] = []
                if _AUTH_DECORATOR_RE.search(func_text):
                    controls_found.append(("auth_decorator", "Authentication decorator detected"))
                if _INPUT_VALIDATION_RE.search(func_text):
                    controls_found.append(("input_validation", "Input validation detected"))

                if not controls_found:
                    continue

                func_nid = f"function::{fpath}::{fname}::{start}"
                for ctrl_type, ctrl_label in controls_found:
                    ctrl_nid = f"control::{fpath}::{fname}::{start}::{ctrl_type}"
                    ctrl_node = KGNode(
                        node_id=ctrl_nid,
                        type=KGNodeType.CONTROL,
                        label=ctrl_label,
                        properties={
                            "control_type": ctrl_type,
                            "file": fpath,
                            "function": fname,
                            "line_start": start,
                        },
                    )
                    self.add_node(graph, ctrl_node)

                    # Find sinks in same function → MITIGATES
                    for sink_nid, efunc_nid in sink_to_func.items():
                        if efunc_nid == func_nid:
                            self.add_edge(
                                graph,
                                KGEdge(
                                    from_id=ctrl_nid,
                                    to_id=sink_nid,
                                    relation="MITIGATES",
                                ),
                            )

        return graph

    # ------------------------------------------------------------------
    # Graph mutation helpers
    # ------------------------------------------------------------------

    def add_node(self, graph: SecurityKnowledgeGraph, node: KGNode) -> str:
        """Add node if not already present (by node_id). Returns the node_id."""
        if node.node_id not in graph.node_index:
            graph.node_index[node.node_id] = len(graph.nodes)
            graph.nodes.append(node)
        return node.node_id

    def add_edge(self, graph: SecurityKnowledgeGraph, edge: KGEdge) -> None:
        """Append an edge. Duplicate (from_id, to_id, relation) triplets are skipped."""
        for existing in graph.edges:
            if (
                existing.from_id == edge.from_id
                and existing.to_id == edge.to_id
                and existing.relation == edge.relation
            ):
                return
        graph.edges.append(edge)

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def query_paths(
        self,
        graph: SecurityKnowledgeGraph,
        from_type: KGNodeType,
        to_type: KGNodeType,
        max_len: int = 6,
    ) -> List[List[str]]:
        """
        BFS to find all simple paths from nodes of *from_type* to nodes of
        *to_type*.  Returns a list of node_id paths, each at most *max_len*
        nodes long.
        """
        # Build adjacency list
        adj: Dict[str, List[str]] = {}
        for edge in graph.edges:
            adj.setdefault(edge.from_id, []).append(edge.to_id)

        # Identify start and goal sets
        start_ids: Set[str] = set()
        goal_ids: Set[str] = set()
        for node in graph.nodes:
            if node.type == from_type:
                start_ids.add(node.node_id)
            if node.type == to_type:
                goal_ids.add(node.node_id)

        results: List[List[str]] = []
        # BFS queue: (current_node_id, path_so_far)
        queue: deque[Tuple[str, List[str]]] = deque()
        for sid in start_ids:
            queue.append((sid, [sid]))

        while queue:
            current, path = queue.popleft()
            if len(path) > max_len:
                continue
            if current in goal_ids and len(path) > 1:
                results.append(path)
                continue  # do not extend beyond a found goal
            for neighbor in adj.get(current, []):
                if neighbor not in path:  # avoid cycles
                    queue.append((neighbor, path + [neighbor]))

        return results

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_json(self, graph: SecurityKnowledgeGraph) -> str:
        """Serialize graph to JSON with ``nodes`` and ``edges`` arrays."""
        return json.dumps(
            {
                "nodes": [n.model_dump() for n in graph.nodes],
                "edges": [e.model_dump() for e in graph.edges],
            },
            indent=2,
            default=str,
        )

    def to_cypher(self, graph: SecurityKnowledgeGraph) -> str:
        """
        Generate Neo4j Cypher CREATE statements for all nodes and edges.

        Node format::

            CREATE (:KGNodeType {node_id: "...", label: "...", ...})

        Edge format::

            MATCH (a {node_id: "..."}), (b {node_id: "..."})
            CREATE (a)-[:RELATION]->(b)
        """
        lines: List[str] = []

        def _escape(v: Any) -> str:
            if isinstance(v, str):
                return '"' + v.replace("\\", "\\\\").replace('"', '\\"') + '"'
            if isinstance(v, bool):
                return "true" if v else "false"
            if isinstance(v, (int, float)):
                return str(v)
            return '"' + str(v).replace('"', '\\"') + '"'

        for node in graph.nodes:
            label = node.type.value.upper()
            props: Dict[str, Any] = {
                "node_id": node.node_id,
                "label": node.label,
            }
            props.update(
                {k: v for k, v in node.properties.items() if not isinstance(v, (list, dict))}
            )
            prop_str = ", ".join(f"{k}: {_escape(v)}" for k, v in props.items())
            lines.append(f'CREATE (:{label} {{{prop_str}}})')

        lines.append("")  # blank separator

        for edge in graph.edges:
            rel = edge.relation.replace(" ", "_").upper()
            lines.append(
                f'MATCH (a {{node_id: {_escape(edge.from_id)}}}), '
                f'(b {{node_id: {_escape(edge.to_id)}}})\n'
                f'CREATE (a)-[:{rel} {{weight: {edge.weight}}}]->(b)'
            )

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Analytics
    # ------------------------------------------------------------------

    def get_risk_surface(self, graph: SecurityKnowledgeGraph) -> Dict[str, Any]:
        """
        Return a summary dict covering:

        * total_nodes / total_edges
        * nodes_by_type  (type → count)
        * sinks_count
        * cves_count
        * fixes_available
        * coverage  (% of sinks that have a FIX reachable via a CVE)
        """
        nodes_by_type: Dict[str, int] = {}
        for node in graph.nodes:
            key = node.type.value
            nodes_by_type[key] = nodes_by_type.get(key, 0) + 1

        sinks_count = nodes_by_type.get(KGNodeType.SINK.value, 0)
        cves_count = nodes_by_type.get(KGNodeType.CVE.value, 0)
        fixes_available = nodes_by_type.get(KGNodeType.FIX.value, 0)

        # Coverage: sinks that reach at least one FIX node
        adj: Dict[str, Set[str]] = {}
        for edge in graph.edges:
            adj.setdefault(edge.from_id, set()).add(edge.to_id)

        fix_ids: Set[str] = {n.node_id for n in graph.nodes if n.type == KGNodeType.FIX}
        sink_ids: List[str] = [n.node_id for n in graph.nodes if n.type == KGNodeType.SINK]

        covered = 0
        for sink_id in sink_ids:
            visited: Set[str] = set()
            stack = [sink_id]
            while stack:
                curr = stack.pop()
                if curr in visited:
                    continue
                visited.add(curr)
                if curr in fix_ids:
                    covered += 1
                    break
                stack.extend(adj.get(curr, set()))

        coverage = round(covered / sinks_count * 100, 1) if sinks_count else 0.0

        return {
            "total_nodes": len(graph.nodes),
            "total_edges": len(graph.edges),
            "nodes_by_type": nodes_by_type,
            "sinks_count": sinks_count,
            "cves_count": cves_count,
            "fixes_available": fixes_available,
            "coverage_percent": coverage,
        }

    # ------------------------------------------------------------------
    # Phase 2: ingest_finding
    # ------------------------------------------------------------------

    def ingest_finding(
        self,
        graph: SecurityKnowledgeGraph,
        finding: Any,
    ) -> List[str]:
        """
        Ingest a Finding into the KnowledgeGraph.

        Creates / links:
          - FINDING node
          - CWE_NODE
          - SOURCE node (from finding.file / finding.line)
          - SINK node (from finding.file / finding.line)
          - VULNERABLE_TO edge: SOURCE → CWE_NODE
          - LEADS_TO edge:      FINDING → SINK

        Returns the list of created (or ensured) node_ids.
        """
        created: List[str] = []

        rule_id = getattr(finding, "rule_id", "") or ""
        fpath = getattr(finding, "file", "") or ""
        line = getattr(finding, "line", 0) or 0
        severity = getattr(finding, "severity", "MEDIUM") or "MEDIUM"
        confidence = getattr(finding, "confidence", 0.8)
        cwe_id = getattr(finding, "cwe_id", "") or ""
        description = getattr(finding, "description", "") or ""
        recommendation = getattr(finding, "recommendation", "") or ""

        # --- FINDING node ---
        finding_nid = f"finding::{rule_id}::{fpath}::{line}"
        finding_node = KGNode(
            node_id=finding_nid,
            type=KGNodeType.FINDING,
            label=rule_id or "finding",
            properties={
                "rule_id": rule_id,
                "file": fpath,
                "line": line,
                "severity": severity,
                "confidence": confidence,
                "cwe_id": cwe_id,
                "description": description,
                "recommendation": recommendation,
            },
        )
        self.add_node(graph, finding_node)
        created.append(finding_nid)

        # --- CWE_NODE ---
        if cwe_id:
            cwe_nid = f"cwe::{cwe_id}"
            cwe_node = KGNode(
                node_id=cwe_nid,
                type=KGNodeType.CWE_NODE,
                label=cwe_id,
                properties={"cwe_id": cwe_id},
            )
            self.add_node(graph, cwe_node)
            created.append(cwe_nid)

            # FINDING → CWE_NODE: VULNERABLE_TO
            self.add_edge(
                graph,
                KGEdge(from_id=finding_nid, to_id=cwe_nid, relation="VULNERABLE_TO"),
            )
        else:
            cwe_nid = None

        # --- SOURCE node ---
        source_nid = f"source::{fpath}::{line}"
        source_node = KGNode(
            node_id=source_nid,
            type=KGNodeType.SOURCE,
            label=f"src:{os.path.basename(fpath)}:{line}",
            properties={"file": fpath, "line": line, "rule_id": rule_id},
        )
        self.add_node(graph, source_node)
        created.append(source_nid)

        # SOURCE → CWE_NODE: VULNERABLE_TO
        if cwe_nid:
            self.add_edge(
                graph,
                KGEdge(from_id=source_nid, to_id=cwe_nid, relation="VULNERABLE_TO"),
            )

        # --- SINK node ---
        sink_nid = f"sink::{rule_id}::{fpath}::{line}"
        sink_node = KGNode(
            node_id=sink_nid,
            type=KGNodeType.SINK,
            label=rule_id,
            properties={
                "file": fpath,
                "line": line,
                "severity": severity,
                "cwe_id": cwe_id,
                "description": description,
            },
        )
        self.add_node(graph, sink_node)
        created.append(sink_nid)

        # FINDING → SINK: LEADS_TO
        self.add_edge(
            graph,
            KGEdge(from_id=finding_nid, to_id=sink_nid, relation="LEADS_TO"),
        )

        return created

    # ------------------------------------------------------------------
    # Phase 2: to_graphml
    # ------------------------------------------------------------------

    def to_graphml(self, graph: Optional[SecurityKnowledgeGraph] = None) -> str:
        """
        Serialize the graph to GraphML XML format.
        If *graph* is None, an empty SecurityKnowledgeGraph is used.
        """
        if graph is None:
            graph = SecurityKnowledgeGraph()
        lines: List[str] = []
        lines.append('<?xml version="1.0" encoding="UTF-8"?>')
        lines.append('<graphml xmlns="http://graphml.graphdrawing.org/graphml">')
        lines.append('  <key id="type" for="node" attr.name="type" attr.type="string"/>')
        lines.append('  <key id="label" for="node" attr.name="label" attr.type="string"/>')
        lines.append('  <key id="relation" for="edge" attr.name="relation" attr.type="string"/>')
        lines.append('  <key id="weight" for="edge" attr.name="weight" attr.type="double"/>')
        lines.append('  <graph id="G" edgedefault="directed">')

        def _xml_escape(s: str) -> str:
            return (
                s.replace("&", "&amp;")
                 .replace("<", "&lt;")
                 .replace(">", "&gt;")
                 .replace('"', "&quot;")
                 .replace("'", "&apos;")
            )

        for node in graph.nodes:
            nid = _xml_escape(node.node_id)
            ntype = _xml_escape(node.type.value)
            nlabel = _xml_escape(node.label)
            lines.append(f'    <node id="{nid}">')
            lines.append(f'      <data key="type">{ntype}</data>')
            lines.append(f'      <data key="label">{nlabel}</data>')
            lines.append('    </node>')

        for idx, edge in enumerate(graph.edges):
            fid = _xml_escape(edge.from_id)
            tid = _xml_escape(edge.to_id)
            rel = _xml_escape(edge.relation)
            lines.append(f'    <edge id="e{idx}" source="{fid}" target="{tid}">')
            lines.append(f'      <data key="relation">{rel}</data>')
            lines.append(f'      <data key="weight">{edge.weight}</data>')
            lines.append('    </edge>')

        lines.append('  </graph>')
        lines.append('</graphml>')
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Phase 2: to_html
    # ------------------------------------------------------------------

    def to_html(self, graph: Optional[SecurityKnowledgeGraph] = None) -> str:
        """
        Generate a self-contained interactive HTML visualization using vis.js.
        Node colors are assigned by KGNodeType. Edge labels are shown.
        If *graph* is None, an empty SecurityKnowledgeGraph is used.
        """
        if graph is None:
            graph = SecurityKnowledgeGraph()
        # Color map by node type
        color_map: Dict[str, str] = {
            "finding":       "#e74c3c",    # red
            "cve":           "#e67e22",    # orange
            "cwe_node":      "#d35400",    # dark orange
            "capec_node":    "#c0392b",    # dark red
            "source":        "#2980b9",    # blue
            "sink":          "#8b0000",    # dark red
            "dataflow":      "#8e44ad",    # purple
            "function":      "#27ae60",    # green
            "method":        "#1e8449",    # dark green
            "class":         "#16a085",    # teal
            "module":        "#1abc9c",    # light teal
            "package":       "#f39c12",    # yellow-orange
            "dependency":    "#e8a838",    # amber
            "endpoint":      "#3498db",    # light blue
            "api_route":     "#2471a3",    # medium blue
            "code_unit":     "#7f8c8d",    # grey
            "control":       "#2ecc71",    # bright green
            "fix":           "#00b894",    # mint
            "asset":         "#6c3483",    # dark purple
            "cloud_resource":"#5dade2",    # sky blue
            "verification":  "#f1c40f",    # yellow
        }

        # Build nodes JS array
        nodes_js_parts: List[str] = []
        for node in graph.nodes:
            nid = node.node_id.replace("\\", "\\\\").replace('"', '\\"')
            nlabel = node.label.replace("\\", "\\\\").replace('"', '\\"')
            ntype = node.type.value
            color = color_map.get(ntype, "#95a5a6")
            nodes_js_parts.append(
                f'{{id: "{nid}", label: "{nlabel}", color: "{color}", '
                f'title: "{ntype}"}}'
            )

        # Build edges JS array
        edges_js_parts: List[str] = []
        for idx, edge in enumerate(graph.edges):
            fid = edge.from_id.replace("\\", "\\\\").replace('"', '\\"')
            tid = edge.to_id.replace("\\", "\\\\").replace('"', '\\"')
            rel = edge.relation.replace("\\", "\\\\").replace('"', '\\"')
            edges_js_parts.append(
                f'{{id: "e{idx}", from: "{fid}", to: "{tid}", '
                f'label: "{rel}", arrows: "to"}}'
            )

        nodes_js = "[\n    " + ",\n    ".join(nodes_js_parts) + "\n  ]"
        edges_js = "[\n    " + ",\n    ".join(edges_js_parts) + "\n  ]"

        # Legend HTML rows
        legend_rows = "".join(
            f'<tr><td style="background:{c};width:18px;height:14px;border:1px solid #555"></td>'
            f'<td style="padding:2px 6px;font-size:12px">{t}</td></tr>\n'
            for t, c in sorted(color_map.items())
        )

        html = f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <title>Security Knowledge Graph</title>
  <script src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
  <style>
    body {{ margin: 0; font-family: Arial, sans-serif; display: flex; height: 100vh; }}
    #network {{ flex: 1; border: 1px solid #ccc; }}
    #legend {{
      width: 200px; padding: 10px; overflow-y: auto;
      background: #f9f9f9; border-left: 1px solid #ccc;
    }}
    #legend h3 {{ margin-top: 0; font-size: 14px; }}
    table {{ border-collapse: collapse; }}
  </style>
</head>
<body>
  <div id="network"></div>
  <div id="legend">
    <h3>Node Types</h3>
    <table>
{legend_rows}    </table>
  </div>
  <script>
  var nodes = new vis.DataSet({nodes_js});
  var edges = new vis.DataSet({edges_js});
  var container = document.getElementById("network");
  var data = {{ nodes: nodes, edges: edges }};
  var options = {{
    edges: {{
      font: {{ size: 10, align: "middle" }},
      smooth: {{ type: "dynamic" }}
    }},
    nodes: {{
      shape: "dot",
      size: 16,
      font: {{ size: 12 }}
    }},
    physics: {{
      stabilization: {{ iterations: 200 }},
      barnesHut: {{ gravitationalConstant: -8000, springLength: 140 }}
    }},
    interaction: {{ hover: true, tooltipDelay: 200 }}
  }};
  new vis.Network(container, data, options);
  </script>
</body>
</html>"""
        return html

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_functions(filepath: str) -> List[Tuple[str, int, int]]:
        """
        Parse *filepath* with the Python AST and return a list of
        ``(qualified_name, start_line, end_line)`` tuples for every
        top-level function and class method.  Returns an empty list if
        the file cannot be parsed.
        """
        try:
            with open(filepath, "r", errors="replace") as fh:
                source = fh.read()
        except OSError:
            return []

        try:
            tree = ast.parse(source, filename=filepath)
        except SyntaxError:
            return []

        results: List[Tuple[str, int, int]] = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                for item in ast.walk(node):
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        qname = f"{node.name}.{item.name}"
                        end = getattr(item, "end_lineno", item.lineno)
                        results.append((qname, item.lineno, end))
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                # Exclude methods already captured via class iteration
                end = getattr(node, "end_lineno", node.lineno)
                results.append((node.name, node.lineno, end))

        # De-duplicate by (name, start)
        seen: Set[Tuple[str, int]] = set()
        unique: List[Tuple[str, int, int]] = []
        for name, start, end in results:
            if (name, start) not in seen:
                seen.add((name, start))
                unique.append((name, start, end))
        return unique

    @staticmethod
    def _find_enclosing_function(
        fpath: str,
        line: int,
        file_functions: Dict[str, List[Tuple[str, int, int]]],
    ) -> Optional[str]:
        """
        Return the node_id of the innermost function that contains *line*
        in *fpath*, or ``None`` if no function matches.
        """
        best: Optional[Tuple[str, int, int]] = None
        for fname, start, end in file_functions.get(fpath, []):
            if start <= line <= end:
                if best is None or (end - start) < (best[2] - best[1]):
                    best = (fname, start, end)
        if best is None:
            return None
        return f"function::{fpath}::{best[0]}::{best[1]}"


# ---------------------------------------------------------------------------
# Module-level convenience function
# ---------------------------------------------------------------------------


def build_knowledge_graph(
    project_root: str,
    findings: List[Finding],
    cve_records: Optional[List] = None,
) -> SecurityKnowledgeGraph:
    """Convenience wrapper: construct and return a SecurityKnowledgeGraph."""
    return KnowledgeGraphBuilder().build(project_root, findings, cve_records)


# ---------------------------------------------------------------------------
# Incremental Knowledge Graph methods (Phase 6, Part 7)
# Attached to KnowledgeGraphBuilder at module level.
# ---------------------------------------------------------------------------

import time as _kg_time
import hashlib as _kg_hash


def _kg_build_delta(
    self: "KnowledgeGraphBuilder",
    graph: SecurityKnowledgeGraph,
    added_findings: List,
    removed_findings: List,
    changed_files: Optional[List[str]] = None,
) -> int:
    """
    Incrementally update *graph* instead of rebuilding from scratch.

    Steps:
      1. Remove nodes/edges tied to *removed_findings* (by rule_id + file + line).
      2. Ingest each *added_finding* via the existing ingest_finding() method.
      3. For changed_files: remove all CODE_UNIT and FUNCTION nodes for those
         files and let fresh findings re-create them.

    Returns total count of node mutations (adds + removes).
    """
    mutations = 0

    # Step 1: remove nodes for removed findings
    for finding in removed_findings:
        fdict = finding if isinstance(finding, dict) else finding.dict() if hasattr(finding, "dict") else {}
        ffile = fdict.get("file", "")
        fline = fdict.get("line", 0)
        frule = fdict.get("rule_id", fdict.get("type", ""))

        to_remove: List[int] = []
        for i, node in enumerate(graph.nodes):
            props = node.properties
            if (props.get("file") == ffile and props.get("line") == fline
                    and props.get("rule_id", props.get("type", "")) == frule):
                to_remove.append(i)
        # Remove in reverse order to preserve indices
        for i in sorted(to_remove, reverse=True):
            nid = graph.nodes[i].node_id
            graph.nodes.pop(i)
            # Remove from index
            graph.node_index.pop(nid, None)
            # Remove edges referencing this node
            graph.edges = [e for e in graph.edges if e.from_id != nid and e.to_id != nid]
            mutations += 1

    # Step 2: remove nodes for changed files
    if changed_files:
        changed_set = set(changed_files)
        changed_set |= {str(Path(f).resolve()) for f in changed_files}
        nodes_to_remove = [
            i for i, node in enumerate(graph.nodes)
            if node.properties.get("file", "") in changed_set
            and node.type in (KGNodeType.CODE_UNIT, KGNodeType.FUNCTION)
        ]
        for i in sorted(nodes_to_remove, reverse=True):
            nid = graph.nodes[i].node_id
            graph.nodes.pop(i)
            graph.node_index.pop(nid, None)
            graph.edges = [e for e in graph.edges if e.from_id != nid and e.to_id != nid]
            mutations += 1

    # Rebuild index after bulk removal
    graph.node_index = {node.node_id: idx for idx, node in enumerate(graph.nodes)}

    # Step 3: ingest new findings
    for finding in added_findings:
        try:
            self.ingest_finding(graph, finding)
            mutations += 1
        except Exception:
            pass

    return mutations


def _kg_patch_node(
    self: "KnowledgeGraphBuilder",
    graph: SecurityKnowledgeGraph,
    node_id: str,
    properties: Dict[str, Any],
) -> bool:
    """
    Update properties of an existing graph node in-place.
    Returns True if node was found and updated.
    """
    idx = graph.node_index.get(node_id)
    if idx is None or idx >= len(graph.nodes):
        return False
    graph.nodes[idx].properties.update(properties)
    return True


def _kg_patch_edge(
    self: "KnowledgeGraphBuilder",
    graph: SecurityKnowledgeGraph,
    from_id: str,
    to_id: str,
    relation: str,
    weight: float,
) -> bool:
    """
    Update weight of an existing edge, or add it if missing.
    Returns True if an existing edge was updated; False if a new edge was added.
    """
    for edge in graph.edges:
        if edge.from_id == from_id and edge.to_id == to_id and edge.relation == relation:
            edge.weight = weight
            return True
    # Add new edge
    graph.edges.append(KGEdge(
        from_id=from_id, to_id=to_id, relation=relation, weight=weight
    ))
    return False


def _kg_apply_file_delta(
    self: "KnowledgeGraphBuilder",
    changed_files: List[str],
    new_findings: List,
) -> int:
    """
    Convenience method used by GraphAwareIncrementalScanner.
    If we have no current graph, this is a no-op.
    Returns count of mutations (best-effort).
    """
    # The scanner passes findings as dicts; we need to handle both dict and Finding
    added = []
    for f in new_findings:
        if isinstance(f, dict):
            try:
                added.append(Finding(**{k: v for k, v in f.items()
                                        if k in Finding.model_fields}))
            except Exception:
                pass
        else:
            added.append(f)
    # Without a live graph reference this is a no-op — callers should pass graph explicitly
    return len(added)


KnowledgeGraphBuilder.build_delta      = _kg_build_delta      # type: ignore[attr-defined]
KnowledgeGraphBuilder.patch_node       = _kg_patch_node       # type: ignore[attr-defined]
KnowledgeGraphBuilder.patch_edge       = _kg_patch_edge       # type: ignore[attr-defined]
KnowledgeGraphBuilder.apply_file_delta = _kg_apply_file_delta # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Phase 7 — DAST extensions: ingest runtime findings + DAST query methods
# ---------------------------------------------------------------------------

def _kg_ingest_runtime_findings(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
    correlated_findings: List[Dict[str, Any]],
) -> int:
    """
    Ingest Phase 7 CorrelatedFinding records into the knowledge graph.

    For each record:
      ENDPOINT node ←[EXPOSED_BY]→ RUNTIME_FINDING node
      RUNTIME_FINDING ←[VERIFIED_BY]→ RUNTIME_EVIDENCE node
      FINDING (SAST) ←[CONFIRMED_BY]→ RUNTIME_FINDING (if static_evidence present)

    Returns count of new nodes added.
    """
    added = 0
    for cf in correlated_findings:
        corr_id  = cf.get("correlation_id", "")
        ep_info  = cf.get("endpoint", {})
        ep_path  = ep_info.get("path", "") or cf.get("endpoint_path", "")
        ep_method = ep_info.get("method", "GET")
        cwe      = cf.get("cwe", "")
        sev      = cf.get("severity", "MEDIUM")
        status   = cf.get("verification_status", "detected")
        conf     = cf.get("combined_confidence", 50)

        # ENDPOINT node
        ep_nid = f"endpoint::{ep_method}::{ep_path}"
        ep_node = KGNode(
            node_id=ep_nid,
            type=KGNodeType.ENDPOINT,
            label=f"{ep_method} {ep_path}",
            properties={
                "url":     ep_info.get("url", ""),
                "path":    ep_path,
                "method":  ep_method,
                "handler": ep_info.get("handler", "") or cf.get("handler", ""),
            },
        )
        self.add_node(graph, ep_node)

        # RUNTIME_FINDING node
        rf_nid = f"runtime_finding::{corr_id}"
        rf_node = KGNode(
            node_id=rf_nid,
            type=KGNodeType.RUNTIME_FINDING,
            label=cf.get("title", "Runtime Finding")[:80],
            properties={
                "cwe":                 cwe,
                "severity":            sev,
                "verification_status": status,
                "combined_confidence": conf,
                "owasp_category":      cf.get("owasp_category", ""),
                "risk_score":          cf.get("risk_score", 0.0),
            },
        )
        self.add_node(graph, rf_node)
        added += 1

        # ENDPOINT → RUNTIME_FINDING: EXPOSED_BY relation
        self.add_edge(graph, KGEdge(
            from_id=ep_nid, to_id=rf_nid,
            relation="EXPOSED_BY",
            weight=conf / 100.0,
        ))

        # RUNTIME_EVIDENCE node
        re_info = cf.get("runtime_evidence", {})
        if re_info and re_info.get("url"):
            re_nid = f"runtime_evidence::{corr_id}"
            re_node = KGNode(
                node_id=re_nid,
                type=KGNodeType.RUNTIME_EVIDENCE,
                label=f"{re_info.get('method','GET')} {re_info.get('url','')[:50]}",
                properties={
                    "url":       re_info.get("url", ""),
                    "method":    re_info.get("method", "GET"),
                    "evidence":  re_info.get("evidence", "")[:300],
                    "confidence": re_info.get("confidence", 0),
                    "source":    re_info.get("source_scanner", "dast"),
                },
            )
            self.add_node(graph, re_node)
            added += 1

            # RUNTIME_FINDING → RUNTIME_EVIDENCE: VERIFIED_BY
            self.add_edge(graph, KGEdge(
                from_id=rf_nid, to_id=re_nid,
                relation="VERIFIED_BY",
                weight=1.0,
            ))

        # Connect to SAST FINDING if static evidence is present
        se_info = cf.get("static_evidence", {})
        if se_info and se_info.get("file"):
            sast_finding_nid = (
                f"finding::{se_info.get('rule_id','')}::"
                f"{se_info.get('file','')}::{se_info.get('line',0)}"
            )
            if sast_finding_nid in graph.node_index:
                self.add_edge(graph, KGEdge(
                    from_id=sast_finding_nid,
                    to_id=rf_nid,
                    relation="CONFIRMED_BY",
                    weight=conf / 100.0,
                ))

    return added


def _kg_find_exposed_endpoints(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List["KGNode"]:
    """Return all ENDPOINT nodes in the graph."""
    return [n for n in graph.nodes if n.type == KGNodeType.ENDPOINT]


def _kg_find_runtime_findings(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
    min_confidence: int = 0,
) -> List["KGNode"]:
    """Return RUNTIME_FINDING nodes, optionally filtered by min confidence."""
    return [
        n for n in graph.nodes
        if n.type == KGNodeType.RUNTIME_FINDING
        and n.properties.get("combined_confidence", 0) >= min_confidence
    ]


def _kg_find_verified_exploits(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List["KGNode"]:
    """Return RUNTIME_FINDING nodes with verification_status == 'verified'."""
    return [
        n for n in graph.nodes
        if n.type == KGNodeType.RUNTIME_FINDING
        and n.properties.get("verification_status") == "verified"
    ]


def _kg_find_reachable_endpoints(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List["KGNode"]:
    """Return ENDPOINT nodes that have at least one outgoing EXPOSED_BY edge."""
    endpoints_with_findings: Set[str] = {
        e.from_id for e in graph.edges if e.relation == "EXPOSED_BY"
    }
    return [n for n in graph.nodes
            if n.type == KGNodeType.ENDPOINT
            and n.node_id in endpoints_with_findings]


def _kg_find_attack_surface(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> Dict[str, Any]:
    """
    Summarise the attack surface: total endpoints, findings per endpoint,
    high-risk endpoints, and top 5 exploitable routes.
    """
    endpoints = _kg_find_exposed_endpoints(self, graph)
    runtime_findings = _kg_find_runtime_findings(self, graph)

    # Count findings per endpoint
    ep_finding_count: Dict[str, int] = {}
    for edge in graph.edges:
        if edge.relation == "EXPOSED_BY":
            ep_finding_count[edge.from_id] = ep_finding_count.get(edge.from_id, 0) + 1

    high_risk = [
        n for n in endpoints
        if n.properties.get("risk_level") in ("CRITICAL", "HIGH")
    ]

    top_routes = sorted(
        ep_finding_count.items(), key=lambda x: -x[1]
    )[:5]

    node_map = {n.node_id: n for n in graph.nodes}
    return {
        "total_endpoints":     len(endpoints),
        "endpoints_with_findings": len(ep_finding_count),
        "high_risk_endpoints": len(high_risk),
        "runtime_findings":    len(runtime_findings),
        "verified_exploits":   len(_kg_find_verified_exploits(self, graph)),
        "top_exploitable_routes": [
            {
                "endpoint": nid,
                "label":    node_map[nid].label if nid in node_map else nid,
                "finding_count": cnt,
            }
            for nid, cnt in top_routes
        ],
    }


def _kg_find_exploitable_routes(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
    min_severity: str = "HIGH",
) -> List[Dict[str, Any]]:
    """
    Return endpoint → runtime_finding paths where finding severity ≥ min_severity.
    Each entry: {endpoint_node, finding_node, severity, verification_status}.
    """
    _rank = {"CRITICAL": 5, "HIGH": 4, "MEDIUM": 3, "LOW": 2, "INFO": 1}
    min_rank = _rank.get(min_severity.upper(), 4)

    results: List[Dict[str, Any]] = []
    node_map = {n.node_id: n for n in graph.nodes}

    for edge in graph.edges:
        if edge.relation != "EXPOSED_BY":
            continue
        finding = node_map.get(edge.to_id)
        endpoint = node_map.get(edge.from_id)
        if not finding or not endpoint:
            continue
        if finding.type != KGNodeType.RUNTIME_FINDING:
            continue
        sev = finding.properties.get("severity", "INFO").upper()
        if _rank.get(sev, 0) >= min_rank:
            results.append({
                "endpoint_id":    endpoint.node_id,
                "endpoint_label": endpoint.label,
                "finding_id":     finding.node_id,
                "finding_label":  finding.label,
                "severity":       sev,
                "verification_status": finding.properties.get("verification_status", "detected"),
                "cwe":            finding.properties.get("cwe", ""),
                "risk_score":     finding.properties.get("risk_score", 0.0),
            })

    return sorted(results, key=lambda r: -r.get("risk_score", 0))


KnowledgeGraphBuilder.build_delta             = _kg_build_delta             # type: ignore[attr-defined]
KnowledgeGraphBuilder.patch_node              = _kg_patch_node              # type: ignore[attr-defined]
KnowledgeGraphBuilder.patch_edge              = _kg_patch_edge              # type: ignore[attr-defined]
KnowledgeGraphBuilder.apply_file_delta        = _kg_apply_file_delta        # type: ignore[attr-defined]
KnowledgeGraphBuilder.ingest_runtime_findings = _kg_ingest_runtime_findings # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_exposed_endpoints  = _kg_find_exposed_endpoints  # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_runtime_findings   = _kg_find_runtime_findings   # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_verified_exploits  = _kg_find_verified_exploits  # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_reachable_endpoints = _kg_find_reachable_endpoints # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_attack_surface     = _kg_find_attack_surface     # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_exploitable_routes = _kg_find_exploitable_routes # type: ignore[attr-defined]


# ===========================================================================
# Phase 8 — TON Elite extensions to KnowledgeGraphBuilder
# ===========================================================================

def _kg_ingest_ton_findings(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
    ton_findings: List[Any],
    sbom: Optional[Any] = None,
) -> int:
    """
    Ingest TON analyzer findings into the Knowledge Graph.

    Creates SMART_CONTRACT / TON_WALLET / JETTON / NFT_COLLECTION / TREASURY /
    MULTISIG nodes for each unique contract file, FINDING nodes for each
    vulnerability, and VULNERABLE_TO edges connecting them.

    Returns number of nodes created.
    """
    created = 0
    seen_contracts: Dict[str, str] = {}   # file → node_id

    # Build contract type map from SBOM if available
    sbom_type_map: Dict[str, str] = {}
    if sbom and hasattr(sbom, "entries"):
        for e in sbom.entries:
            sbom_type_map[e.file] = e.contract_type

    for finding in ton_findings:
        file_path = finding.get("file", "unknown")
        rule_id   = finding.get("rule_id", finding.get("id", "UNKNOWN"))
        severity  = finding.get("severity", "INFO")
        cwe       = finding.get("cwe", "")
        desc      = finding.get("description", "")

        # --- Contract node ---
        if file_path not in seen_contracts:
            ctype_str = sbom_type_map.get(file_path, _infer_kg_contract_type(file_path, desc))
            kg_type   = _contract_type_to_kg_node_type(ctype_str)
            cn_id     = f"contract:{file_path}"
            name      = file_path.rsplit("/", 1)[-1] if "/" in file_path else file_path

            if not any(n.node_id == cn_id for n in graph.nodes):
                graph.nodes.append(KGNode(
                    node_id=cn_id,
                    type=kg_type,
                    label=name,
                    properties={
                        "file":          file_path,
                        "contract_type": ctype_str,
                        "language":      _detect_language_kg(file_path),
                    },
                ))
                created += 1
            seen_contracts[file_path] = cn_id

        contract_nid = seen_contracts[file_path]

        # --- Finding node ---
        finding_nid = f"ton_finding:{rule_id}:{file_path}:{finding.get('line', 0)}"
        if not any(n.node_id == finding_nid for n in graph.nodes):
            graph.nodes.append(KGNode(
                node_id=finding_nid,
                type=KGNodeType.FINDING,
                label=f"{rule_id}: {desc[:60]}",
                properties={
                    "rule_id":     rule_id,
                    "severity":    severity,
                    "cwe":         cwe,
                    "description": desc,
                    "file":        file_path,
                    "line":        finding.get("line", 0),
                    "category":    finding.get("category", ""),
                    "source":      finding.get("source", "ton_analyzer"),
                },
            ))
            created += 1

        graph.edges.append(KGEdge(
            from_id=contract_nid,
            to_id=finding_nid,
            relation="VULNERABLE_TO",
            weight=_severity_to_weight(severity),
        ))

    # Add OWNS / CONTROLS edges from SBOM
    if sbom and hasattr(sbom, "entries"):
        for entry in sbom.entries:
            cn_id = f"contract:{entry.file}"
            if not any(n.node_id == cn_id for n in graph.nodes):
                continue
            for dep in entry.dependencies:
                dep_nid = f"contract:{dep}"
                graph.edges.append(KGEdge(
                    from_id=cn_id,
                    to_id=dep_nid,
                    relation="DEPENDS_ON",
                    weight=0.5,
                ))
            for actor in entry.privileged_actors:
                actor_nid = f"actor:{actor[:16]}"
                if not any(n.node_id == actor_nid for n in graph.nodes):
                    graph.nodes.append(KGNode(
                        node_id=actor_nid,
                        type=KGNodeType.ASSET,
                        label=f"Actor {actor[:16]}",
                        properties={"address": actor, "role": "privileged"},
                    ))
                    created += 1
                graph.edges.append(KGEdge(
                    from_id=actor_nid,
                    to_id=cn_id,
                    relation="CONTROLS",
                    weight=1.0,
                ))

    return created


def _kg_find_vulnerable_contracts(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
    min_severity: str = "HIGH",
) -> List["KGNode"]:
    """Return SMART_CONTRACT/WALLET/JETTON/etc. nodes that have at least one VULNERABLE_TO edge
    to a FINDING with severity >= min_severity."""
    _rank = {"CRITICAL": 5, "HIGH": 4, "MEDIUM": 3, "LOW": 2, "INFO": 1}
    min_rank = _rank.get(min_severity.upper(), 4)
    node_map = {n.node_id: n for n in graph.nodes}

    vulnerable_contract_ids: set = set()
    for edge in graph.edges:
        if edge.relation != "VULNERABLE_TO":
            continue
        finding = node_map.get(edge.to_id)
        if finding and finding.type == KGNodeType.FINDING:
            sev = finding.properties.get("severity", "INFO").upper()
            if _rank.get(sev, 0) >= min_rank:
                vulnerable_contract_ids.add(edge.from_id)

    _ton_types = {
        KGNodeType.SMART_CONTRACT, KGNodeType.TON_WALLET,
        KGNodeType.JETTON, KGNodeType.NFT_COLLECTION,
        KGNodeType.TREASURY, KGNodeType.MULTISIG,
    }
    return [n for n in graph.nodes
            if n.node_id in vulnerable_contract_ids and n.type in _ton_types]


def _kg_find_vulnerable_wallets(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List["KGNode"]:
    """Return TON_WALLET nodes that have VULNERABLE_TO edges."""
    wallet_ids = {
        e.from_id for e in graph.edges if e.relation == "VULNERABLE_TO"
    }
    return [n for n in graph.nodes
            if n.node_id in wallet_ids and n.type == KGNodeType.TON_WALLET]


def _kg_find_exploitable_messages(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List["KGNode"]:
    """Return TON_MESSAGE nodes that have LEADS_TO edges to FINDING nodes."""
    msg_nodes_with_findings = {
        e.from_id for e in graph.edges
        if e.relation in ("LEADS_TO", "TRIGGERS")
        and any(n.node_id == e.to_id and n.type == KGNodeType.FINDING
                for n in graph.nodes)
    }
    return [n for n in graph.nodes
            if n.node_id in msg_nodes_with_findings and n.type == KGNodeType.TON_MESSAGE]


def _kg_find_ownership_takeovers(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List["KGNode"]:
    """Return FINDING nodes categorized as ownership takeover vulnerabilities."""
    return [
        n for n in graph.nodes
        if n.type == KGNodeType.FINDING
        and any(kw in n.properties.get("description", "").lower()
                for kw in ("ownership", "owner", "admin", "init guard", "takeover"))
        and n.properties.get("severity") in ("CRITICAL", "HIGH")
    ]


def _kg_find_fund_loss_paths(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List[Dict[str, Any]]:
    """Return paths from SMART_CONTRACT nodes to fund-drain FINDING nodes."""
    _drain_keywords = ("fund drain", "mode 128", "carry all balance", "drain", "empty")
    drain_findings = {
        n.node_id for n in graph.nodes
        if n.type == KGNodeType.FINDING
        and any(kw in n.properties.get("description", "").lower() for kw in _drain_keywords)
    }
    node_map = {n.node_id: n for n in graph.nodes}
    paths: List[Dict[str, Any]] = []
    for edge in graph.edges:
        if edge.relation == "VULNERABLE_TO" and edge.to_id in drain_findings:
            contract = node_map.get(edge.from_id)
            finding  = node_map.get(edge.to_id)
            if contract and finding:
                paths.append({
                    "contract_id":    contract.node_id,
                    "contract_label": contract.label,
                    "contract_type":  contract.properties.get("contract_type", "unknown"),
                    "finding_id":     finding.node_id,
                    "severity":       finding.properties.get("severity", "UNKNOWN"),
                    "description":    finding.properties.get("description", ""),
                    "cwe":            finding.properties.get("cwe", ""),
                })
    return paths


def _kg_find_affected_assets(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List["KGNode"]:
    """Return all TON entity nodes (contracts, wallets, jettons, NFTs, treasuries)."""
    _ton_types = {
        KGNodeType.SMART_CONTRACT, KGNodeType.TON_WALLET,
        KGNodeType.JETTON, KGNodeType.NFT_COLLECTION,
        KGNodeType.TREASURY, KGNodeType.MULTISIG,
    }
    return [n for n in graph.nodes if n.type in _ton_types]


def _kg_build_ton_knowledge_graph(
    self: "KnowledgeGraphBuilder",
    ton_findings: List[Any],
    sbom: Optional[Any] = None,
    cross_contract: Optional[Any] = None,
) -> "SecurityKnowledgeGraph":
    """
    Build a complete SecurityKnowledgeGraph from TON scan results.
    Integrates contract nodes, finding nodes, SBOM deps, and cross-contract paths.
    """
    graph = SecurityKnowledgeGraph()
    _kg_ingest_ton_findings(self, graph, ton_findings, sbom)
    # Add cross-contract path edges
    if cross_contract:
        for attr in ("fund_drain_paths", "ownership_takeover_paths",
                     "reentrancy_paths", "jetton_abuse_paths"):
            for path_obj in getattr(cross_contract, attr, []):
                path = getattr(path_obj, "path", [])
                for i in range(len(path) - 1):
                    from_nid = f"contract:{path[i]}"
                    to_nid   = f"contract:{path[i+1]}"
                    graph.edges.append(KGEdge(
                        from_id=from_nid,
                        to_id=to_nid,
                        relation="INTERACTS_WITH",
                        weight=1.0,
                    ))
    return graph


# ---------------------------------------------------------------------------
# Helpers for TON KG extensions
# ---------------------------------------------------------------------------

_TON_TYPE_MAP = {
    "wallet":        KGNodeType.TON_WALLET,
    "jetton_master": KGNodeType.JETTON,
    "jetton_wallet": KGNodeType.JETTON,
    "nft_collection": KGNodeType.NFT_COLLECTION,
    "nft_item":      KGNodeType.NFT_COLLECTION,
    "treasury":      KGNodeType.TREASURY,
    "dao":           KGNodeType.TREASURY,
    "multisig":      KGNodeType.MULTISIG,
}


def _infer_kg_contract_type(file_path: str, desc: str) -> str:
    name = (file_path + " " + desc).lower()
    if "treasury" in name:          return "treasury"
    if "multisig" in name:          return "multisig"
    if "dao" in name:               return "dao"
    if "jetton_master" in name:     return "jetton_master"
    if "jetton_wallet" in name:     return "jetton_wallet"
    if "jetton" in name:            return "jetton_master"
    if "nft_collection" in name:    return "nft_collection"
    if "wallet" in name:            return "wallet"
    return "smart_contract"


def _contract_type_to_kg_node_type(ctype: str) -> "KGNodeType":
    return _TON_TYPE_MAP.get(ctype, KGNodeType.SMART_CONTRACT)


def _detect_language_kg(file_path: str) -> str:
    if file_path.endswith(".tact"):  return "tact"
    if file_path.endswith(".tlb"):   return "tlb"
    return "func"


def _severity_to_weight(severity: str) -> float:
    return {"CRITICAL": 1.0, "HIGH": 0.8, "MEDIUM": 0.6, "LOW": 0.4}.get(severity.upper(), 0.2)


# Register Phase 8 methods on KnowledgeGraphBuilder
KnowledgeGraphBuilder.ingest_ton_findings        = _kg_ingest_ton_findings        # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_vulnerable_contracts  = _kg_find_vulnerable_contracts  # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_vulnerable_wallets    = _kg_find_vulnerable_wallets    # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_exploitable_messages  = _kg_find_exploitable_messages  # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_ownership_takeovers   = _kg_find_ownership_takeovers   # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_fund_loss_paths       = _kg_find_fund_loss_paths       # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_affected_assets       = _kg_find_affected_assets       # type: ignore[attr-defined]
KnowledgeGraphBuilder.build_ton_knowledge_graph  = _kg_build_ton_knowledge_graph  # type: ignore[attr-defined]


# ===========================================================================
# Phase 9 — Cloud Security Graph (appended, no duplicate engines)
# ===========================================================================

# ── New node types ──────────────────────────────────────────────────────────
# We extend the existing KGNodeType enum by registering new members via the
# functional API so we don't touch the class definition above.

def _extend_kg_node_types() -> None:
    """Add Phase 9 cloud node types to KGNodeType if they don't exist yet."""
    _new = {
        "CLOUD_ACCOUNT":    "cloud_account",
        "IAM_IDENTITY":     "iam_identity",
        "IAM_ROLE":         "iam_role",
        "IAM_PERMISSION":   "iam_permission",
        "CLOUD_STORAGE":    "cloud_storage",
        "CLOUD_DATABASE":   "cloud_database",
        "CLOUD_FUNCTION":   "cloud_function",
        "CLOUD_NETWORK":    "cloud_network",
        "CLUSTER":          "cluster",
        "K8S_NAMESPACE":    "k8s_namespace",
        "K8S_POD":          "k8s_pod",
        "CONTAINER":        "container",
        "CONTAINER_IMAGE":  "container_image",
        "BUSINESS_ASSET":   "business_asset",
    }
    for name, value in _new.items():
        if name not in KGNodeType.__members__:
            # Extend enum dynamically
            try:
                extend_enum(KGNodeType, name, value)
            except Exception:
                pass  # may fail if aenum not available; fall through


def _safe_extend_kg_node_types() -> None:
    try:
        from aenum import extend_enum  # type: ignore
        _new = {
            "CLOUD_ACCOUNT":    "cloud_account",
            "IAM_IDENTITY":     "iam_identity",
            "IAM_ROLE":         "iam_role",
            "IAM_PERMISSION":   "iam_permission",
            "CLOUD_STORAGE":    "cloud_storage",
            "CLOUD_DATABASE":   "cloud_database",
            "CLOUD_FUNCTION":   "cloud_function",
            "CLOUD_NETWORK":    "cloud_network",
            "CLUSTER":          "cluster",
            "K8S_NAMESPACE":    "k8s_namespace",
            "K8S_POD":          "k8s_pod",
            "CONTAINER":        "container",
            "CONTAINER_IMAGE":  "container_image",
            "BUSINESS_ASSET":   "business_asset",
        }
        for name, value in _new.items():
            if name not in KGNodeType.__members__:
                extend_enum(KGNodeType, name, value)
    except ImportError:
        pass


_safe_extend_kg_node_types()

# ── Cloud node ingestion ────────────────────────────────────────────────────

_CLOUD_RESOURCE_TYPES = frozenset({
    "aws_s3_bucket", "aws_rds_instance", "aws_ec2_instance",
    "aws_lambda_function", "aws_security_group", "aws_iam_role",
    "azurerm_storage_account", "azurerm_sql_server", "azurerm_virtual_machine",
    "google_storage_bucket", "google_sql_database_instance", "google_compute_instance",
    "s3", "rds", "ec2", "lambda", "iam", "storage", "database", "compute",
})

_SEVERITY_WEIGHT_P9 = {"CRITICAL": 1.0, "HIGH": 0.8, "MEDIUM": 0.6, "LOW": 0.4, "INFO": 0.1}


def _kg_ingest_cloud_findings(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
    cloud_findings: List[Dict[str, Any]],
) -> int:
    """
    Ingest cloud misconfiguration findings into the Knowledge Graph.

    Each finding dict should have:
      rule_id, severity, file, resource_type, resource_name, description, category
    Creates CLOUD_RESOURCE / CLOUD_STORAGE / CLOUD_DATABASE nodes + FINDING nodes.
    Returns count of nodes added.
    """
    added = 0
    for f in cloud_findings:
        rule_id    = f.get("rule_id", f.get("id", "CLOUD-UNKNOWN"))
        severity   = f.get("severity", "INFO").upper()
        file_path  = f.get("file", "")
        res_type   = f.get("resource_type", "").lower()
        res_name   = f.get("resource_name", f.get("resource", file_path))
        desc       = f.get("description", "")
        category   = f.get("category", "")
        public     = f.get("public_access", False) or "public" in desc.lower()

        # Choose node type based on resource type
        if "storage" in res_type or "s3" in res_type or "blob" in res_type or "gcs" in res_type:
            ntype = "cloud_storage"
        elif "database" in res_type or "rds" in res_type or "sql" in res_type:
            ntype = "cloud_database"
        elif "iam" in res_type or "role" in res_type or "policy" in res_type:
            ntype = "iam_identity"
        elif "network" in res_type or "security_group" in res_type or "firewall" in res_type:
            ntype = "cloud_network"
        elif "cluster" in res_type or "k8s" in res_type or "kubernetes" in res_type:
            ntype = "cluster"
        elif "container" in res_type or "pod" in res_type:
            ntype = "container"
        else:
            ntype = "cloud_resource"

        # Resource node
        resource_id = f"cloud:{ntype}:{res_name.lower().replace(' ', '_')[:40]}"
        if resource_id not in graph.node_index:
            graph.nodes.append(KGNode(
                node_id=resource_id,
                type=KGNodeType.CLOUD_RESOURCE,
                label=res_name or res_type or "cloud_resource",
                properties={
                    "resource_type": res_type,
                    "provider": f.get("provider", ""),
                    "public_access": public,
                    "severity": severity,
                },
            ))
            graph.node_index[resource_id] = len(graph.nodes) - 1
            added += 1

        # Finding node
        finding_id = f"cloud:finding:{rule_id}:{file_path}:{f.get('line', 0)}"
        if finding_id not in graph.node_index:
            graph.nodes.append(KGNode(
                node_id=finding_id,
                type=KGNodeType.FINDING,
                label=f"{rule_id}: {desc[:60]}",
                properties={
                    "severity": severity,
                    "description": desc,
                    "category": category,
                    "file": file_path,
                    "weight": _SEVERITY_WEIGHT_P9.get(severity, 0.5),
                },
            ))
            graph.node_index[finding_id] = len(graph.nodes) - 1
            added += 1

        # FINDING → EXPOSED_THROUGH → CLOUD_RESOURCE
        graph.edges.append(KGEdge(
            from_id=finding_id,
            to_id=resource_id,
            relation="EXPOSED_THROUGH",
            weight=_SEVERITY_WEIGHT_P9.get(severity, 0.5),
        ))

        # If public: add EXPOSES edge
        if public:
            graph.edges.append(KGEdge(
                from_id=resource_id,
                to_id=finding_id,
                relation="EXPOSES",
                weight=1.0,
            ))

    return added


def _kg_ingest_iam_findings(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
    iam_findings: List[Dict[str, Any]],
) -> int:
    """
    Ingest IAM findings into the Knowledge Graph.
    Creates IAM_IDENTITY, IAM_ROLE, IAM_PERMISSION nodes.
    """
    added = 0
    for f in iam_findings:
        principal  = f.get("principal", f.get("resource", ""))
        permission = f.get("permission", "")
        severity   = f.get("severity", "INFO").upper()
        category   = f.get("category", "")
        rule_id    = f.get("rule_id", "IAM-UNKNOWN")
        desc       = f.get("description", "")

        # Identity node
        if principal:
            identity_id = f"iam:identity:{principal.lower().replace(' ', '_')[:40]}"
            if identity_id not in graph.node_index:
                graph.nodes.append(KGNode(
                    node_id=identity_id,
                    type=KGNodeType.CLOUD_RESOURCE,
                    label=principal,
                    properties={"node_subtype": "iam_identity", "severity": severity},
                ))
                graph.node_index[identity_id] = len(graph.nodes) - 1
                added += 1

            # Permission node
            if permission:
                perm_id = f"iam:perm:{permission.lower().replace(':', '_')[:40]}"
                if perm_id not in graph.node_index:
                    graph.nodes.append(KGNode(
                        node_id=perm_id,
                        type=KGNodeType.CLOUD_RESOURCE,
                        label=permission,
                        properties={
                            "node_subtype": "iam_permission",
                            "severity": severity,
                            "category": category,
                        },
                    ))
                    graph.node_index[perm_id] = len(graph.nodes) - 1
                    added += 1

                graph.edges.append(KGEdge(
                    from_id=identity_id,
                    to_id=perm_id,
                    relation="HAS_PERMISSION",
                    weight=_SEVERITY_WEIGHT_P9.get(severity, 0.5),
                ))

                # WILDCARD / escalation edges
                if "WILDCARD" in category or "*" in permission or "iam:*" in permission.lower():
                    graph.edges.append(KGEdge(
                        from_id=perm_id,
                        to_id=identity_id,
                        relation="ESCALATES_TO",
                        weight=1.0,
                    ))

    return added


def _kg_find_cloud_attack_paths(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List[Dict[str, Any]]:
    """
    Find attack paths from FINDING nodes to CLOUD_RESOURCE nodes.
    BFS: FINDING → ... → CLOUD_RESOURCE (via any edge chain, max depth 6).
    """
    # Build adjacency list from edges
    adj: Dict[str, List[str]] = {}
    for edge in graph.edges:
        adj.setdefault(edge.from_id, []).append(edge.to_id)

    # Cloud node ids
    cloud_ids: set = set()
    finding_ids: set = set()
    for node in graph.nodes:
        ntype_val = node.type.value if hasattr(node.type, "value") else str(node.type)
        if ntype_val in ("cloud_resource", "cloud_storage", "cloud_database",
                         "cloud_function", "cloud_network", "cloud_account"):
            cloud_ids.add(node.node_id)
        if ntype_val in ("finding", "vulnerability", "cve", "runtime_finding"):
            finding_ids.add(node.node_id)

    paths: List[Dict[str, Any]] = []
    seen_pairs: set = set()
    node_map = {n.node_id: n for n in graph.nodes}

    for start_id in finding_ids:
        # BFS
        queue: List[List[str]] = [[start_id]]
        while queue:
            path = queue.pop(0)
            if len(path) > 6:
                continue
            current = path[-1]
            if current in cloud_ids and current != start_id:
                pair = (start_id, current)
                if pair not in seen_pairs:
                    seen_pairs.add(pair)
                    start_node = node_map.get(start_id)
                    end_node   = node_map.get(current)
                    paths.append({
                        "path_id":    f"cloud_path:{start_id[:20]}:{current[:20]}",
                        "start_node": start_id,
                        "end_node":   current,
                        "start_label": start_node.label if start_node else start_id,
                        "end_label":   end_node.label   if end_node   else current,
                        "node_count": len(path),
                        "severity":   (start_node.properties.get("severity", "INFO")
                                       if start_node else "INFO"),
                    })
                continue
            for neighbour in adj.get(current, []):
                if neighbour not in path:
                    queue.append(path + [neighbour])

    return sorted(paths, key=lambda p: -_SEVERITY_WEIGHT_P9.get(p["severity"], 0.1))


def _kg_find_exposed_cloud_resources(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List[Dict[str, Any]]:
    """Return CLOUD_RESOURCE nodes with public_access=True or connected via EXPOSES edges."""
    exposed_ids: set = set()
    for edge in graph.edges:
        if edge.relation == "EXPOSES":
            exposed_ids.add(edge.to_id)
            exposed_ids.add(edge.from_id)

    results = []
    for node in graph.nodes:
        ntype_val = node.type.value if hasattr(node.type, "value") else str(node.type)
        if ntype_val in ("cloud_resource", "cloud_storage", "cloud_database", "cloud_network"):
            if node.properties.get("public_access") or node.node_id in exposed_ids:
                results.append({
                    "node_id":       node.node_id,
                    "label":         node.label,
                    "resource_type": node.properties.get("resource_type", ntype_val),
                    "severity":      node.properties.get("severity", "HIGH"),
                    "public_access": True,
                })
    return results


def _kg_find_privilege_escalation_paths(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List[Dict[str, Any]]:
    """Return paths involving ESCALATES_TO edges in the IAM/cloud subgraph."""
    escalation_edges = [e for e in graph.edges if e.relation == "ESCALATES_TO"]
    node_map = {n.node_id: n for n in graph.nodes}
    results = []
    for edge in escalation_edges:
        src = node_map.get(edge.from_id)
        dst = node_map.get(edge.to_id)
        results.append({
            "from_id":    edge.from_id,
            "from_label": src.label if src else edge.from_id,
            "to_id":      edge.to_id,
            "to_label":   dst.label if dst else edge.to_id,
            "severity":   "CRITICAL",
            "description": f"Privilege escalation: {src.label if src else edge.from_id} → {dst.label if dst else edge.to_id}",
        })
    return results


def _kg_find_reachable_cloud_assets(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List[Dict[str, Any]]:
    """Return all CLOUD_* nodes reachable from any FINDING node."""
    return _kg_find_cloud_attack_paths(self, graph)


def _kg_find_container_risks(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List[Dict[str, Any]]:
    """Return CONTAINER/CONTAINER_IMAGE nodes with HIGH/CRITICAL severity."""
    results = []
    for node in graph.nodes:
        ntype_val = node.type.value if hasattr(node.type, "value") else str(node.type)
        sub = node.properties.get("node_subtype", "")
        if ntype_val in ("container", "container_image") or sub in ("container", "container_image"):
            sev = node.properties.get("severity", "INFO")
            if sev in ("CRITICAL", "HIGH"):
                results.append({
                    "node_id": node.node_id,
                    "label":   node.label,
                    "severity": sev,
                })
    return results


def _kg_find_kubernetes_risks(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List[Dict[str, Any]]:
    """Return K8S_POD/CLUSTER/K8S_NAMESPACE nodes with HIGH/CRITICAL severity."""
    results = []
    for node in graph.nodes:
        ntype_val = node.type.value if hasattr(node.type, "value") else str(node.type)
        sub = node.properties.get("node_subtype", "")
        if ntype_val in ("cluster", "k8s_pod", "k8s_namespace") or "k8s" in sub:
            sev = node.properties.get("severity", "INFO")
            if sev in ("CRITICAL", "HIGH"):
                results.append({
                    "node_id":      node.node_id,
                    "label":        node.label,
                    "severity":     sev,
                    "resource_type": ntype_val,
                })
    return results


def _kg_find_business_critical_findings(
    self: "KnowledgeGraphBuilder",
    graph: "SecurityKnowledgeGraph",
) -> List[Dict[str, Any]]:
    """Return CRITICAL findings in cloud/iam/container layers (BUSINESS_ASSET reachable)."""
    results = []
    for node in graph.nodes:
        ntype_val = node.type.value if hasattr(node.type, "value") else str(node.type)
        if ntype_val in ("finding", "runtime_finding"):
            sev = node.properties.get("severity", "INFO")
            cat = node.properties.get("category", "").lower()
            if sev == "CRITICAL" and any(kw in cat for kw in ("cloud", "iam", "container", "k8s", "access")):
                results.append({
                    "node_id":   node.node_id,
                    "label":     node.label,
                    "severity":  sev,
                    "category":  cat,
                    "business_critical": True,
                })
    return results


def _kg_build_cloud_knowledge_graph(
    self: "KnowledgeGraphBuilder",
    cloud_findings: List[Dict[str, Any]],
    iam_findings: Optional[List[Dict[str, Any]]] = None,
    k8s_findings: Optional[List[Dict[str, Any]]] = None,
    container_findings: Optional[List[Dict[str, Any]]] = None,
) -> "SecurityKnowledgeGraph":
    """
    Build a SecurityKnowledgeGraph from cloud-layer findings.
    Ingests: cloud misconfigs + IAM findings + K8s findings + container findings.
    """
    graph = SecurityKnowledgeGraph()
    _kg_ingest_cloud_findings(self, graph, cloud_findings)
    if iam_findings:
        _kg_ingest_iam_findings(self, graph, iam_findings)
    if k8s_findings:
        for f in k8s_findings:
            f2 = dict(f)
            f2.setdefault("resource_type", "k8s_pod")
            f2.setdefault("resource_name", f2.get("resource_name", f2.get("resource", "pod")))
            _kg_ingest_cloud_findings(self, graph, [f2])
    if container_findings:
        for f in container_findings:
            f2 = dict(f)
            f2.setdefault("resource_type", "container_image")
            f2.setdefault("resource_name", f2.get("image", "container"))
            _kg_ingest_cloud_findings(self, graph, [f2])
    return graph


# Register Phase 9 methods on KnowledgeGraphBuilder
KnowledgeGraphBuilder.ingest_cloud_findings          = _kg_ingest_cloud_findings          # type: ignore[attr-defined]
KnowledgeGraphBuilder.ingest_iam_findings_cloud      = _kg_ingest_iam_findings            # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_cloud_attack_paths        = _kg_find_cloud_attack_paths        # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_exposed_cloud_resources   = _kg_find_exposed_cloud_resources   # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_cloud_privilege_escalation = _kg_find_privilege_escalation_paths  # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_reachable_cloud_assets    = _kg_find_reachable_cloud_assets    # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_container_risks           = _kg_find_container_risks           # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_kubernetes_risks          = _kg_find_kubernetes_risks          # type: ignore[attr-defined]
KnowledgeGraphBuilder.find_business_critical_findings = _kg_find_business_critical_findings  # type: ignore[attr-defined]
KnowledgeGraphBuilder.build_cloud_knowledge_graph    = _kg_build_cloud_knowledge_graph    # type: ignore[attr-defined]
