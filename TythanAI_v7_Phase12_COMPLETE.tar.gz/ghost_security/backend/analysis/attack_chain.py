"""
backend/analysis/attack_chain.py — Attack Chain Builder.

Constructs complete multi-step exploitation chains from security findings.
Shows how vulnerabilities chain from initial access to full compromise.

Example chain:
  User Input (HTTP)
  → SQL Injection [finding]
  → Full database dump
  → Credential extraction
  → Server authentication
  → RCE via stored procedure
  → Full system compromise
"""
from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field
from functools import reduce
from typing import Dict, List, Optional, Tuple

from backend.core.confidence import Finding

logger = logging.getLogger("tythanai.attack_chain")


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class AttackStep:
    step_id: str
    step_number: int
    step_type: str              # "initial_access", "execution", "persistence",
                                 # "privilege_escalation", "lateral_movement",
                                 # "collection", "exfiltration", "impact"
    finding_ref: Optional[str]  # finding.rule_id if this step is based on a finding
    description: str
    mitre_technique: str        # "T1190", "T1059.004", etc.
    mitre_tactic: str           # "Initial Access", "Execution", etc.
    requires_steps: List[str]   # step_ids that must happen first
    probability: float          # 0.0-1.0
    effort: str                 # "LOW", "MEDIUM", "HIGH"
    impact_if_successful: str


@dataclass
class AttackChain:
    chain_id: str
    title: str
    description: str
    steps: List[AttackStep]
    total_probability: float
    attack_complexity: str      # "LOW", "MEDIUM", "HIGH"
    required_privileges: str    # "NONE", "LOW", "HIGH"
    impact: str                 # "CRITICAL", "HIGH", "MEDIUM", "LOW"
    cvss_score: float
    mitre_tactic_sequence: List[str]
    affected_assets: List[str]
    kill_chain_stage: str
    narrative: str              # human-readable multi-step description


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------

class AttackChainBuilder:
    """Builds attack chains from security findings."""

    # MITRE ATT&CK technique mapping per CWE
    _CWE_TO_TECHNIQUE: Dict[str, Tuple[str, str, str]] = {
        "CWE-89":  ("T1190", "Initial Access", "Exploit Public-Facing Application (SQL Injection)"),
        "CWE-79":  ("T1059.007", "Execution", "Command and Scripting Interpreter: JavaScript"),
        "CWE-78":  ("T1059.004", "Execution", "Command and Scripting Interpreter: Unix Shell"),
        "CWE-22":  ("T1083", "Discovery", "File and Directory Discovery via Path Traversal"),
        "CWE-798": ("T1552.001", "Credential Access", "Credentials In Files"),
        "CWE-327": ("T1600", "Defense Evasion", "Weaken Encryption"),
        "CWE-502": ("T1059", "Execution", "Command and Scripting Interpreter (Deserialization)"),
        "CWE-918": ("T1090.002", "Command and Control", "External Proxy / SSRF"),
        "CWE-94":  ("T1059.007", "Execution", "Command and Scripting Interpreter (SSTI)"),
        "CWE-287": ("T1556", "Credential Access", "Modify Authentication Process"),
        "CWE-611": ("T1005", "Collection", "Data from Local System (XXE)"),
    }

    # CWEs that represent web-facing initial access points
    _INITIAL_ACCESS_CWES = {"CWE-89", "CWE-78", "CWE-79", "CWE-94", "CWE-502", "CWE-918"}

    def build_chains(self, findings: List[Finding]) -> List[AttackChain]:
        """Build all possible attack chains from a list of findings."""
        initial_access_findings = self._find_initial_access(findings)

        chains: List[AttackChain] = []
        for finding in initial_access_findings:
            cwe = finding.cwe_id
            if cwe == "CWE-89":
                chain = self._build_sqli_chain(finding)
            elif cwe in ("CWE-78", "CWE-79"):
                chain = self._build_cmdi_chain(finding)
            elif cwe == "CWE-918":
                chain = self._build_ssrf_chain(finding)
            elif cwe == "CWE-22":
                chain = self._build_path_traversal_chain(finding)
            elif cwe == "CWE-94":
                chain = self._build_ssti_chain(finding)
            else:
                chain = self._build_generic_chain(finding)
            chains.append(chain)

        # Check for cross-chain connections: SQL injection → secrets → lateral movement
        sqli_chains = [c for c in chains if any(s.finding_ref and "sqli" in s.finding_ref.lower() for s in c.steps)
                       or any("SQL" in s.description for s in c.steps)]
        secret_findings = [f for f in findings if f.cwe_id == "CWE-798"]
        if sqli_chains and secret_findings:
            logger.debug(
                "Cross-chain connection: %d SQLi chain(s) → %d secret finding(s) → lateral movement",
                len(sqli_chains), len(secret_findings),
            )
            for chain in sqli_chains:
                if "credential_extraction" not in [s.step_type for s in chain.steps]:
                    # extend existing chain's affected assets to reflect lateral movement
                    if "internal_network" not in chain.affected_assets:
                        chain.affected_assets.append("internal_network")

        # Sort by CVSS score descending
        chains.sort(key=lambda c: c.cvss_score, reverse=True)
        return chains

    # ------------------------------------------------------------------ helpers

    def _find_initial_access(self, findings: List[Finding]) -> List[Finding]:
        """Return findings that represent likely web-facing entry points."""
        return [f for f in findings if f.cwe_id in self._INITIAL_ACCESS_CWES]

    def _make_chain_id(self, prefix: str, finding: Finding) -> str:
        raw = f"{prefix}:{finding.file}:{finding.line}:{finding.rule_id}"
        return "chain-" + hashlib.sha1(raw.encode()).hexdigest()[:12]

    # ------------------------------------------------------------------ chain builders

    def _build_sqli_chain(self, finding: Finding) -> AttackChain:
        """SQL injection → DB credential dump → Auth bypass → Data exfiltration."""
        step1 = AttackStep(
            step_id="sqli-s1",
            step_number=1,
            step_type="initial_access",
            finding_ref=finding.rule_id,
            description=f"Attacker sends malicious SQL payload via HTTP parameter in {finding.file}:{finding.line}",
            mitre_technique="T1190",
            mitre_tactic="Initial Access",
            requires_steps=[],
            probability=0.85,
            effort="LOW",
            impact_if_successful="Application processes attacker-controlled SQL fragment",
        )
        step2 = AttackStep(
            step_id="sqli-s2",
            step_number=2,
            step_type="collection",
            finding_ref=finding.rule_id,
            description="SQL UNION/error-based injection extracts full database schema and credential tables",
            mitre_technique="T1190",
            mitre_tactic="Collection",
            requires_steps=["sqli-s1"],
            probability=0.75,
            effort="LOW",
            impact_if_successful="Full database dump including hashed or plaintext credentials",
        )
        step3 = AttackStep(
            step_id="sqli-s3",
            step_number=3,
            step_type="credential_access",
            finding_ref=None,
            description="Offline cracking or reuse of extracted credentials against application login",
            mitre_technique="T1552.001",
            mitre_tactic="Credential Access",
            requires_steps=["sqli-s2"],
            probability=0.60,
            effort="MEDIUM",
            impact_if_successful="Authenticated access to application and potentially related services",
        )
        step4 = AttackStep(
            step_id="sqli-s4",
            step_number=4,
            step_type="exfiltration",
            finding_ref=None,
            description="Bulk exfiltration of personal data, business records, and PII via authenticated API",
            mitre_technique="T1041",
            mitre_tactic="Exfiltration",
            requires_steps=["sqli-s3"],
            probability=0.90,
            effort="LOW",
            impact_if_successful="Complete data breach — all records exposed to attacker",
        )
        steps = [step1, step2, step3, step4]
        total_prob = 0.85 * 0.75 * 0.60
        narrative = self.format_narrative(AttackChain(
            chain_id=self._make_chain_id("sqli", finding),
            title="SQL Injection → Full Database Compromise",
            description=(
                "An attacker exploits unsanitised SQL query construction to dump the entire "
                "database, extract credentials, and exfiltrate all business data."
            ),
            steps=steps,
            total_probability=total_prob,
            attack_complexity="LOW",
            required_privileges="NONE",
            impact="CRITICAL",
            cvss_score=9.1,
            mitre_tactic_sequence=["Initial Access", "Collection", "Credential Access", "Exfiltration"],
            affected_assets=["database", "user_credentials", "personal_data", "business_data"],
            kill_chain_stage="Actions on Objectives",
            narrative="",
        ))
        return AttackChain(
            chain_id=self._make_chain_id("sqli", finding),
            title="SQL Injection → Full Database Compromise",
            description=(
                "An attacker exploits unsanitised SQL query construction to dump the entire "
                "database, extract credentials, and exfiltrate all business data."
            ),
            steps=steps,
            total_probability=total_prob,
            attack_complexity="LOW",
            required_privileges="NONE",
            impact="CRITICAL",
            cvss_score=9.1,
            mitre_tactic_sequence=["Initial Access", "Collection", "Credential Access", "Exfiltration"],
            affected_assets=["database", "user_credentials", "personal_data", "business_data"],
            kill_chain_stage="Actions on Objectives",
            narrative=narrative,
        )

    def _build_cmdi_chain(self, finding: Finding) -> AttackChain:
        """Command injection → Reverse shell → Persistent backdoor → Lateral movement."""
        step1 = AttackStep(
            step_id="cmdi-s1",
            step_number=1,
            step_type="initial_access",
            finding_ref=finding.rule_id,
            description=f"Attacker injects OS command via user-controlled input in {finding.file}:{finding.line}",
            mitre_technique="T1059.004",
            mitre_tactic="Initial Access",
            requires_steps=[],
            probability=0.80,
            effort="LOW",
            impact_if_successful="Arbitrary OS command executed with web application privileges",
        )
        step2 = AttackStep(
            step_id="cmdi-s2",
            step_number=2,
            step_type="execution",
            finding_ref=finding.rule_id,
            description="Injected command launches reverse shell connecting back to attacker-controlled host",
            mitre_technique="T1059.004",
            mitre_tactic="Execution",
            requires_steps=["cmdi-s1"],
            probability=0.70,
            effort="LOW",
            impact_if_successful="Interactive shell access to server as application user",
        )
        step3 = AttackStep(
            step_id="cmdi-s3",
            step_number=3,
            step_type="persistence",
            finding_ref=None,
            description="Attacker installs cron-based backdoor and SSH authorized_keys for persistent access",
            mitre_technique="T1136.001",
            mitre_tactic="Persistence",
            requires_steps=["cmdi-s2"],
            probability=0.65,
            effort="LOW",
            impact_if_successful="Persistent foothold survives service restarts and deployments",
        )
        step4 = AttackStep(
            step_id="cmdi-s4",
            step_number=4,
            step_type="lateral_movement",
            finding_ref=None,
            description="Using internal network access and harvested credentials, attacker pivots to adjacent systems",
            mitre_technique="T1021.004",
            mitre_tactic="Lateral Movement",
            requires_steps=["cmdi-s3"],
            probability=0.55,
            effort="MEDIUM",
            impact_if_successful="Compromise of internal services, databases, and adjacent hosts",
        )
        steps = [step1, step2, step3, step4]
        total_prob = 0.80 * 0.70 * 0.65
        narrative = self.format_narrative(AttackChain(
            chain_id=self._make_chain_id("cmdi", finding),
            title="Command Injection → Full System Compromise",
            description=(
                "An attacker exploits OS command injection to obtain a reverse shell, "
                "establish persistence, and move laterally through the internal network."
            ),
            steps=steps,
            total_probability=total_prob,
            attack_complexity="LOW",
            required_privileges="NONE",
            impact="CRITICAL",
            cvss_score=9.8,
            mitre_tactic_sequence=["Initial Access", "Execution", "Persistence", "Lateral Movement"],
            affected_assets=["operating_system", "server_filesystem", "internal_network", "all_processes"],
            kill_chain_stage="Actions on Objectives",
            narrative="",
        ))
        return AttackChain(
            chain_id=self._make_chain_id("cmdi", finding),
            title="Command Injection → Full System Compromise",
            description=(
                "An attacker exploits OS command injection to obtain a reverse shell, "
                "establish persistence, and move laterally through the internal network."
            ),
            steps=steps,
            total_probability=total_prob,
            attack_complexity="LOW",
            required_privileges="NONE",
            impact="CRITICAL",
            cvss_score=9.8,
            mitre_tactic_sequence=["Initial Access", "Execution", "Persistence", "Lateral Movement"],
            affected_assets=["operating_system", "server_filesystem", "internal_network", "all_processes"],
            kill_chain_stage="Actions on Objectives",
            narrative=narrative,
        )

    def _build_ssrf_chain(self, finding: Finding) -> AttackChain:
        """User-controlled URL → SSRF → Internal network scan → Cloud metadata → IAM credentials → Cloud takeover."""
        step1 = AttackStep(
            step_id="ssrf-s1",
            step_number=1,
            step_type="initial_access",
            finding_ref=finding.rule_id,
            description=f"Attacker supplies a crafted URL parameter in {finding.file}:{finding.line}; server fetches it",
            mitre_technique="T1090.002",
            mitre_tactic="Initial Access",
            requires_steps=[],
            probability=0.75,
            effort="LOW",
            impact_if_successful="Server makes outbound HTTP request to attacker-specified destination",
        )
        step2 = AttackStep(
            step_id="ssrf-s2",
            step_number=2,
            step_type="discovery",
            finding_ref=None,
            description="Attacker iterates RFC-1918 ranges via SSRF to map internal network topology",
            mitre_technique="T1046",
            mitre_tactic="Discovery",
            requires_steps=["ssrf-s1"],
            probability=0.60,
            effort="MEDIUM",
            impact_if_successful="Internal service map including admin panels, metadata endpoints, and DBs",
        )
        step3 = AttackStep(
            step_id="ssrf-s3",
            step_number=3,
            step_type="credential_access",
            finding_ref=None,
            description="SSRF request to http://169.254.169.254/latest/meta-data/iam/security-credentials/ returns temporary IAM keys",
            mitre_technique="T1552.005",
            mitre_tactic="Credential Access",
            requires_steps=["ssrf-s2"],
            probability=0.80,
            effort="LOW",
            impact_if_successful="AWS/GCP/Azure temporary IAM credentials with application role permissions",
        )
        step4 = AttackStep(
            step_id="ssrf-s4",
            step_number=4,
            step_type="impact",
            finding_ref=None,
            description="Using stolen IAM credentials, attacker enumerates S3 buckets, reads secrets, creates persistent IAM users",
            mitre_technique="T1078.004",
            mitre_tactic="Privilege Escalation",
            requires_steps=["ssrf-s3"],
            probability=0.70,
            effort="LOW",
            impact_if_successful="Full cloud account takeover — all data and services accessible to attacker",
        )
        steps = [step1, step2, step3, step4]
        total_prob = 0.75 * 0.60 * 0.80
        narrative = self.format_narrative(AttackChain(
            chain_id=self._make_chain_id("ssrf", finding),
            title="SSRF → Cloud Metadata → IAM Takeover",
            description=(
                "An attacker exploits Server-Side Request Forgery to reach the cloud instance "
                "metadata service, steal IAM credentials, and take over the cloud account."
            ),
            steps=steps,
            total_probability=total_prob,
            attack_complexity="LOW",
            required_privileges="NONE",
            impact="CRITICAL",
            cvss_score=8.6,
            mitre_tactic_sequence=["Initial Access", "Discovery", "Credential Access", "Privilege Escalation"],
            affected_assets=["internal_network", "cloud_infrastructure", "IAM_credentials", "S3_data"],
            kill_chain_stage="Command & Control",
            narrative="",
        ))
        return AttackChain(
            chain_id=self._make_chain_id("ssrf", finding),
            title="SSRF → Cloud Metadata → IAM Takeover",
            description=(
                "An attacker exploits Server-Side Request Forgery to reach the cloud instance "
                "metadata service, steal IAM credentials, and take over the cloud account."
            ),
            steps=steps,
            total_probability=total_prob,
            attack_complexity="LOW",
            required_privileges="NONE",
            impact="CRITICAL",
            cvss_score=8.6,
            mitre_tactic_sequence=["Initial Access", "Discovery", "Credential Access", "Privilege Escalation"],
            affected_assets=["internal_network", "cloud_infrastructure", "IAM_credentials", "S3_data"],
            kill_chain_stage="Command & Control",
            narrative=narrative,
        )

    def _build_path_traversal_chain(self, finding: Finding) -> AttackChain:
        """Traversal path → SSH key read → Server authentication → Privilege escalation."""
        step1 = AttackStep(
            step_id="pt-s1",
            step_number=1,
            step_type="initial_access",
            finding_ref=finding.rule_id,
            description=f"Attacker uses ../ sequences in file path parameter in {finding.file}:{finding.line}",
            mitre_technique="T1083",
            mitre_tactic="Discovery",
            requires_steps=[],
            probability=0.80,
            effort="LOW",
            impact_if_successful="Arbitrary file read outside intended directory",
        )
        step2 = AttackStep(
            step_id="pt-s2",
            step_number=2,
            step_type="credential_access",
            finding_ref=None,
            description="Traversal reads /root/.ssh/id_rsa or /home/deploy/.ssh/id_rsa private key",
            mitre_technique="T1552.004",
            mitre_tactic="Credential Access",
            requires_steps=["pt-s1"],
            probability=0.50,
            effort="LOW",
            impact_if_successful="SSH private key for server or deploy user extracted",
        )
        step3 = AttackStep(
            step_id="pt-s3",
            step_number=3,
            step_type="lateral_movement",
            finding_ref=None,
            description="Attacker uses extracted SSH key to authenticate directly to server or CI/CD pipeline",
            mitre_technique="T1021.004",
            mitre_tactic="Lateral Movement",
            requires_steps=["pt-s2"],
            probability=0.70,
            effort="LOW",
            impact_if_successful="Direct SSH access to production server",
        )
        step4 = AttackStep(
            step_id="pt-s4",
            step_number=4,
            step_type="privilege_escalation",
            finding_ref=None,
            description="Using server shell, attacker exploits misconfigurations (sudo, SUID) to gain root",
            mitre_technique="T1068",
            mitre_tactic="Privilege Escalation",
            requires_steps=["pt-s3"],
            probability=0.60,
            effort="MEDIUM",
            impact_if_successful="Full root/SYSTEM access to production server",
        )
        steps = [step1, step2, step3, step4]
        total_prob = 0.80 * 0.50 * 0.70
        narrative = self.format_narrative(AttackChain(
            chain_id=self._make_chain_id("pt", finding),
            title="Path Traversal → SSH Key Theft → Server Compromise",
            description=(
                "An attacker exploits path traversal to read SSH private keys, "
                "authenticate to the server, and escalate to root privileges."
            ),
            steps=steps,
            total_probability=total_prob,
            attack_complexity="MEDIUM",
            required_privileges="NONE",
            impact="HIGH",
            cvss_score=7.5,
            mitre_tactic_sequence=["Discovery", "Credential Access", "Lateral Movement", "Privilege Escalation"],
            affected_assets=["configuration_files", "ssh_keys", "secrets_files", "source_code"],
            kill_chain_stage="Exploitation",
            narrative="",
        ))
        return AttackChain(
            chain_id=self._make_chain_id("pt", finding),
            title="Path Traversal → SSH Key Theft → Server Compromise",
            description=(
                "An attacker exploits path traversal to read SSH private keys, "
                "authenticate to the server, and escalate to root privileges."
            ),
            steps=steps,
            total_probability=total_prob,
            attack_complexity="MEDIUM",
            required_privileges="NONE",
            impact="HIGH",
            cvss_score=7.5,
            mitre_tactic_sequence=["Discovery", "Credential Access", "Lateral Movement", "Privilege Escalation"],
            affected_assets=["configuration_files", "ssh_keys", "secrets_files", "source_code"],
            kill_chain_stage="Exploitation",
            narrative=narrative,
        )

    def _build_ssti_chain(self, finding: Finding) -> AttackChain:
        """Template injection → OS command execution → Full server compromise."""
        step1 = AttackStep(
            step_id="ssti-s1",
            step_number=1,
            step_type="initial_access",
            finding_ref=finding.rule_id,
            description=f"Attacker injects template expression (e.g. {{{{7*7}}}}) via user input in {finding.file}:{finding.line}",
            mitre_technique="T1059.007",
            mitre_tactic="Execution",
            requires_steps=[],
            probability=0.85,
            effort="LOW",
            impact_if_successful="Template engine evaluates attacker expression in server context",
        )
        step2 = AttackStep(
            step_id="ssti-s2",
            step_number=2,
            step_type="execution",
            finding_ref=finding.rule_id,
            description="Escalated payload uses template engine internals (__class__.__mro__) to execute OS commands",
            mitre_technique="T1059.007",
            mitre_tactic="Execution",
            requires_steps=["ssti-s1"],
            probability=0.80,
            effort="LOW",
            impact_if_successful="Arbitrary OS command execution with web server process privileges",
        )
        step3 = AttackStep(
            step_id="ssti-s3",
            step_number=3,
            step_type="impact",
            finding_ref=None,
            description="Full server compromise: data exfiltration, reverse shell, credential theft",
            mitre_technique="T1059.004",
            mitre_tactic="Impact",
            requires_steps=["ssti-s2"],
            probability=0.90,
            effort="LOW",
            impact_if_successful="Complete server compromise — all data, processes, and secrets accessible",
        )
        steps = [step1, step2, step3]
        total_prob = 0.85 * 0.80
        narrative = self.format_narrative(AttackChain(
            chain_id=self._make_chain_id("ssti", finding),
            title="Server-Side Template Injection → RCE",
            description=(
                "An attacker exploits SSTI to escalate from expression evaluation to "
                "arbitrary OS command execution and full server compromise."
            ),
            steps=steps,
            total_probability=total_prob,
            attack_complexity="LOW",
            required_privileges="NONE",
            impact="CRITICAL",
            cvss_score=9.8,
            mitre_tactic_sequence=["Execution", "Execution", "Impact"],
            affected_assets=["web_server", "application_secrets", "server_filesystem", "all_data"],
            kill_chain_stage="Actions on Objectives",
            narrative="",
        ))
        return AttackChain(
            chain_id=self._make_chain_id("ssti", finding),
            title="Server-Side Template Injection → RCE",
            description=(
                "An attacker exploits SSTI to escalate from expression evaluation to "
                "arbitrary OS command execution and full server compromise."
            ),
            steps=steps,
            total_probability=total_prob,
            attack_complexity="LOW",
            required_privileges="NONE",
            impact="CRITICAL",
            cvss_score=9.8,
            mitre_tactic_sequence=["Execution", "Execution", "Impact"],
            affected_assets=["web_server", "application_secrets", "server_filesystem", "all_data"],
            kill_chain_stage="Actions on Objectives",
            narrative=narrative,
        )

    def _build_generic_chain(self, finding: Finding) -> AttackChain:
        """Generic chain for CWEs not covered by specific builders."""
        technique, tactic, technique_name = self._CWE_TO_TECHNIQUE.get(
            finding.cwe_id,
            ("T1190", "Initial Access", "Exploit Public-Facing Application"),
        )
        step1 = AttackStep(
            step_id="generic-s1",
            step_number=1,
            step_type="initial_access",
            finding_ref=finding.rule_id,
            description=f"Attacker exploits {finding.cwe_id} vulnerability in {finding.file}:{finding.line}",
            mitre_technique=technique,
            mitre_tactic=tactic,
            requires_steps=[],
            probability=0.70,
            effort="MEDIUM",
            impact_if_successful=f"Initial exploitation of {finding.cwe_id}",
        )
        step2 = AttackStep(
            step_id="generic-s2",
            step_number=2,
            step_type="impact",
            finding_ref=None,
            description="Attacker leverages initial access to escalate privileges or exfiltrate data",
            mitre_technique="T1078",
            mitre_tactic="Privilege Escalation",
            requires_steps=["generic-s1"],
            probability=0.60,
            effort="MEDIUM",
            impact_if_successful="Escalated access or data exposure depending on application context",
        )
        steps = [step1, step2]
        total_prob = 0.70 * 0.60
        narrative = self.format_narrative(AttackChain(
            chain_id=self._make_chain_id("generic", finding),
            title=f"{finding.cwe_id} Exploitation Chain",
            description=f"Generic exploitation chain starting from {finding.cwe_id} ({technique_name})",
            steps=steps,
            total_probability=total_prob,
            attack_complexity="MEDIUM",
            required_privileges="NONE",
            impact="HIGH",
            cvss_score=7.0,
            mitre_tactic_sequence=[tactic, "Privilege Escalation"],
            affected_assets=["application", "data"],
            kill_chain_stage="Exploitation",
            narrative="",
        ))
        return AttackChain(
            chain_id=self._make_chain_id("generic", finding),
            title=f"{finding.cwe_id} Exploitation Chain",
            description=f"Generic exploitation chain starting from {finding.cwe_id} ({technique_name})",
            steps=steps,
            total_probability=total_prob,
            attack_complexity="MEDIUM",
            required_privileges="NONE",
            impact="HIGH",
            cvss_score=7.0,
            mitre_tactic_sequence=[tactic, "Privilege Escalation"],
            affected_assets=["application", "data"],
            kill_chain_stage="Exploitation",
            narrative=narrative,
        )

    # ------------------------------------------------------------------ utilities

    @staticmethod
    def _compute_chain_probability(steps: List[AttackStep]) -> float:
        """Product of all step probabilities."""
        if not steps:
            return 0.0
        return reduce(lambda a, b: a * b, [s.probability for s in steps])

    @staticmethod
    def format_narrative(chain: AttackChain) -> str:
        """Return a multi-line human-readable attack chain description."""
        lines: List[str] = []
        lines.append(f"## Attack Chain: {chain.title}")
        lines.append("")
        lines.append(
            f"**Complexity**: {chain.attack_complexity} | **CVSS**: {chain.cvss_score}"
        )
        lines.append(f"**Required Privileges**: {chain.required_privileges}")
        lines.append(f"**Affected Assets**: {', '.join(chain.affected_assets)}")
        lines.append("")
        lines.append("### Attack Steps:")
        lines.append("")
        for step in chain.steps:
            human_type = step.step_type.replace("_", " ").title()
            lines.append(
                f"{step.step_number}. **{human_type}** (MITRE {step.mitre_technique})"
            )
            lines.append(f"   {step.description}")
            lines.append(
                f"   Probability: {step.probability:.0%} | Attacker Effort: {step.effort}"
            )
            lines.append("")
        if chain.steps:
            last_step = chain.steps[-1]
            lines.append("### Impact if Fully Exploited:")
            lines.append(last_step.impact_if_successful)
        return "\n".join(lines)
