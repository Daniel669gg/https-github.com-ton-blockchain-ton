"""TythanAI — analysis modules."""
