# TythanAI Security Platform
# Copyright (c) 2026 TythanAI Labs
# Licensed under the Business Source License 1.1 (see LICENSE).

"""
backend/saas/webhook_manager.py — TythanAI Webhook Manager
Registers, dispatches, and logs webhook deliveries with HMAC signatures.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import sqlite3
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("tythanai.webhooks")

# ─── Supported events ──────────────────────────────────────────────────────────

SUPPORTED_EVENTS = {
    "scan.completed",
    "finding.critical",
    "patch.pr_opened",
    "patch.pr_merged",
    "regression.detected",
}

# ─── DB schema ─────────────────────────────────────────────────────────────────

_DB_SCHEMA = """
CREATE TABLE IF NOT EXISTS webhooks (
    id          TEXT PRIMARY KEY,
    account_id  TEXT NOT NULL,
    url         TEXT NOT NULL,
    events      TEXT NOT NULL DEFAULT '[]',
    secret      TEXT,
    created_at  TEXT NOT NULL,
    active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS webhook_deliveries (
    id           TEXT PRIMARY KEY,
    webhook_id   TEXT NOT NULL,
    event_type   TEXT NOT NULL,
    status_code  INTEGER,
    attempt      INTEGER NOT NULL DEFAULT 1,
    delivered_at TEXT NOT NULL,
    payload      TEXT NOT NULL DEFAULT '{}',
    response     TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_wh_account ON webhooks(account_id);
CREATE INDEX IF NOT EXISTS idx_wd_webhook ON webhook_deliveries(webhook_id);
"""


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ─── Webhook Manager ──────────────────────────────────────────────────────────

class WebhookManager:
    """Manage webhook registrations and deliver events with HMAC signatures."""

    def __init__(self, db_path: str = "data/webhooks.db") -> None:
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    # ── Private helpers ────────────────────────────────────────────────────────

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _init_db(self) -> None:
        with self._conn() as conn:
            for stmt in _DB_SCHEMA.split(";"):
                stmt = stmt.strip()
                if stmt:
                    conn.execute(stmt)

    @staticmethod
    def _sign_payload(secret: str, body: bytes) -> str:
        """Compute HMAC-SHA256 signature for the payload."""
        mac = hmac.new(secret.encode(), body, hashlib.sha256)
        return f"sha256={mac.hexdigest()}"

    def _deliver_once(
        self,
        webhook_id: str,
        url: str,
        secret: Optional[str],
        event_type: str,
        payload: dict,
        attempt: int,
    ) -> Dict[str, Any]:
        """Attempt a single delivery. Returns delivery log dict."""
        body = json.dumps(payload).encode()
        headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "X-TythanAI-Event": event_type,
            "X-TythanAI-Delivery": str(uuid.uuid4()),
        }
        if secret:
            headers["X-TythanAI-Signature"] = self._sign_payload(secret, body)

        status_code = 0
        response_body = ""
        delivered_at = _now_iso()

        try:
            req = urllib.request.Request(url, data=body, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=10) as resp:
                status_code = resp.status
                response_body = resp.read(4096).decode("utf-8", errors="replace")
        except urllib.error.HTTPError as exc:
            status_code = exc.code
            response_body = str(exc)
        except Exception as exc:
            status_code = 0
            response_body = str(exc)

        delivery_id = str(uuid.uuid4())
        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO webhook_deliveries
                    (id, webhook_id, event_type, status_code, attempt, delivered_at, payload, response)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    delivery_id,
                    webhook_id,
                    event_type,
                    status_code,
                    attempt,
                    delivered_at,
                    json.dumps(payload),
                    response_body,
                ),
            )

        return {
            "delivery_id": delivery_id,
            "webhook_id": webhook_id,
            "status_code": status_code,
            "attempt": attempt,
            "delivered_at": delivered_at,
            "success": 200 <= status_code < 300,
        }

    def _deliver_with_retry(
        self,
        webhook_id: str,
        url: str,
        secret: Optional[str],
        event_type: str,
        payload: dict,
    ) -> Dict[str, Any]:
        """Try up to 3 times with exponential backoff (2s, 4s, 8s)."""
        backoff_seconds = [2, 4, 8]
        last_result: Dict[str, Any] = {}

        for attempt_num, wait in enumerate(backoff_seconds, start=1):
            result = self._deliver_once(
                webhook_id, url, secret, event_type, payload, attempt_num
            )
            last_result = result
            if result.get("success"):
                return result
            if attempt_num < len(backoff_seconds):
                logger.debug(
                    "Delivery attempt %d failed (status=%s) for webhook %s; retrying in %ds",
                    attempt_num,
                    result.get("status_code"),
                    webhook_id,
                    wait,
                )
                time.sleep(wait)

        return last_result

    # ── Public API ─────────────────────────────────────────────────────────────

    def register(
        self,
        account_id: str,
        url: str,
        events: List[str],
        secret: Optional[str] = None,
    ) -> dict:
        """Register a new webhook endpoint. Returns the webhook record dict."""
        webhook_id = str(uuid.uuid4())
        created_at = _now_iso()

        # Validate events
        unknown = [e for e in events if e not in SUPPORTED_EVENTS]
        if unknown:
            logger.warning("Unknown events will be stored but may not fire: %s", unknown)

        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO webhooks (id, account_id, url, events, secret, created_at, active)
                VALUES (?, ?, ?, ?, ?, ?, 1)
                """,
                (webhook_id, account_id, url, json.dumps(events), secret, created_at),
            )

        record = {
            "id": webhook_id,
            "account_id": account_id,
            "url": url,
            "events": events,
            "secret": secret,
            "created_at": created_at,
            "active": True,
        }
        logger.info("Registered webhook %s for account %s → %s", webhook_id, account_id, url)
        return record

    def dispatch(
        self,
        event_type: str,
        payload: dict,
        account_id: str,
    ) -> dict:
        """
        Dispatch an event to all active webhooks registered for this account+event.
        Returns {"delivered": N, "failed": M}.
        """
        with self._conn() as conn:
            rows = conn.execute(
                """
                SELECT id, url, events, secret
                FROM webhooks
                WHERE account_id = ? AND active = 1
                """,
                (account_id,),
            ).fetchall()

        delivered = 0
        failed = 0
        full_payload = {
            "event": event_type,
            "account_id": account_id,
            "timestamp": _now_iso(),
            "data": payload,
        }

        for row in rows:
            subscribed = json.loads(row["events"])
            if event_type not in subscribed:
                continue
            result = self._deliver_with_retry(
                webhook_id=row["id"],
                url=row["url"],
                secret=row["secret"],
                event_type=event_type,
                payload=full_payload,
            )
            if result.get("success"):
                delivered += 1
            else:
                failed += 1

        return {"delivered": delivered, "failed": failed}

    def list_webhooks(self, account_id: str) -> List[dict]:
        """Return all webhooks for this account."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM webhooks WHERE account_id = ? ORDER BY created_at DESC",
                (account_id,),
            ).fetchall()

        return [
            {
                "id": r["id"],
                "account_id": r["account_id"],
                "url": r["url"],
                "events": json.loads(r["events"]),
                "secret": r["secret"],
                "created_at": r["created_at"],
                "active": bool(r["active"]),
            }
            for r in rows
        ]

    def delete_webhook(self, webhook_id: str) -> bool:
        """Soft-delete (deactivate) a webhook. Returns True if found and deactivated."""
        with self._conn() as conn:
            cursor = conn.execute(
                "UPDATE webhooks SET active = 0 WHERE id = ?",
                (webhook_id,),
            )
        return cursor.rowcount > 0

    def get_delivery_log(self, webhook_id: str, limit: int = 50) -> List[dict]:
        """Return delivery history for a specific webhook."""
        with self._conn() as conn:
            rows = conn.execute(
                """
                SELECT * FROM webhook_deliveries
                WHERE webhook_id = ?
                ORDER BY delivered_at DESC
                LIMIT ?
                """,
                (webhook_id, limit),
            ).fetchall()

        return [
            {
                "id": r["id"],
                "webhook_id": r["webhook_id"],
                "event_type": r["event_type"],
                "status_code": r["status_code"],
                "attempt": r["attempt"],
                "delivered_at": r["delivered_at"],
                "payload": json.loads(r["payload"]),
                "response": r["response"],
                "success": 200 <= (r["status_code"] or 0) < 300,
            }
            for r in rows
        ]
