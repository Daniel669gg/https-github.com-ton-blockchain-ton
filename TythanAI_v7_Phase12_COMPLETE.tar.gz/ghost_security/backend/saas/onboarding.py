"""
backend/saas/onboarding.py — TythanAI SaaS Onboarding Flow
Handles new account creation, API key generation, and initial project scanning.
"""
from __future__ import annotations

import logging
import os
import secrets
import smtplib
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.mime.text import MIMEText
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger("tythanai.onboarding")

# ─── Data model ───────────────────────────────────────────────────────────────

@dataclass
class OnboardingResult:
    account_id: str
    api_key: str
    project_id: str
    scan_summary: Dict[str, Any]
    session_id: str


# ─── DB helpers ───────────────────────────────────────────────────────────────

_DB_PATH = Path("data/onboarding.db")

_DB_SCHEMA = """
CREATE TABLE IF NOT EXISTS onboarding_sessions (
    session_id   TEXT PRIMARY KEY,
    account_id   TEXT NOT NULL,
    api_key      TEXT NOT NULL,
    project_id   TEXT NOT NULL,
    email        TEXT NOT NULL,
    repo_url     TEXT NOT NULL,
    plan         TEXT NOT NULL DEFAULT 'free',
    status       TEXT NOT NULL DEFAULT 'active',
    scan_summary TEXT NOT NULL DEFAULT '{}',
    created_at   TEXT NOT NULL
);
"""


def _get_conn(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def _init_db(db_path: Path) -> None:
    with _get_conn(db_path) as conn:
        conn.execute(_DB_SCHEMA)


# ─── Onboarding flow ──────────────────────────────────────────────────────────

class OnboardingFlow:
    """End-to-end SaaS onboarding pipeline for new users."""

    def __init__(self, db_path: str = "data/onboarding.db") -> None:
        self._db_path = Path(db_path)
        _init_db(self._db_path)

    # ── Private helpers ────────────────────────────────────────────────────────

    def _store_session(self, result: OnboardingResult, email: str, repo_url: str, plan: str) -> None:
        import json
        with _get_conn(self._db_path) as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO onboarding_sessions
                    (session_id, account_id, api_key, project_id, email, repo_url,
                     plan, status, scan_summary, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)
                """,
                (
                    result.session_id,
                    result.account_id,
                    result.api_key,
                    result.project_id,
                    email,
                    repo_url,
                    plan,
                    json.dumps(result.scan_summary),
                    datetime.now(timezone.utc).isoformat(),
                ),
            )

    def _send_welcome_email(self, email: str, account_id: str, api_key: str) -> bool:
        """Attempt to send a welcome email via SMTP. Returns False if not configured."""
        smtp_host = os.environ.get("SMTP_HOST", "")
        smtp_port = int(os.environ.get("SMTP_PORT", "587"))
        smtp_user = os.environ.get("SMTP_USER", "")
        smtp_pass = os.environ.get("SMTP_PASS", "")

        if not smtp_host:
            logger.warning(
                "SMTP not configured (SMTP_HOST not set); skipping welcome email for %s", email
            )
            return False

        try:
            body = (
                f"Welcome to TythanAI!\n\n"
                f"Account ID: {account_id}\n"
                f"API Key: {api_key}\n\n"
                f"Get started at https://app.tythanai.com\n"
            )
            msg = MIMEText(body)
            msg["Subject"] = "Welcome to TythanAI Security Platform"
            msg["From"] = smtp_user or "noreply@tythanai.com"
            msg["To"] = email

            with smtplib.SMTP(smtp_host, smtp_port, timeout=10) as server:
                server.ehlo()
                if smtp_user and smtp_pass:
                    server.starttls()
                    server.login(smtp_user, smtp_pass)
                server.sendmail(msg["From"], [email], msg.as_string())

            logger.info("Welcome email sent to %s", email)
            return True
        except Exception as exc:
            logger.warning("Failed to send welcome email to %s: %s", email, exc)
            return False

    def _run_fast_scan(self, repo_url: str) -> Dict[str, Any]:
        """Run a fast supply chain scan if repo_url is a local path."""
        local_path = Path(repo_url)
        if not local_path.exists():
            return {}

        try:
            from backend.scanners.supply_chain import SupplyChainScanner
            scanner = SupplyChainScanner()
            result = scanner.scan(str(local_path))
            if isinstance(result, dict):
                return result
            return {}
        except Exception as exc:
            logger.warning("Fast scan failed: %s", exc)
            return {}

    # ── Public API ─────────────────────────────────────────────────────────────

    def complete(
        self,
        email: str,
        repo_url: str,
        plan: str = "free",
    ) -> OnboardingResult:
        """
        Run the full onboarding pipeline.
        Returns an OnboardingResult with account credentials and initial scan summary.
        """
        # 1. Generate IDs
        account_id = str(uuid.uuid4())
        api_key = secrets.token_urlsafe(32)
        project_id = str(uuid.uuid4())
        session_id = str(uuid.uuid4())

        # 2. Run fast scan
        scan_summary = self._run_fast_scan(repo_url)

        # 3. Build result
        result = OnboardingResult(
            account_id=account_id,
            api_key=api_key,
            project_id=project_id,
            scan_summary=scan_summary,
            session_id=session_id,
        )

        # 4. Persist to SQLite
        self._store_session(result, email, repo_url, plan)

        # 5. Send welcome email (best-effort)
        self._send_welcome_email(email, account_id, api_key)

        logger.info("Onboarding complete for %s — account=%s", email, account_id)
        return result

    def get_status(self, session_id: str) -> dict:
        """Return session status from the onboarding database."""
        import json
        with _get_conn(self._db_path) as conn:
            row = conn.execute(
                "SELECT * FROM onboarding_sessions WHERE session_id = ?",
                (session_id,),
            ).fetchone()

        if row is None:
            return {"error": "session_not_found", "session_id": session_id}

        return {
            "session_id": row["session_id"],
            "account_id": row["account_id"],
            "project_id": row["project_id"],
            "email": row["email"],
            "repo_url": row["repo_url"],
            "plan": row["plan"],
            "status": row["status"],
            "scan_summary": json.loads(row["scan_summary"]),
            "created_at": row["created_at"],
        }
