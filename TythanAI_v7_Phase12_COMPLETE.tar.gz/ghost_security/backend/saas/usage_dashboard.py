"""
backend/saas/usage_dashboard.py — TythanAI Usage Dashboard
Account statistics, billing summaries, and team activity views.
"""
from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from cloud.billing.usage_tracker import UsageTracker
from cloud.billing.plan_enforcer import PLANS

logger = logging.getLogger("tythanai.usage_dashboard")

# ─── Dashboard ────────────────────────────────────────────────────────────────

class UsageDashboard:
    """
    Provides account-level usage statistics, billing summaries, and team activity.
    Reads from UsageTracker (cloud/billing) and the onboarding SQLite DB.
    """

    def __init__(
        self,
        usage_tracker: Optional[UsageTracker] = None,
        onboarding_db: str = "data/onboarding.db",
    ) -> None:
        self._tracker = usage_tracker or UsageTracker()
        self._onboarding_db = Path(onboarding_db)

    # ── Private helpers ────────────────────────────────────────────────────────

    def _onboarding_conn(self) -> Optional[sqlite3.Connection]:
        if not self._onboarding_db.exists():
            return None
        conn = sqlite3.connect(str(self._onboarding_db))
        conn.row_factory = sqlite3.Row
        return conn

    def _get_plan_for_account(self, account_id: str) -> str:
        """Look up the plan for this account from the onboarding DB."""
        conn = self._onboarding_conn()
        if conn is None:
            return "free"
        try:
            row = conn.execute(
                "SELECT plan FROM onboarding_sessions WHERE account_id = ? LIMIT 1",
                (account_id,),
            ).fetchone()
            return row["plan"] if row else "free"
        except sqlite3.OperationalError:
            return "free"
        finally:
            conn.close()

    @staticmethod
    def _trend(current: int, previous: int) -> str:
        if current > previous:
            return "up"
        elif current < previous:
            return "down"
        return "stable"

    # ── Public API ─────────────────────────────────────────────────────────────

    def get_account_stats(self, account_id: str) -> dict:
        """
        Return usage statistics for the current month.
        Keys: scans_this_month, findings_by_severity, trend, top5_risky_files.
        """
        now = datetime.now(timezone.utc)
        current = self._tracker.get_monthly_usage(account_id, now.year, now.month)

        # Previous month for trend
        prev_month = now.month - 1 or 12
        prev_year = now.year if now.month > 1 else now.year - 1
        previous = self._tracker.get_monthly_usage(account_id, prev_year, prev_month)

        scans_this_month = current.get("scans", 0)
        prev_scans = previous.get("scans", 0)
        trend = self._trend(scans_this_month, prev_scans)

        total_findings = current.get("findings", 0)

        # Severity breakdown and per-file risk come from the findings store, if
        # the tracker exposes one. We never fabricate a distribution: when no
        # per-severity data is available we report zeros for every bucket and
        # set `severity_breakdown_available` to False so consumers know the
        # zeros mean "not measured", not "no findings".
        real_breakdown = self._real_severity_breakdown(account_id, now)
        breakdown_available = real_breakdown is not None
        findings_by_severity = real_breakdown or {
            "CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0,
        }
        top5_risky_files = self._real_top_risky_files(account_id, now)

        return {
            "account_id": account_id,
            "scans_this_month": scans_this_month,
            "findings_total": total_findings,
            "findings_by_severity": findings_by_severity,
            "severity_breakdown_available": breakdown_available,
            "trend": trend,
            "top5_risky_files": top5_risky_files,
            "files_scanned_this_month": current.get("files_scanned", 0),
            "api_calls_this_month": current.get("api_calls", 0),
        }

    def _real_severity_breakdown(self, account_id: str, now: datetime) -> Optional[Dict[str, int]]:
        """
        Return the real per-severity finding counts for the current month from
        the UsageTracker findings store, or None if the tracker does not expose
        a severity breakdown. We never synthesize a distribution.
        """
        getter = getattr(self._tracker, "get_findings_by_severity", None)
        if not callable(getter):
            return None
        try:
            data = getter(account_id, now.year, now.month)
        except Exception:  # noqa: BLE001 — tracker is best-effort
            return None
        if not isinstance(data, dict):
            return None
        return {
            sev: int(data.get(sev, 0))
            for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO")
        }

    def _real_top_risky_files(self, account_id: str, now: datetime) -> List[str]:
        """
        Return the real top-5 risky files from the tracker if it exposes them,
        otherwise an empty list. No fabricated file names.
        """
        getter = getattr(self._tracker, "get_top_risky_files", None)
        if not callable(getter):
            return []
        try:
            files = getter(account_id, now.year, now.month, limit=5)
        except Exception:  # noqa: BLE001
            return []
        return list(files) if isinstance(files, (list, tuple)) else []

    def get_billing_summary(self, account_id: str) -> dict:
        """
        Return billing information for this account.
        Keys: current_plan, usage_pct, next_payment_date.
        """
        plan_name = self._get_plan_for_account(account_id)
        plan_limits = PLANS.get(plan_name, PLANS["free"])

        now = datetime.now(timezone.utc)
        monthly = self._tracker.get_monthly_usage(account_id, now.year, now.month)

        scan_limit = plan_limits.get("scans_per_month")
        scans_used = monthly.get("scans", 0)
        if scan_limit:
            usage_pct = min(100.0, round((scans_used / scan_limit) * 100, 1))
        else:
            usage_pct = 0.0  # unlimited

        # Next payment date: first of next month
        if now.month == 12:
            next_payment = datetime(now.year + 1, 1, 1, tzinfo=timezone.utc)
        else:
            next_payment = datetime(now.year, now.month + 1, 1, tzinfo=timezone.utc)

        return {
            "account_id": account_id,
            "current_plan": plan_name,
            "plan_description": plan_limits.get("description", ""),
            "scans_limit": scan_limit,
            "scans_used": scans_used,
            "usage_pct": usage_pct,
            "next_payment_date": next_payment.strftime("%Y-%m-%d"),
        }

    def get_team_activity(self, account_id: str, limit: int = 20) -> List[dict]:
        """
        Return recent team activity events.
        Reads from onboarding.db if available, otherwise returns mock data.
        """
        conn = self._onboarding_conn()
        if conn is not None:
            try:
                rows = conn.execute(
                    """
                    SELECT session_id, email, plan, created_at, status
                    FROM onboarding_sessions
                    WHERE account_id = ?
                    ORDER BY created_at DESC
                    LIMIT ?
                    """,
                    (account_id, limit),
                ).fetchall()
                conn.close()
                return [
                    {
                        "event": "onboarding",
                        "actor": row["email"],
                        "session_id": row["session_id"],
                        "plan": row["plan"],
                        "status": row["status"],
                        "timestamp": row["created_at"],
                    }
                    for row in rows
                ]
            except sqlite3.OperationalError:
                conn.close()

        # No activity store available — return an empty list rather than
        # fabricating events.
        return []
