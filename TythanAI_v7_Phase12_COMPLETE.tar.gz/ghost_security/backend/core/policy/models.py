"""Policy-as-Code data models."""
from __future__ import annotations

from enum import Enum
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Callable, Any


class PolicyAction(str, Enum):
    BLOCK = "block"                        # Block the scan/deployment
    WARN = "warn"                          # Warning only
    REQUIRE_REVIEW = "require_review"      # Require human review
    AUTO_FIX = "auto_fix"                  # Attempt automatic fix
    NOTIFY = "notify"                      # Send notification only


class PolicySeverity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    ANY = "ANY"


@dataclass
class PolicyCondition:
    """A single condition that must be satisfied for a policy to fire."""
    field: str       # "severity", "cwe_id", "confidence", "rule_id", "description"
    operator: str    # "eq", "neq", "gte", "lte", "in", "contains", "matches"
    value: Any       # comparison value


@dataclass
class PolicyRule:
    """A complete policy rule: conditions (AND) → action."""
    rule_id: str
    name: str
    description: str
    conditions: List[PolicyCondition]   # ALL must match (AND logic)
    action: PolicyAction
    message: str                        # Human-readable message when rule fires
    enabled: bool = True
    tags: List[str] = field(default_factory=list)   # "owasp", "pci-dss", "gdpr", etc.
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PolicyViolation:
    """A single rule violation for a specific finding."""
    rule: PolicyRule
    finding_id: str
    action: PolicyAction
    message: str
    blocking: bool       # Does this violation block deployment?


@dataclass
class PolicyResult:
    """Aggregate result of evaluating a set of findings against all policies."""
    findings_evaluated: int
    violations: List[PolicyViolation]
    blocked: bool                           # Any BLOCK actions triggered?
    total_blocks: int
    total_warns: int
    compliance_status: Dict[str, bool]      # "pci-dss" → compliant?
    summary: str
