"""
Built-in security and compliance policies.

Covers: OWASP Top 10, PCI-DSS requirements, GDPR, SOC2, and
organisation-level security gates (block critical, block unverified secrets).
"""
from __future__ import annotations

from typing import List

from .models import PolicyAction, PolicyCondition, PolicyRule


class BuiltInPolicies:
    """Factory for built-in security and compliance policy rules."""

    @classmethod
    def all_rules(cls) -> List[PolicyRule]:
        """Return all built-in policy rules in priority order."""
        return [
            cls.block_critical(),
            cls.block_high_confidence(),
            cls.warn_medium(),
            cls.block_hardcoded_secrets(),
            cls.block_sqli(),
            cls.block_cmdi(),
            cls.require_review_ssrf(),
            cls.require_review_deserialization(),
            cls.pci_dss_no_weak_crypto(),
            cls.gdpr_protect_personal_data(),
            cls.block_path_traversal(),
            cls.warn_xss(),
            cls.require_review_xss_high(),
            cls.block_low_confidence_disabled(),
        ]

    # ------------------------------------------------------------------
    # Severity-based gates
    # ------------------------------------------------------------------

    @staticmethod
    def block_critical() -> PolicyRule:
        return PolicyRule(
            rule_id="BLOCK_CRITICAL",
            name="Block Critical Severity Findings",
            description=(
                "Any finding rated CRITICAL must block the build or deployment. "
                "Critical findings represent immediate, highly exploitable risks."
            ),
            conditions=[
                PolicyCondition(field="severity", operator="eq", value="CRITICAL"),
            ],
            action=PolicyAction.BLOCK,
            message=(
                "CRITICAL severity finding detected. Deployment is blocked until "
                "this vulnerability is remediated or explicitly accepted by a "
                "security officer."
            ),
            enabled=True,
            tags=["owasp", "pci-dss", "soc2", "gdpr", "baseline"],
        )

    @staticmethod
    def block_high_confidence() -> PolicyRule:
        return PolicyRule(
            rule_id="BLOCK_HIGH_CONFIDENCE",
            name="Block High Severity with High Confidence",
            description=(
                "HIGH severity findings with confidence ≥ 0.85 are blocked. "
                "High confidence reduces the chance of false positives, making "
                "the block decision defensible."
            ),
            conditions=[
                PolicyCondition(field="severity", operator="eq", value="HIGH"),
                PolicyCondition(field="confidence", operator="gte", value=0.85),
            ],
            action=PolicyAction.BLOCK,
            message=(
                "HIGH severity finding with ≥ 85% confidence detected. "
                "This is very likely a real vulnerability. Remediate before deploying."
            ),
            enabled=True,
            tags=["baseline", "owasp"],
        )

    @staticmethod
    def warn_medium() -> PolicyRule:
        return PolicyRule(
            rule_id="WARN_MEDIUM",
            name="Warn on Medium Severity Findings",
            description=(
                "MEDIUM severity findings generate a warning that is included in "
                "scan reports and dashboards but do not block deployments."
            ),
            conditions=[
                PolicyCondition(field="severity", operator="eq", value="MEDIUM"),
            ],
            action=PolicyAction.WARN,
            message=(
                "MEDIUM severity finding detected. Review and remediate in the "
                "next sprint. Escalate to HIGH if exploitability is confirmed."
            ),
            enabled=True,
            tags=["baseline"],
        )

    # ------------------------------------------------------------------
    # Specific vulnerability types
    # ------------------------------------------------------------------

    @staticmethod
    def block_hardcoded_secrets() -> PolicyRule:
        return PolicyRule(
            rule_id="BLOCK_HARDCODED_SECRETS",
            name="Block Hardcoded Credentials / Secrets",
            description=(
                "Hardcoded secrets (CWE-798) in source code are an immediate "
                "supply-chain and insider threat risk. Any detection blocks "
                "the build regardless of confidence."
            ),
            conditions=[
                PolicyCondition(field="cwe_id", operator="eq", value="CWE-798"),
            ],
            action=PolicyAction.BLOCK,
            message=(
                "Hardcoded secret or credential detected (CWE-798). Remove the "
                "secret from source code and rotate it immediately. Use environment "
                "variables or a secrets manager instead."
            ),
            enabled=True,
            tags=["owasp", "pci-dss", "gdpr", "soc2", "secrets"],
            metadata={"owasp_category": "A02:2021 - Cryptographic Failures"},
        )

    @staticmethod
    def block_sqli() -> PolicyRule:
        return PolicyRule(
            rule_id="BLOCK_SQLI",
            name="Block SQL Injection",
            description=(
                "SQL injection (CWE-89) allows attackers to read, modify, or destroy "
                "database contents and is consistently ranked #1 in OWASP Top 10. "
                "All detections are blocked regardless of severity."
            ),
            conditions=[
                PolicyCondition(field="cwe_id", operator="eq", value="CWE-89"),
            ],
            action=PolicyAction.BLOCK,
            message=(
                "SQL injection vulnerability detected (CWE-89 / OWASP A03:2021). "
                "Use parameterised queries or an ORM. Never concatenate user input "
                "directly into SQL strings."
            ),
            enabled=True,
            tags=["owasp", "pci-dss", "gdpr"],
            metadata={"owasp_category": "A03:2021 - Injection"},
        )

    @staticmethod
    def block_cmdi() -> PolicyRule:
        return PolicyRule(
            rule_id="BLOCK_CMDI",
            name="Block Command Injection",
            description=(
                "Command injection (CWE-78) allows arbitrary OS command execution. "
                "This leads to full server compromise and must never reach production."
            ),
            conditions=[
                PolicyCondition(field="cwe_id", operator="eq", value="CWE-78"),
            ],
            action=PolicyAction.BLOCK,
            message=(
                "OS command injection vulnerability detected (CWE-78 / OWASP A03:2021). "
                "Use subprocess with a list of arguments and never pass shell=True with "
                "user-controlled input. Use shlex.quote() for shell strings."
            ),
            enabled=True,
            tags=["owasp", "pci-dss"],
            metadata={"owasp_category": "A03:2021 - Injection"},
        )

    @staticmethod
    def require_review_ssrf() -> PolicyRule:
        return PolicyRule(
            rule_id="REQUIRE_REVIEW_SSRF",
            name="Require Security Review for SSRF",
            description=(
                "Server-Side Request Forgery (CWE-918) allows attackers to reach "
                "internal services. Requires explicit security review before deployment "
                "because many SSRF findings need architectural assessment."
            ),
            conditions=[
                PolicyCondition(field="cwe_id", operator="eq", value="CWE-918"),
            ],
            action=PolicyAction.REQUIRE_REVIEW,
            message=(
                "SSRF vulnerability detected (CWE-918 / OWASP A10:2021). "
                "A security engineer must review this before deployment. "
                "Implement URL allowlisting and validate destination domains."
            ),
            enabled=True,
            tags=["owasp"],
            metadata={"owasp_category": "A10:2021 - Server-Side Request Forgery"},
        )

    @staticmethod
    def require_review_deserialization() -> PolicyRule:
        return PolicyRule(
            rule_id="REQUIRE_REVIEW_DESERIALIZATION",
            name="Require Security Review for Unsafe Deserialization",
            description=(
                "Insecure deserialization (CWE-502) can lead to remote code execution. "
                "Requires human review to assess blast radius and applicability."
            ),
            conditions=[
                PolicyCondition(field="cwe_id", operator="eq", value="CWE-502"),
            ],
            action=PolicyAction.REQUIRE_REVIEW,
            message=(
                "Unsafe deserialization detected (CWE-502 / OWASP A08:2021). "
                "Replace pickle/yaml.load with json.loads or ast.literal_eval for "
                "untrusted input. A security review is mandatory before release."
            ),
            enabled=True,
            tags=["owasp"],
            metadata={"owasp_category": "A08:2021 - Software and Data Integrity Failures"},
        )

    # ------------------------------------------------------------------
    # Compliance: PCI-DSS
    # ------------------------------------------------------------------

    @staticmethod
    def pci_dss_no_weak_crypto() -> PolicyRule:
        return PolicyRule(
            rule_id="PCI_DSS_NO_WEAK_CRYPTO",
            name="PCI-DSS: Block Weak Cryptography",
            description=(
                "PCI-DSS requirement 4.2 prohibits use of weak or broken cryptographic "
                "algorithms (MD5, SHA-1, DES, RC4) for protecting cardholder data. "
                "Detected via CWE-327."
            ),
            conditions=[
                PolicyCondition(field="cwe_id", operator="eq", value="CWE-327"),
            ],
            action=PolicyAction.BLOCK,
            message=(
                "Weak or broken cryptographic algorithm detected (CWE-327). "
                "PCI-DSS requires at least SHA-256 for hashing and AES-128+ for "
                "symmetric encryption. Replace MD5/SHA-1 with SHA-256 or higher."
            ),
            enabled=True,
            tags=["pci-dss", "crypto"],
            metadata={"pci_dss_requirement": "4.2.1", "owasp_category": "A02:2021"},
        )

    # ------------------------------------------------------------------
    # Compliance: GDPR
    # ------------------------------------------------------------------

    @staticmethod
    def gdpr_protect_personal_data() -> PolicyRule:
        return PolicyRule(
            rule_id="GDPR_PROTECT_PERSONAL_DATA",
            name="GDPR: Protect Personal Data Flows",
            description=(
                "GDPR Article 25 (data protection by design) and Article 32 (security "
                "of processing) require that vulnerabilities in code handling personal "
                "data (via SQL, HTML output, or secret storage) are blocked."
            ),
            conditions=[
                PolicyCondition(
                    field="cwe_id",
                    operator="in",
                    value=["CWE-89", "CWE-79", "CWE-798", "CWE-200", "CWE-312"],
                ),
            ],
            action=PolicyAction.BLOCK,
            message=(
                "Vulnerability in a code path that likely handles personal data. "
                "GDPR Articles 25 and 32 require this to be remediated before "
                "processing personal data. Document the risk assessment if "
                "an exception is granted."
            ),
            enabled=True,
            tags=["gdpr"],
            metadata={"gdpr_articles": ["25", "32"]},
        )

    # ------------------------------------------------------------------
    # Path Traversal
    # ------------------------------------------------------------------

    @staticmethod
    def block_path_traversal() -> PolicyRule:
        return PolicyRule(
            rule_id="BLOCK_PATH_TRAVERSAL",
            name="Block Path Traversal",
            description=(
                "Path traversal (CWE-22) allows attackers to access files and directories "
                "outside the intended location, potentially exposing secrets, configs, "
                "or arbitrary files on the server."
            ),
            conditions=[
                PolicyCondition(field="cwe_id", operator="eq", value="CWE-22"),
            ],
            action=PolicyAction.BLOCK,
            message=(
                "Path traversal vulnerability detected (CWE-22 / OWASP A01:2021). "
                "Canonicalise paths with os.path.realpath() and verify the result "
                "starts with the expected base directory."
            ),
            enabled=True,
            tags=["owasp"],
            metadata={"owasp_category": "A01:2021 - Broken Access Control"},
        )

    # ------------------------------------------------------------------
    # XSS — warn on all, require review for HIGH
    # ------------------------------------------------------------------

    @staticmethod
    def warn_xss() -> PolicyRule:
        return PolicyRule(
            rule_id="WARN_XSS",
            name="Warn on Cross-Site Scripting (XSS)",
            description=(
                "XSS (CWE-79) allows injection of malicious scripts into web pages. "
                "All non-HIGH detections generate a warning; HIGH detections require review."
            ),
            conditions=[
                PolicyCondition(field="cwe_id", operator="eq", value="CWE-79"),
                PolicyCondition(field="severity", operator="neq", value="HIGH"),
                PolicyCondition(field="severity", operator="neq", value="CRITICAL"),
            ],
            action=PolicyAction.WARN,
            message=(
                "XSS vulnerability detected (CWE-79 / OWASP A03:2021). "
                "Ensure all user-controlled output is HTML-escaped. "
                "Use html.escape(), MarkupSafe, or template auto-escaping."
            ),
            enabled=True,
            tags=["owasp"],
            metadata={"owasp_category": "A03:2021 - Injection"},
        )

    @staticmethod
    def require_review_xss_high() -> PolicyRule:
        return PolicyRule(
            rule_id="REQUIRE_REVIEW_XSS_HIGH",
            name="Require Review for HIGH XSS",
            description=(
                "HIGH severity XSS findings require explicit security review "
                "before the code can be merged or deployed."
            ),
            conditions=[
                PolicyCondition(field="cwe_id", operator="eq", value="CWE-79"),
                PolicyCondition(field="severity", operator="eq", value="HIGH"),
            ],
            action=PolicyAction.REQUIRE_REVIEW,
            message=(
                "HIGH severity XSS vulnerability detected (CWE-79). "
                "A security engineer must review and approve this change. "
                "Implement Content Security Policy (CSP) as a defence-in-depth measure."
            ),
            enabled=True,
            tags=["owasp"],
            metadata={"owasp_category": "A03:2021 - Injection"},
        )

    # ------------------------------------------------------------------
    # Low-confidence suppression gate (informational — does NOT block)
    # ------------------------------------------------------------------

    @staticmethod
    def block_low_confidence_disabled() -> PolicyRule:
        return PolicyRule(
            rule_id="BLOCK_LOW_CONFIDENCE_DISABLED",
            name="Do Not Block Low-Confidence Findings",
            description=(
                "Findings with confidence < 0.5 are very likely false positives. "
                "This rule is intentionally set to NOTIFY only (not BLOCK) so that "
                "low-confidence noise does not gate deployments."
            ),
            conditions=[
                PolicyCondition(field="confidence", operator="lte", value=0.5),
            ],
            action=PolicyAction.NOTIFY,
            message=(
                "Low-confidence finding (≤ 50%) — classified as informational. "
                "Review manually if you believe it is a real issue, but no automated "
                "action will be taken."
            ),
            enabled=True,
            tags=["baseline"],
            metadata={"note": "intentionally non-blocking for low-confidence findings"},
        )
