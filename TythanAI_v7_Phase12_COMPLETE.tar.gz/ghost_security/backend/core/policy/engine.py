"""
PolicyEngine — Evaluates security findings against configured policies.
Supports: blocking policies, warning policies, compliance enforcement.
"""
from __future__ import annotations

import re
import logging
from typing import Any, Dict, List, Optional

try:
    import yaml  # type: ignore
    _YAML_AVAILABLE = True
except ImportError:
    _YAML_AVAILABLE = False

from backend.core.confidence import Finding
from .models import (
    PolicyAction,
    PolicyCondition,
    PolicyRule,
    PolicyResult,
    PolicyViolation,
)
from .built_in import BuiltInPolicies

logger = logging.getLogger("tythanai.policy_engine")

# ---------------------------------------------------------------------------
# Compliance framework definitions
# ---------------------------------------------------------------------------

# CWEs that are in-scope for each compliance framework
_PCI_DSS_CWES = {"CWE-89", "CWE-78", "CWE-79", "CWE-22", "CWE-798", "CWE-327", "CWE-918"}
_GDPR_CWES = {"CWE-89", "CWE-79", "CWE-798", "CWE-200", "CWE-312", "CWE-359"}
_SOC2_CWES = {"CWE-89", "CWE-78", "CWE-79", "CWE-22", "CWE-798", "CWE-327", "CWE-502"}

# OWASP Top 10 2021 category → CWE mapping
_OWASP_CATEGORY_CWES: Dict[str, set] = {
    "A01:2021-Broken Access Control": {"CWE-22", "CWE-284", "CWE-285", "CWE-639"},
    "A02:2021-Cryptographic Failures": {"CWE-327", "CWE-328", "CWE-798", "CWE-312"},
    "A03:2021-Injection": {"CWE-89", "CWE-78", "CWE-79", "CWE-77", "CWE-917"},
    "A04:2021-Insecure Design": {"CWE-73", "CWE-183"},
    "A05:2021-Security Misconfiguration": {"CWE-16", "CWE-611"},
    "A06:2021-Vulnerable Components": {"CWE-937", "CWE-1035"},
    "A07:2021-Auth Failures": {"CWE-287", "CWE-307", "CWE-798"},
    "A08:2021-Software Integrity Failures": {"CWE-502", "CWE-494"},
    "A09:2021-Logging Failures": {"CWE-117", "CWE-778"},
    "A10:2021-SSRF": {"CWE-918"},
}


class PolicyEngine:
    """
    Evaluates a list of Finding objects against a set of PolicyRule objects
    and returns a PolicyResult describing all violations and compliance status.
    """

    def __init__(self, rules: Optional[List[PolicyRule]] = None) -> None:
        self._rules: List[PolicyRule] = (
            rules if rules is not None else BuiltInPolicies.all_rules()
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def evaluate(self, findings: List[Finding]) -> PolicyResult:
        """
        Evaluate every finding against every enabled rule.
        Returns aggregated violations, block status, and compliance map.
        """
        violations: List[PolicyViolation] = []

        for finding in findings:
            for rule in self._rules:
                if not rule.enabled:
                    continue
                if self._all_conditions_match(finding, rule.conditions):
                    is_blocking = rule.action == PolicyAction.BLOCK
                    violation = PolicyViolation(
                        rule=rule,
                        finding_id=finding.fingerprint(),
                        action=rule.action,
                        message=rule.message,
                        blocking=is_blocking,
                    )
                    violations.append(violation)
                    logger.info(
                        "policy '%s' triggered for finding %s (action=%s blocking=%s)",
                        rule.rule_id, finding.fingerprint(), rule.action.value, is_blocking,
                    )

        total_blocks = sum(1 for v in violations if v.blocking)
        total_warns = sum(1 for v in violations if v.action == PolicyAction.WARN)
        blocked = total_blocks > 0

        compliance_status = self._check_compliance(findings, violations)

        summary = self._build_summary(
            num_findings=len(findings),
            violations=violations,
            blocked=blocked,
            total_blocks=total_blocks,
            total_warns=total_warns,
            compliance_status=compliance_status,
        )

        return PolicyResult(
            findings_evaluated=len(findings),
            violations=violations,
            blocked=blocked,
            total_blocks=total_blocks,
            total_warns=total_warns,
            compliance_status=compliance_status,
            summary=summary,
        )

    def add_rule(self, rule: PolicyRule) -> None:
        """Add a new policy rule. Replaces any existing rule with the same rule_id."""
        self._rules = [r for r in self._rules if r.rule_id != rule.rule_id]
        self._rules.append(rule)
        logger.debug("added policy rule '%s'", rule.rule_id)

    def remove_rule(self, rule_id: str) -> None:
        """Remove a rule by rule_id. Silent no-op if not found."""
        before = len(self._rules)
        self._rules = [r for r in self._rules if r.rule_id != rule_id]
        if len(self._rules) < before:
            logger.debug("removed policy rule '%s'", rule_id)
        else:
            logger.warning("policy rule '%s' not found — nothing removed", rule_id)

    def load_from_yaml(self, yaml_content: str) -> List[PolicyRule]:
        """
        Parse a YAML policy file and return a list of PolicyRule objects.

        Expected YAML structure:
        rules:
          - rule_id: MY_RULE
            name: "My Rule"
            description: "..."
            action: "block"
            message: "..."
            enabled: true
            tags: ["owasp"]
            conditions:
              - field: severity
                operator: eq
                value: CRITICAL
        """
        if not _YAML_AVAILABLE:
            raise ImportError(
                "PyYAML is not installed. Run: pip install pyyaml"
            )

        data = yaml.safe_load(yaml_content)
        if not isinstance(data, dict) or "rules" not in data:
            raise ValueError("YAML must have a top-level 'rules' list.")

        parsed: List[PolicyRule] = []
        for raw in data["rules"]:
            conditions = [
                PolicyCondition(
                    field=c["field"],
                    operator=c["operator"],
                    value=c["value"],
                )
                for c in raw.get("conditions", [])
            ]
            rule = PolicyRule(
                rule_id=raw["rule_id"],
                name=raw.get("name", raw["rule_id"]),
                description=raw.get("description", ""),
                conditions=conditions,
                action=PolicyAction(raw["action"]),
                message=raw.get("message", ""),
                enabled=raw.get("enabled", True),
                tags=raw.get("tags", []),
                metadata=raw.get("metadata", {}),
            )
            parsed.append(rule)

        logger.debug("loaded %d rules from YAML", len(parsed))
        return parsed

    def export_to_yaml(self, rules: Optional[List[PolicyRule]] = None) -> str:
        """
        Serialise policy rules to a YAML string.

        If *rules* is None, exports the engine's current rule set.
        """
        if not _YAML_AVAILABLE:
            raise ImportError("PyYAML is not installed. Run: pip install pyyaml")

        target = rules if rules is not None else self._rules
        out: dict = {
            "rules": [
                {
                    "rule_id": r.rule_id,
                    "name": r.name,
                    "description": r.description,
                    "action": r.action.value,
                    "message": r.message,
                    "enabled": r.enabled,
                    "tags": r.tags,
                    "metadata": r.metadata,
                    "conditions": [
                        {
                            "field": c.field,
                            "operator": c.operator,
                            "value": c.value,
                        }
                        for c in r.conditions
                    ],
                }
                for r in target
            ]
        }
        return yaml.dump(out, default_flow_style=False, sort_keys=False)

    # ------------------------------------------------------------------
    # Condition evaluation
    # ------------------------------------------------------------------

    def _all_conditions_match(
        self, finding: Finding, conditions: List[PolicyCondition]
    ) -> bool:
        """Return True only if ALL conditions match (AND semantics)."""
        return all(
            self._matches_condition(finding, cond) for cond in conditions
        )

    def _matches_condition(self, finding: Finding, condition: PolicyCondition) -> bool:
        """
        Evaluate a single condition against a finding.

        Supported operators:
          eq       — field == value
          neq      — field != value
          gte      — field >= value  (numeric)
          lte      — field <= value  (numeric)
          in       — field in value  (value must be a list)
          contains — value in field  (string containment)
          matches  — re.search(value, field)  (regex)
        """
        field_val = self._get_field(finding, condition.field)
        op = condition.operator.lower()
        cmp_val = condition.value

        try:
            if op == "eq":
                # Case-insensitive for string fields
                if isinstance(field_val, str) and isinstance(cmp_val, str):
                    return field_val.upper() == cmp_val.upper()
                return field_val == cmp_val

            elif op == "neq":
                if isinstance(field_val, str) and isinstance(cmp_val, str):
                    return field_val.upper() != cmp_val.upper()
                return field_val != cmp_val

            elif op == "gte":
                return float(field_val) >= float(cmp_val)

            elif op == "lte":
                return float(field_val) <= float(cmp_val)

            elif op == "in":
                # value is a list; check if field_val is one of them
                if isinstance(cmp_val, list):
                    normalised = [
                        str(v).upper() if isinstance(v, str) else v
                        for v in cmp_val
                    ]
                    check = field_val.upper() if isinstance(field_val, str) else field_val
                    return check in normalised
                return field_val in cmp_val

            elif op == "contains":
                # check if cmp_val (substring) appears in field_val
                return str(cmp_val).lower() in str(field_val).lower()

            elif op == "matches":
                return bool(re.search(str(cmp_val), str(field_val), re.IGNORECASE))

            else:
                logger.warning("unknown policy operator '%s' — condition skipped", op)
                return False

        except (TypeError, ValueError) as exc:
            logger.warning(
                "condition evaluation error (field=%s op=%s value=%s): %s",
                condition.field, op, cmp_val, exc,
            )
            return False

    @staticmethod
    def _get_field(finding: Finding, field_name: str) -> Any:
        """Retrieve a named field from a Finding with sensible defaults."""
        field_map = {
            "severity": finding.severity,
            "cwe_id": finding.cwe_id,
            "confidence": finding.confidence,
            "rule_id": finding.rule_id,
            "description": finding.description,
            "file": finding.file,
            "line": finding.line,
        }
        if field_name in field_map:
            return field_map[field_name]
        # Fall back to model attribute access for extended fields
        return getattr(finding, field_name, "")

    # ------------------------------------------------------------------
    # Compliance checks
    # ------------------------------------------------------------------

    def _check_compliance(
        self, findings: List[Finding], violations: List[PolicyViolation]
    ) -> Dict[str, bool]:
        """
        Derive compliance pass/fail for each framework based on findings.

        Returns a dict: framework_name → is_compliant (True = compliant).
        """
        finding_cwes = {f.cwe_id for f in findings}
        finding_severities = {f.severity.upper() for f in findings}

        # PCI-DSS: non-compliant if CRITICAL/HIGH finding touches PCI scope
        pci_hit = (
            bool(_PCI_DSS_CWES & finding_cwes)
            and bool({"CRITICAL", "HIGH"} & finding_severities)
        )

        # GDPR: non-compliant if any finding touches GDPR-scoped CWEs
        gdpr_hit = bool(_GDPR_CWES & finding_cwes)

        # SOC2: non-compliant if any CRITICAL finding
        soc2_hit = "CRITICAL" in finding_severities

        # OWASP: per-category compliance
        owasp_status: Dict[str, bool] = {}
        for category, cwes in _OWASP_CATEGORY_CWES.items():
            owasp_status[category] = not bool(cwes & finding_cwes)

        # Aggregate: OWASP is compliant only if all categories pass
        owasp_compliant = all(owasp_status.values())

        return {
            "pci-dss": not pci_hit,
            "gdpr": not gdpr_hit,
            "soc2": not soc2_hit,
            "owasp": owasp_compliant,
            **{k: v for k, v in owasp_status.items()},
        }

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    @staticmethod
    def _build_summary(
        num_findings: int,
        violations: List[PolicyViolation],
        blocked: bool,
        total_blocks: int,
        total_warns: int,
        compliance_status: Dict[str, bool],
    ) -> str:
        reviews = sum(
            1 for v in violations if v.action == PolicyAction.REQUIRE_REVIEW
        )
        compliant_frameworks = [k for k, v in compliance_status.items() if v and "/" not in k]
        non_compliant = [k for k, v in compliance_status.items() if not v and "/" not in k]

        status_word = "BLOCKED" if blocked else "PASSED"
        parts = [
            f"Policy evaluation: {status_word}.",
            f"Findings evaluated: {num_findings}.",
            f"Violations: {len(violations)} total "
            f"({total_blocks} blocking, {total_warns} warnings, {reviews} require-review).",
        ]
        if non_compliant:
            parts.append(f"Non-compliant frameworks: {', '.join(non_compliant)}.")
        if compliant_frameworks:
            parts.append(f"Compliant frameworks: {', '.join(compliant_frameworks)}.")

        return "  ".join(parts)
