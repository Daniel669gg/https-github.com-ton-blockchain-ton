"""
backend/core/patterns.py — Unified security pattern registry.

Single source of truth for:
- Taint source patterns (per CWE, with confidence scores)
- Taint sink patterns (per CWE)
- Sanitizer patterns (per CWE)
- CWE → MITRE ATT&CK technique mapping
- CWE severity and OWASP category mapping

All other modules should import from here instead of defining their own patterns.
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# SOURCE_PATTERNS
# CWE → [(regex_str, confidence)]
# Sources are patterns that represent user-controlled or externally-sourced data.
# Confidence reflects how directly the data flows from an untrusted actor.
# ---------------------------------------------------------------------------

SOURCE_PATTERNS: Dict[str, List[Tuple[str, float]]] = {
    # SQL Injection — any externally-tainted input that ends up in DB calls
    "CWE-89": [
        (r"request\.args\b",                    0.95),
        (r"request\.form\b",                    0.95),
        (r"request\.json\b",                    0.95),
        (r"request\.get_json\s*\(",             0.95),
        (r"request\.files\b",                   0.85),
        (r"request\.headers\b",                 0.80),
        (r"request\.cookies\b",                 0.85),
        (r"request\.data\b",                    0.90),
        (r"request\.values\b",                  0.90),
        (r"\binput\s*\(",                        0.85),
        (r"\bsys\.argv\b",                       0.70),
        (r"os\.environ\b",                       0.60),
        (r"os\.getenv\s*\(",                     0.60),
        (r"\bfileinput\b",                       0.65),
        (r"sys\.stdin\.read\s*\(",              0.75),
        (r"click\.argument\b",                  0.70),
        (r"typer\.argument\b",                  0.70),
    ],
    # Cross-Site Scripting — user input reflected into HTML responses
    "CWE-79": [
        (r"request\.args\b",                    0.95),
        (r"request\.form\b",                    0.95),
        (r"request\.json\b",                    0.90),
        (r"request\.get_json\s*\(",             0.90),
        (r"request\.files\b",                   0.80),
        (r"request\.headers\b",                 0.75),
        (r"request\.cookies\b",                 0.80),
        (r"request\.data\b",                    0.88),
        (r"request\.values\b",                  0.88),
        (r"\binput\s*\(",                        0.80),
        (r"\bsys\.argv\b",                       0.65),
        (r"os\.environ\b",                       0.55),
        (r"os\.getenv\s*\(",                     0.55),
        (r"\bfileinput\b",                       0.60),
        (r"sys\.stdin\.read\s*\(",              0.70),
        (r"click\.argument\b",                  0.65),
        (r"typer\.argument\b",                  0.65),
    ],
    # Command Injection — any external input passed to shell execution
    "CWE-78": [
        (r"request\.args\b",                    0.95),
        (r"request\.form\b",                    0.95),
        (r"request\.json\b",                    0.90),
        (r"request\.get_json\s*\(",             0.90),
        (r"request\.files\b",                   0.85),
        (r"request\.headers\b",                 0.80),
        (r"request\.cookies\b",                 0.85),
        (r"request\.data\b",                    0.88),
        (r"request\.values\b",                  0.88),
        (r"\binput\s*\(",                        0.85),
        (r"\bsys\.argv\b",                       0.75),
        (r"os\.environ\b",                       0.65),
        (r"os\.getenv\s*\(",                     0.65),
        (r"\bfileinput\b",                       0.70),
        (r"sys\.stdin\.read\s*\(",              0.75),
        (r"click\.argument\b",                  0.72),
        (r"typer\.argument\b",                  0.72),
    ],
    # Path Traversal — user-controlled file path inputs
    "CWE-22": [
        (r"request\.args\b",                    0.95),
        (r"request\.form\b",                    0.95),
        (r"request\.json\b",                    0.90),
        (r"request\.get_json\s*\(",             0.90),
        (r"request\.files\b",                   0.88),
        (r"request\.headers\b",                 0.75),
        (r"request\.cookies\b",                 0.82),
        (r"request\.data\b",                    0.87),
        (r"request\.values\b",                  0.87),
        (r"\binput\s*\(",                        0.80),
        (r"\bsys\.argv\b",                       0.72),
        (r"os\.environ\b",                       0.60),
        (r"os\.getenv\s*\(",                     0.60),
        (r"\bfileinput\b",                       0.68),
        (r"sys\.stdin\.read\s*\(",              0.72),
        (r"click\.argument\b",                  0.68),
        (r"typer\.argument\b",                  0.68),
    ],
    # Hardcoded Credentials — secret embedded directly in source code
    "CWE-798": [
        (r"request\.args\b",                    0.30),
        (r"request\.form\b",                    0.30),
        (r"request\.json\b",                    0.30),
        (r"request\.get_json\s*\(",             0.30),
        (r"os\.environ\b",                       0.20),
        (r"os\.getenv\s*\(",                     0.20),
        (r"\binput\s*\(",                        0.40),
        (r"\bsys\.argv\b",                       0.35),
        (r"\bfileinput\b",                       0.25),
        (r"sys\.stdin\.read\s*\(",              0.30),
        (r"click\.argument\b",                  0.35),
        (r"typer\.argument\b",                  0.35),
    ],
    # SSRF — external URLs passed to outbound HTTP calls
    "CWE-918": [
        (r"request\.args\b",                    0.95),
        (r"request\.form\b",                    0.95),
        (r"request\.json\b",                    0.95),
        (r"request\.get_json\s*\(",             0.95),
        (r"request\.files\b",                   0.80),
        (r"request\.headers\b",                 0.82),
        (r"request\.cookies\b",                 0.85),
        (r"request\.data\b",                    0.92),
        (r"request\.values\b",                  0.92),
        (r"\binput\s*\(",                        0.85),
        (r"\bsys\.argv\b",                       0.72),
        (r"os\.environ\b",                       0.62),
        (r"os\.getenv\s*\(",                     0.62),
        (r"\bfileinput\b",                       0.65),
        (r"sys\.stdin\.read\s*\(",              0.75),
        (r"click\.argument\b",                  0.70),
        (r"typer\.argument\b",                  0.70),
    ],
    # Unsafe Deserialization — attacker-controlled serialized objects
    "CWE-502": [
        (r"request\.args\b",                    0.95),
        (r"request\.form\b",                    0.95),
        (r"request\.json\b",                    0.90),
        (r"request\.get_json\s*\(",             0.90),
        (r"request\.files\b",                   0.92),
        (r"request\.headers\b",                 0.85),
        (r"request\.cookies\b",                 0.90),
        (r"request\.data\b",                    0.95),
        (r"request\.values\b",                  0.92),
        (r"\binput\s*\(",                        0.80),
        (r"\bsys\.argv\b",                       0.70),
        (r"os\.environ\b",                       0.58),
        (r"os\.getenv\s*\(",                     0.58),
        (r"\bfileinput\b",                       0.65),
        (r"sys\.stdin\.read\s*\(",              0.78),
        (r"click\.argument\b",                  0.68),
        (r"typer\.argument\b",                  0.68),
    ],
    # Code Injection — user-supplied code passed to eval/exec
    "CWE-94": [
        (r"request\.args\b",                    0.95),
        (r"request\.form\b",                    0.95),
        (r"request\.json\b",                    0.95),
        (r"request\.get_json\s*\(",             0.95),
        (r"request\.files\b",                   0.85),
        (r"request\.headers\b",                 0.82),
        (r"request\.cookies\b",                 0.88),
        (r"request\.data\b",                    0.92),
        (r"request\.values\b",                  0.92),
        (r"\binput\s*\(",                        0.88),
        (r"\bsys\.argv\b",                       0.75),
        (r"os\.environ\b",                       0.65),
        (r"os\.getenv\s*\(",                     0.65),
        (r"\bfileinput\b",                       0.70),
        (r"sys\.stdin\.read\s*\(",              0.80),
        (r"click\.argument\b",                  0.72),
        (r"typer\.argument\b",                  0.72),
    ],
}

# ---------------------------------------------------------------------------
# SINK_PATTERNS
# CWE → [regex_str]
# Sink patterns identify dangerous function calls where tainted data would
# cause a vulnerability if it reaches there unsanitized.
# ---------------------------------------------------------------------------

SINK_PATTERNS: Dict[str, List[str]] = {
    # SQL Injection sinks: raw SQL execution and string concat patterns
    "CWE-89": [
        r"cursor\.execute\s*\(",
        r"\bdb\.execute\s*\(",
        r"\.raw\s*\(",
        r"session\.execute\s*\(",
        r"connection\.execute\s*\(",
        r"executemany\s*\(",
        r"\.execute\s*\([\"'][^\"']*\+",        # string concatenation in execute
        r"\.execute\s*\([\"'][^\"']*%\s*\w",    # %-interpolation in execute
        r"\.execute\s*\([^,)]+\+\s*\w",         # variable concat in execute
        r"\.query\s*\([\"'][^\"']*\+",           # string concat in query()
    ],
    # XSS sinks: HTML returned to browser without escaping
    "CWE-79": [
        r"return\s+.*<.*>.*\+",                  # return with HTML string concat
        r"render_template_string\s*\(",
        r"make_response\s*\(.*<",                # make_response with raw HTML
        r"Markup\s*\(\s*\w",                     # Markup() wrapping user variable
        r"Response\s*\([^,)]*\+",                # Response with string concat
        r"HttpResponse\s*\([^,)]*\+",
        r"innerHTML\s*=",
        r"document\.write\s*\(",
    ],
    # Command Injection sinks: OS shell execution with user data
    "CWE-78": [
        r"os\.system\s*\(",
        r"subprocess\.run\s*\(.*shell\s*=\s*True",
        r"subprocess\.Popen\s*\(.*shell\s*=\s*True",
        r"subprocess\.call\s*\(.*shell\s*=\s*True",
        r"subprocess\.check_output\s*\(.*shell\s*=\s*True",
        r"os\.popen\s*\(",
        r"commands\.getoutput\s*\(",
        r"commands\.getstatusoutput\s*\(",
        r"popen\s*\(",
    ],
    # Path Traversal sinks: file-system operations with user-controlled path
    "CWE-22": [
        r"\bopen\s*\(",
        r"pathlib\.Path\s*\(",
        r"send_file\s*\(",
        r"send_from_directory\s*\(",
        r"os\.path\.join\s*\(",
        r"shutil\.copy\s*\(",
        r"shutil\.move\s*\(",
        r"shutil\.rmtree\s*\(",
        r"os\.remove\s*\(",
        r"os\.unlink\s*\(",
        r"os\.makedirs\s*\(",
        r"os\.listdir\s*\(",
    ],
    # Hardcoded Credentials — assignment of literal secret values
    "CWE-798": [
        r"(?i)(password|passwd|pwd)\s*=\s*['\"][^'\"]{4,}['\"]",
        r"(?i)(secret|secret_key|api_secret)\s*=\s*['\"][^'\"]{8,}['\"]",
        r"(?i)(api_key|apikey|access_key)\s*=\s*['\"][^'\"]{8,}['\"]",
        r"(?i)(token|auth_token|bearer)\s*=\s*['\"][^'\"]{8,}['\"]",
        r"(?i)aws_access_key_id\s*=\s*['\"]AKIA[0-9A-Z]{16}['\"]",
        r"(?i)aws_secret_access_key\s*=\s*['\"][^'\"]{40}['\"]",
        r"-----BEGIN (RSA|EC|DSA|OPENSSH) PRIVATE KEY-----",
        r"ghp_[0-9A-Za-z]{36}",
        r"sk-[0-9A-Za-z]{48}",
    ],
    # SSRF — outbound HTTP calls with user-controlled URL
    "CWE-918": [
        r"requests\.get\s*\(",
        r"requests\.post\s*\(",
        r"requests\.put\s*\(",
        r"requests\.delete\s*\(",
        r"requests\.request\s*\(",
        r"urllib\.request\.urlopen\s*\(",
        r"urllib\.urlopen\s*\(",
        r"httpx\.get\s*\(",
        r"httpx\.post\s*\(",
        r"httpx\.request\s*\(",
        r"aiohttp\.ClientSession\s*\(",
        r"urlopen\s*\(",
    ],
    # Unsafe Deserialization — deserializing attacker-supplied bytes
    "CWE-502": [
        r"pickle\.loads\s*\(",
        r"pickle\.load\s*\(",
        r"yaml\.load\s*\(",
        r"marshal\.loads\s*\(",
        r"marshal\.load\s*\(",
        r"shelve\.open\s*\(",
        r"jsonpickle\.decode\s*\(",
        r"dill\.loads\s*\(",
        r"dill\.load\s*\(",
    ],
    # Code Injection — executing user-supplied code strings
    "CWE-94": [
        r"\beval\s*\(",
        r"\bexec\s*\(",
        r"render_template_string\s*\(",
        r"Template\s*\(\s*\w",                   # Jinja2/Mako Template() with variable
        r"\bcompile\s*\(",
        r"__import__\s*\(",
        r"importlib\.import_module\s*\(",
        r"execfile\s*\(",
    ],
}

# ---------------------------------------------------------------------------
# SANITIZER_PATTERNS
# CWE → [(compiled_re.Pattern, human_readable_name)]
# Merged from sanitization_checker.py, verification_agent.py, and verifier.py.
# ---------------------------------------------------------------------------

SANITIZER_PATTERNS: Dict[str, List[Tuple[re.Pattern, str]]] = {
    # SQL Injection — parameterized queries, ORM methods, placeholder patterns
    "CWE-89": [
        (re.compile(r"cursor\.execute\s*\([^,]+,\s*[\(\[\{]"),   "parameterized cursor.execute"),
        (re.compile(r"\$\d+|\?(?!\s*\))"),                        "positional query parameter"),
        (re.compile(r"session\.query\s*\("),                      "SQLAlchemy session.query ORM"),
        (re.compile(r"db\.session\.execute\s*\(\s*text\s*\("),    "SQLAlchemy text() with execute"),
        (re.compile(r"\.objects\.(filter|get|exclude|all)\s*\("), "Django ORM queryset"),
        (re.compile(r"(prepare|parameterize)\s*\("),              "prepare/parameterize call"),
        (re.compile(r"\.filter\s*\("),                            "ORM .filter() call"),
        (re.compile(r"execute\s*\([^)]*%s[^)]*,\s*\("),          "%-style parameterized query"),
        (re.compile(r"\bparamstyle\b"),                           "DB-API paramstyle"),
        (re.compile(r"\.execute\s*\(\s*[\"'][^\"']*%s"),          "format-placeholder execute"),
        (re.compile(r"\.execute\s*\(\s*[\"'][^\"']*\?"),          "?-placeholder execute"),
        (re.compile(r"SQLAlchemy|sqlalchemy"),                    "SQLAlchemy ORM"),
        (re.compile(r"django\.db|from django"),                   "Django ORM"),
        (re.compile(r"peewee\.|tortoise\."),                      "Peewee/Tortoise ORM"),
    ],
    # XSS — HTML encoding, escaping, safe wrappers, auto-escape environments
    "CWE-79": [
        (re.compile(r"html\.escape\s*\("),                        "html.escape()"),
        (re.compile(r"(?<!\w)escape\s*\("),                       "escape()"),
        (re.compile(r"markupsafe"),                               "MarkupSafe"),
        (re.compile(r"markupsafe\.escape"),                       "MarkupSafe.escape()"),
        (re.compile(r"bleach\.clean\s*\("),                       "bleach.clean()"),
        (re.compile(r"autoescape\s*=\s*True"),                    "Jinja2 autoescape=True"),
        (re.compile(r"flask\.escape\s*\("),                       "flask.escape()"),
        (re.compile(r"Markup\s*\("),                              "Markup() safe wrapper"),
        (re.compile(r"jinja2\.Environment.*autoescape"),          "Jinja2 autoescape env"),
        (re.compile(r"cgi\.escape\s*\("),                         "cgi.escape()"),
        (re.compile(r"DOMPurify\.sanitize"),                      "DOMPurify.sanitize()"),
        (re.compile(r"encodeURIComponent\s*\("),                  "encodeURIComponent()"),
        (re.compile(r"textContent\s*="),                          "DOM textContent (safe assignment)"),
    ],
    # Command Injection — argument list forms, shell quoting
    "CWE-78": [
        (re.compile(r"shlex\.quote\s*\("),                        "shlex.quote()"),
        (re.compile(r"subprocess\.(run|call|check_output|Popen)\s*\(\s*\["), "subprocess with list args"),
        (re.compile(r"shlex\.split\s*\("),                        "shlex.split()"),
        (re.compile(r"pipes\.quote\s*\("),                        "pipes.quote()"),
        (re.compile(r"shell\s*=\s*False"),                        "shell=False (safe)"),
    ],
    # Path Traversal — path normalization and containment checks
    "CWE-22": [
        (re.compile(r"os\.path\.abspath\s*\("),                   "os.path.abspath()"),
        (re.compile(r"os\.path\.realpath\s*\("),                  "os.path.realpath()"),
        (re.compile(r"\.resolve\s*\(\s*\)"),                      "pathlib Path.resolve()"),
        (re.compile(r"\.startswith\s*\("),                        ".startswith() base-path check"),
        (re.compile(r"os\.path\.commonpath\s*\("),                "os.path.commonpath()"),
        (re.compile(r"os\.path\.commonprefix\s*\("),              "os.path.commonprefix()"),
        (re.compile(r"Path\s*\([^)]*\)\.resolve\s*\("),           "pathlib resolve()"),
        (re.compile(r"\.resolve\(\)\.is_relative_to\s*\("),       "is_relative_to() check"),
        (re.compile(r"send_from_directory\s*\("),                 "Flask send_from_directory()"),
    ],
    # Hardcoded Credentials — env var retrieval instead of literal values
    "CWE-798": [
        (re.compile(r"os\.environ\.get\s*\("),                    "os.environ.get() (env var)"),
        (re.compile(r"os\.environ\["),                            "os.environ[] lookup"),
        (re.compile(r"getenv\s*\("),                              "getenv() call"),
        (re.compile(r"dotenv|python-decouple"),                   "dotenv/decouple config"),
        (re.compile(r"SecretStr\s*\("),                           "Pydantic SecretStr"),
        (re.compile(r"vault\.|hvac\."),                           "HashiCorp Vault client"),
    ],
    # Weak Cryptography — no runtime sanitization, always flag
    "CWE-327": [
        (re.compile(r"hashlib\.sha256\s*\("),                     "sha256 (strong hash)"),
        (re.compile(r"hashlib\.sha3_"),                           "sha3 (strong hash)"),
        (re.compile(r"hashlib\.sha512\s*\("),                     "sha512 (strong hash)"),
        (re.compile(r"hashlib\.blake2"),                          "blake2 (strong hash)"),
        (re.compile(r"bcrypt\."),                                 "bcrypt (password hash)"),
        (re.compile(r"argon2\."),                                 "argon2 (password hash)"),
        (re.compile(r"scrypt\s*\("),                              "scrypt KDF"),
        (re.compile(r"pbkdf2_hmac\s*\("),                         "pbkdf2_hmac KDF"),
    ],
    # Unsafe Deserialization — safe parsing alternatives
    "CWE-502": [
        (re.compile(r"json\.loads\s*\("),                         "json.loads() safe alternative"),
        (re.compile(r"ast\.literal_eval\s*\("),                   "ast.literal_eval() safe alternative"),
        (re.compile(r"json\.load\s*\("),                          "json.load() safe alternative"),
        (re.compile(r"msgpack\."),                                "msgpack (type-safe)"),
        (re.compile(r"hmac\.compare_digest"),                     "hmac.compare_digest"),
        (re.compile(r"itsdangerous\."),                           "itsdangerous (signed data)"),
        (re.compile(r"cryptography\."),                           "cryptography library"),
    ],
    # SSRF — URL validation and allowlist checks
    "CWE-918": [
        (re.compile(r"urllib\.parse\.urlparse\s*\("),             "urllib.parse.urlparse()"),
        (re.compile(r"allowlist|allow_list|whitelist"),           "URL allowlist check"),
        (re.compile(r"\.netloc\s*(==|in)\s*"),                   "netloc domain check"),
        (re.compile(r"ALLOWED_HOSTS|ALLOWED_URLS|SAFE_DOMAINS"),  "allowed hosts constant"),
        (re.compile(r"tldextract\."),                             "tldextract domain validation"),
        (re.compile(r"validators\.url\s*\("),                     "validators.url()"),
        (re.compile(r"ipaddress\."),                              "ipaddress module check"),
        (re.compile(r"socket\.getaddrinfo"),                      "socket.getaddrinfo"),
    ],
    # Code Injection — no runtime sanitization; flag always
    "CWE-94": [
        (re.compile(r"ast\.literal_eval\s*\("),                   "ast.literal_eval() safe eval"),
        (re.compile(r"json\.loads\s*\("),                         "json.loads() instead of eval"),
        (re.compile(r"jinja2\.sandbox\.SandboxedEnvironment"),    "Jinja2 sandboxed environment"),
        (re.compile(r"RestrictedPython"),                         "RestrictedPython sandbox"),
    ],
}

# ---------------------------------------------------------------------------
# CWE_META
# CWE → {owasp, severity, mitre_technique, mitre_tactic, cvss_base}
# ---------------------------------------------------------------------------

CWE_META: Dict[str, dict] = {
    "CWE-89": {
        "owasp":            "A03:2021 – Injection",
        "severity":         "CRITICAL",
        "mitre_technique":  "T1190",
        "mitre_tactic":     "Initial Access",
        "cvss_base":        9.8,
        "description":      "SQL Injection — untrusted data interpreted as SQL commands.",
    },
    "CWE-79": {
        "owasp":            "A03:2021 – Injection",
        "severity":         "HIGH",
        "mitre_technique":  "T1189",
        "mitre_tactic":     "Initial Access",
        "cvss_base":        8.8,
        "description":      "Cross-Site Scripting — untrusted data rendered as HTML/JS.",
    },
    "CWE-78": {
        "owasp":            "A03:2021 – Injection",
        "severity":         "CRITICAL",
        "mitre_technique":  "T1059",
        "mitre_tactic":     "Execution",
        "cvss_base":        9.8,
        "description":      "OS Command Injection — untrusted data passed to shell execution.",
    },
    "CWE-22": {
        "owasp":            "A01:2021 – Broken Access Control",
        "severity":         "HIGH",
        "mitre_technique":  "T1083",
        "mitre_tactic":     "Discovery",
        "cvss_base":        7.5,
        "description":      "Path Traversal — attacker traverses outside intended directory.",
    },
    "CWE-798": {
        "owasp":            "A07:2021 – Identification and Authentication Failures",
        "severity":         "HIGH",
        "mitre_technique":  "T1552",
        "mitre_tactic":     "Credential Access",
        "cvss_base":        7.5,
        "description":      "Hardcoded Credentials — secrets embedded in source code.",
    },
    "CWE-918": {
        "owasp":            "A10:2021 – Server-Side Request Forgery",
        "severity":         "HIGH",
        "mitre_technique":  "T1090",
        "mitre_tactic":     "Command and Control",
        "cvss_base":        8.6,
        "description":      "SSRF — attacker induces server to make requests to internal resources.",
    },
    "CWE-502": {
        "owasp":            "A08:2021 – Software and Data Integrity Failures",
        "severity":         "HIGH",
        "mitre_technique":  "T1059",
        "mitre_tactic":     "Execution",
        "cvss_base":        8.8,
        "description":      "Unsafe Deserialization — attacker-controlled data deserialized without validation.",
    },
    "CWE-94": {
        "owasp":            "A03:2021 – Injection",
        "severity":         "CRITICAL",
        "mitre_technique":  "T1059.006",
        "mitre_tactic":     "Execution",
        "cvss_base":        9.8,
        "description":      "Code Injection — attacker-supplied code executed by the interpreter.",
    },
    "CWE-327": {
        "owasp":            "A02:2021 – Cryptographic Failures",
        "severity":         "MEDIUM",
        "mitre_technique":  "T1600",
        "mitre_tactic":     "Defense Evasion",
        "cvss_base":        5.9,
        "description":      "Weak Cryptography — use of broken or weak cryptographic algorithm.",
    },
}

# ---------------------------------------------------------------------------
# Compiled pattern caches (lazy; populated on first access per CWE)
# ---------------------------------------------------------------------------

_COMPILED_SOURCES: Dict[str, List[Tuple[re.Pattern, float]]] = {}
_COMPILED_SINKS:   Dict[str, List[re.Pattern]] = {}


def _ensure_sources_compiled(cwe_id: str) -> None:
    if cwe_id not in _COMPILED_SOURCES:
        _COMPILED_SOURCES[cwe_id] = [
            (re.compile(pat), conf)
            for pat, conf in SOURCE_PATTERNS.get(cwe_id, [])
        ]


def _ensure_sinks_compiled(cwe_id: str) -> None:
    if cwe_id not in _COMPILED_SINKS:
        _COMPILED_SINKS[cwe_id] = [
            re.compile(pat)
            for pat in SINK_PATTERNS.get(cwe_id, [])
        ]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_sources(cwe_id: str) -> List[Tuple[re.Pattern, float]]:
    """Compile and return source patterns for the given CWE ID.

    Returns a list of (compiled_pattern, confidence_score) tuples, or an
    empty list if the CWE ID is not registered.
    """
    _ensure_sources_compiled(cwe_id)
    return _COMPILED_SOURCES.get(cwe_id, [])


def get_sinks(cwe_id: str) -> List[re.Pattern]:
    """Compile and return sink patterns for the given CWE ID.

    Returns a list of compiled regex patterns, or an empty list if the CWE
    ID is not registered.
    """
    _ensure_sinks_compiled(cwe_id)
    return _COMPILED_SINKS.get(cwe_id, [])


def get_sanitizers(cwe_id: str) -> List[Tuple[re.Pattern, str]]:
    """Return sanitizer patterns for the given CWE ID.

    Returns a list of (compiled_pattern, human_readable_name) tuples.
    An empty list means no sanitizers are registered (e.g. CWE-798, CWE-327
    where no sanitizer can make the code safe).
    """
    return SANITIZER_PATTERNS.get(cwe_id, [])


def get_cwe_meta(cwe_id: str) -> dict:
    """Return metadata dict for the given CWE ID.

    Returns an empty dict if the CWE ID is not registered.  Keys include:
    owasp, severity, mitre_technique, mitre_tactic, cvss_base, description.
    """
    return CWE_META.get(cwe_id, {})


def all_cwe_ids() -> List[str]:
    """Return all CWE IDs registered in this pattern registry."""
    return sorted(CWE_META.keys())


def classify_node_as_source(
    code: str,
    cwe_id: Optional[str] = None,
) -> Optional[Tuple[str, float]]:
    """Check whether *code* matches any registered taint source pattern.

    Parameters
    ----------
    code:
        The source-code snippet or node code to examine.
    cwe_id:
        If provided, only check patterns for this specific CWE.  If None,
        all registered CWEs are checked and the highest-confidence match
        is returned.

    Returns
    -------
    (matched_cwe_id, confidence) if a match is found, otherwise None.
    """
    if not code:
        return None

    cwe_ids_to_check = [cwe_id] if cwe_id else list(SOURCE_PATTERNS.keys())
    best: Optional[Tuple[str, float]] = None

    for cid in cwe_ids_to_check:
        _ensure_sources_compiled(cid)
        for pattern, confidence in _COMPILED_SOURCES.get(cid, []):
            if pattern.search(code):
                if best is None or confidence > best[1]:
                    best = (cid, confidence)
                # Short-circuit on maximum possible confidence
                if best[1] >= 0.95:
                    return best

    return best


def classify_node_as_sink(
    code: str,
    cwe_id: Optional[str] = None,
) -> Optional[str]:
    """Check whether *code* matches any registered taint sink pattern.

    Parameters
    ----------
    code:
        The source-code snippet or node code to examine.
    cwe_id:
        If provided, only check patterns for this specific CWE.  If None,
        all registered CWEs are checked in order.

    Returns
    -------
    The matched CWE ID string if found, otherwise None.
    """
    if not code:
        return None

    cwe_ids_to_check = [cwe_id] if cwe_id else list(SINK_PATTERNS.keys())

    for cid in cwe_ids_to_check:
        _ensure_sinks_compiled(cid)
        for pattern in _COMPILED_SINKS.get(cid, []):
            if pattern.search(code):
                return cid

    return None


def classify_node_as_sanitizer(
    code: str,
    cwe_id: str,
) -> Optional[str]:
    """Check whether *code* matches any registered sanitizer pattern for *cwe_id*.

    Returns the human-readable sanitizer name if a match is found, otherwise
    None.  An empty sanitizer list (e.g. for CWE-798) always returns None.
    """
    if not code:
        return None

    for pattern, name in SANITIZER_PATTERNS.get(cwe_id, []):
        if pattern.search(code):
            return name

    return None
