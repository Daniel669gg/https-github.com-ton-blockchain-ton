"""
backend/core/cpg/interprocedural.py — Interprocedural dataflow analysis.

Extends CPG with multi-hop taint propagation across function boundaries:
- DFG_FLOW edges (intra-procedural data flow, highest confidence)
- CG_CALL edges (argument → parameter binding)
- CG_RETURN edges (return value → call site)
- CFG_NEXT edges (control flow fallback)

Source → func1 → func2 → func3 → Sink: full chain preserved with evidence.
"""
from __future__ import annotations

import hashlib
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

from backend.core.cpg.graph import CodePropertyGraph, CPGEdgeType, CPGNode, CPGNodeType
from backend.core.patterns import (
    classify_node_as_sanitizer,
    classify_node_as_sink,
    classify_node_as_source,
    get_sanitizers,
    get_sinks,
    get_sources,
)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class TaintHop:
    """One step in an interprocedural taint chain."""
    hop_index: int
    node_id: str
    code: str
    file: str
    line: int
    hop_type: str          # "source","dfg_flow","call_arg","return_value","cfg_flow","sink"
    edge_type: str         # CPGEdgeType name
    confidence_at_hop: float
    is_sanitized: bool = False
    sanitizer_name: str = ""


@dataclass
class InterproceduralTaintPath:
    """Full source-to-sink taint path across function/file boundaries."""
    path_id: str
    cwe_id: str
    sink_type: str
    source_node_id: str
    source_code: str
    source_file: str
    source_line: int
    sink_node_id: str
    sink_code: str
    sink_file: str
    sink_line: int
    hops: List[TaintHop]
    total_hops: int
    cross_function_count: int
    cross_file_count: int
    total_confidence: float
    is_sanitized_on_path: bool
    sanitizers_found: List[str]
    propagation_evidence: str
    vulnerability_description: str


@dataclass
class InterproceduralAnalysisResult:
    """Full result of interprocedural analysis over one CPG."""
    taint_paths: List[InterproceduralTaintPath]
    total_paths_found: int
    cross_function_paths: int
    cross_file_paths: int
    high_confidence_paths: List[InterproceduralTaintPath]
    sanitized_paths: List[InterproceduralTaintPath]
    by_cwe: Dict[str, List[InterproceduralTaintPath]]
    analysis_duration_ms: float


# ---------------------------------------------------------------------------
# Confidence decay per hop type
# ---------------------------------------------------------------------------

_HOP_CONFIDENCE: Dict[str, float] = {
    "dfg_flow":     1.00,
    "call_arg":     0.95,
    "return_value": 0.90,
    "cfg_flow":     0.80,
    "alias":        0.85,
    "source":       1.00,
    "sink":         1.00,
}

_ALL_CWE_IDS = ["CWE-89", "CWE-79", "CWE-78", "CWE-22", "CWE-918", "CWE-502", "CWE-94"]

_EDGE_TO_HOP: Dict = {
    CPGEdgeType.DFG_FLOW:          ("dfg_flow",     _HOP_CONFIDENCE["dfg_flow"]),
    CPGEdgeType.CG_CALL:           ("call_arg",     _HOP_CONFIDENCE["call_arg"]),
    CPGEdgeType.CG_RETURN:         ("return_value", _HOP_CONFIDENCE["return_value"]),
    CPGEdgeType.CFG_NEXT:          ("cfg_flow",     _HOP_CONFIDENCE["cfg_flow"]),
    CPGEdgeType.CFG_BRANCH_TRUE:   ("cfg_flow",     _HOP_CONFIDENCE["cfg_flow"]),
    CPGEdgeType.CFG_BRANCH_FALSE:  ("cfg_flow",     _HOP_CONFIDENCE["cfg_flow"]),
}

# Edges that propagate taint
_TAINT_EDGE_TYPES = {
    CPGEdgeType.DFG_FLOW,
    CPGEdgeType.CG_CALL,
    CPGEdgeType.CG_RETURN,
    CPGEdgeType.CFG_NEXT,
    CPGEdgeType.CFG_BRANCH_TRUE,
    CPGEdgeType.CFG_BRANCH_FALSE,
}


class InterproceduralDataflow:
    """
    Interprocedural taint analysis using BFS over CPG edges.

    Priority: DFG_FLOW > CG_CALL > CG_RETURN > CFG_NEXT
    """

    MAX_DEPTH: int = 20
    MAX_PATHS_PER_SOURCE: int = 5

    def __init__(
        self,
        cpg: CodePropertyGraph,
        ssa: Optional[Any] = None,
    ) -> None:
        self._cpg = cpg
        self._ssa = ssa
        self._source_cache: Dict[str, List[CPGNode]] = {}
        self._sink_cache: Dict[str, List[CPGNode]] = {}

    def analyze(self) -> InterproceduralAnalysisResult:
        """Run full interprocedural analysis for all CWEs."""
        t0 = time.time()
        all_paths: List[InterproceduralTaintPath] = []

        for cwe_id in _ALL_CWE_IDS:
            paths = self.find_paths_for_cwe(cwe_id)
            all_paths.extend(paths)

        # Deduplicate by path_id
        seen: Set[str] = set()
        deduped: List[InterproceduralTaintPath] = []
        for p in all_paths:
            if p.path_id not in seen:
                seen.add(p.path_id)
                deduped.append(p)

        cross_fn = [p for p in deduped if p.cross_function_count > 0]
        cross_file = [p for p in deduped if p.cross_file_count > 0]
        high_conf = [p for p in deduped if p.total_confidence >= 0.7]
        sanitized = [p for p in deduped if p.is_sanitized_on_path]

        by_cwe: Dict[str, List[InterproceduralTaintPath]] = {}
        for p in deduped:
            by_cwe.setdefault(p.cwe_id, []).append(p)

        return InterproceduralAnalysisResult(
            taint_paths=deduped,
            total_paths_found=len(deduped),
            cross_function_paths=len(cross_fn),
            cross_file_paths=len(cross_file),
            high_confidence_paths=high_conf,
            sanitized_paths=sanitized,
            by_cwe=by_cwe,
            analysis_duration_ms=(time.time() - t0) * 1000,
        )

    def find_paths_for_cwe(self, cwe_id: str) -> List[InterproceduralTaintPath]:
        """Find all taint paths for a specific CWE."""
        sources = self._find_source_nodes(cwe_id)
        sinks = self._find_sink_nodes(cwe_id)
        if not sources or not sinks:
            return []

        sink_ids: Set[str] = {s.node_id for s in sinks}
        sink_map: Dict[str, CPGNode] = {s.node_id: s for s in sinks}

        all_paths: List[InterproceduralTaintPath] = []
        for source in sources:
            raw_paths = self._bfs_taint_propagation(source, sink_ids, cwe_id)
            for hop_chain in raw_paths[:self.MAX_PATHS_PER_SOURCE]:
                if not hop_chain:
                    continue
                sink_id = hop_chain[-1].node_id
                sink_node = sink_map.get(sink_id)
                if not sink_node:
                    continue
                sanitized, san_names = self._check_sanitization_on_path(hop_chain, cwe_id)
                confidence = self._compute_path_confidence(hop_chain)
                path = self._build_taint_path(
                    hop_chain, cwe_id, source, sink_node, san_names
                )
                all_paths.append(path)

        return all_paths

    def trace_from_node(
        self,
        source_node: CPGNode,
        cwe_id: str,
        max_depth: int = None,
    ) -> List[InterproceduralTaintPath]:
        """Trace taint from a specific CPG node."""
        sinks = self._find_sink_nodes(cwe_id)
        sink_ids = {s.node_id for s in sinks}
        sink_map = {s.node_id: s for s in sinks}

        raw_paths = self._bfs_taint_propagation(source_node, sink_ids, cwe_id)
        results = []
        for hops in raw_paths:
            if not hops:
                continue
            sink_id = hops[-1].node_id
            sink_node = sink_map.get(sink_id)
            if not sink_node:
                continue
            sanitized, san_names = self._check_sanitization_on_path(hops, cwe_id)
            path = self._build_taint_path(hops, cwe_id, source_node, sink_node, san_names)
            results.append(path)
        return results

    def _find_source_nodes(self, cwe_id: str) -> List[CPGNode]:
        if cwe_id in self._source_cache:
            return self._source_cache[cwe_id]

        sources: List[CPGNode] = []
        source_patterns = get_sources(cwe_id)

        for nid, node in self._cpg.nodes.items():
            if not node.code:
                continue
            # Check using patterns module
            result = classify_node_as_source(node.code, cwe_id)
            if result:
                sources.append(node)
                continue
            # Also check DFG_DEF nodes with taint source code
            if node.node_type == CPGNodeType.DFG_DEF:
                for pat, conf in source_patterns:
                    if pat.search(node.code):
                        sources.append(node)
                        break

        self._source_cache[cwe_id] = sources
        return sources

    def _find_sink_nodes(self, cwe_id: str) -> List[CPGNode]:
        if cwe_id in self._sink_cache:
            return self._sink_cache[cwe_id]

        sinks: List[CPGNode] = []
        sink_patterns = get_sinks(cwe_id)

        for nid, node in self._cpg.nodes.items():
            if not node.code:
                continue
            result = classify_node_as_sink(node.code, cwe_id)
            if result == cwe_id:
                sinks.append(node)
                continue
            for pat in sink_patterns:
                if pat.search(node.code):
                    sinks.append(node)
                    break

        self._sink_cache[cwe_id] = sinks
        return sinks

    def _bfs_taint_propagation(
        self,
        source: CPGNode,
        sink_ids: Set[str],
        cwe_id: str,
    ) -> List[List[TaintHop]]:
        """BFS from source through CPG following taint-propagating edges."""
        found_paths: List[List[TaintHop]] = []

        # State: (node_id, confidence, hops_list, visited_set)
        initial_hop = TaintHop(
            hop_index=0,
            node_id=source.node_id,
            code=source.code or "",
            file=source.file or "",
            line=source.line or 0,
            hop_type="source",
            edge_type="source",
            confidence_at_hop=1.0,
        )

        queue: deque = deque([(source.node_id, 1.0, [initial_hop], {source.node_id})])

        while queue and len(found_paths) < self.MAX_PATHS_PER_SOURCE:
            cur_id, cur_conf, cur_hops, visited = queue.popleft()

            if len(cur_hops) > self.MAX_DEPTH:
                continue

            if cur_id in sink_ids and len(cur_hops) > 1:
                found_paths.append(list(cur_hops))
                continue

            # Expand via all taint-propagating edge types
            # Use _adj directly since successors() returns nodes (not edges)
            for edge in self._cpg._adj.get(cur_id, []):
                if edge.edge_type not in _TAINT_EDGE_TYPES:
                    continue
                next_id = edge.dst_id
                if next_id in visited:
                    continue

                hop_type, decay = _EDGE_TO_HOP.get(edge.edge_type, ("cfg_flow", 0.80))
                new_conf = cur_conf * decay

                if new_conf < 0.1:
                    continue  # prune low-confidence paths

                next_node = self._cpg.nodes.get(next_id)
                if not next_node:
                    continue

                new_hop = TaintHop(
                    hop_index=len(cur_hops),
                    node_id=next_id,
                    code=next_node.code or "",
                    file=next_node.file or "",
                    line=next_node.line or 0,
                    hop_type="sink" if next_id in sink_ids else hop_type,
                    edge_type=edge.edge_type.name if hasattr(edge.edge_type, 'name') else str(edge.edge_type),
                    confidence_at_hop=new_conf,
                )

                new_visited = visited | {next_id}
                queue.append((next_id, new_conf, cur_hops + [new_hop], new_visited))

        return found_paths

    def _check_sanitization_on_path(
        self, hops: List[TaintHop], cwe_id: str
    ) -> Tuple[bool, List[str]]:
        """Check if any sanitizer for cwe_id appears on the path hops."""
        sanitizers_found: List[str] = []
        san_patterns = get_sanitizers(cwe_id)

        for hop in hops:
            if not hop.code:
                continue
            for pat, name in san_patterns:
                if pat.search(hop.code):
                    sanitizers_found.append(name)

        return bool(sanitizers_found), sanitizers_found

    def _compute_path_confidence(self, hops: List[TaintHop]) -> float:
        """
        Compute total path confidence:
        - Product of per-hop decay factors
        - Bonus if DFG_FLOW edges dominate
        - Penalty for long paths
        """
        if not hops:
            return 0.0

        conf = hops[-1].confidence_at_hop

        # Bonus for DFG-heavy paths
        dfg_count = sum(1 for h in hops if h.hop_type == "dfg_flow")
        if dfg_count > len(hops) * 0.5:
            conf = min(1.0, conf + 0.05)

        # Count function boundary crossings (file changes in hops)
        files = [h.file for h in hops if h.file]
        file_changes = sum(1 for i in range(1, len(files)) if files[i] != files[i - 1])
        conf = max(0.1, conf - file_changes * 0.03)

        return round(min(1.0, max(0.0, conf)), 3)

    def _build_taint_path(
        self,
        hops: List[TaintHop],
        cwe_id: str,
        source: CPGNode,
        sink: CPGNode,
        sanitizers: List[str],
    ) -> InterproceduralTaintPath:
        """Assemble InterproceduralTaintPath from raw hop data."""
        # Count cross-function and cross-file hops
        files = [h.file for h in hops if h.file]
        file_changes = sum(1 for i in range(1, len(files)) if files[i] != files[i - 1])

        fn_changes = sum(
            1 for h in hops
            if h.hop_type in ("call_arg", "return_value")
        )

        confidence = self._compute_path_confidence(hops)
        is_sanitized = bool(sanitizers)

        # Build path_id from source+sink
        raw = f"{cwe_id}:{source.node_id}:{sink.node_id}"
        path_id = hashlib.md5(raw.encode()).hexdigest()[:16]

        evidence = self._build_evidence_string(hops)

        cwe_descs = {
            "CWE-89": "SQL injection: user input flows into SQL query without parameterization",
            "CWE-79": "XSS: user input flows into HTML output without escaping",
            "CWE-78": "Command injection: user input flows into OS command execution",
            "CWE-22": "Path traversal: user input flows into file system path",
            "CWE-918": "SSRF: user input flows into outbound HTTP request URL",
            "CWE-502": "Unsafe deserialization: external data flows into deserializer",
            "CWE-94": "Code injection: user input flows into code execution sink",
        }

        return InterproceduralTaintPath(
            path_id=path_id,
            cwe_id=cwe_id,
            sink_type=cwe_id,
            source_node_id=source.node_id,
            source_code=source.code or "",
            source_file=source.file or "",
            source_line=source.line or 0,
            sink_node_id=sink.node_id,
            sink_code=sink.code or "",
            sink_file=sink.file or "",
            sink_line=sink.line or 0,
            hops=hops,
            total_hops=len(hops),
            cross_function_count=fn_changes,
            cross_file_count=file_changes,
            total_confidence=confidence,
            is_sanitized_on_path=is_sanitized,
            sanitizers_found=sanitizers,
            propagation_evidence=evidence,
            vulnerability_description=cwe_descs.get(cwe_id, cwe_id),
        )

    def _build_evidence_string(self, hops: List[TaintHop]) -> str:
        """Human-readable propagation evidence."""
        if not hops:
            return "No propagation path found."
        parts = []
        for hop in hops:
            loc = f"{hop.file}:{hop.line}" if hop.file else f"line {hop.line}"
            snippet = (hop.code[:60] + "...") if len(hop.code) > 60 else hop.code
            parts.append(f"[{hop.hop_type}@{loc}] {snippet}")
        return " → ".join(parts[:10])
