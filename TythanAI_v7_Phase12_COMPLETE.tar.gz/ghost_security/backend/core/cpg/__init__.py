"""
backend/core/cpg — Code Property Graph engine for TythanAI.

Exports the primary public API for building and querying CPGs.
"""

from .graph import (
    CPGEdge,
    CPGEdgeType,
    CPGNode,
    CPGNodeType,
    CodePropertyGraph,
)
from .builder import CPGBuilder
from .query_engine import CPGQueryEngine, TaintPath
from .repo_analyzer import RepoAnalyzer, RepoAnalysisResult

__all__ = [
    # Graph primitives
    "CodePropertyGraph",
    "CPGNode",
    "CPGEdge",
    "CPGNodeType",
    "CPGEdgeType",
    # Construction
    "CPGBuilder",
    # Querying
    "CPGQueryEngine",
    "TaintPath",
    # Repository-level
    "RepoAnalyzer",
    "RepoAnalysisResult",
]
