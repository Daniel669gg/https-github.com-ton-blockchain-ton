"""
backend/core/cpg/builder.py — Build a CPG from Python source code.

Uses Python's built-in `ast` module to extract:
  1. AST structure (parent-child edges)
  2. CFG (sequential + branch edges between basic blocks)
  3. DFG (def-use chains via variable assignment/usage tracking)
  4. Call graph edges (function definition + call resolution)

The result is a CodePropertyGraph instance that unifies all layers.
"""

from __future__ import annotations

import ast
import hashlib
import os
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

from .graph import (
    CPGEdge,
    CPGEdgeType,
    CPGNode,
    CPGNodeType,
    CodePropertyGraph,
)


# ---------------------------------------------------------------------------
# Small helper data-classes used during construction
# ---------------------------------------------------------------------------

@dataclass
class FuncDef:
    """Records a function definition found during the CG pass."""
    name:    str
    node_id: str
    params:  List[str]
    file:    str
    line:    int


@dataclass
class CallSite:
    """Records a function call site found during the CG pass."""
    callee_name: str
    node_id:     str
    file:        str
    line:        int


@dataclass
class BasicBlock:
    """A run of statements with no internal branching."""
    block_id:   str
    stmts:      List[ast.AST] = field(default_factory=list)
    successors: List[Tuple[str, CPGEdgeType]] = field(default_factory=list)
    is_entry:   bool = False
    is_exit:    bool = False


# ---------------------------------------------------------------------------
# Definition / use tracking for DFG
# ---------------------------------------------------------------------------

@dataclass
class VarState:
    """The current 'live' definition node-IDs for a variable name."""
    name:    str
    def_ids: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# CPGBuilder
# ---------------------------------------------------------------------------

class CPGBuilder:
    """
    Converts a Python source file into a unified Code Property Graph.

    Usage::

        builder = CPGBuilder()
        cpg = builder.build_file("/path/to/module.py")
    """

    def __init__(self) -> None:
        self._edge_counter: int = 0

    # ------------------------------------------------------------------
    # Public entry points
    # ------------------------------------------------------------------

    def build_file(self, file_path: str) -> CodePropertyGraph:
        """Parse *file_path* and return its CPG."""
        with open(file_path, "r", encoding="utf-8", errors="replace") as fh:
            source = fh.read()
        return self.build_source(source, file_path=os.path.abspath(file_path))

    def build_source(
        self,
        source: str,
        file_path: str = "<string>",
    ) -> CodePropertyGraph:
        """Parse *source* string and return its CPG tagged with *file_path*."""
        try:
            tree = ast.parse(source, filename=file_path)
        except SyntaxError as exc:
            # Return an empty graph rather than crashing the whole analysis.
            cpg = CodePropertyGraph()
            err_node = CPGNode(
                node_id=self._node_id(file_path, 0, 0, "parse_error"),
                node_type=CPGNodeType.AST_NODE,
                ast_type="ParseError",
                code=str(exc),
                file=file_path,
                line=0,
                col=0,
                properties={"error": str(exc)},
            )
            cpg.add_node(err_node)
            return cpg

        cpg = CodePropertyGraph()

        # Annotate every AST node with its parent so we can walk back up.
        for node in ast.walk(tree):
            for child in ast.iter_child_nodes(node):
                child._parent = node  # type: ignore[attr-defined]
        tree._parent = None  # type: ignore[attr-defined]

        self._build_ast_layer(tree, cpg, file_path)
        self._build_cfg_layer(tree, cpg, file_path)
        self._build_dfg_layer(tree, cpg, file_path)
        self._build_cg_layer(tree, cpg, file_path)

        return cpg

    # ------------------------------------------------------------------
    # ID generator
    # ------------------------------------------------------------------

    def _node_id(
        self,
        file: str,
        line: int,
        col: int,
        suffix: str = "",
    ) -> str:
        """
        Produce a stable, deterministic node ID.

        Format: sha8(file):line:col[:suffix]
        """
        file_hash = hashlib.sha256(file.encode()).hexdigest()[:8]
        parts = [file_hash, str(line), str(col)]
        if suffix:
            parts.append(suffix)
        return ":".join(parts)

    def _edge_id(self) -> str:
        self._edge_counter += 1
        return f"e{self._edge_counter}"

    # ------------------------------------------------------------------
    # Layer 1 — AST
    # ------------------------------------------------------------------

    def _build_ast_layer(
        self,
        tree: ast.AST,
        cpg: CodePropertyGraph,
        file_path: str,
    ) -> None:
        """
        Walk the AST and add one CPGNode per AST node, plus
        AST_CHILD / AST_PARENT edges between them.
        """

        def _code_snippet(node: ast.AST) -> str:
            """Best-effort single-line code representation."""
            try:
                return ast.unparse(node)
            except Exception:
                return type(node).__name__

        def _node_type_for_ast(node: ast.AST) -> CPGNodeType:
            if isinstance(node, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
                return CPGNodeType.DFG_DEF
            if isinstance(node, ast.Call):
                return CPGNodeType.CG_CALL
            if isinstance(node, ast.Return):
                return CPGNodeType.CG_RETURN
            return CPGNodeType.AST_NODE

        def _extra_props(node: ast.AST) -> Dict[str, Any]:
            props: Dict[str, Any] = {}
            if isinstance(node, ast.FunctionDef):
                props["func_name"] = node.name
            elif isinstance(node, ast.AsyncFunctionDef):
                props["func_name"] = node.name
            elif isinstance(node, ast.ClassDef):
                props["class_name"] = node.name
            elif isinstance(node, ast.Name):
                props["var_name"] = node.id
                props["ctx"] = type(node.ctx).__name__
            elif isinstance(node, ast.Constant):
                props["value"] = repr(node.value)
            elif isinstance(node, ast.Call):
                try:
                    props["callee"] = ast.unparse(node.func)
                except Exception:
                    props["callee"] = ""
            return props

        # Walk the tree and build nodes
        for ast_node in ast.walk(tree):
            line = getattr(ast_node, "lineno", 0)
            col  = getattr(ast_node, "col_offset", 0)
            nid  = self._node_id(file_path, line, col, type(ast_node).__name__)

            props = _extra_props(ast_node)
            props["ast_node_ref"] = id(ast_node)  # for later cross-referencing

            cpg_node = CPGNode(
                node_id=nid,
                node_type=_node_type_for_ast(ast_node),
                ast_type=type(ast_node).__name__,
                code=_code_snippet(ast_node),
                file=file_path,
                line=line,
                col=col,
                properties=props,
            )
            cpg.add_node(cpg_node)

            # Parent edge
            parent = getattr(ast_node, "_parent", None)
            if parent is not None:
                p_line = getattr(parent, "lineno", 0)
                p_col  = getattr(parent, "col_offset", 0)
                p_nid  = self._node_id(
                    file_path, p_line, p_col, type(parent).__name__
                )
                if p_nid in cpg.nodes:
                    # child → parent
                    cpg.add_edge(CPGEdge(
                        edge_id=self._edge_id(),
                        src_id=p_nid,
                        dst_id=nid,
                        edge_type=CPGEdgeType.AST_CHILD,
                    ))
                    cpg.add_edge(CPGEdge(
                        edge_id=self._edge_id(),
                        src_id=nid,
                        dst_id=p_nid,
                        edge_type=CPGEdgeType.AST_PARENT,
                    ))

    # ------------------------------------------------------------------
    # Layer 2 — CFG
    # ------------------------------------------------------------------

    def _build_cfg_layer(
        self,
        tree: ast.AST,
        cpg: CodePropertyGraph,
        file_path: str,
    ) -> None:
        """
        Build intra-procedural CFG for each function definition
        (and the module-level body).

        For each function / module body we:
          1. Partition statements into basic blocks.
          2. Connect blocks with CFG_NEXT / CFG_BRANCH_TRUE / CFG_BRANCH_FALSE.
          3. Add synthetic CFG_ENTRY and CFG_EXIT nodes.
        """
        # Gather function defs + the module body treated as "__module__"
        regions: List[Tuple[str, List[ast.stmt], int]] = []

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                regions.append(
                    (node.name, node.body, getattr(node, "lineno", 0))
                )

        # Module-level body
        if isinstance(tree, ast.Module) and tree.body:
            regions.append(("__module__", tree.body, 0))

        for func_name, body, func_line in regions:
            self._build_function_cfg(
                func_name, body, func_line, cpg, file_path
            )

    def _build_function_cfg(
        self,
        func_name: str,
        body: List[ast.stmt],
        func_line: int,
        cpg: CodePropertyGraph,
        file_path: str,
    ) -> None:
        """Build the CFG for one function body."""
        if not body:
            return

        entry_id = self._node_id(
            file_path, func_line, 0, f"CFG_ENTRY_{func_name}"
        )
        exit_id = self._node_id(
            file_path, func_line, 0, f"CFG_EXIT_{func_name}"
        )

        entry_node = CPGNode(
            node_id=entry_id,
            node_type=CPGNodeType.CFG_ENTRY,
            ast_type="CFG_ENTRY",
            code=f"ENTRY:{func_name}",
            file=file_path,
            line=func_line,
            col=0,
            properties={"function": func_name},
        )
        exit_node = CPGNode(
            node_id=exit_id,
            node_type=CPGNodeType.CFG_EXIT,
            ast_type="CFG_EXIT",
            code=f"EXIT:{func_name}",
            file=file_path,
            line=func_line,
            col=0,
            properties={"function": func_name},
        )
        cpg.add_node(entry_node)
        cpg.add_node(exit_node)

        # Update all AST nodes in this function with the function name
        for stmt in ast.walk(ast.Module(body=body, type_ignores=[])):
            line = getattr(stmt, "lineno", 0)
            col  = getattr(stmt, "col_offset", 0)
            nid  = self._node_id(file_path, line, col, type(stmt).__name__)
            if nid in cpg.nodes:
                cpg.nodes[nid].properties["function"] = func_name

        # Partition into basic blocks
        blocks = self._partition_into_blocks(
            body, func_name, file_path, cpg
        )

        if not blocks:
            return

        # Connect ENTRY → first block
        first_block_node_id = self._stmt_node_id(body[0], file_path)
        if first_block_node_id in cpg.nodes:
            cpg.add_edge(CPGEdge(
                edge_id=self._edge_id(),
                src_id=entry_id,
                dst_id=first_block_node_id,
                edge_type=CPGEdgeType.CFG_NEXT,
            ))

        # Wire blocks
        for block in blocks:
            self._wire_block(block, exit_id, cpg, file_path, func_name)

    def _stmt_node_id(self, stmt: ast.AST, file_path: str) -> str:
        line = getattr(stmt, "lineno", 0)
        col  = getattr(stmt, "col_offset", 0)
        return self._node_id(file_path, line, col, type(stmt).__name__)

    def _partition_into_blocks(
        self,
        stmts: List[ast.stmt],
        func_name: str,
        file_path: str,
        cpg: CodePropertyGraph,
    ) -> List[BasicBlock]:
        """
        Split a statement list into BasicBlock objects.
        Each statement that ends a block (if/for/while/try/with/return) starts a new block.
        """
        blocks: List[BasicBlock] = []
        current_stmts: List[ast.stmt] = []

        def flush() -> Optional[BasicBlock]:
            if not current_stmts:
                return None
            # Use the first statement as the block's representative node
            first = current_stmts[0]
            bid   = self._stmt_node_id(first, file_path)
            blk   = BasicBlock(block_id=bid, stmts=list(current_stmts))
            blocks.append(blk)
            current_stmts.clear()
            return blk

        branch_stmts = (
            ast.If,
            ast.For,
            ast.AsyncFor,
            ast.While,
            ast.Try,
            ast.With,
            ast.AsyncWith,
            ast.Return,
            ast.Raise,
            ast.Break,
            ast.Continue,
        )

        for stmt in stmts:
            current_stmts.append(stmt)
            if isinstance(stmt, branch_stmts):
                flush()

        flush()  # trailing statements
        return blocks

    def _wire_block(
        self,
        block: BasicBlock,
        exit_id: str,
        cpg: CodePropertyGraph,
        file_path: str,
        func_name: str,
    ) -> None:
        """Add CFG edges FROM the block's representative node."""
        if not block.stmts:
            return

        last_stmt = block.stmts[-1]
        last_nid  = self._stmt_node_id(last_stmt, file_path)

        # ------------------------------------------------------------------
        # Connect sequential statements WITHIN the block
        # ------------------------------------------------------------------
        for i in range(len(block.stmts) - 1):
            s_nid = self._stmt_node_id(block.stmts[i], file_path)
            t_nid = self._stmt_node_id(block.stmts[i + 1], file_path)
            if s_nid in cpg.nodes and t_nid in cpg.nodes:
                if not any(
                    e.dst_id == t_nid and e.edge_type == CPGEdgeType.CFG_NEXT
                    for e in cpg._adj.get(s_nid, [])
                ):
                    cpg.add_edge(CPGEdge(
                        edge_id=self._edge_id(),
                        src_id=s_nid,
                        dst_id=t_nid,
                        edge_type=CPGEdgeType.CFG_NEXT,
                    ))

        # ------------------------------------------------------------------
        # Handle the branching statement at the end of the block
        # ------------------------------------------------------------------
        if isinstance(last_stmt, ast.If):
            self._wire_if(last_stmt, last_nid, exit_id, cpg, file_path, func_name)

        elif isinstance(last_stmt, (ast.For, ast.AsyncFor)):
            self._wire_for(last_stmt, last_nid, exit_id, cpg, file_path, func_name)

        elif isinstance(last_stmt, ast.While):
            self._wire_while(last_stmt, last_nid, exit_id, cpg, file_path, func_name)

        elif isinstance(last_stmt, (ast.Try,)):
            self._wire_try(last_stmt, last_nid, exit_id, cpg, file_path, func_name)

        elif isinstance(last_stmt, (ast.With, ast.AsyncWith)):
            self._wire_with(last_stmt, last_nid, exit_id, cpg, file_path, func_name)

        elif isinstance(last_stmt, (ast.Return, ast.Raise)):
            if last_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=last_nid,
                    dst_id=exit_id,
                    edge_type=CPGEdgeType.CFG_NEXT,
                ))

    def _wire_if(
        self,
        node: ast.If,
        nid: str,
        exit_id: str,
        cpg: CodePropertyGraph,
        file_path: str,
        func_name: str,
    ) -> None:
        """Wire if/elif/else branches."""
        if nid not in cpg.nodes:
            return

        # True branch — first statement of body
        if node.body:
            true_nid = self._stmt_node_id(node.body[0], file_path)
            if true_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=nid,
                    dst_id=true_nid,
                    edge_type=CPGEdgeType.CFG_BRANCH_TRUE,
                ))
            # Recursively wire body
            body_blocks = self._partition_into_blocks(
                node.body, func_name, file_path, cpg
            )
            for blk in body_blocks:
                self._wire_block(blk, exit_id, cpg, file_path, func_name)
            # Last body statement → exit (fall-through)
            last_body_nid = self._stmt_node_id(node.body[-1], file_path)
            if last_body_nid in cpg.nodes and last_body_nid != exit_id:
                if not isinstance(node.body[-1], (ast.Return, ast.Raise)):
                    cpg.add_edge(CPGEdge(
                        edge_id=self._edge_id(),
                        src_id=last_body_nid,
                        dst_id=exit_id,
                        edge_type=CPGEdgeType.CFG_NEXT,
                    ))

        # False / orelse branch
        if node.orelse:
            false_nid = self._stmt_node_id(node.orelse[0], file_path)
            if false_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=nid,
                    dst_id=false_nid,
                    edge_type=CPGEdgeType.CFG_BRANCH_FALSE,
                ))
            orelse_blocks = self._partition_into_blocks(
                node.orelse, func_name, file_path, cpg
            )
            for blk in orelse_blocks:
                self._wire_block(blk, exit_id, cpg, file_path, func_name)
            last_orelse_nid = self._stmt_node_id(node.orelse[-1], file_path)
            if last_orelse_nid in cpg.nodes and last_orelse_nid != exit_id:
                if not isinstance(node.orelse[-1], (ast.Return, ast.Raise)):
                    cpg.add_edge(CPGEdge(
                        edge_id=self._edge_id(),
                        src_id=last_orelse_nid,
                        dst_id=exit_id,
                        edge_type=CPGEdgeType.CFG_NEXT,
                    ))
        else:
            # No else → if-condition falls through directly to exit
            cpg.add_edge(CPGEdge(
                edge_id=self._edge_id(),
                src_id=nid,
                dst_id=exit_id,
                edge_type=CPGEdgeType.CFG_BRANCH_FALSE,
            ))

    def _wire_for(
        self,
        node: ast.For,
        nid: str,
        exit_id: str,
        cpg: CodePropertyGraph,
        file_path: str,
        func_name: str,
    ) -> None:
        """Wire for-loop body with back-edge."""
        if nid not in cpg.nodes:
            return

        if node.body:
            body_nid = self._stmt_node_id(node.body[0], file_path)
            if body_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=nid,
                    dst_id=body_nid,
                    edge_type=CPGEdgeType.CFG_BRANCH_TRUE,
                ))
            body_blocks = self._partition_into_blocks(
                node.body, func_name, file_path, cpg
            )
            for blk in body_blocks:
                self._wire_block(blk, exit_id, cpg, file_path, func_name)
            # Back-edge: last body statement → loop header
            last_body_nid = self._stmt_node_id(node.body[-1], file_path)
            if last_body_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=last_body_nid,
                    dst_id=nid,
                    edge_type=CPGEdgeType.CFG_NEXT,
                ))

        # Loop exits (loop terminates or else clause)
        if node.orelse:
            else_nid = self._stmt_node_id(node.orelse[0], file_path)
            if else_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=nid,
                    dst_id=else_nid,
                    edge_type=CPGEdgeType.CFG_BRANCH_FALSE,
                ))
        else:
            cpg.add_edge(CPGEdge(
                edge_id=self._edge_id(),
                src_id=nid,
                dst_id=exit_id,
                edge_type=CPGEdgeType.CFG_BRANCH_FALSE,
            ))

    def _wire_while(
        self,
        node: ast.While,
        nid: str,
        exit_id: str,
        cpg: CodePropertyGraph,
        file_path: str,
        func_name: str,
    ) -> None:
        """Wire while-loop body with back-edge."""
        if nid not in cpg.nodes:
            return

        if node.body:
            body_nid = self._stmt_node_id(node.body[0], file_path)
            if body_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=nid,
                    dst_id=body_nid,
                    edge_type=CPGEdgeType.CFG_BRANCH_TRUE,
                ))
            body_blocks = self._partition_into_blocks(
                node.body, func_name, file_path, cpg
            )
            for blk in body_blocks:
                self._wire_block(blk, exit_id, cpg, file_path, func_name)
            last_body_nid = self._stmt_node_id(node.body[-1], file_path)
            if last_body_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=last_body_nid,
                    dst_id=nid,
                    edge_type=CPGEdgeType.CFG_NEXT,
                ))

        cpg.add_edge(CPGEdge(
            edge_id=self._edge_id(),
            src_id=nid,
            dst_id=exit_id,
            edge_type=CPGEdgeType.CFG_BRANCH_FALSE,
        ))

    def _wire_try(
        self,
        node: ast.Try,
        nid: str,
        exit_id: str,
        cpg: CodePropertyGraph,
        file_path: str,
        func_name: str,
    ) -> None:
        """Wire try/except/else/finally blocks."""
        if nid not in cpg.nodes:
            return

        # try body → first statement
        if node.body:
            try_nid = self._stmt_node_id(node.body[0], file_path)
            if try_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=nid,
                    dst_id=try_nid,
                    edge_type=CPGEdgeType.CFG_BRANCH_TRUE,
                ))
            body_blocks = self._partition_into_blocks(
                node.body, func_name, file_path, cpg
            )
            for blk in body_blocks:
                self._wire_block(blk, exit_id, cpg, file_path, func_name)

        # handlers
        for handler in node.handlers:
            handler_stmts = handler.body
            if handler_stmts:
                h_nid = self._stmt_node_id(handler_stmts[0], file_path)
                if h_nid in cpg.nodes:
                    cpg.add_edge(CPGEdge(
                        edge_id=self._edge_id(),
                        src_id=nid,
                        dst_id=h_nid,
                        edge_type=CPGEdgeType.CFG_BRANCH_FALSE,
                    ))
                handler_blocks = self._partition_into_blocks(
                    handler_stmts, func_name, file_path, cpg
                )
                for blk in handler_blocks:
                    self._wire_block(blk, exit_id, cpg, file_path, func_name)

        # finalbody
        if node.finalbody:
            fin_nid = self._stmt_node_id(node.finalbody[0], file_path)
            if fin_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=nid,
                    dst_id=fin_nid,
                    edge_type=CPGEdgeType.CFG_NEXT,
                ))

    def _wire_with(
        self,
        node: ast.With,
        nid: str,
        exit_id: str,
        cpg: CodePropertyGraph,
        file_path: str,
        func_name: str,
    ) -> None:
        """Wire with-block body."""
        if nid not in cpg.nodes:
            return

        if node.body:
            body_nid = self._stmt_node_id(node.body[0], file_path)
            if body_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=nid,
                    dst_id=body_nid,
                    edge_type=CPGEdgeType.CFG_NEXT,
                ))
            body_blocks = self._partition_into_blocks(
                node.body, func_name, file_path, cpg
            )
            for blk in body_blocks:
                self._wire_block(blk, exit_id, cpg, file_path, func_name)
            last_nid = self._stmt_node_id(node.body[-1], file_path)
            if last_nid in cpg.nodes:
                cpg.add_edge(CPGEdge(
                    edge_id=self._edge_id(),
                    src_id=last_nid,
                    dst_id=exit_id,
                    edge_type=CPGEdgeType.CFG_NEXT,
                ))

    # ------------------------------------------------------------------
    # Layer 3 — DFG (def-use chains)
    # ------------------------------------------------------------------

    def _build_dfg_layer(
        self,
        tree: ast.AST,
        cpg: CodePropertyGraph,
        file_path: str,
    ) -> None:
        """
        Build intra-procedural data-flow edges.

        For each function (and module level) we perform a linear scan
        collecting definition sites and use sites for each variable name,
        then wire DFG_FLOW edges from each def to subsequent uses.
        """

        def _scan_scope(stmts: List[ast.stmt], scope_name: str) -> None:
            # Mapping: var_name → list of def node-ids (most recent first)
            defs: Dict[str, List[str]] = defaultdict(list)

            def _register_def(name: str, stmt: ast.AST) -> None:
                nid = self._stmt_node_id(stmt, file_path)
                if nid in cpg.nodes:
                    cpg.nodes[nid].node_type = CPGNodeType.DFG_DEF
                    cpg.nodes[nid].properties["defines"] = name
                    defs[name].append(nid)

            def _register_use(name: str, node: ast.AST) -> None:
                nid = self._stmt_node_id(node, file_path)
                if nid not in cpg.nodes:
                    return
                cpg.nodes[nid].properties.setdefault("uses", []).append(name)

                for def_nid in defs.get(name, []):
                    # Add DFG_FLOW edge def → use
                    already = any(
                        e.dst_id == nid and e.edge_type == CPGEdgeType.DFG_FLOW
                        for e in cpg._adj.get(def_nid, [])
                    )
                    if not already and def_nid != nid:
                        try:
                            cpg.add_edge(CPGEdge(
                                edge_id=self._edge_id(),
                                src_id=def_nid,
                                dst_id=nid,
                                edge_type=CPGEdgeType.DFG_FLOW,
                                properties={"var": name},
                            ))
                        except ValueError:
                            pass

            def _process_stmt(stmt: ast.stmt) -> None:
                if isinstance(stmt, (ast.Assign,)):
                    # Register uses in the value expression first
                    for name_node in ast.walk(stmt.value):
                        if (
                            isinstance(name_node, ast.Name)
                            and isinstance(name_node.ctx, ast.Load)
                        ):
                            _register_use(name_node.id, stmt)

                    # Then register the definitions (targets)
                    for target in stmt.targets:
                        for name_node in ast.walk(target):
                            if (
                                isinstance(name_node, ast.Name)
                                and isinstance(name_node.ctx, ast.Store)
                            ):
                                _register_def(name_node.id, stmt)

                elif isinstance(stmt, ast.AnnAssign):
                    if stmt.value:
                        for name_node in ast.walk(stmt.value):
                            if (
                                isinstance(name_node, ast.Name)
                                and isinstance(name_node.ctx, ast.Load)
                            ):
                                _register_use(name_node.id, stmt)
                    if isinstance(stmt.target, ast.Name):
                        _register_def(stmt.target.id, stmt)

                elif isinstance(stmt, ast.AugAssign):
                    # AugAssign is both use and def
                    if isinstance(stmt.target, ast.Name):
                        _register_use(stmt.target.id, stmt)
                        _register_def(stmt.target.id, stmt)

                elif isinstance(stmt, ast.Expr):
                    for name_node in ast.walk(stmt):
                        if (
                            isinstance(name_node, ast.Name)
                            and isinstance(name_node.ctx, ast.Load)
                        ):
                            _register_use(name_node.id, stmt)

                elif isinstance(stmt, ast.Return):
                    if stmt.value:
                        for name_node in ast.walk(stmt.value):
                            if (
                                isinstance(name_node, ast.Name)
                                and isinstance(name_node.ctx, ast.Load)
                            ):
                                _register_use(name_node.id, stmt)

                elif isinstance(stmt, (ast.If, ast.For, ast.AsyncFor, ast.While)):
                    # Process the test / iter expression
                    test_node = getattr(stmt, "test", None) or getattr(stmt, "iter", None)
                    if test_node:
                        for name_node in ast.walk(test_node):
                            if (
                                isinstance(name_node, ast.Name)
                                and isinstance(name_node.ctx, ast.Load)
                            ):
                                _register_use(name_node.id, stmt)

                    # For-target is a definition
                    if isinstance(stmt, (ast.For, ast.AsyncFor)):
                        for name_node in ast.walk(stmt.target):
                            if (
                                isinstance(name_node, ast.Name)
                                and isinstance(name_node.ctx, ast.Store)
                            ):
                                _register_def(name_node.id, stmt)

                    # Process sub-bodies recursively
                    body = getattr(stmt, "body", [])
                    orelse = getattr(stmt, "orelse", [])
                    for sub in body + orelse:
                        _process_stmt(sub)

                elif isinstance(stmt, (ast.Try,)):
                    for sub in stmt.body:
                        _process_stmt(sub)
                    for handler in stmt.handlers:
                        if handler.name:
                            # exception variable definition
                            _register_def(handler.name, handler.body[0] if handler.body else stmt)
                        for sub in handler.body:
                            _process_stmt(sub)
                    for sub in stmt.orelse + stmt.finalbody:
                        _process_stmt(sub)

                elif isinstance(stmt, (ast.With, ast.AsyncWith)):
                    for item in stmt.items:
                        if item.optional_vars:
                            for name_node in ast.walk(item.optional_vars):
                                if (
                                    isinstance(name_node, ast.Name)
                                    and isinstance(name_node.ctx, ast.Store)
                                ):
                                    _register_def(name_node.id, stmt)
                    for sub in stmt.body:
                        _process_stmt(sub)

                elif isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    # Parameters are defs within that function's scope
                    # We recurse into a new scope
                    param_names = [
                        a.arg for a in stmt.args.args
                        + stmt.args.posonlyargs
                        + stmt.args.kwonlyargs
                    ]
                    if stmt.args.vararg:
                        param_names.append(stmt.args.vararg.arg)
                    if stmt.args.kwarg:
                        param_names.append(stmt.args.kwarg.arg)
                    _scan_scope(stmt.body, stmt.name)

            for stmt in stmts:
                _process_stmt(stmt)

        # Module-level
        if isinstance(tree, ast.Module):
            _scan_scope(tree.body, "__module__")

        # Each function
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                # Register parameter defs
                param_defs: Dict[str, List[str]] = defaultdict(list)
                entry_id = self._node_id(
                    file_path,
                    getattr(node, "lineno", 0),
                    0,
                    f"CFG_ENTRY_{node.name}",
                )
                if entry_id in cpg.nodes:
                    for arg in (
                        node.args.args
                        + node.args.posonlyargs
                        + node.args.kwonlyargs
                    ):
                        cpg.nodes[entry_id].properties.setdefault(
                            "params", []
                        ).append(arg.arg)
                        param_defs[arg.arg].append(entry_id)

    # ------------------------------------------------------------------
    # Layer 4 — Call Graph
    # ------------------------------------------------------------------

    def _build_cg_layer(
        self,
        tree: ast.AST,
        cpg: CodePropertyGraph,
        file_path: str,
    ) -> None:
        """
        Resolve intra-file call graph edges.

        Collects all FunctionDef nodes and all Call nodes, then connects
        each call site to the function definition node via CG_CALL edges.
        """
        func_defs: Dict[str, FuncDef] = {}
        call_sites: List[CallSite] = []

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                line = getattr(node, "lineno", 0)
                nid  = self._node_id(file_path, line, 0, f"CFG_ENTRY_{node.name}")
                if nid not in cpg.nodes:
                    nid = self._stmt_node_id(node, file_path)

                params = [
                    a.arg
                    for a in (
                        node.args.args
                        + node.args.posonlyargs
                        + node.args.kwonlyargs
                    )
                ]
                fd = FuncDef(
                    name=node.name,
                    node_id=nid,
                    params=params,
                    file=file_path,
                    line=line,
                )
                func_defs[node.name] = fd

            elif isinstance(node, ast.Call):
                callee = ""
                try:
                    callee = ast.unparse(node.func)
                except Exception:
                    pass
                line = getattr(node, "lineno", 0)
                col  = getattr(node, "col_offset", 0)
                nid  = self._node_id(file_path, line, col, "Call")
                call_sites.append(CallSite(
                    callee_name=callee,
                    node_id=nid,
                    file=file_path,
                    line=line,
                ))

        # Wire call site → function definition (intra-file)
        # Also collect ast.Call nodes for interprocedural DFG wiring below
        ast_call_map: Dict[str, ast.Call] = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                line = getattr(node, "lineno", 0)
                col  = getattr(node, "col_offset", 0)
                nid  = self._node_id(file_path, line, col, "Call")
                ast_call_map[nid] = node

        for cs in call_sites:
            # Simple name match (handles "foo()" → def foo)
            callee_base = cs.callee_name.split(".")[-1]
            fd = func_defs.get(cs.callee_name) or func_defs.get(callee_base)
            if fd is None:
                continue
            if cs.node_id not in cpg.nodes or fd.node_id not in cpg.nodes:
                continue
            # Avoid duplicate CG_CALL edges
            already = any(
                e.dst_id == fd.node_id and e.edge_type == CPGEdgeType.CG_CALL
                for e in cpg._adj.get(cs.node_id, [])
            )
            if not already:
                try:
                    cpg.add_edge(CPGEdge(
                        edge_id=self._edge_id(),
                        src_id=cs.node_id,
                        dst_id=fd.node_id,
                        edge_type=CPGEdgeType.CG_CALL,
                        properties={
                            "callee": cs.callee_name,
                            "params": fd.params,
                        },
                    ))
                    # Reverse CG_RETURN edge
                    cpg.add_edge(CPGEdge(
                        edge_id=self._edge_id(),
                        src_id=fd.node_id,
                        dst_id=cs.node_id,
                        edge_type=CPGEdgeType.CG_RETURN,
                        properties={"callee": cs.callee_name},
                    ))
                except ValueError:
                    pass

            # ------------------------------------------------------------------
            # Interprocedural DFG: argument → parameter
            # For each positional argument at the call site that is a Name (variable),
            # add a DFG_FLOW edge from the *definition* of that argument to the
            # CFG_ENTRY node of the callee (which represents the parameter binding).
            # This allows taint to propagate across function-call boundaries.
            # ------------------------------------------------------------------
            if fd is None:
                continue
            ast_call = ast_call_map.get(cs.node_id)
            if ast_call is None:
                continue

            for arg_idx, arg_node in enumerate(ast_call.args):
                # Find the statement that wraps this call to look up the def
                # We use the call-site's parent statement node_id as the def anchor.
                # Walk up to find Name nodes in the argument.
                arg_names: List[str] = []
                for sub in ast.walk(arg_node):
                    if isinstance(sub, ast.Name) and isinstance(sub.ctx, ast.Load):
                        arg_names.append(sub.id)

                if not arg_names:
                    continue

                # Find DFG_DEF nodes for these arg names
                for def_node in cpg.nodes.values():
                    if def_node.node_type != CPGNodeType.DFG_DEF:
                        continue
                    defined_var = def_node.properties.get("defines", "")
                    if defined_var not in arg_names:
                        continue
                    if def_node.file != file_path:
                        continue

                    # Add DFG_FLOW: def_site → callee_entry
                    if fd.node_id not in cpg.nodes:
                        continue
                    already_dfg = any(
                        e.dst_id == fd.node_id and e.edge_type == CPGEdgeType.DFG_FLOW
                        for e in cpg._adj.get(def_node.node_id, [])
                    )
                    if not already_dfg:
                        try:
                            cpg.add_edge(CPGEdge(
                                edge_id=self._edge_id(),
                                src_id=def_node.node_id,
                                dst_id=fd.node_id,
                                edge_type=CPGEdgeType.DFG_FLOW,
                                properties={
                                    "var":           defined_var,
                                    "interprocedural": True,
                                    "arg_index":     arg_idx,
                                    "callee":        cs.callee_name,
                                },
                            ))
                        except ValueError:
                            pass
