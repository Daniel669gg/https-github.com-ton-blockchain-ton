# TythanAI Security Platform
# Copyright (c) 2026 TythanAI Labs
# Licensed under the Business Source License 1.1 (see LICENSE).

"""
backend/core/cpg/rust_builder.py — Rust CPG builder.

Produces a CodePropertyGraph from Rust source code using regex-based parsing
(no external dependencies required).

Supports:
- Sources: std::env::args, std::io::stdin, actix-web/axum request handlers
- Sinks: Command::new with user input, fs::read/fs::write with user path,
         SQL string concat
- Special patterns:
  - unwrap() on security-sensitive paths → medium finding (CWE-390)
  - unsafe { } blocks → medium finding (CWE-242)

Tracks taint through let/let mut bindings and produces CPGNodes for each
finding (SOURCE/SINK/SANITIZER nodes) and CPGEdges for taint flow.
"""
from __future__ import annotations

import hashlib
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from backend.core.cpg.graph import (
    CPGEdge,
    CPGEdgeType,
    CPGNode,
    CPGNodeType,
    CodePropertyGraph,
)

logger = logging.getLogger("tythanai.rust_cpg_builder")

# ---------------------------------------------------------------------------
# Source patterns — user-controlled inputs in Rust
# ---------------------------------------------------------------------------

_RUST_SOURCES: List[Tuple[re.Pattern, str, float]] = [
    # Standard library sources
    (re.compile(r'std::env::args\b|env::args\s*\(\s*\)'), "std::env::args (CLI args)", 0.90),
    (re.compile(r'std::env::var\s*\(|env::var\s*\('), "env::var (environment variable)", 0.85),
    (re.compile(r'std::io::stdin\s*\(\s*\)|io::stdin\s*\(\s*\)'), "io::stdin (stdin)", 0.88),
    (re.compile(r'stdin\s*\(\s*\)\.lock\s*\(\s*\)|BufReader::new\s*\(\s*stdin\s*\(\s*\)'), "stdin reader", 0.85),
    # Actix-web sources
    (re.compile(r'\bweb::(?:Query|Path|Json|Form)\s*[<(]'), "actix-web extractor", 0.92),
    (re.compile(r'HttpRequest\s*\.\s*(?:query_string|match_info|headers)\s*\(\s*\)'), "actix HttpRequest", 0.90),
    (re.compile(r'req\.(?:query_string|match_info|uri|headers)\s*\(\s*\)'), "actix req fields", 0.90),
    (re.compile(r'Query\s*::<\w+>.*\.into_inner\s*\(\s*\)'), "actix Query extractor", 0.90),
    (re.compile(r'\bweb::Query\s*<'), "actix-web Query<T>", 0.92),
    # Axum sources
    (re.compile(r'\bextract::(?:Path|Query|Json|Form)\s*[<(]'), "axum extractor", 0.92),
    (re.compile(r'Path\s*\(\s*\w+\s*\)|Query\s*\(\s*\w+\s*\)|Json\s*\(\s*\w+\s*\)'), "axum extracted param", 0.90),
    # Rocket sources
    (re.compile(r'#\[(?:get|post|put|delete|patch)\s*\("'), "Rocket route annotation", 0.88),
    (re.compile(r'rocket::request::Form\s*<|rocket::form::Form\s*<'), "Rocket Form input", 0.90),
    # Generic: reading from a file / network that might be user-controlled
    (re.compile(r'read_line\s*\('), "read_line (stdin)", 0.80),
    (re.compile(r'args\s*\(\s*\)\.collect\s*::<Vec'), "args().collect() (CLI)", 0.88),
]

# ---------------------------------------------------------------------------
# Sink patterns — grouped by CWE
# ---------------------------------------------------------------------------

_RUST_SINKS: Dict[str, List[Tuple[re.Pattern, str]]] = {
    "CWE-78": [
        (re.compile(r'Command::new\s*\('), "Command::new (OS command injection)"),
        (re.compile(r'\.arg\s*\(\s*&?\w+'), ".arg() with variable (command injection)"),
        (re.compile(r'std::process::Command'), "std::process::Command"),
        (re.compile(r'process::Command::new\s*\('), "process::Command::new"),
    ],
    "CWE-22": [
        (re.compile(r'fs::read\s*\('), "fs::read (path traversal)"),
        (re.compile(r'fs::write\s*\('), "fs::write (path traversal)"),
        (re.compile(r'fs::read_to_string\s*\('), "fs::read_to_string"),
        (re.compile(r'File::open\s*\('), "File::open (path traversal)"),
        (re.compile(r'File::create\s*\('), "File::create (path traversal)"),
        (re.compile(r'fs::remove_file\s*\('), "fs::remove_file"),
        (re.compile(r'PathBuf::from\s*\([^)]*\+'), "PathBuf::from with concat"),
        (re.compile(r'Path::new\s*\([^)]*\+'), "Path::new with concat"),
    ],
    "CWE-89": [
        (re.compile(r'execute\s*\(\s*["\'][^"\']*"\s*\+|query\s*\(\s*["\'][^"\']*"\s*\+'), "SQL with string concat"),
        (re.compile(r'format!\s*\(\s*".*SELECT|INSERT|UPDATE|DELETE'), "format! SQL template"),
        (re.compile(r'sqlx::query\s*\(|diesel::sql_query\s*\('), "sqlx/diesel raw query"),
        (re.compile(r'client\.execute\s*\(|client\.query\s*\('), "DB client query"),
        (re.compile(r'\.execute\s*\(&format!'), ".execute(&format! ...) SQL concat"),
    ],
    "CWE-918": [
        (re.compile(r'reqwest::get\s*\('), "reqwest::get (SSRF)"),
        (re.compile(r'reqwest::Client.*\.(?:get|post|request)\s*\('), "reqwest client request"),
        (re.compile(r'hyper::Client.*\.request\s*\('), "hyper client request"),
        (re.compile(r'ureq::get\s*\(|ureq::post\s*\('), "ureq request"),
    ],
}

_RUST_SINK_FLAT: List[Tuple[str, re.Pattern, str]] = [
    (cwe, pat, label)
    for cwe, items in _RUST_SINKS.items()
    for (pat, label) in items
]

# ---------------------------------------------------------------------------
# Sanitizer patterns
# ---------------------------------------------------------------------------

_RUST_SANITIZERS: Dict[str, List[Tuple[re.Pattern, str]]] = {
    "CWE-89": [
        (re.compile(r'sqlx::query!\s*\(|query!\s*\('), "sqlx query! macro (parameterized)"),
        (re.compile(r'diesel::insert_into|diesel::update'), "diesel ORM (type-safe)"),
        (re.compile(r'\$\d+|::\w+\s*=\s*\$'), "parameterized query placeholder"),
    ],
    "CWE-22": [
        (re.compile(r'canonicalize\s*\(\s*\)'), "Path::canonicalize()"),
        (re.compile(r'starts_with\s*\('), ".starts_with() base check"),
        (re.compile(r'strip_prefix\s*\('), ".strip_prefix() base check"),
    ],
    "CWE-78": [
        (re.compile(r'Command::new\s*\([^)]+\)\.args\s*\(\s*\['), "Command with literal args array"),
        (re.compile(r'shell_escape\s*\('), "shell_escape sanitizer"),
    ],
}

_ALL_RUST_SANITIZERS: List[re.Pattern] = [
    re.compile(r'sqlx::query!\s*\('),
    re.compile(r'query!\s*\('),
    re.compile(r'canonicalize\s*\(\s*\)'),
    re.compile(r'starts_with\s*\('),
    re.compile(r'strip_prefix\s*\('),
    re.compile(r'shell_escape\s*\('),
    re.compile(r'diesel::\w+'),
]

# ---------------------------------------------------------------------------
# Special Rust security patterns
# ---------------------------------------------------------------------------

# unwrap() on security-sensitive operations
_RUST_UNWRAP_SECURITY_RE = re.compile(
    r'(?:'
    r'env::var|std::env::var'
    r'|File::open|fs::read|fs::write'
    r'|Command::new|process::Command'
    r'|reqwest|ureq|hyper'
    r')\s*\([^)]*\).*?\.unwrap\s*\(\s*\)'
    r'|\.unwrap\s*\(\s*\).*?(?:env|file|command|request)',
    re.DOTALL,
)

# Simple unwrap on the same line near sensitive code
_RUST_UNWRAP_LINE_RE = re.compile(r'\.unwrap\s*\(\s*\)')

_RUST_UNSAFE_BLOCK_RE = re.compile(r'\bunsafe\s*\{')

# CWE severity
_CWE_SEVERITY: Dict[str, str] = {
    "CWE-78": "CRITICAL",
    "CWE-22": "HIGH",
    "CWE-89": "HIGH",
    "CWE-918": "HIGH",
    "CWE-242": "MEDIUM",
    "CWE-390": "MEDIUM",
}

_CWE_NAMES: Dict[str, str] = {
    "CWE-78": "OS Command Injection",
    "CWE-22": "Path Traversal",
    "CWE-89": "SQL Injection",
    "CWE-918": "Server-Side Request Forgery (SSRF)",
    "CWE-242": "Use of Inherently Dangerous Function (unsafe block)",
    "CWE-390": "Detection of Error Condition Without Action (unwrap on sensitive path)",
}

# ---------------------------------------------------------------------------
# Rust parsing helpers
# ---------------------------------------------------------------------------

# let binding: let [mut] varName [: Type] = expr
_RUST_LET_RE = re.compile(
    r"^\s*let\s+(?:mut\s+)?([A-Za-z_][\w]*)\s*(?::\s*[\w<>\[\]&';\s:,]+)?\s*=\s*(.+)"
)

# Function / impl method start
_RUST_FN_START_RE = re.compile(
    r"^\s*(?:pub(?:\s*\(.*?\))?\s+)?(?:async\s+)?fn\s+(\w+)\s*[<(]"
)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_rust_edge_counter = 0


def _make_rust_node_id(file_path: str, line: int, col: int, suffix: str = "") -> str:
    file_hash = hashlib.sha256(file_path.encode()).hexdigest()[:8]
    parts = [file_hash, str(line), str(col)]
    if suffix:
        parts.append(suffix)
    return ":".join(parts)


def _make_rust_edge_id() -> str:
    global _rust_edge_counter
    _rust_edge_counter += 1
    return f"rse{_rust_edge_counter}"


def _safe_add_edge(cpg: CodePropertyGraph, edge: CPGEdge) -> None:
    if edge.src_id not in cpg.nodes or edge.dst_id not in cpg.nodes:
        return
    for existing in cpg._adj.get(edge.src_id, []):
        if existing.dst_id == edge.dst_id and existing.edge_type == edge.edge_type:
            return
    try:
        cpg.add_edge(edge)
    except ValueError:
        pass


# ---------------------------------------------------------------------------
# RustCPGBuilder
# ---------------------------------------------------------------------------


class RustCPGBuilder:
    """
    Builds a CodePropertyGraph from Rust source code using regex-based parsing.

    Special Rust-specific detections:
    - unwrap() on security-sensitive paths → medium finding (CWE-390)
    - unsafe { } blocks → medium finding (CWE-242)
    - Tracks taint through let/let mut bindings
    """

    def build_file(self, path: str) -> CodePropertyGraph:
        """Parse *path* and return its CPG."""
        try:
            source = Path(path).read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.warning("Cannot read %s: %s", path, exc)
            cpg = CodePropertyGraph()
            err_node = CPGNode(
                node_id=_make_rust_node_id(path, 0, 0, "parse_error"),
                node_type=CPGNodeType.AST_NODE,
                ast_type="ParseError",
                code=str(exc),
                file=path,
                line=0,
                col=0,
                properties={"error": str(exc)},
            )
            cpg.add_node(err_node)
            return cpg
        return self.build_source(source, file_path=os.path.abspath(path))

    def build_source(self, source: str, file_path: str = "<rust>") -> CodePropertyGraph:
        """Parse Rust *source* string and return its CPG."""
        cpg = CodePropertyGraph()
        lines = source.splitlines()

        # Extract function blocks
        functions = self._extract_functions(lines)

        if not functions:
            functions = [
                {
                    "name": "__module__",
                    "start_line": 1,
                    "end_line": len(lines),
                    "body_lines": lines,
                }
            ]

        for func in functions:
            self._build_function_cpg(func, file_path, cpg)

        return cpg

    # ------------------------------------------------------------------
    # Function extraction
    # ------------------------------------------------------------------

    def _extract_functions(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extract Rust function blocks by brace counting."""
        functions: List[Dict[str, Any]] = []
        n = len(lines)
        i = 0

        while i < n:
            m = _RUST_FN_START_RE.match(lines[i])
            if m:
                func_name = m.group(1)
                start_line = i + 1  # 1-indexed
                # Find the opening brace (may be on same or next line)
                depth = 0
                j = i
                while j < n:
                    depth += lines[j].count("{") - lines[j].count("}")
                    if depth > 0:
                        j += 1
                        break
                    j += 1
                # Now count until depth returns to 0
                while j < n and depth > 0:
                    depth += lines[j].count("{") - lines[j].count("}")
                    j += 1

                body_lines = lines[i:j]
                functions.append(
                    {
                        "name": func_name,
                        "start_line": start_line,
                        "end_line": j,
                        "body_lines": body_lines,
                    }
                )
                i = j
            else:
                i += 1

        return functions

    # ------------------------------------------------------------------
    # Per-function CPG building
    # ------------------------------------------------------------------

    def _build_function_cpg(
        self,
        func: Dict[str, Any],
        file_path: str,
        cpg: CodePropertyGraph,
    ) -> None:
        """Build CPG nodes/edges for one Rust function."""
        func_name = func["name"]
        start_line = func["start_line"]
        body_lines = func["body_lines"]
        base_line = start_line

        # Synthetic ENTRY
        entry_id = _make_rust_node_id(file_path, start_line, 0, f"ENTRY_{func_name}")
        entry_node = CPGNode(
            node_id=entry_id,
            node_type=CPGNodeType.CFG_ENTRY,
            ast_type="CFG_ENTRY",
            code=f"ENTRY:{func_name}",
            file=file_path,
            line=start_line,
            col=0,
            properties={"function": func_name, "rust_node": True},
        )
        cpg.add_node(entry_node)

        end_line = func.get("end_line", start_line + len(body_lines))
        exit_id = _make_rust_node_id(file_path, end_line, 0, f"EXIT_{func_name}")
        exit_node = CPGNode(
            node_id=exit_id,
            node_type=CPGNodeType.CFG_EXIT,
            ast_type="CFG_EXIT",
            code=f"EXIT:{func_name}",
            file=file_path,
            line=end_line,
            col=0,
            properties={"function": func_name, "rust_node": True},
        )
        cpg.add_node(exit_node)

        # Taint tracking
        var_defs: Dict[str, List[str]] = {}
        tainted_vars: Set[str] = set()

        stmt_nodes: List[CPGNode] = []

        # Track if we're inside an unsafe block
        unsafe_depth = 0

        for idx, raw_line in enumerate(body_lines):
            line_no = base_line + idx
            stripped = raw_line.strip()

            if not stripped or stripped.startswith("//"):
                continue

            # Track unsafe blocks
            if _RUST_UNSAFE_BLOCK_RE.search(stripped):
                unsafe_depth += stripped.count("{") - stripped.count("}")
                # Create an unsafe block finding node
                unsafe_id = _make_rust_node_id(
                    file_path, line_no, 0, f"unsafe_block_{line_no}"
                )
                unsafe_node = CPGNode(
                    node_id=unsafe_id,
                    node_type=CPGNodeType.DFG_SINK,
                    ast_type="UnsafeBlock",
                    code=stripped[:200],
                    file=file_path,
                    line=line_no,
                    col=len(raw_line) - len(raw_line.lstrip()),
                    properties={
                        "function": func_name,
                        "rust_node": True,
                        "is_unsafe_block": True,
                        "is_taint_sink": True,
                        "sink_cwe": "CWE-242",
                        "sink_label": "unsafe block (CWE-242)",
                        "severity": "MEDIUM",
                        "confidence": 0.85,
                    },
                )
                cpg.add_node(unsafe_node)
                stmt_nodes.append(unsafe_node)
                continue

            # Check sanitizers on this line
            line_sanitized = any(san.search(stripped) for san in _ALL_RUST_SANITIZERS)

            # Detect source patterns
            source_matched = None
            source_conf = 0.0
            for src_pat, src_label, src_conf_val in _RUST_SOURCES:
                if src_pat.search(stripped):
                    source_matched = src_label
                    source_conf = src_conf_val
                    break

            # Detect sink patterns
            sink_cwe = None
            sink_label_str = None
            for cwe, sink_pat, label in _RUST_SINK_FLAT:
                if sink_pat.search(stripped):
                    sink_sanitized = False
                    for san_pat, _ in _RUST_SANITIZERS.get(cwe, []):
                        if san_pat.search(stripped):
                            sink_sanitized = True
                            break
                    if not sink_sanitized and not line_sanitized:
                        sink_cwe = cwe
                        sink_label_str = label
                    break

            # Detect unwrap() on security-sensitive lines (special pattern)
            has_unwrap_risk = False
            if _RUST_UNWRAP_LINE_RE.search(stripped):
                # Check if the line involves security-sensitive operations
                sensitive_ops = [
                    "env::var", "File::open", "fs::read", "fs::write",
                    "Command::new", "reqwest", "fs::read_to_string",
                ]
                if any(op in stripped for op in sensitive_ops):
                    has_unwrap_risk = True

            # Detect variable bindings
            assigned_var: Optional[str] = None
            m = _RUST_LET_RE.match(stripped)
            if m:
                assigned_var = m.group(1)

            # Determine node type
            if source_matched and not line_sanitized:
                node_type = CPGNodeType.DFG_SOURCE
            elif sink_cwe:
                node_type = CPGNodeType.DFG_SINK
            elif has_unwrap_risk:
                node_type = CPGNodeType.DFG_SINK
            elif assigned_var:
                node_type = CPGNodeType.DFG_DEF
            elif "::" in stripped or "(" in stripped:
                node_type = CPGNodeType.CG_CALL
            else:
                node_type = CPGNodeType.CFG_NODE

            props: Dict[str, Any] = {
                "function": func_name,
                "rust_node": True,
            }

            if source_matched and not line_sanitized:
                props["is_taint_source"] = True
                props["source_label"] = source_matched
                props["source_confidence"] = source_conf
                if assigned_var:
                    tainted_vars.add(assigned_var)

            if sink_cwe:
                props["is_taint_sink"] = True
                props["sink_cwe"] = sink_cwe
                props["sink_label"] = sink_label_str

            if has_unwrap_risk and not sink_cwe:
                props["is_taint_sink"] = True
                props["sink_cwe"] = "CWE-390"
                props["sink_label"] = "unwrap() on security-sensitive path (CWE-390)"
                props["severity"] = "MEDIUM"
                props["confidence"] = 0.75

            if assigned_var:
                props["defines"] = assigned_var

            col = len(raw_line) - len(raw_line.lstrip())
            nid = _make_rust_node_id(
                file_path, line_no, col, f"{func_name}_stmt_{line_no}"
            )

            stmt_node = CPGNode(
                node_id=nid,
                node_type=node_type,
                ast_type=f"Rust_{node_type.value.upper()}",
                code=stripped[:200],
                file=file_path,
                line=line_no,
                col=col,
                properties=props,
            )
            cpg.add_node(stmt_node)
            stmt_nodes.append(stmt_node)

            if assigned_var:
                var_defs.setdefault(assigned_var, []).append(nid)

            # Propagate taint
            # Skip '_' (Rust wildcard) — it should not be tracked as a tainted var
            if assigned_var and assigned_var != "_" and source_matched is None:
                # If this line is sanitized (e.g. starts_with check), don't propagate
                if not line_sanitized:
                    for tv in list(tainted_vars):
                        # Skip empty or single-underscore tainted vars
                        if not tv or tv == "_":
                            continue
                        if re.search(r"\b" + re.escape(tv) + r"\b", stripped):
                            tainted_vars.add(assigned_var)
                            break

        # Wire CFG edges
        if stmt_nodes:
            _safe_add_edge(cpg, CPGEdge(
                edge_id=_make_rust_edge_id(),
                src_id=entry_id,
                dst_id=stmt_nodes[0].node_id,
                edge_type=CPGEdgeType.CFG_NEXT,
                properties={"function": func_name},
            ))
            for i in range(len(stmt_nodes) - 1):
                _safe_add_edge(cpg, CPGEdge(
                    edge_id=_make_rust_edge_id(),
                    src_id=stmt_nodes[i].node_id,
                    dst_id=stmt_nodes[i + 1].node_id,
                    edge_type=CPGEdgeType.CFG_NEXT,
                    properties={"function": func_name},
                ))
            _safe_add_edge(cpg, CPGEdge(
                edge_id=_make_rust_edge_id(),
                src_id=stmt_nodes[-1].node_id,
                dst_id=exit_id,
                edge_type=CPGEdgeType.CFG_NEXT,
                properties={"function": func_name},
            ))
        else:
            _safe_add_edge(cpg, CPGEdge(
                edge_id=_make_rust_edge_id(),
                src_id=entry_id,
                dst_id=exit_id,
                edge_type=CPGEdgeType.CFG_NEXT,
                properties={"function": func_name},
            ))

        # Wire DFG_FLOW edges
        for stmt_node in stmt_nodes:
            code = stmt_node.code
            for var_name, def_ids in var_defs.items():
                if var_name == stmt_node.properties.get("defines"):
                    continue
                if re.search(r"\b" + re.escape(var_name) + r"\b", code):
                    for def_id in def_ids:
                        if def_id != stmt_node.node_id:
                            _safe_add_edge(cpg, CPGEdge(
                                edge_id=_make_rust_edge_id(),
                                src_id=def_id,
                                dst_id=stmt_node.node_id,
                                edge_type=CPGEdgeType.DFG_FLOW,
                                properties={
                                    "var": var_name,
                                    "function": func_name,
                                },
                            ))

        # Wire taint source -> sink
        source_nodes = [n for n in stmt_nodes if n.properties.get("is_taint_source")]
        sink_nodes = [n for n in stmt_nodes if n.properties.get("is_taint_sink")]

        for src_node in source_nodes:
            src_var = src_node.properties.get("defines", "")
            for sink_node in sink_nodes:
                sink_code = sink_node.code
                found_taint = False

                if src_var and re.search(r"\b" + re.escape(src_var) + r"\b", sink_code):
                    _safe_add_edge(cpg, CPGEdge(
                        edge_id=_make_rust_edge_id(),
                        src_id=src_node.node_id,
                        dst_id=sink_node.node_id,
                        edge_type=CPGEdgeType.DFG_FLOW,
                        properties={
                            "taint_flow": True,
                            "source_var": src_var,
                            "function": func_name,
                        },
                    ))
                    found_taint = True

                if not found_taint:
                    for tv in tainted_vars:
                        # Skip Rust wildcard '_' and empty strings — not meaningful identifiers
                        if not tv or tv == "_":
                            continue
                        if re.search(r"\b" + re.escape(tv) + r"\b", sink_code):
                            _safe_add_edge(cpg, CPGEdge(
                                edge_id=_make_rust_edge_id(),
                                src_id=src_node.node_id,
                                dst_id=sink_node.node_id,
                                edge_type=CPGEdgeType.DFG_FLOW,
                                properties={
                                    "taint_flow": True,
                                    "tainted_var": tv,
                                    "function": func_name,
                                    "indirect": True,
                                },
                            ))
                            break
