"""
backend/core/cpg/repo_analyzer.py — Full-repository CPG analysis.

Builds individual file CPGs, merges them, resolves cross-file
call graph edges, and runs vulnerability queries across the
entire merged graph.
"""

from __future__ import annotations

import ast
import fnmatch
import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from .builder import CPGBuilder, FuncDef, CallSite
from .graph import (
    CPGEdge,
    CPGEdgeType,
    CPGNode,
    CPGNodeType,
    CodePropertyGraph,
)
from .query_engine import CPGQueryEngine, TaintPath


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class RepoAnalysisResult:
    """Aggregated output of a full-repository CPG scan."""
    files_analyzed:    int
    total_nodes:       int
    total_edges:       int
    findings:          List[TaintPath]
    hardcoded_secrets: List[Dict[str, Any]]
    cross_file_flows:  int
    call_graph_edges:  int
    summary:           str
    duration_seconds:  float = 0.0
    errors:            List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "files_analyzed":    self.files_analyzed,
            "total_nodes":       self.total_nodes,
            "total_edges":       self.total_edges,
            "findings":          [f.to_dict() for f in self.findings],
            "hardcoded_secrets": self.hardcoded_secrets,
            "cross_file_flows":  self.cross_file_flows,
            "call_graph_edges":  self.call_graph_edges,
            "summary":           self.summary,
            "duration_seconds":  self.duration_seconds,
            "errors":            self.errors,
        }


# ---------------------------------------------------------------------------
# RepoAnalyzer
# ---------------------------------------------------------------------------

class RepoAnalyzer:
    """
    Orchestrates CPG construction and vulnerability analysis for an entire
    Python codebase rooted at *root*.

    Steps performed by ``analyze()``:
      1. Walk the directory tree collecting ``*.py`` files.
      2. Build a CPG for each file using ``CPGBuilder``.
      3. Merge all per-file CPGs into a single global CPG.
      4. Resolve cross-file call-graph edges (call sites whose callee name
         matches a function defined in a *different* file).
      5. Run all ``CPGQueryEngine`` queries on the merged graph.
      6. Package results into a ``RepoAnalysisResult``.
    """

    # Default include glob patterns (Python files)
    _DEFAULT_PATTERNS: List[str] = ["*.py"]

    # Directories to skip unconditionally
    _SKIP_DIRS: Set[str] = {
        ".git", "__pycache__", ".tox", ".mypy_cache", ".pytest_cache",
        "node_modules", ".venv", "venv", "env", "dist", "build", "site-packages",
        ".eggs", "*.egg-info",
    }

    def __init__(
        self,
        root: str,
        include_patterns: Optional[List[str]] = None,
        max_file_size_kb: int = 512,
    ) -> None:
        self.root = os.path.abspath(root)
        self.include_patterns: List[str] = include_patterns or self._DEFAULT_PATTERNS
        self.max_file_size_bytes: int = max_file_size_kb * 1024
        self._builder = CPGBuilder()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze(self) -> RepoAnalysisResult:
        """Run the full analysis pipeline and return a ``RepoAnalysisResult``."""
        t_start = time.monotonic()
        errors: List[str] = []

        # ---- Step 1: collect files ----------------------------------------
        py_files = self._collect_files()

        # ---- Step 2: build per-file CPGs ----------------------------------
        global_cpg = CodePropertyGraph()
        file_func_defs: Dict[str, List[FuncDef]] = {}   # file → FuncDefs
        file_call_sites: Dict[str, List[CallSite]] = {}  # file → CallSites

        for fpath in py_files:
            try:
                cpg = self._builder.build_file(fpath)
                fds, css = self._extract_func_defs_and_calls(fpath, cpg)
                file_func_defs[fpath]  = fds
                file_call_sites[fpath] = css
                global_cpg.merge(cpg)
            except Exception as exc:
                errors.append(f"{fpath}: {exc}")

        # ---- Step 3: resolve cross-file CG edges --------------------------
        cross_file_edges = self._resolve_cross_file_calls(
            global_cpg, file_func_defs, file_call_sites
        )

        # ---- Step 4: count CG edges ---------------------------------------
        cg_edge_count = sum(
            1 for e in global_cpg.edges
            if e.edge_type == CPGEdgeType.CG_CALL
        )

        # ---- Step 5: query engine -----------------------------------------
        engine = CPGQueryEngine(global_cpg)
        query_results = engine.run_all_queries()

        sql_paths  = [TaintPath(**_dict_to_taintpath_kwargs(r, global_cpg))
                      for r in query_results["sql_injection"]]
        cmd_paths  = [TaintPath(**_dict_to_taintpath_kwargs(r, global_cpg))
                      for r in query_results["command_injection"]]
        path_paths = [TaintPath(**_dict_to_taintpath_kwargs(r, global_cpg))
                      for r in query_results["path_traversal"]]
        code_paths = [TaintPath(**_dict_to_taintpath_kwargs(r, global_cpg))
                      for r in query_results["code_injection"]]
        cross_fn   = [TaintPath(**_dict_to_taintpath_kwargs(r, global_cpg))
                      for r in query_results["cross_function"]]

        all_findings = sql_paths + cmd_paths + path_paths + code_paths + cross_fn
        secrets      = query_results["hardcoded_secrets"]

        t_end = time.monotonic()

        summary = self._build_summary(
            files_analyzed=len(py_files),
            total_nodes=len(global_cpg.nodes),
            total_edges=len(global_cpg.edges),
            findings=all_findings,
            secrets=secrets,
            cross_file_flows=cross_file_edges,
            cg_edges=cg_edge_count,
            duration=t_end - t_start,
            errors=errors,
        )

        return RepoAnalysisResult(
            files_analyzed=len(py_files),
            total_nodes=len(global_cpg.nodes),
            total_edges=len(global_cpg.edges),
            findings=all_findings,
            hardcoded_secrets=secrets,
            cross_file_flows=cross_file_edges,
            call_graph_edges=cg_edge_count,
            summary=summary,
            duration_seconds=round(t_end - t_start, 3),
            errors=errors,
        )

    # ------------------------------------------------------------------
    # File collection
    # ------------------------------------------------------------------

    def _collect_files(self) -> List[str]:
        """Walk *self.root* and return all matching Python source files."""
        matched: List[str] = []

        for dirpath, dirnames, filenames in os.walk(self.root, topdown=True):
            # Prune directories in-place so os.walk won't descend into them
            dirnames[:] = [
                d for d in dirnames
                if not self._should_skip_dir(d)
            ]

            for fname in filenames:
                if not self._matches_include(fname):
                    continue
                fpath = os.path.join(dirpath, fname)
                # Skip oversized files
                try:
                    if os.path.getsize(fpath) > self.max_file_size_bytes:
                        continue
                except OSError:
                    continue
                matched.append(fpath)

        return matched

    def _should_skip_dir(self, dname: str) -> bool:
        for pattern in self._SKIP_DIRS:
            if fnmatch.fnmatch(dname, pattern):
                return True
        return False

    def _matches_include(self, fname: str) -> bool:
        return any(fnmatch.fnmatch(fname, p) for p in self.include_patterns)

    # ------------------------------------------------------------------
    # Extract function defs / call sites from a CPG
    # ------------------------------------------------------------------

    def _extract_func_defs_and_calls(
        self,
        file_path: str,
        cpg: CodePropertyGraph,
    ) -> tuple[List[FuncDef], List[CallSite]]:
        """
        Re-read function definitions and call sites from a constructed CPG.
        This avoids re-parsing the AST; we read CPG node metadata instead.
        """
        func_defs:  List[FuncDef]  = []
        call_sites: List[CallSite] = []

        for node in cpg.nodes.values():
            if node.file != file_path:
                continue

            if node.node_type == CPGNodeType.CFG_ENTRY:
                func_name = node.properties.get("function", "")
                if func_name and func_name != "__module__":
                    params = node.properties.get("params", [])
                    func_defs.append(FuncDef(
                        name=func_name,
                        node_id=node.node_id,
                        params=params,
                        file=file_path,
                        line=node.line,
                    ))

            elif node.node_type == CPGNodeType.CG_CALL:
                callee = node.properties.get("callee", "")
                if callee:
                    call_sites.append(CallSite(
                        callee_name=callee,
                        node_id=node.node_id,
                        file=file_path,
                        line=node.line,
                    ))

        return func_defs, call_sites

    # ------------------------------------------------------------------
    # Cross-file call graph resolution
    # ------------------------------------------------------------------

    def _resolve_cross_file_calls(
        self,
        global_cpg: CodePropertyGraph,
        file_func_defs:  Dict[str, List[FuncDef]],
        file_call_sites: Dict[str, List[CallSite]],
    ) -> int:
        """
        For each call site, check if the callee is defined in a *different*
        file and add CG_CALL / CG_RETURN edges across files.

        Returns the number of cross-file edges added.
        """
        # Build a global name → FuncDef map (last-writer-wins for duplicates)
        global_funcs: Dict[str, FuncDef] = {}
        for fds in file_func_defs.values():
            for fd in fds:
                global_funcs[fd.name] = fd

        edges_added = 0

        for caller_file, css in file_call_sites.items():
            for cs in css:
                callee_base = cs.callee_name.split(".")[-1]
                fd = global_funcs.get(cs.callee_name) or global_funcs.get(callee_base)

                if fd is None:
                    continue
                # Skip same-file edges (already wired by builder)
                if fd.file == caller_file:
                    continue
                if cs.node_id not in global_cpg.nodes:
                    continue
                if fd.node_id not in global_cpg.nodes:
                    continue

                # Check for existing edge
                already = any(
                    e.dst_id == fd.node_id and e.edge_type == CPGEdgeType.CG_CALL
                    for e in global_cpg._adj.get(cs.node_id, [])
                )
                if already:
                    continue

                try:
                    global_cpg.add_edge(CPGEdge(
                        edge_id=f"xfile_cg_{edges_added}",
                        src_id=cs.node_id,
                        dst_id=fd.node_id,
                        edge_type=CPGEdgeType.CG_CALL,
                        properties={
                            "callee":      cs.callee_name,
                            "cross_file":  True,
                            "caller_file": caller_file,
                            "callee_file": fd.file,
                        },
                    ))
                    global_cpg.add_edge(CPGEdge(
                        edge_id=f"xfile_cg_ret_{edges_added}",
                        src_id=fd.node_id,
                        dst_id=cs.node_id,
                        edge_type=CPGEdgeType.CG_RETURN,
                        properties={
                            "callee":      cs.callee_name,
                            "cross_file":  True,
                        },
                    ))
                    edges_added += 1
                except ValueError:
                    pass

        return edges_added

    # ------------------------------------------------------------------
    # Summary generation
    # ------------------------------------------------------------------

    def _build_summary(
        self,
        files_analyzed: int,
        total_nodes: int,
        total_edges: int,
        findings: List[TaintPath],
        secrets: List[Dict[str, Any]],
        cross_file_flows: int,
        cg_edges: int,
        duration: float,
        errors: List[str],
    ) -> str:
        by_type: Dict[str, int] = {}
        for f in findings:
            by_type[f.sink_type] = by_type.get(f.sink_type, 0) + 1

        type_breakdown = ", ".join(
            f"{k}: {v}" for k, v in sorted(by_type.items())
        )

        high_conf = sum(1 for f in findings if f.confidence >= 0.7)

        lines = [
            "=" * 60,
            "TythanAI CPG Repository Analysis",
            "=" * 60,
            f"Files analysed  : {files_analyzed}",
            f"CPG nodes       : {total_nodes:,}",
            f"CPG edges       : {total_edges:,}",
            f"Call-graph edges: {cg_edges:,}",
            f"Cross-file flows: {cross_file_flows}",
            f"Duration        : {duration:.2f}s",
            "",
            "Vulnerability Findings",
            "-" * 40,
            f"Total taint paths : {len(findings)}",
            f"High-confidence   : {high_conf}",
            f"By type           : {type_breakdown or 'none'}",
            f"Hardcoded secrets : {len(secrets)}",
        ]

        if errors:
            lines += ["", f"Errors ({len(errors)}):", "-" * 40]
            for e in errors[:10]:
                lines.append(f"  {e}")
            if len(errors) > 10:
                lines.append(f"  ... and {len(errors) - 10} more")

        lines.append("=" * 60)
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Helper — reconstruct TaintPath from serialised dict
# ---------------------------------------------------------------------------

def _dict_to_taintpath_kwargs(
    d: Dict[str, Any],
    cpg: CodePropertyGraph,
) -> Dict[str, Any]:
    """
    Convert the dict produced by TaintPath.to_dict() back into kwargs
    suitable for the TaintPath constructor.

    We look up nodes from the CPG to get live CPGNode objects; if a node
    no longer exists in the merged graph we construct a minimal placeholder.
    """

    def _node_from_dict(nd: Dict[str, Any]) -> CPGNode:
        nid = nd.get("node_id", "")
        if nid and nid in cpg.nodes:
            return cpg.nodes[nid]
        return CPGNode(
            node_id=nd.get("node_id", "unknown"),
            node_type=CPGNodeType.AST_NODE,
            ast_type=nd.get("ast_type", "Unknown"),
            code=nd.get("code", ""),
            file=nd.get("file", ""),
            line=nd.get("line", 0),
            col=nd.get("col", 0),
            properties=nd.get("properties", {}),
        )

    src_node = _node_from_dict(d.get("src_node", {}))
    dst_node = _node_from_dict(d.get("dst_node", {}))
    path_nodes = [_node_from_dict(pn) for pn in d.get("path", [])]

    return {
        "src_node":   src_node,
        "dst_node":   dst_node,
        "path":       path_nodes,
        "confidence": d.get("confidence", 0.5),
        "sink_type":  d.get("sink_type", "unknown"),
        "vuln_desc":  d.get("vuln_desc", ""),
        "file":       d.get("file", src_node.file),
        "line":       d.get("line", src_node.line),
    }
