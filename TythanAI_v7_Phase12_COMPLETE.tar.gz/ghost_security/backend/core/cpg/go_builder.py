# TythanAI Security Platform
# Copyright (c) 2026 TythanAI Labs
# Licensed under the Business Source License 1.1 (see LICENSE).

"""
backend/core/cpg/go_builder.py — Go CPG builder.

Produces a CodePropertyGraph from Go source code using regex-based parsing
(no external dependencies required).

Detects:
- Sources: r.FormValue, r.URL.Query(), r.Body, os.Getenv, json.Unmarshal args
- Sinks:   db.Query/db.Exec with string concat, exec.Command, os.Open with user
           input, fmt.Fprintf(w
- Sanitizers: html.EscapeString, url.QueryEscape, strconv.Atoi,
              regexp.MatchString

Tracks taint through := assignments and produces CPGNodes (SOURCE/SINK/CALL)
plus CPGEdges (DFG_FLOW) for taint flow.
"""
from __future__ import annotations

import hashlib
import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from backend.core.cpg.graph import (
    CPGEdge,
    CPGEdgeType,
    CPGNode,
    CPGNodeType,
    CodePropertyGraph,
)

logger = logging.getLogger("tythanai.go_cpg_builder")

# ---------------------------------------------------------------------------
# Source patterns — user-controlled inputs in Go
# ---------------------------------------------------------------------------

_GO_SOURCES: List[Tuple[re.Pattern, str, float]] = [
    (re.compile(r'r\.FormValue\s*\('), "r.FormValue (HTTP form input)", 0.95),
    (re.compile(r'r\.URL\.Query\(\)'), "r.URL.Query() (HTTP query string)", 0.95),
    (re.compile(r'r\.URL\.Query\(\)\.Get\s*\('), "r.URL.Query().Get() (query param)", 0.95),
    (re.compile(r'\br\.Body\b'), "r.Body (HTTP request body)", 0.90),
    (re.compile(r'os\.Getenv\s*\('), "os.Getenv (environment variable)", 0.80),
    (re.compile(r'json\.Unmarshal\s*\('), "json.Unmarshal (deserialized input)", 0.85),
    (re.compile(r'ioutil\.ReadAll\s*\(\s*r\.Body'), "ioutil.ReadAll(r.Body)", 0.90),
    (re.compile(r'io\.ReadAll\s*\(\s*r\.Body'), "io.ReadAll(r.Body)", 0.90),
    (re.compile(r'mux\.Vars\s*\('), "mux.Vars (URL path variables)", 0.90),
    (re.compile(r'r\.PostFormValue\s*\('), "r.PostFormValue (POST form input)", 0.95),
    (re.compile(r'chi\.URLParam\s*\('), "chi.URLParam (URL path param)", 0.90),
    (re.compile(r'os\.Args\b'), "os.Args (command-line arguments)", 0.85),
    (re.compile(r'bufio\.NewReader\s*\(\s*os\.Stdin\s*\)'), "stdin reader", 0.80),
    (re.compile(r'fmt\.Scan\b|fmt\.Scanln\b|fmt\.Scanf\b'), "fmt.Scan* (stdin)", 0.80),
]

# ---------------------------------------------------------------------------
# Sink patterns — grouped by CWE
# ---------------------------------------------------------------------------

_GO_SINKS: Dict[str, List[Tuple[re.Pattern, str]]] = {
    "CWE-89": [
        (re.compile(r'db\.Query\s*\([^)]*\+'), "db.Query with string concat (SQLi)"),
        (re.compile(r'db\.Exec\s*\([^)]*\+'), "db.Exec with string concat (SQLi)"),
        (re.compile(r'db\.QueryRow\s*\([^)]*\+'), "db.QueryRow with string concat"),
        (re.compile(r'db\.Query\s*\(\s*fmt\.Sprintf'), "db.Query with fmt.Sprintf"),
        (re.compile(r'db\.Exec\s*\(\s*fmt\.Sprintf'), "db.Exec with fmt.Sprintf"),
        (re.compile(r'fmt\.Sprintf\s*\([^)]*SELECT|INSERT|UPDATE|DELETE'), "fmt.Sprintf SQL"),
        # Broader: db.Query/db.Exec called with a variable (taint check done in builder)
        (re.compile(r'\bdb\.Query\s*\(\s*[A-Za-z_]'), "db.Query with variable (potential SQLi)"),
        (re.compile(r'\bdb\.Exec\s*\(\s*[A-Za-z_]'), "db.Exec with variable (potential SQLi)"),
        (re.compile(r'\bdb\.QueryRow\s*\(\s*[A-Za-z_]'), "db.QueryRow with variable"),
    ],
    "CWE-78": [
        (re.compile(r'exec\.Command\s*\('), "exec.Command (OS command injection)"),
        (re.compile(r'exec\.CommandContext\s*\('), "exec.CommandContext"),
        (re.compile(r'syscall\.Exec\s*\('), "syscall.Exec"),
    ],
    "CWE-22": [
        (re.compile(r'os\.Open\s*\('), "os.Open (path traversal)"),
        (re.compile(r'os\.Create\s*\('), "os.Create with user path"),
        (re.compile(r'ioutil\.ReadFile\s*\('), "ioutil.ReadFile with user path"),
        (re.compile(r'os\.ReadFile\s*\('), "os.ReadFile with user path"),
        (re.compile(r'filepath\.Join\s*\([^)]*\+'), "filepath.Join with user input"),
    ],
    "CWE-79": [
        (re.compile(r'fmt\.Fprintf\s*\(\s*w\b'), "fmt.Fprintf(w ...) response write"),
        (re.compile(r'w\.Write\s*\('), "w.Write response output"),
        (re.compile(r'fmt\.Fprint\s*\(\s*w\b'), "fmt.Fprint(w ...) response write"),
        (re.compile(r'io\.WriteString\s*\(\s*w\b'), "io.WriteString(w ...)"),
        (re.compile(r'template\.HTML\s*\('), "template.HTML unsafe cast"),
    ],
    "CWE-918": [
        (re.compile(r'http\.Get\s*\('), "http.Get (SSRF)"),
        (re.compile(r'http\.Post\s*\('), "http.Post (SSRF)"),
        (re.compile(r'http\.NewRequest\s*\('), "http.NewRequest (SSRF)"),
        (re.compile(r'url\.Parse\s*\('), "url.Parse with user input"),
    ],
}

_GO_SINK_FLAT: List[Tuple[str, re.Pattern, str]] = [
    (cwe, pat, label)
    for cwe, items in _GO_SINKS.items()
    for (pat, label) in items
]

# ---------------------------------------------------------------------------
# Sanitizer patterns
# ---------------------------------------------------------------------------

_GO_SANITIZERS: Dict[str, List[Tuple[re.Pattern, str]]] = {
    "CWE-89": [
        (re.compile(r'\$\d+|\?'), "parameterized query placeholder"),
        (re.compile(r'db\.Prepare\s*\(|db\.PrepareContext\s*\('), "db.Prepare"),
        (re.compile(r'sqlx\.NamedExec|sqlx\.Select'), "sqlx named query"),
    ],
    "CWE-79": [
        (re.compile(r'html\.EscapeString\s*\('), "html.EscapeString"),
        (re.compile(r'template\.HTMLEscapeString\s*\('), "template.HTMLEscapeString"),
        (re.compile(r'text/template'), "text/template (auto-escaping)"),
    ],
    "CWE-78": [
        (re.compile(r'regexp\.MatchString\s*\('), "regexp.MatchString validation"),
        (re.compile(r'exec\.Command\s*\([^,]+,\s*\['), "exec.Command with array args"),
    ],
    "CWE-22": [
        (re.compile(r'filepath\.Clean\s*\('), "filepath.Clean"),
        (re.compile(r'strings\.HasPrefix\s*\('), "strings.HasPrefix base check"),
        (re.compile(r'path\.Clean\s*\('), "path.Clean"),
    ],
    "CWE-918": [
        (re.compile(r'url\.Parse\s*\([^)]*allowedHost'), "allowedHost URL check"),
    ],
}

_ALL_GO_SANITIZERS: List[re.Pattern] = [
    re.compile(r'html\.EscapeString\s*\('),
    re.compile(r'url\.QueryEscape\s*\('),
    re.compile(r'strconv\.Atoi\s*\('),
    re.compile(r'strconv\.ParseInt\s*\('),
    re.compile(r'strconv\.ParseFloat\s*\('),
    re.compile(r'regexp\.MatchString\s*\('),
    re.compile(r'regexp\.MustCompile\s*\('),
    re.compile(r'filepath\.Clean\s*\('),
    re.compile(r'template\.HTMLEscapeString\s*\('),
    re.compile(r'db\.Prepare\s*\('),
]

# Severity mapping per CWE
_CWE_SEVERITY: Dict[str, str] = {
    "CWE-89": "HIGH",
    "CWE-79": "HIGH",
    "CWE-78": "CRITICAL",
    "CWE-22": "HIGH",
    "CWE-918": "HIGH",
}

_CWE_NAMES: Dict[str, str] = {
    "CWE-89": "SQL Injection",
    "CWE-79": "Cross-site Scripting (XSS)",
    "CWE-78": "OS Command Injection",
    "CWE-22": "Path Traversal",
    "CWE-918": "Server-Side Request Forgery (SSRF)",
}

# ---------------------------------------------------------------------------
# Go assignment tracking pattern
# ---------------------------------------------------------------------------

# Short variable declaration: varName := expr  or  varName, varName2 := expr
_GO_SHORT_ASSIGN_RE = re.compile(
    r"^\s*([A-Za-z_][\w]*)(?:\s*,\s*[A-Za-z_][\w]*)?\s*:=\s*(.+)"
)
# Regular assignment: varName = expr
_GO_ASSIGN_RE = re.compile(
    r"^\s*([A-Za-z_][\w]*)\s*=\s*([^=].*)"
)
# var declaration: var varName type = expr
_GO_VAR_DECL_RE = re.compile(
    r"^\s*var\s+([A-Za-z_][\w]*)\s+\w[\w.*\[\]]*\s*=\s*(.+)"
)

# Function/handler start detection
_GO_FUNC_START_RE = re.compile(
    r"^\s*func\s+(?:\(\s*\w+\s+\*?\w+\s*\)\s*)?(\w+)\s*\("
)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_go_edge_counter = 0


def _make_go_node_id(file_path: str, line: int, col: int, suffix: str = "") -> str:
    file_hash = hashlib.sha256(file_path.encode()).hexdigest()[:8]
    parts = [file_hash, str(line), str(col)]
    if suffix:
        parts.append(suffix)
    return ":".join(parts)


def _make_go_edge_id() -> str:
    global _go_edge_counter
    _go_edge_counter += 1
    return f"goe{_go_edge_counter}"


def _safe_add_edge(cpg: CodePropertyGraph, edge: CPGEdge) -> None:
    if edge.src_id not in cpg.nodes or edge.dst_id not in cpg.nodes:
        return
    for existing in cpg._adj.get(edge.src_id, []):
        if existing.dst_id == edge.dst_id and existing.edge_type == edge.edge_type:
            return
    try:
        cpg.add_edge(edge)
    except ValueError:
        pass


# ---------------------------------------------------------------------------
# GoCPGBuilder
# ---------------------------------------------------------------------------


class GoCPGBuilder:
    """
    Builds a CodePropertyGraph from Go source code using regex-based parsing.

    Pipeline:
    1. Split source into function blocks
    2. For each function/handler, scan lines for sources, sinks, assignments
    3. Build CPGNodes (DFG_SOURCE, DFG_SINK, DFG_DEF, CG_CALL)
    4. Track taint through := assignments
    5. Wire DFG_FLOW edges from source nodes to sink nodes via tainted variables
    6. Wire CFG_NEXT edges between sequential statements
    """

    def build_file(self, path: str) -> CodePropertyGraph:
        """Parse *path* and return its CPG."""
        try:
            source = Path(path).read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.warning("Cannot read %s: %s", path, exc)
            cpg = CodePropertyGraph()
            err_node = CPGNode(
                node_id=_make_go_node_id(path, 0, 0, "parse_error"),
                node_type=CPGNodeType.AST_NODE,
                ast_type="ParseError",
                code=str(exc),
                file=path,
                line=0,
                col=0,
                properties={"error": str(exc)},
            )
            cpg.add_node(err_node)
            return cpg
        return self.build_source(source, file_path=os.path.abspath(path))

    def build_source(self, source: str, file_path: str = "<go>") -> CodePropertyGraph:
        """Parse Go *source* string and return its CPG."""
        cpg = CodePropertyGraph()
        lines = source.splitlines()

        # Extract function blocks
        functions = self._extract_functions(lines)

        if not functions:
            # Treat entire file as one block
            functions = [
                {
                    "name": "__file__",
                    "start_line": 1,
                    "end_line": len(lines),
                    "body_lines": lines,
                }
            ]

        for func in functions:
            self._build_function_cpg(func, file_path, cpg)

        return cpg

    # ------------------------------------------------------------------
    # Function extraction
    # ------------------------------------------------------------------

    def _extract_functions(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extract Go function blocks by brace counting."""
        functions: List[Dict[str, Any]] = []
        n = len(lines)
        i = 0

        while i < n:
            m = _GO_FUNC_START_RE.match(lines[i])
            if m:
                func_name = m.group(1)
                start_line = i + 1  # 1-indexed
                # Brace counting to find end of function
                depth = lines[i].count("{") - lines[i].count("}")
                j = i + 1
                while j < n and depth > 0:
                    depth += lines[j].count("{") - lines[j].count("}")
                    j += 1
                end_line = j  # exclusive
                body_lines = lines[i:j]
                functions.append(
                    {
                        "name": func_name,
                        "start_line": start_line,
                        "end_line": end_line,
                        "body_lines": body_lines,
                    }
                )
                i = j
            else:
                i += 1

        return functions

    # ------------------------------------------------------------------
    # Per-function CPG building
    # ------------------------------------------------------------------

    def _build_function_cpg(
        self,
        func: Dict[str, Any],
        file_path: str,
        cpg: CodePropertyGraph,
    ) -> None:
        """Build CPG nodes/edges for one Go function."""
        func_name = func["name"]
        start_line = func["start_line"]
        body_lines = func["body_lines"]
        base_line = start_line  # line number of first line in body_lines

        # Synthetic ENTRY node
        entry_id = _make_go_node_id(file_path, start_line, 0, f"ENTRY_{func_name}")
        entry_node = CPGNode(
            node_id=entry_id,
            node_type=CPGNodeType.CFG_ENTRY,
            ast_type="CFG_ENTRY",
            code=f"ENTRY:{func_name}",
            file=file_path,
            line=start_line,
            col=0,
            properties={"function": func_name, "go_node": True},
        )
        cpg.add_node(entry_node)

        end_line = func.get("end_line", start_line + len(body_lines))
        exit_id = _make_go_node_id(file_path, end_line, 0, f"EXIT_{func_name}")
        exit_node = CPGNode(
            node_id=exit_id,
            node_type=CPGNodeType.CFG_EXIT,
            ast_type="CFG_EXIT",
            code=f"EXIT:{func_name}",
            file=file_path,
            line=end_line,
            col=0,
            properties={"function": func_name, "go_node": True},
        )
        cpg.add_node(exit_node)

        # Taint tracking state
        # var_name -> list of node_ids that define it (as tainted sources)
        var_defs: Dict[str, List[str]] = {}
        # Set of variable names known to be tainted
        tainted_vars: Set[str] = set()

        stmt_nodes: List[CPGNode] = []

        for idx, raw_line in enumerate(body_lines):
            line_no = base_line + idx
            stripped = raw_line.strip()

            if not stripped or stripped.startswith("//"):
                continue

            # Check if this line is sanitized (sanitizers present on same line)
            line_sanitized = any(san.search(stripped) for san in _ALL_GO_SANITIZERS)

            # Detect source patterns
            source_matched = None
            source_conf = 0.0
            for src_pat, src_label, src_conf_val in _GO_SOURCES:
                if src_pat.search(stripped):
                    source_matched = src_label
                    source_conf = src_conf_val
                    break

            # Detect sink patterns
            sink_cwe = None
            sink_label_str = None
            for cwe, sink_pat, label in _GO_SINK_FLAT:
                if sink_pat.search(stripped):
                    # Check sink-specific sanitizer
                    sink_sanitized = False
                    for san_pat, _ in _GO_SANITIZERS.get(cwe, []):
                        if san_pat.search(stripped):
                            sink_sanitized = True
                            break
                    if not sink_sanitized and not line_sanitized:
                        sink_cwe = cwe
                        sink_label_str = label
                    break

            # Determine assignment: var := expr or var = expr
            assigned_var: Optional[str] = None
            for assign_re in (_GO_SHORT_ASSIGN_RE, _GO_VAR_DECL_RE, _GO_ASSIGN_RE):
                m = assign_re.match(stripped)
                if m:
                    assigned_var = m.group(1)
                    break

            # Decide node type
            if source_matched and not line_sanitized:
                node_type = CPGNodeType.DFG_SOURCE
            elif sink_cwe:
                node_type = CPGNodeType.DFG_SINK
            elif assigned_var:
                node_type = CPGNodeType.DFG_DEF
            elif "(" in stripped:
                node_type = CPGNodeType.CG_CALL
            else:
                node_type = CPGNodeType.CFG_NODE

            props: Dict[str, Any] = {
                "function": func_name,
                "go_node": True,
            }

            if source_matched and not line_sanitized:
                props["is_taint_source"] = True
                props["source_label"] = source_matched
                props["source_confidence"] = source_conf
                if assigned_var:
                    tainted_vars.add(assigned_var)
                    props["defines"] = assigned_var

            if sink_cwe:
                props["is_taint_sink"] = True
                props["sink_cwe"] = sink_cwe
                props["sink_label"] = sink_label_str

            if assigned_var:
                props["defines"] = assigned_var

            col = len(raw_line) - len(raw_line.lstrip())
            nid = _make_go_node_id(
                file_path, line_no, col, f"{func_name}_stmt_{line_no}"
            )

            stmt_node = CPGNode(
                node_id=nid,
                node_type=node_type,
                ast_type=f"Go_{node_type.value.upper()}",
                code=stripped[:200],
                file=file_path,
                line=line_no,
                col=col,
                properties=props,
            )
            cpg.add_node(stmt_node)
            stmt_nodes.append(stmt_node)

            # Track variable definitions for DFG wiring
            if assigned_var:
                var_defs.setdefault(assigned_var, []).append(nid)

            # Propagate taint through assignments
            # If the RHS of the assignment references a tainted var, the LHS is also tainted
            if assigned_var and source_matched is None:
                for tv in list(tainted_vars):
                    # Simple check: does the line mention the tainted variable
                    if re.search(r"\b" + re.escape(tv) + r"\b", stripped):
                        tainted_vars.add(assigned_var)
                        props["tainted_by"] = tv
                        break

        # Wire CFG edges: ENTRY -> stmt[0] -> ... -> stmt[-1] -> EXIT
        if stmt_nodes:
            _safe_add_edge(cpg, CPGEdge(
                edge_id=_make_go_edge_id(),
                src_id=entry_id,
                dst_id=stmt_nodes[0].node_id,
                edge_type=CPGEdgeType.CFG_NEXT,
                properties={"function": func_name},
            ))
            for i in range(len(stmt_nodes) - 1):
                _safe_add_edge(cpg, CPGEdge(
                    edge_id=_make_go_edge_id(),
                    src_id=stmt_nodes[i].node_id,
                    dst_id=stmt_nodes[i + 1].node_id,
                    edge_type=CPGEdgeType.CFG_NEXT,
                    properties={"function": func_name},
                ))
            _safe_add_edge(cpg, CPGEdge(
                edge_id=_make_go_edge_id(),
                src_id=stmt_nodes[-1].node_id,
                dst_id=exit_id,
                edge_type=CPGEdgeType.CFG_NEXT,
                properties={"function": func_name},
            ))
        else:
            _safe_add_edge(cpg, CPGEdge(
                edge_id=_make_go_edge_id(),
                src_id=entry_id,
                dst_id=exit_id,
                edge_type=CPGEdgeType.CFG_NEXT,
                properties={"function": func_name},
            ))

        # Wire DFG_FLOW edges: definition -> use
        # For each stmt node, check if it uses any defined variable
        for stmt_node in stmt_nodes:
            code = stmt_node.code
            for var_name, def_ids in var_defs.items():
                if var_name == stmt_node.properties.get("defines"):
                    continue  # skip self-reference
                if re.search(r"\b" + re.escape(var_name) + r"\b", code):
                    for def_id in def_ids:
                        if def_id != stmt_node.node_id:
                            _safe_add_edge(cpg, CPGEdge(
                                edge_id=_make_go_edge_id(),
                                src_id=def_id,
                                dst_id=stmt_node.node_id,
                                edge_type=CPGEdgeType.DFG_FLOW,
                                properties={
                                    "var": var_name,
                                    "function": func_name,
                                },
                            ))

        # Wire taint flow edges: source nodes -> sink nodes via tainted paths
        source_nodes = [n for n in stmt_nodes if n.properties.get("is_taint_source")]
        sink_nodes = [n for n in stmt_nodes if n.properties.get("is_taint_sink")]

        for src_node in source_nodes:
            src_var = src_node.properties.get("defines", "")
            for sink_node in sink_nodes:
                # Check if sink references a tainted var or if we can trace path
                sink_code = sink_node.code
                # Direct taint: source var used in sink
                if src_var and re.search(r"\b" + re.escape(src_var) + r"\b", sink_code):
                    _safe_add_edge(cpg, CPGEdge(
                        edge_id=_make_go_edge_id(),
                        src_id=src_node.node_id,
                        dst_id=sink_node.node_id,
                        edge_type=CPGEdgeType.DFG_FLOW,
                        properties={
                            "taint_flow": True,
                            "source_var": src_var,
                            "function": func_name,
                        },
                    ))
                else:
                    # Indirect taint: check if any intermediate tainted var reaches sink
                    for tv in tainted_vars:
                        if tv and re.search(r"\b" + re.escape(tv) + r"\b", sink_code):
                            _safe_add_edge(cpg, CPGEdge(
                                edge_id=_make_go_edge_id(),
                                src_id=src_node.node_id,
                                dst_id=sink_node.node_id,
                                edge_type=CPGEdgeType.DFG_FLOW,
                                properties={
                                    "taint_flow": True,
                                    "tainted_var": tv,
                                    "function": func_name,
                                    "indirect": True,
                                },
                            ))
                            break
