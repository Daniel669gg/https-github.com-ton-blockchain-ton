# TythanAI Security Platform
# Copyright (c) 2026 TythanAI Labs
# Licensed under the Business Source License 1.1 (see LICENSE).

"""
backend/core/cpg/java_builder.py — Java CPG builder.

Produces a CodePropertyGraph from Java source code using regex-based parsing
(no external dependencies required).

Supports:
- Servlet-style: request.getParameter, request.getHeader, request.getInputStream
- Spring Boot: @RequestParam, @PathVariable, @RequestBody, System.getenv
- Sinks: Statement.execute/prepareStatement with concat, Runtime.exec,
         ProcessBuilder, new File with user input, response.getWriter().write
- Sanitizers: ESAPI.encoder(), StringEscapeUtils, Encode.forHtml,
              PreparedStatement params

Tracks taint through variable assignments and produces CPGNodes for each
finding (SOURCE/SINK/CALL nodes) and CPGEdges for taint flow.
"""
from __future__ import annotations

import hashlib
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from backend.core.cpg.graph import (
    CPGEdge,
    CPGEdgeType,
    CPGNode,
    CPGNodeType,
    CodePropertyGraph,
)

logger = logging.getLogger("tythanai.java_cpg_builder")

# ---------------------------------------------------------------------------
# Source patterns — user-controlled inputs in Java
# ---------------------------------------------------------------------------

_JAVA_SOURCES: List[Tuple[re.Pattern, str, float]] = [
    # Servlet API
    (re.compile(r'request\.getParameter\s*\('), "request.getParameter (HTTP param)", 0.95),
    (re.compile(r'request\.getHeader\s*\('), "request.getHeader (HTTP header)", 0.90),
    (re.compile(r'request\.getInputStream\s*\(\s*\)'), "request.getInputStream", 0.85),
    (re.compile(r'request\.getQueryString\s*\(\s*\)'), "request.getQueryString", 0.90),
    (re.compile(r'request\.getCookies\s*\(\s*\)'), "request.getCookies", 0.85),
    (re.compile(r'request\.getPathInfo\s*\(\s*\)'), "request.getPathInfo", 0.88),
    (re.compile(r'request\.getRemoteAddr\s*\(\s*\)'), "request.getRemoteAddr", 0.80),
    # System environment
    (re.compile(r'System\.getenv\s*\('), "System.getenv (environment variable)", 0.80),
    # Spring Boot annotations (parameter names in method signatures)
    (re.compile(r'@RequestParam\b'), "@RequestParam (Spring param)", 0.92),
    (re.compile(r'@PathVariable\b'), "@PathVariable (Spring path var)", 0.92),
    (re.compile(r'@RequestBody\b'), "@RequestBody (Spring request body)", 0.90),
    (re.compile(r'@RequestHeader\b'), "@RequestHeader (Spring header)", 0.88),
    # Scanner from stdin
    (re.compile(r'new\s+Scanner\s*\(\s*System\.in'), "Scanner(System.in)", 0.80),
    (re.compile(r'System\.in\.read\b'), "System.in.read", 0.80),
    # HttpServletRequest body reading
    (re.compile(r'new\s+BufferedReader\s*\(\s*new\s+InputStreamReader\s*\(\s*request'), "request body reader", 0.88),
]

# ---------------------------------------------------------------------------
# Sink patterns — grouped by CWE
# ---------------------------------------------------------------------------

_JAVA_SINKS: Dict[str, List[Tuple[re.Pattern, str]]] = {
    "CWE-89": [
        (re.compile(r'\.execute\s*\([^)]*\+'), "Statement.execute with concat (SQLi)"),
        (re.compile(r'prepareStatement\s*\([^)]*\+'), "prepareStatement with string concat"),
        (re.compile(r'createStatement\s*\(\s*\)'), "createStatement (dynamic SQL risk)"),
        (re.compile(r'Statement\.execute\s*\('), "Statement.execute"),
        (re.compile(r'\.executeQuery\s*\([^)]*\+'), "executeQuery with string concat"),
        (re.compile(r'\.executeUpdate\s*\([^)]*\+'), "executeUpdate with string concat"),
        (re.compile(r'EntityManager\.createNativeQuery\s*\([^)]*\+'), "createNativeQuery with concat"),
        (re.compile(r'@Query\s*\(\s*["\']native.*\+'), "Spring @Query native with concat"),
    ],
    "CWE-78": [
        (re.compile(r'Runtime\.getRuntime\s*\(\s*\)\.exec\s*\('), "Runtime.exec (OS command injection)"),
        (re.compile(r'new\s+ProcessBuilder\s*\('), "ProcessBuilder (command injection)"),
        (re.compile(r'new\s+ProcessBuilder\b'), "ProcessBuilder constructor"),
        (re.compile(r'Runtime\.exec\s*\('), "Runtime.exec"),
    ],
    "CWE-22": [
        (re.compile(r'new\s+File\s*\('), "new File() (path traversal)"),
        (re.compile(r'new\s+FileInputStream\s*\('), "new FileInputStream"),
        (re.compile(r'new\s+FileOutputStream\s*\('), "new FileOutputStream"),
        (re.compile(r'Files\.readAllBytes\s*\('), "Files.readAllBytes"),
        (re.compile(r'Paths\.get\s*\([^)]*\+'), "Paths.get with concat"),
        (re.compile(r'new\s+FileReader\s*\('), "new FileReader"),
    ],
    "CWE-79": [
        (re.compile(r'response\.getWriter\s*\(\s*\)\.(?:write|print|println)\s*\('), "response.getWriter().write (XSS)"),
        (re.compile(r'PrintWriter.*\.print(?:ln)?\s*\('), "PrintWriter.println (XSS)"),
        (re.compile(r'response\.getOutputStream\s*\(\s*\)\.write\s*\('), "response.getOutputStream().write"),
        (re.compile(r'out\.print(?:ln)?\s*\('), "out.println (JSP output)"),
    ],
    "CWE-918": [
        (re.compile(r'new\s+URL\s*\('), "new URL() (SSRF)"),
        (re.compile(r'HttpClient.*\.get\s*\(|HttpClient.*\.post\s*\('), "HttpClient request"),
        (re.compile(r'RestTemplate.*\.(?:get|post|exchange)\s*\('), "RestTemplate request"),
        (re.compile(r'WebClient.*\.(?:get|post)\s*\(\s*\)'), "WebClient request"),
    ],
    "CWE-502": [
        (re.compile(r'ObjectInputStream\s*\('), "ObjectInputStream (deserialization)"),
        (re.compile(r'\.readObject\s*\(\s*\)'), ".readObject() deserialization"),
        (re.compile(r'XStream\.fromXML\s*\('), "XStream.fromXML"),
        (re.compile(r'new\s+XmlDecoder\s*\('), "XmlDecoder"),
    ],
}

_JAVA_SINK_FLAT: List[Tuple[str, re.Pattern, str]] = [
    (cwe, pat, label)
    for cwe, items in _JAVA_SINKS.items()
    for (pat, label) in items
]

# ---------------------------------------------------------------------------
# Sanitizer patterns
# ---------------------------------------------------------------------------

_JAVA_SANITIZERS: Dict[str, List[Tuple[re.Pattern, str]]] = {
    "CWE-89": [
        (re.compile(r'PreparedStatement|prepareStatement\s*\('), "PreparedStatement"),
        (re.compile(r'\?\s*,|\?\s*\)|\?\s*;'), "JDBC parameter placeholder (?)"),
        (re.compile(r'NamedParameterJdbcTemplate'), "NamedParameterJdbcTemplate"),
        (re.compile(r'@Param\s*\(|:param'), "named JPA param"),
    ],
    "CWE-79": [
        (re.compile(r'ESAPI\.encoder\(\)\.encodeForHTML'), "ESAPI.encodeForHTML"),
        (re.compile(r'StringEscapeUtils\.escapeHtml'), "StringEscapeUtils.escapeHtml"),
        (re.compile(r'Encode\.forHtml\s*\('), "Encode.forHtml (OWASP Java Encoder)"),
        (re.compile(r'HtmlUtils\.htmlEscape\s*\('), "HtmlUtils.htmlEscape (Spring)"),
    ],
    "CWE-78": [
        (re.compile(r'ProcessBuilder\s*\([^)]*Arrays\.asList'), "ProcessBuilder with list args"),
        (re.compile(r'new\s+String\[\]\s*\{'), "command array literal"),
        (re.compile(r'ESAPI\.encoder\(\)\.encodeForOS'), "ESAPI.encodeForOS"),
    ],
    "CWE-22": [
        (re.compile(r'\.getCanonicalPath\s*\(\s*\)'), "getCanonicalPath()"),
        (re.compile(r'\.startsWith\s*\('), ".startsWith() base check"),
        (re.compile(r'FilenameUtils\.getName\s*\('), "FilenameUtils.getName"),
    ],
}

_ALL_JAVA_SANITIZERS: List[re.Pattern] = [
    re.compile(r'ESAPI\.encoder\(\)'),
    re.compile(r'StringEscapeUtils\.escape'),
    re.compile(r'Encode\.for(?:Html|Xml|JavaScript|CSS)'),
    re.compile(r'PreparedStatement'),
    re.compile(r'\.getCanonicalPath\s*\(\)'),
    re.compile(r'HtmlUtils\.htmlEscape'),
    re.compile(r'FilenameUtils\.getName\s*\('),
]

# Severity mapping per CWE
_CWE_SEVERITY: Dict[str, str] = {
    "CWE-89": "HIGH",
    "CWE-79": "HIGH",
    "CWE-78": "CRITICAL",
    "CWE-22": "HIGH",
    "CWE-918": "HIGH",
    "CWE-502": "CRITICAL",
}

_CWE_NAMES: Dict[str, str] = {
    "CWE-89": "SQL Injection",
    "CWE-79": "Cross-site Scripting (XSS)",
    "CWE-78": "OS Command Injection",
    "CWE-22": "Path Traversal",
    "CWE-918": "Server-Side Request Forgery (SSRF)",
    "CWE-502": "Deserialization of Untrusted Data",
}

# ---------------------------------------------------------------------------
# Java parsing helpers
# ---------------------------------------------------------------------------

# Variable assignment: Type varName = expr  or  varName = expr
_JAVA_TYPED_ASSIGN_RE = re.compile(
    r"^\s*(?:(?:final\s+)?[\w<>\[\].]+\s+)?([A-Za-z_$][\w$]*)\s*=\s*(.+)"
)
# Java method definition
_JAVA_METHOD_START_RE = re.compile(
    r"""
    ^\s*
    (?:(?:public|private|protected|static|final|synchronized|abstract|default|native)\s+)*
    (?:[\w<>\[\].,\s]+\s+)?  # return type
    ([A-Za-z_$][\w$]*)\s*    # method name
    \(                         # opening paren
    """,
    re.VERBOSE,
)
# Annotation pattern
_JAVA_ANNOTATION_RE = re.compile(r"^\s*@(\w+)")

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_java_edge_counter = 0


def _make_java_node_id(file_path: str, line: int, col: int, suffix: str = "") -> str:
    file_hash = hashlib.sha256(file_path.encode()).hexdigest()[:8]
    parts = [file_hash, str(line), str(col)]
    if suffix:
        parts.append(suffix)
    return ":".join(parts)


def _make_java_edge_id() -> str:
    global _java_edge_counter
    _java_edge_counter += 1
    return f"jave{_java_edge_counter}"


def _safe_add_edge(cpg: CodePropertyGraph, edge: CPGEdge) -> None:
    if edge.src_id not in cpg.nodes or edge.dst_id not in cpg.nodes:
        return
    for existing in cpg._adj.get(edge.src_id, []):
        if existing.dst_id == edge.dst_id and existing.edge_type == edge.edge_type:
            return
    try:
        cpg.add_edge(edge)
    except ValueError:
        pass


# ---------------------------------------------------------------------------
# JavaCPGBuilder
# ---------------------------------------------------------------------------


class JavaCPGBuilder:
    """
    Builds a CodePropertyGraph from Java source code using regex-based parsing.

    Handles:
    - Servlet-style request handling
    - Spring Boot @RequestParam / @PathVariable / @RequestBody annotations
    - SQL injection via Statement / PreparedStatement misuse
    - Command injection via Runtime.exec / ProcessBuilder
    - Path traversal via new File() with user input
    - XSS via response.getWriter().write() with unsanitized data
    """

    def build_file(self, path: str) -> CodePropertyGraph:
        """Parse *path* and return its CPG."""
        try:
            source = Path(path).read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.warning("Cannot read %s: %s", path, exc)
            cpg = CodePropertyGraph()
            err_node = CPGNode(
                node_id=_make_java_node_id(path, 0, 0, "parse_error"),
                node_type=CPGNodeType.AST_NODE,
                ast_type="ParseError",
                code=str(exc),
                file=path,
                line=0,
                col=0,
                properties={"error": str(exc)},
            )
            cpg.add_node(err_node)
            return cpg
        return self.build_source(source, file_path=os.path.abspath(path))

    def build_source(self, source: str, file_path: str = "<java>") -> CodePropertyGraph:
        """Parse Java *source* string and return its CPG."""
        cpg = CodePropertyGraph()
        lines = source.splitlines()

        # Extract method blocks
        methods = self._extract_methods(lines)

        if not methods:
            # Treat entire file as single block
            methods = [
                {
                    "name": "__class__",
                    "start_line": 1,
                    "end_line": len(lines),
                    "body_lines": lines,
                    "annotations": [],
                }
            ]

        for method in methods:
            self._build_method_cpg(method, file_path, cpg)

        return cpg

    # ------------------------------------------------------------------
    # Method extraction
    # ------------------------------------------------------------------

    def _extract_methods(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extract Java method blocks by brace counting."""
        methods: List[Dict[str, Any]] = []
        n = len(lines)
        i = 0
        pending_annotations: List[str] = []

        while i < n:
            raw = lines[i]
            stripped = raw.strip()

            # Collect annotations
            ann_m = _JAVA_ANNOTATION_RE.match(stripped)
            if ann_m and not stripped.endswith("{"):
                pending_annotations.append(ann_m.group(1))
                i += 1
                continue

            # Look for method start (line with opening brace)
            if "{" in stripped:
                mm = _JAVA_METHOD_START_RE.match(raw)
                if mm:
                    method_name = mm.group(1)
                    # Skip keywords that are not method names
                    if method_name in (
                        "if", "else", "for", "while", "try", "catch",
                        "switch", "synchronized", "finally", "class",
                        "interface", "enum", "new",
                    ):
                        pending_annotations = []
                        i += 1
                        continue

                    start_line = i + 1  # 1-indexed
                    depth = stripped.count("{") - stripped.count("}")
                    j = i + 1
                    while j < n and depth > 0:
                        depth += lines[j].count("{") - lines[j].count("}")
                        j += 1

                    body_lines = lines[i:j]
                    methods.append(
                        {
                            "name": method_name,
                            "start_line": start_line,
                            "end_line": j,
                            "body_lines": body_lines,
                            "annotations": list(pending_annotations),
                        }
                    )
                    pending_annotations = []
                    i = j
                    continue

            pending_annotations = []
            i += 1

        return methods

    # ------------------------------------------------------------------
    # Per-method CPG building
    # ------------------------------------------------------------------

    def _build_method_cpg(
        self,
        method: Dict[str, Any],
        file_path: str,
        cpg: CodePropertyGraph,
    ) -> None:
        """Build CPG nodes/edges for one Java method."""
        method_name = method["name"]
        start_line = method["start_line"]
        body_lines = method["body_lines"]
        annotations = method.get("annotations", [])
        base_line = start_line

        # Check if method has Spring request mapping annotations
        is_request_handler = any(
            a in annotations
            for a in ("GetMapping", "PostMapping", "PutMapping", "DeleteMapping",
                       "RequestMapping", "PatchMapping")
        )

        # Synthetic ENTRY
        entry_id = _make_java_node_id(file_path, start_line, 0, f"ENTRY_{method_name}")
        entry_node = CPGNode(
            node_id=entry_id,
            node_type=CPGNodeType.CFG_ENTRY,
            ast_type="CFG_ENTRY",
            code=f"ENTRY:{method_name}",
            file=file_path,
            line=start_line,
            col=0,
            properties={
                "function": method_name,
                "java_node": True,
                "is_request_handler": is_request_handler,
                "annotations": annotations,
            },
        )
        cpg.add_node(entry_node)

        end_line = method.get("end_line", start_line + len(body_lines))
        exit_id = _make_java_node_id(file_path, end_line, 0, f"EXIT_{method_name}")
        exit_node = CPGNode(
            node_id=exit_id,
            node_type=CPGNodeType.CFG_EXIT,
            ast_type="CFG_EXIT",
            code=f"EXIT:{method_name}",
            file=file_path,
            line=end_line,
            col=0,
            properties={"function": method_name, "java_node": True},
        )
        cpg.add_node(exit_node)

        # Taint tracking
        var_defs: Dict[str, List[str]] = {}
        tainted_vars: Set[str] = set()

        # Scan method signature for Spring annotations
        # Parameters annotated with @RequestParam etc. are taint sources
        signature_line = body_lines[0] if body_lines else ""
        spring_param_sources = self._extract_spring_params(signature_line, annotations)
        for param_name in spring_param_sources:
            tainted_vars.add(param_name)

        stmt_nodes: List[CPGNode] = []

        for idx, raw_line in enumerate(body_lines):
            line_no = base_line + idx
            stripped = raw_line.strip()

            if not stripped or stripped.startswith("//") or stripped.startswith("*"):
                continue

            # Check global sanitization on this line
            line_sanitized = any(san.search(stripped) for san in _ALL_JAVA_SANITIZERS)

            # Detect source
            source_matched = None
            source_conf = 0.0
            for src_pat, src_label, src_conf_val in _JAVA_SOURCES:
                if src_pat.search(stripped):
                    source_matched = src_label
                    source_conf = src_conf_val
                    break

            # Detect sink
            sink_cwe = None
            sink_label_str = None
            for cwe, sink_pat, label in _JAVA_SINK_FLAT:
                if sink_pat.search(stripped):
                    sink_sanitized = False
                    for san_pat, _ in _JAVA_SANITIZERS.get(cwe, []):
                        if san_pat.search(stripped):
                            sink_sanitized = True
                            break
                    if not sink_sanitized and not line_sanitized:
                        sink_cwe = cwe
                        sink_label_str = label
                    break

            # Detect assignment target
            assigned_var: Optional[str] = None
            m = _JAVA_TYPED_ASSIGN_RE.match(stripped)
            if m:
                candidate = m.group(1)
                # Filter out keywords / types
                if candidate not in (
                    "if", "else", "for", "while", "return", "throw",
                    "new", "true", "false", "null", "this", "super",
                    "class", "interface", "enum", "static", "final",
                ):
                    assigned_var = candidate

            # Determine node type
            if source_matched and not line_sanitized:
                node_type = CPGNodeType.DFG_SOURCE
            elif sink_cwe:
                node_type = CPGNodeType.DFG_SINK
            elif assigned_var:
                node_type = CPGNodeType.DFG_DEF
            elif "(" in stripped:
                node_type = CPGNodeType.CG_CALL
            else:
                node_type = CPGNodeType.CFG_NODE

            props: Dict[str, Any] = {
                "function": method_name,
                "java_node": True,
            }

            if source_matched and not line_sanitized:
                props["is_taint_source"] = True
                props["source_label"] = source_matched
                props["source_confidence"] = source_conf
                if assigned_var:
                    tainted_vars.add(assigned_var)

            if sink_cwe:
                props["is_taint_sink"] = True
                props["sink_cwe"] = sink_cwe
                props["sink_label"] = sink_label_str

            if assigned_var:
                props["defines"] = assigned_var

            col = len(raw_line) - len(raw_line.lstrip())
            nid = _make_java_node_id(
                file_path, line_no, col, f"{method_name}_stmt_{line_no}"
            )

            stmt_node = CPGNode(
                node_id=nid,
                node_type=node_type,
                ast_type=f"Java_{node_type.value.upper()}",
                code=stripped[:200],
                file=file_path,
                line=line_no,
                col=col,
                properties=props,
            )
            cpg.add_node(stmt_node)
            stmt_nodes.append(stmt_node)

            if assigned_var:
                var_defs.setdefault(assigned_var, []).append(nid)

            # Propagate taint through assignments
            if assigned_var and source_matched is None:
                for tv in list(tainted_vars):
                    if re.search(r"\b" + re.escape(tv) + r"\b", stripped):
                        tainted_vars.add(assigned_var)
                        break

        # Add Spring param source nodes if method is a handler and has tainted params
        if spring_param_sources and is_request_handler:
            param_source_id = _make_java_node_id(
                file_path, start_line, 0, f"{method_name}_spring_params"
            )
            if param_source_id not in cpg.nodes:
                param_node = CPGNode(
                    node_id=param_source_id,
                    node_type=CPGNodeType.DFG_SOURCE,
                    ast_type="SpringParamSource",
                    code=f"@RequestParam/@PathVariable: {', '.join(spring_param_sources)}",
                    file=file_path,
                    line=start_line,
                    col=0,
                    properties={
                        "function": method_name,
                        "java_node": True,
                        "is_taint_source": True,
                        "source_label": "Spring request parameter",
                        "source_confidence": 0.92,
                        "defines": spring_param_sources[0] if spring_param_sources else "",
                        "spring_params": spring_param_sources,
                    },
                )
                cpg.add_node(param_node)
                stmt_nodes.insert(0, param_node)
                for param_name in spring_param_sources:
                    var_defs.setdefault(param_name, []).append(param_source_id)

        # Wire CFG edges
        if stmt_nodes:
            _safe_add_edge(cpg, CPGEdge(
                edge_id=_make_java_edge_id(),
                src_id=entry_id,
                dst_id=stmt_nodes[0].node_id,
                edge_type=CPGEdgeType.CFG_NEXT,
                properties={"function": method_name},
            ))
            for i in range(len(stmt_nodes) - 1):
                _safe_add_edge(cpg, CPGEdge(
                    edge_id=_make_java_edge_id(),
                    src_id=stmt_nodes[i].node_id,
                    dst_id=stmt_nodes[i + 1].node_id,
                    edge_type=CPGEdgeType.CFG_NEXT,
                    properties={"function": method_name},
                ))
            _safe_add_edge(cpg, CPGEdge(
                edge_id=_make_java_edge_id(),
                src_id=stmt_nodes[-1].node_id,
                dst_id=exit_id,
                edge_type=CPGEdgeType.CFG_NEXT,
                properties={"function": method_name},
            ))
        else:
            _safe_add_edge(cpg, CPGEdge(
                edge_id=_make_java_edge_id(),
                src_id=entry_id,
                dst_id=exit_id,
                edge_type=CPGEdgeType.CFG_NEXT,
                properties={"function": method_name},
            ))

        # Wire DFG_FLOW edges: definition -> use
        for stmt_node in stmt_nodes:
            code = stmt_node.code
            for var_name, def_ids in var_defs.items():
                if var_name == stmt_node.properties.get("defines"):
                    continue
                if re.search(r"\b" + re.escape(var_name) + r"\b", code):
                    for def_id in def_ids:
                        if def_id != stmt_node.node_id:
                            _safe_add_edge(cpg, CPGEdge(
                                edge_id=_make_java_edge_id(),
                                src_id=def_id,
                                dst_id=stmt_node.node_id,
                                edge_type=CPGEdgeType.DFG_FLOW,
                                properties={
                                    "var": var_name,
                                    "function": method_name,
                                },
                            ))

        # Wire taint flow: source -> sink via tainted variables
        source_nodes = [n for n in stmt_nodes if n.properties.get("is_taint_source")]
        sink_nodes = [n for n in stmt_nodes if n.properties.get("is_taint_sink")]

        for src_node in source_nodes:
            src_var = src_node.properties.get("defines", "")
            spring_params = src_node.properties.get("spring_params", [])
            all_src_vars = ([src_var] if src_var else []) + spring_params

            for sink_node in sink_nodes:
                sink_code = sink_node.code
                found_taint = False

                # Direct: source var used in sink
                for sv in all_src_vars:
                    if sv and re.search(r"\b" + re.escape(sv) + r"\b", sink_code):
                        _safe_add_edge(cpg, CPGEdge(
                            edge_id=_make_java_edge_id(),
                            src_id=src_node.node_id,
                            dst_id=sink_node.node_id,
                            edge_type=CPGEdgeType.DFG_FLOW,
                            properties={
                                "taint_flow": True,
                                "source_var": sv,
                                "function": method_name,
                            },
                        ))
                        found_taint = True
                        break

                # Indirect: tainted variable used in sink
                if not found_taint:
                    for tv in tainted_vars:
                        if tv and re.search(r"\b" + re.escape(tv) + r"\b", sink_code):
                            _safe_add_edge(cpg, CPGEdge(
                                edge_id=_make_java_edge_id(),
                                src_id=src_node.node_id,
                                dst_id=sink_node.node_id,
                                edge_type=CPGEdgeType.DFG_FLOW,
                                properties={
                                    "taint_flow": True,
                                    "tainted_var": tv,
                                    "function": method_name,
                                    "indirect": True,
                                },
                            ))
                            break

    def _extract_spring_params(
        self, signature_line: str, annotations: List[str]
    ) -> List[str]:
        """
        Extract parameter names from Spring @RequestParam / @PathVariable / @RequestBody
        annotated method signatures.
        """
        params: List[str] = []
        # Match pattern: @RequestParam ... Type paramName
        for ann_type in ("RequestParam", "PathVariable", "RequestBody", "RequestHeader"):
            pattern = re.compile(
                r"@" + ann_type + r"[^)]*\)\s+[\w<>\[\].,]+\s+(\w+)"
                r"|"
                r"@" + ann_type + r"\s+[\w<>\[\].,]+\s+(\w+)"
            )
            for m in pattern.finditer(signature_line):
                param_name = m.group(1) or m.group(2)
                if param_name:
                    params.append(param_name)

        return params
