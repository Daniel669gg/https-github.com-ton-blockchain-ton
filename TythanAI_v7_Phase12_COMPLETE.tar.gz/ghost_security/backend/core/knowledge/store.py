"""
backend/core/knowledge/store.py — Security knowledge store with query API.

Provides in-memory storage for VulnerabilityKnowledge entries and efficient
lookup by CWE ID, OWASP category, severity, CVSS range, and free-text search.
Seeded automatically from built_in_data.py.
"""
from __future__ import annotations

import logging
import re
from typing import Callable, List, Optional

from .models import (
    CAPECEntry, CVEEntry, CWEEntry, ExploitPattern,
    FixPattern, VulnerabilityKnowledge,
)
from .built_in_data import BUILT_IN_KNOWLEDGE, CVE_ENTRIES, CWE_ENTRIES, CAPEC_ENTRIES

logger = logging.getLogger("tythanai.knowledge.store")


class KnowledgeStore:
    """
    Central repository for vulnerability knowledge.

    Backed by in-memory dicts; pre-seeded with OWASP Top 10 entries.
    Supports CRUD operations and multiple query strategies.
    """

    def __init__(self, seed_built_in: bool = True) -> None:
        self._knowledge: dict[str, VulnerabilityKnowledge] = {}
        self._cwe_index: dict[str, list[str]] = {}   # cwe_id -> [knowledge_id, ...]
        self._owasp_index: dict[str, list[str]] = {}  # owasp_cat -> [knowledge_id, ...]

        if seed_built_in:
            for entry in BUILT_IN_KNOWLEDGE.values():
                self.add(entry)
            logger.debug("KnowledgeStore seeded with %d built-in entries", len(self._knowledge))

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def add(self, knowledge: VulnerabilityKnowledge) -> None:
        """Add or replace a knowledge entry."""
        self._knowledge[knowledge.knowledge_id] = knowledge

        # Update CWE index
        cwe_id = knowledge.cwe.cwe_id
        self._cwe_index.setdefault(cwe_id, [])
        if knowledge.knowledge_id not in self._cwe_index[cwe_id]:
            self._cwe_index[cwe_id].append(knowledge.knowledge_id)

        # Update OWASP index
        cat = knowledge.owasp_category
        self._owasp_index.setdefault(cat, [])
        if knowledge.knowledge_id not in self._owasp_index[cat]:
            self._owasp_index[cat].append(knowledge.knowledge_id)

    def remove(self, knowledge_id: str) -> bool:
        """Remove an entry by ID. Returns True if removed."""
        entry = self._knowledge.pop(knowledge_id, None)
        if entry is None:
            return False
        # Clean up indexes
        cid = entry.cwe.cwe_id
        if cid in self._cwe_index:
            self._cwe_index[cid] = [x for x in self._cwe_index[cid] if x != knowledge_id]
        cat = entry.owasp_category
        if cat in self._owasp_index:
            self._owasp_index[cat] = [x for x in self._owasp_index[cat] if x != knowledge_id]
        return True

    # ------------------------------------------------------------------
    # Lookup helpers
    # ------------------------------------------------------------------

    def get(self, knowledge_id: str) -> Optional[VulnerabilityKnowledge]:
        """Return entry by knowledge_id, or None."""
        return self._knowledge.get(knowledge_id)

    def get_by_cwe(self, cwe_id: str) -> List[VulnerabilityKnowledge]:
        """Return all knowledge entries that cover the given CWE."""
        ids = self._cwe_index.get(cwe_id, [])
        return [self._knowledge[i] for i in ids if i in self._knowledge]

    def get_by_owasp(self, owasp_category: str) -> List[VulnerabilityKnowledge]:
        """Return all entries in an OWASP Top 10 category (e.g. 'A03:2021')."""
        ids = self._owasp_index.get(owasp_category, [])
        return [self._knowledge[i] for i in ids if i in self._knowledge]

    def get_exploit_patterns(self, cwe_id: str) -> List[ExploitPattern]:
        """Return all ExploitPattern objects for a given CWE."""
        entries = self.get_by_cwe(cwe_id)
        patterns: list[ExploitPattern] = []
        for e in entries:
            patterns.extend(e.exploit_patterns)
        return patterns

    def get_fix_patterns(self, cwe_id: str) -> List[FixPattern]:
        """Return all FixPattern objects for a given CWE."""
        entries = self.get_by_cwe(cwe_id)
        fixes: list[FixPattern] = []
        for e in entries:
            fixes.extend(e.fix_patterns)
        return fixes

    def get_cve(self, cve_id: str) -> Optional[CVEEntry]:
        """Look up a CVE by ID across all knowledge entries."""
        for e in self._knowledge.values():
            for cve in e.related_cves:
                if cve.cve_id == cve_id:
                    return cve
        return None

    def get_high_risk(self, min_score: float = 80.0) -> List[VulnerabilityKnowledge]:
        """Return all entries with risk_score >= min_score, sorted descending."""
        return sorted(
            [e for e in self._knowledge.values() if e.risk_score >= min_score],
            key=lambda x: x.risk_score,
            reverse=True,
        )

    def get_kev_cves(self) -> List[CVEEntry]:
        """Return all CVEs in the store that are CISA Known Exploited Vulnerabilities."""
        result: list[CVEEntry] = []
        for e in self._knowledge.values():
            for cve in e.related_cves:
                if cve.is_kev:
                    result.append(cve)
        return result

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(
        self,
        query: str,
        *,
        max_results: int = 10,
    ) -> List[VulnerabilityKnowledge]:
        """
        Full-text search across knowledge_id, CWE name/description,
        owasp_category, and CVE IDs.  Case-insensitive.  Returns up to
        max_results entries ranked by relevance score.
        """
        q = query.lower()
        scored: list[tuple[float, VulnerabilityKnowledge]] = []

        for entry in self._knowledge.values():
            score = 0.0

            # Exact knowledge_id match
            if q in entry.knowledge_id.lower():
                score += 4.0

            # CWE ID exact match
            if q == entry.cwe.cwe_id.lower():
                score += 5.0

            # CWE name match
            if q in entry.cwe.name.lower():
                score += 3.0

            # OWASP category
            if q in entry.owasp_category.lower():
                score += 2.0

            # Description keyword
            if q in entry.cwe.description.lower():
                score += 1.5

            # CVE ID match
            for cve in entry.related_cves:
                if q in cve.cve_id.lower():
                    score += 3.0
                    break

            # Exploit pattern name
            for ep in entry.exploit_patterns:
                if q in ep.name.lower():
                    score += 1.0
                    break

            if score > 0:
                scored.append((score, entry))

        scored.sort(key=lambda t: t[0], reverse=True)
        return [e for _, e in scored[:max_results]]

    def filter(
        self,
        predicate: Callable[[VulnerabilityKnowledge], bool],
    ) -> List[VulnerabilityKnowledge]:
        """Return all entries satisfying predicate."""
        return [e for e in self._knowledge.values() if predicate(e)]

    # ------------------------------------------------------------------
    # Stats / introspection
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._knowledge)

    def all_cwe_ids(self) -> List[str]:
        """Return sorted list of all CWE IDs in the store."""
        return sorted(self._cwe_index.keys())

    def all_owasp_categories(self) -> List[str]:
        """Return sorted list of all OWASP categories in the store."""
        return sorted(self._owasp_index.keys())

    def stats(self) -> dict:
        """Return a summary dict for logging/monitoring."""
        total_cves = sum(len(e.related_cves) for e in self._knowledge.values())
        total_exploits = sum(len(e.exploit_patterns) for e in self._knowledge.values())
        total_fixes = sum(len(e.fix_patterns) for e in self._knowledge.values())
        return {
            "total_knowledge_entries": len(self._knowledge),
            "total_cve_entries": total_cves,
            "total_exploit_patterns": total_exploits,
            "total_fix_patterns": total_fixes,
            "cwe_ids_covered": len(self._cwe_index),
            "owasp_categories": len(self._owasp_index),
        }
