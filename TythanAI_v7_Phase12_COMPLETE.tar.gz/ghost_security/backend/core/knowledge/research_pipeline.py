"""
backend/core/knowledge/research_pipeline.py — Automated vulnerability research pipeline.

Converts raw CVE/CWE descriptions into actionable detection rules and knowledge entries.

Pipeline stages:
  1. Parse — extract structured metadata from CVE/CWE text
  2. Pattern extraction — derive code-level detection patterns from descriptions
  3. Rule synthesis — generate taint-analysis rule configurations
  4. Validation — verify rules produce correct results on reference snippets
  5. Integration — add validated rules to the KnowledgeStore
"""
from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from typing import List, Optional

from .models import CWEEntry, CVEEntry, ExploitPattern, FixPattern, VulnerabilityKnowledge
from .store import KnowledgeStore

logger = logging.getLogger("tythanai.knowledge.research")


# ---------------------------------------------------------------------------
# Pipeline result types
# ---------------------------------------------------------------------------

@dataclass
class ParsedCVE:
    """Structured output from the CVE parsing stage."""
    cve_id: str
    cvss_v3: float
    severity: str
    cwe_ids: list[str]
    affected_products: list[str]
    attack_vector: str          # NETWORK, ADJACENT, LOCAL, PHYSICAL
    attack_complexity: str      # LOW, HIGH
    code_patterns: list[str]    # regex strings extracted from description
    exploitation_description: str


@dataclass
class SynthesizedRule:
    """A taint-analysis detection rule synthesized from a CVE/CWE."""
    rule_id: str
    name: str
    cwe_id: str
    source_patterns: list[str]
    sink_patterns: list[str]
    sanitizer_patterns: list[str]
    confidence_score: float     # expected confidence 0.0-1.0
    validated: bool = False
    validation_tp: int = 0
    validation_fp: int = 0
    validation_fn: int = 0


@dataclass
class PipelineResult:
    """Full result of one pipeline run."""
    cve_id: str
    cwe_ids: list[str]
    parsed: ParsedCVE
    rules: list[SynthesizedRule]
    knowledge_entry: Optional[VulnerabilityKnowledge]
    added_to_store: bool = False
    validation_passed: bool = False
    errors: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Pipeline stages
# ---------------------------------------------------------------------------

class CVEParser:
    """Stage 1 — Parse a CVE description into structured metadata."""

    # CVSSv3 vector component extraction
    _AV_MAP = {"N": "NETWORK", "A": "ADJACENT", "L": "LOCAL", "P": "PHYSICAL"}
    _AC_MAP = {"L": "LOW", "H": "HIGH"}

    # CWE keyword hints for automatic CWE assignment from description
    _KEYWORD_CWE: list[tuple[re.Pattern, str]] = [
        (re.compile(r'\bSQL\b.*inject|inject.*\bSQL\b', re.I), "CWE-89"),
        (re.compile(r'cross.site.script|XSS', re.I), "CWE-79"),
        (re.compile(r'command.inject|OS.command|shell.inject', re.I), "CWE-78"),
        (re.compile(r'path.travers|directory.travers', re.I), "CWE-22"),
        (re.compile(r'server.side.request|SSRF', re.I), "CWE-918"),
        (re.compile(r'hardcoded.credent|hard.coded.password', re.I), "CWE-798"),
        (re.compile(r'deserializ', re.I), "CWE-502"),
        (re.compile(r'template.inject|SSTI', re.I), "CWE-94"),
        (re.compile(r'broken.crypto|weak.cipher|RC4|DES\b|MD5\b|SHA.?1\b', re.I), "CWE-327"),
    ]

    def parse(self, cve_id: str, description: str, cvss_vector: str = "",
              known_cwe_ids: Optional[list[str]] = None) -> ParsedCVE:
        cvss_v3, severity = self._parse_cvss(cvss_vector)
        av, ac = self._extract_av_ac(cvss_vector)
        cwe_ids = list(known_cwe_ids or [])
        if not cwe_ids:
            cwe_ids = self._infer_cwe(description)
        code_patterns = self._extract_code_patterns(description)
        affected = self._extract_affected(description)

        return ParsedCVE(
            cve_id=cve_id,
            cvss_v3=cvss_v3,
            severity=severity,
            cwe_ids=cwe_ids,
            affected_products=affected,
            attack_vector=av,
            attack_complexity=ac,
            code_patterns=code_patterns,
            exploitation_description=self._extract_exploit_description(description),
        )

    def _parse_cvss(self, vector: str) -> tuple[float, str]:
        # Try to extract score from vector string like "CVSS:3.1/.../AV:N..."
        # We use a simple lookup table based on AV+AC+PR+UI combination
        if not vector:
            return 7.5, "HIGH"
        # Extract base score components
        score = 7.5
        severity = "HIGH"
        if "/C:H/I:H/A:H" in vector:
            score = 9.8
            severity = "CRITICAL"
        elif "/C:H/I:H" in vector or "/C:H/I:L/A:" in vector:
            score = 8.6
            severity = "HIGH"
        elif "/C:H/I:N/" in vector:
            score = 7.5
            severity = "HIGH"
        elif "/C:L/I:L/" in vector:
            score = 5.3
            severity = "MEDIUM"
        return score, severity

    def _extract_av_ac(self, vector: str) -> tuple[str, str]:
        av = "NETWORK"
        ac = "LOW"
        m = re.search(r'AV:([NALP])', vector)
        if m:
            av = self._AV_MAP.get(m.group(1), "NETWORK")
        m = re.search(r'AC:([LH])', vector)
        if m:
            ac = self._AC_MAP.get(m.group(1), "LOW")
        return av, ac

    def _infer_cwe(self, description: str) -> list[str]:
        cwes = []
        for pattern, cwe_id in self._KEYWORD_CWE:
            if pattern.search(description):
                cwes.append(cwe_id)
        return cwes or ["CWE-20"]  # default to improper input validation

    def _extract_code_patterns(self, description: str) -> list[str]:
        """Extract code-level patterns mentioned in description (function names, API calls)."""
        patterns = []
        # Function/method names
        for m in re.finditer(r'`([^`]+\()`|`([^`]+)`', description):
            val = m.group(1) or m.group(2)
            if val and re.search(r'\w', val):
                # Escape and make into a simple regex
                escaped = re.escape(val.split('(')[0].strip())
                if escaped:
                    patterns.append(escaped + r'\s*\(')
        # JNDI-style injection patterns
        if re.search(r'JNDI|jndi', description):
            patterns.append(r'\$\{jndi:')
        # OGNL patterns
        if re.search(r'OGNL', description):
            patterns.append(r'\$\{.*\(')
        return patterns

    def _extract_affected(self, description: str) -> list[str]:
        """Extract affected software names from description."""
        matches = re.findall(r'(?:Apache|Spring|Microsoft|OpenSSL|Log4j)\s+\S+(?:\s+\d[\d.x -]*)?', description)
        return list(dict.fromkeys(matches))  # deduplicate while preserving order

    def _extract_exploit_description(self, description: str) -> str:
        # Take the first sentence that mentions attacker or exploit
        for sentence in re.split(r'(?<=[.!?])\s+', description):
            if re.search(r'attacker|exploit|inject|bypass|execut', sentence, re.I):
                return sentence.strip()
        return description[:200].strip()


class PatternExtractor:
    """Stage 2 — Derive source/sink/sanitizer patterns for a given CWE."""

    _SOURCE_PATTERNS: dict[str, list[str]] = {
        "CWE-89": [r'request\.args\.get\s*\(', r'request\.form\.get\s*\(', r'request\.values\.get\s*\(', r'input\s*\('],
        "CWE-79": [r'request\.args\.get\s*\(', r'request\.form\.get\s*\(', r'request\.json\s*\.get\s*\('],
        "CWE-78": [r'request\.args\.get\s*\(', r'request\.form\.get\s*\(', r'input\s*\(', r'sys\.argv'],
        "CWE-22": [r'request\.args\.get\s*\(', r'request\.form\.get\s*\(', r'request\.files\b'],
        "CWE-918": [r'request\.args\.get\s*\(', r'request\.form\.get\s*\(', r'request\.json\s*\.get\s*\('],
        "CWE-94": [r'request\.args\.get\s*\(', r'request\.form\.get\s*\('],
        "CWE-502": [r'request\.data\b', r'request\.get_data\s*\(', r'socket\.recv\s*\('],
    }

    _SINK_PATTERNS: dict[str, list[str]] = {
        "CWE-89": [r'cursor\.execute\s*\(', r'db\.execute\s*\(', r'\.raw\s*\(', r'\.filter\s*\(raw'],
        "CWE-79": [r'return\s+.*<[^>]+>.*\+', r'render_template_string\s*\(', r'make_response\s*\('],
        "CWE-78": [r'os\.system\s*\(', r'subprocess\.(run|call|Popen)\s*\(', r'eval\s*\('],
        "CWE-22": [r'open\s*\(', r'pathlib\.Path\s*\(', r'send_file\s*\(', r'os\.path\.join\s*\('],
        "CWE-918": [r'requests\.(get|post|put|delete)\s*\(', r'urllib\.request\.urlopen\s*\(', r'httpx\.(get|post)\s*\('],
        "CWE-94": [r'render_template_string\s*\(', r'Template\s*\(', r'from_string\s*\(', r'eval\s*\('],
        "CWE-502": [r'pickle\.loads\s*\(', r'yaml\.load\s*\(', r'marshal\.loads\s*\('],
    }

    _SANITIZER_PATTERNS: dict[str, list[str]] = {
        "CWE-89": [r'cursor\.execute\s*\([^,]+,\s*[\(\[]', r'execute\s*\([^)]*%s[^)]*,\s*\('],
        "CWE-79": [r'html\.escape\s*\(', r'markupsafe', r'bleach\.clean\s*\('],
        "CWE-78": [r'shlex\.quote\s*\(', r'subprocess\.(run|call)\s*\(\s*\['],
        "CWE-22": [r'os\.path\.realpath\s*\(', r'\.resolve\s*\(\)', r'os\.path\.abspath\s*\('],
        "CWE-918": [r'urlparse\s*\(', r'ALLOWED_HOSTS', r'\.netloc\s*(==|in)\s*'],
        "CWE-94": [],
        "CWE-502": [r'json\.loads\s*\(', r'yaml\.safe_load\s*\(', r'ast\.literal_eval\s*\('],
    }

    def extract(self, cwe_id: str) -> tuple[list[str], list[str], list[str]]:
        """Return (source_patterns, sink_patterns, sanitizer_patterns) for a CWE."""
        sources = self._SOURCE_PATTERNS.get(cwe_id, [r'request\.\w+\.get\s*\('])
        sinks = self._SINK_PATTERNS.get(cwe_id, [])
        sanitizers = self._SANITIZER_PATTERNS.get(cwe_id, [])
        return sources, sinks, sanitizers


class RuleSynthesizer:
    """Stage 3 — Synthesize a SynthesizedRule from parsed CVE + pattern extraction."""

    def __init__(self) -> None:
        self._extractor = PatternExtractor()

    def synthesize(self, parsed: ParsedCVE) -> list[SynthesizedRule]:
        rules = []
        for cwe_id in parsed.cwe_ids:
            sources, sinks, sanitizers = self._extractor.extract(cwe_id)
            # Add any code_patterns from the CVE description as additional sinks
            all_sinks = list(sinks) + [p for p in parsed.code_patterns if p not in sinks]

            # Confidence heuristic based on attack vector and complexity
            base_conf = 0.75
            if parsed.attack_vector == "NETWORK":
                base_conf += 0.05
            if parsed.attack_complexity == "LOW":
                base_conf += 0.05
            if parsed.cvss_v3 >= 9.0:
                base_conf += 0.05
            base_conf = min(0.95, base_conf)

            rule_id = f"CVE-{parsed.cve_id}-{cwe_id}".replace("CVE-CVE-", "CVE-")
            rule = SynthesizedRule(
                rule_id=rule_id,
                name=f"CVE-based rule: {cwe_id} from {parsed.cve_id}",
                cwe_id=cwe_id,
                source_patterns=sources,
                sink_patterns=all_sinks,
                sanitizer_patterns=sanitizers,
                confidence_score=base_conf,
            )
            rules.append(rule)
        return rules


class RuleValidator:
    """Stage 4 — Validate synthesized rules against reference code snippets."""

    # Reference snippets: (code, cwe_id, should_trigger)
    _REFERENCE_CASES: list[tuple[str, str, bool]] = [
        # True positives
        ('db.execute("SELECT * FROM t WHERE id=" + uid)', "CWE-89", True),
        ('os.system("ls " + user_input)', "CWE-78", True),
        ('return "<h1>" + name + "</h1>"', "CWE-79", True),
        ('open(os.path.join(base, user_path))', "CWE-22", True),
        ('requests.get(user_url)', "CWE-918", True),
        # True negatives (sanitized)
        ('db.execute("SELECT * FROM t WHERE id=%s", (uid,))', "CWE-89", False),
        ('subprocess.run(["ls", user_input])', "CWE-78", False),
        ('return html.escape(name)', "CWE-79", False),
    ]

    def validate(self, rule: SynthesizedRule) -> SynthesizedRule:
        tp = fp = fn = 0

        for code, cwe_id, should_trigger in self._REFERENCE_CASES:
            if cwe_id != rule.cwe_id:
                continue

            # Check if any sink pattern matches
            sink_match = any(re.search(p, code) for p in rule.sink_patterns)
            # Check if any sanitizer pattern matches
            san_match = any(re.search(p, code) for p in rule.sanitizer_patterns)
            triggered = sink_match and not san_match

            if should_trigger and triggered:
                tp += 1
            elif not should_trigger and triggered:
                fp += 1
            elif should_trigger and not triggered:
                fn += 1

        rule.validation_tp = tp
        rule.validation_fp = fp
        rule.validation_fn = fn
        # A rule passes validation if it has no FPs and at least 1 TP (or no reference cases for this CWE)
        total_cases = tp + fp + fn
        rule.validated = (fp == 0) if total_cases > 0 else True
        return rule


class ResearchPipeline:
    """
    Full CVE → Knowledge pipeline.

    Orchestrates Parser → PatternExtractor → RuleSynthesizer → Validator → KnowledgeStore.
    """

    def __init__(self, store: Optional[KnowledgeStore] = None) -> None:
        self._store = store or KnowledgeStore()
        self._parser = CVEParser()
        self._synthesizer = RuleSynthesizer()
        self._validator = RuleValidator()

    @property
    def store(self) -> KnowledgeStore:
        return self._store

    def process_cve(
        self,
        cve_id: str,
        description: str,
        cvss_vector: str = "",
        cwe_ids: Optional[list[str]] = None,
    ) -> PipelineResult:
        """
        Run the full pipeline for a single CVE.

        Returns a PipelineResult with parsed metadata, synthesized rules,
        validation results, and whether a knowledge entry was created.
        """
        errors: list[str] = []

        # Stage 1 — Parse
        try:
            parsed = self._parser.parse(cve_id, description, cvss_vector, cwe_ids)
        except Exception as exc:
            return PipelineResult(
                cve_id=cve_id, cwe_ids=cwe_ids or [],
                parsed=ParsedCVE(cve_id=cve_id, cvss_v3=0.0, severity="UNKNOWN",
                                 cwe_ids=[], affected_products=[], attack_vector="NETWORK",
                                 attack_complexity="LOW", code_patterns=[],
                                 exploitation_description=""),
                rules=[], knowledge_entry=None, errors=[str(exc)],
            )

        # Stage 2+3 — Extract patterns and synthesize rules
        rules: list[SynthesizedRule] = []
        try:
            rules = self._synthesizer.synthesize(parsed)
        except Exception as exc:
            errors.append(f"synthesis error: {exc}")

        # Stage 4 — Validate
        validated_rules: list[SynthesizedRule] = []
        for rule in rules:
            try:
                validated = self._validator.validate(rule)
                validated_rules.append(validated)
            except Exception as exc:
                errors.append(f"validation error for {rule.rule_id}: {exc}")
                validated_rules.append(rule)

        validation_passed = all(r.validated for r in validated_rules) if validated_rules else True

        # Stage 5 — Build and integrate knowledge entry
        knowledge_entry: Optional[VulnerabilityKnowledge] = None
        added = False
        if parsed.cwe_ids:
            try:
                knowledge_entry = self._build_knowledge_entry(parsed, validated_rules)
                # Only add if there's no conflicting entry already (merge CVEs instead)
                existing = self._store.get_by_cwe(parsed.cwe_ids[0])
                if existing:
                    # Add CVE to existing entry's CVE list
                    cve_obj = CVEEntry(
                        cve_id=cve_id,
                        description=description[:500],
                        cvss_v3=parsed.cvss_v3,
                        severity=parsed.severity,
                        published="",
                        cwe_ids=parsed.cwe_ids,
                        capec_ids=[],
                        affected_software=parsed.affected_products,
                        exploit_available=True,
                        patch_available=False,
                        epss_score=0.0,
                        is_kev=False,
                        code_patterns=parsed.code_patterns,
                        references=[],
                    )
                    existing[0].related_cves.append(cve_obj)
                    added = True
                else:
                    self._store.add(knowledge_entry)
                    added = True
            except Exception as exc:
                errors.append(f"store integration error: {exc}")

        return PipelineResult(
            cve_id=cve_id,
            cwe_ids=parsed.cwe_ids,
            parsed=parsed,
            rules=validated_rules,
            knowledge_entry=knowledge_entry,
            added_to_store=added,
            validation_passed=validation_passed,
            errors=errors,
        )

    def process_batch(
        self,
        cves: list[dict],
    ) -> list[PipelineResult]:
        """
        Process a batch of CVEs.

        Each dict must have: cve_id (str), description (str).
        Optional keys: cvss_vector (str), cwe_ids (list[str]).
        """
        results = []
        for item in cves:
            result = self.process_cve(
                cve_id=item["cve_id"],
                description=item["description"],
                cvss_vector=item.get("cvss_vector", ""),
                cwe_ids=item.get("cwe_ids"),
            )
            results.append(result)
            if result.errors:
                logger.warning("Pipeline errors for %s: %s", item["cve_id"], result.errors)
            else:
                logger.debug("Processed %s → %d rules, validated=%s",
                             item["cve_id"], len(result.rules), result.validation_passed)
        return results

    def _build_knowledge_entry(
        self,
        parsed: ParsedCVE,
        rules: list[SynthesizedRule],
    ) -> VulnerabilityKnowledge:
        """Build a VulnerabilityKnowledge object from pipeline outputs."""
        from .built_in_data import CWE_ENTRIES

        primary_cwe = parsed.cwe_ids[0]
        cwe_entry = CWE_ENTRIES.get(primary_cwe)

        if cwe_entry is None:
            cwe_entry = CWEEntry(
                cwe_id=primary_cwe,
                name=f"Auto-inferred from {parsed.cve_id}",
                description=parsed.exploitation_description,
                extended_description="",
                detection_methods=[r.name for r in rules],
                mitigations=[],
                capec_ids=[],
                related_cwes=parsed.cwe_ids[1:],
                owasp_categories=[],
                severity_typical=parsed.severity,
                exploit_patterns=[r.rule_id for r in rules],
                fix_patterns=[],
            )

        # Build exploit patterns from synthesized rules
        exploit_patterns = []
        for rule in rules:
            if rule.sink_patterns:
                ep = ExploitPattern(
                    pattern_id=rule.rule_id,
                    name=rule.name,
                    cwe_id=rule.cwe_id,
                    code_pattern=rule.sink_patterns[0] if rule.sink_patterns else "",
                    payload_examples=[],
                    detection_hint=f"Sink matches: {', '.join(rule.sink_patterns[:2])}",
                    cvss_vector="",
                )
                exploit_patterns.append(ep)

        cve_obj = CVEEntry(
            cve_id=parsed.cve_id,
            description=parsed.exploitation_description[:500],
            cvss_v3=parsed.cvss_v3,
            severity=parsed.severity,
            published="",
            cwe_ids=parsed.cwe_ids,
            capec_ids=[],
            affected_software=parsed.affected_products,
            exploit_available=True,
            patch_available=False,
            epss_score=0.0,
            is_kev=False,
            code_patterns=parsed.code_patterns,
            references=[],
        )

        knowledge_id = "VULN-" + hashlib.md5(f"{primary_cwe}-{parsed.cve_id}".encode()).hexdigest()[:8].upper()

        risk_score = min(100.0, parsed.cvss_v3 * 10)

        return VulnerabilityKnowledge(
            knowledge_id=knowledge_id,
            cwe=cwe_entry,
            related_cves=[cve_obj],
            capecs=[],
            exploit_patterns=exploit_patterns,
            fix_patterns=[],
            similar_cwe_ids=parsed.cwe_ids[1:],
            owasp_category=cwe_entry.owasp_categories[0] if cwe_entry.owasp_categories else "A00:Unknown",
            risk_score=risk_score,
        )
