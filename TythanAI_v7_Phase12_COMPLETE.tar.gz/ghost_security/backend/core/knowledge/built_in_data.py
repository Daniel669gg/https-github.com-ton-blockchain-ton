"""
backend/core/knowledge/built_in_data.py — Built-in security knowledge corpus.

Covers OWASP Top 10 (2021) with CWE entries, CAPEC attack patterns,
exploit/fix code patterns, and representative CVEs.
All data is statically embedded — no network access required.
"""
from __future__ import annotations

from .models import (
    CAPECEntry, CVEEntry, CWEEntry, ExploitPattern,
    FixPattern, VulnerabilityKnowledge,
)


# ---------------------------------------------------------------------------
# Exploit Patterns
# ---------------------------------------------------------------------------

EXPLOIT_PATTERNS: dict[str, ExploitPattern] = {
    "SQLI-CONCAT": ExploitPattern(
        pattern_id="SQLI-CONCAT",
        name="SQL String Concatenation Injection",
        cwe_id="CWE-89",
        code_pattern=r'execute\s*\(\s*["\'][^"\']*["\'\s]*\+',
        payload_examples=["' OR '1'='1", "'; DROP TABLE users; --", "1 UNION SELECT password FROM users--"],
        detection_hint="Find cursor.execute / db.execute calls where the first argument uses string concatenation (+) with a variable",
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H",
    ),
    "SQLI-FORMAT": ExploitPattern(
        pattern_id="SQLI-FORMAT",
        name="SQL %-format / f-string Injection",
        cwe_id="CWE-89",
        code_pattern=r'execute\s*\(\s*["\'].*%[^s(]|execute\s*\(\s*f["\']',
        payload_examples=["' OR 1=1--", "admin'--", "' UNION SELECT null,null--"],
        detection_hint="Find execute() calls where the query string uses % formatting or f-strings with untrusted data",
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H",
    ),
    "XSS-UNESCAPED-CONCAT": ExploitPattern(
        pattern_id="XSS-UNESCAPED-CONCAT",
        name="Reflected XSS via Unescaped Output Concatenation",
        cwe_id="CWE-79",
        code_pattern=r'return\s+["\']<[^>]+>["\'\s]*\+\s*\w|f["\']<[^>]*>{[^}]*}',
        payload_examples=["<script>alert(1)</script>", "<img src=x onerror=alert(1)>", "';alert(1)//"],
        detection_hint="Find HTML return statements that concatenate user-controlled variables without escaping",
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:H/A:N",
    ),
    "CMDI-SYSTEM": ExploitPattern(
        pattern_id="CMDI-SYSTEM",
        name="OS Command Injection via os.system / subprocess with shell=True",
        cwe_id="CWE-78",
        code_pattern=r'os\.system\s*\(|subprocess\.(run|call|Popen)\s*\([^)]*shell\s*=\s*True',
        payload_examples=["; rm -rf /", "| cat /etc/passwd", "`whoami`", "$(id)"],
        detection_hint="Find os.system() calls or subprocess with shell=True where user input is passed",
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
    ),
    "PATH-TRAVERSAL-OPEN": ExploitPattern(
        pattern_id="PATH-TRAVERSAL-OPEN",
        name="Path Traversal via Unsanitized File Open",
        cwe_id="CWE-22",
        code_pattern=r'open\s*\(\s*\w*[^)]*\)|pathlib\.Path\s*\(',
        payload_examples=["../../etc/passwd", "../../../root/.ssh/id_rsa", "%2e%2e%2f" * 3 + "etc/passwd"],
        detection_hint="Find open() or Path() calls where the filename contains user-supplied path segments",
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
    ),
    "HARDCODED-SECRET": ExploitPattern(
        pattern_id="HARDCODED-SECRET",
        name="Hardcoded Credential or API Key",
        cwe_id="CWE-798",
        code_pattern=r'(password|secret|api_key|token|passwd)\s*=\s*["\'][^"\']{8,}["\']',
        payload_examples=["N/A — secret is already embedded"],
        detection_hint="Find variable assignments where credential-named identifiers are assigned string literals of 8+ chars",
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
    ),
    "SSRF-URLOPEN": ExploitPattern(
        pattern_id="SSRF-URLOPEN",
        name="Server-Side Request Forgery via User-Controlled URL",
        cwe_id="CWE-918",
        code_pattern=r'(requests\.get|urllib\.request\.urlopen|httpx\.get)\s*\(\s*\w',
        payload_examples=["http://169.254.169.254/latest/meta-data/", "http://internal-api/admin", "file:///etc/passwd"],
        detection_hint="Find HTTP client calls where the URL argument is derived from user input without allowlist validation",
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:L/A:N",
    ),
    "SSTI-RENDER": ExploitPattern(
        pattern_id="SSTI-RENDER",
        name="Server-Side Template Injection",
        cwe_id="CWE-94",
        code_pattern=r'render_template_string\s*\(|Template\s*\(\s*\w|from_string\s*\(',
        payload_examples=["{{7*7}}", "{{config}}", "{{''.__class__.__mro__[2].__subclasses__()}}"],
        detection_hint="Find template rendering calls where the template string or name includes user-controlled data",
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H",
    ),
}


# ---------------------------------------------------------------------------
# Fix Patterns
# ---------------------------------------------------------------------------

FIX_PATTERNS: dict[str, FixPattern] = {
    "SQLI-PARAMETERIZED": FixPattern(
        pattern_id="SQLI-PARAMETERIZED",
        cwe_id="CWE-89",
        name="Use Parameterized Queries",
        description="Replace string concatenation with DB-API 2.0 parameterized queries; the driver escapes data before interpolation.",
        before_code='cursor.execute("SELECT * FROM users WHERE id=" + uid)',
        after_code='cursor.execute("SELECT * FROM users WHERE id=%s", (uid,))',
        why_safe="The database driver separates code (query template) from data (parameters). The driver performs escaping specific to the backend dialect, preventing any injected SQL from being parsed as code.",
    ),
    "XSS-HTML-ESCAPE": FixPattern(
        pattern_id="XSS-HTML-ESCAPE",
        cwe_id="CWE-79",
        name="HTML-escape all user output",
        description="Pass user-controlled strings through html.escape() before embedding in HTML responses.",
        before_code='return f"<h1>Hello, {name}!</h1>"',
        after_code='return f"<h1>Hello, {html.escape(name)}!</h1>"',
        why_safe="html.escape() converts <, >, &, \", ' to their HTML entity equivalents, preventing the browser from interpreting injected characters as HTML/JS.",
    ),
    "CMDI-LIST-ARGS": FixPattern(
        pattern_id="CMDI-LIST-ARGS",
        cwe_id="CWE-78",
        name="Use subprocess with list arguments (no shell=True)",
        description="Pass a list of arguments to subprocess.run instead of a shell string; never use shell=True with user input.",
        before_code='subprocess.run(f"ls {user_dir}", shell=True)',
        after_code='subprocess.run(["ls", user_dir])',
        why_safe="When shell=False (the default), the OS does not invoke a shell; each list element is passed as a literal argument to execvp(). No shell metacharacters (;, |, &, $, `) are interpreted.",
    ),
    "PATH-REALPATH": FixPattern(
        pattern_id="PATH-REALPATH",
        cwe_id="CWE-22",
        name="Resolve and validate path against a base directory",
        description="Call os.path.realpath() on the user-supplied path, then verify it starts with the intended base directory.",
        before_code='path = os.path.join(base_dir, user_path)\nreturn open(path).read()',
        after_code='safe = os.path.realpath(os.path.join(base_dir, user_path))\nif not safe.startswith(os.path.realpath(base_dir)):\n    raise PermissionError("path traversal")\nreturn open(safe).read()',
        why_safe="realpath() resolves all symlinks and .. components before the startswith check, making it impossible to escape the base directory via ../../ sequences or symlinks.",
    ),
    "SSRF-ALLOWLIST": FixPattern(
        pattern_id="SSRF-ALLOWLIST",
        cwe_id="CWE-918",
        name="Validate URL against an allowlist before making the request",
        description="Parse the URL with urlparse(), check the scheme and netloc against an allowlist, then make the request.",
        before_code='response = requests.get(user_url)',
        after_code='parsed = urllib.parse.urlparse(user_url)\nif parsed.scheme not in ("http","https") or parsed.netloc not in ALLOWED_HOSTS:\n    raise ValueError("URL not allowed")\nresponse = requests.get(user_url)',
        why_safe="Limiting the scheme prevents file:// / ftp:// attacks. An exact-match allowlist on netloc prevents access to internal services and cloud metadata endpoints.",
    ),
}


# ---------------------------------------------------------------------------
# CAPEC Entries
# ---------------------------------------------------------------------------

CAPEC_ENTRIES: dict[str, CAPECEntry] = {
    "CAPEC-66": CAPECEntry(
        capec_id="CAPEC-66",
        name="SQL Injection",
        description="An attacker inserts SQL syntax into application inputs that are incorporated into SQL queries, altering query logic.",
        cwe_ids=["CWE-89"],
        attack_steps=[
            "Identify input vectors that flow into SQL queries (form fields, URL parameters, headers)",
            "Probe with single-quote to trigger a database error or Boolean-based anomaly",
            "Confirm injection with OR 1=1 vs OR 1=2 and observe response difference",
            "Extract schema information via UNION SELECT or error-based techniques",
            "Exfiltrate data, bypass authentication, or execute OS commands via xp_cmdshell/INTO OUTFILE",
        ],
        prerequisites=["Application constructs SQL queries with unsanitized user input", "Error messages or timing differences leak database state"],
        mitigations=["Parameterized queries / prepared statements", "ORMs that never interpolate raw input", "WAF rules for SQLi patterns", "Least-privilege DB accounts"],
        severity="HIGH",
        likelihood="HIGH",
    ),
    "CAPEC-86": CAPECEntry(
        capec_id="CAPEC-86",
        name="XSS via HTTP Query Strings",
        description="Attacker crafts URLs with script payloads that are reflected into the HTTP response and executed in the victim's browser.",
        cwe_ids=["CWE-79"],
        attack_steps=[
            "Identify URL parameters reflected in HTML responses",
            "Test with <script>alert(1)</script> or event-handler payloads",
            "Craft phishing link containing payload; distribute to victim",
            "Victim clicks link; browser executes attacker script in origin context",
            "Script steals session cookie, performs actions on behalf of victim",
        ],
        prerequisites=["Output reflected to browser without escaping", "User can be tricked into following crafted URL"],
        mitigations=["html.escape() or MarkupSafe for all reflected output", "Content-Security-Policy header", "HttpOnly + Secure cookie flags"],
        severity="HIGH",
        likelihood="HIGH",
    ),
    "CAPEC-88": CAPECEntry(
        capec_id="CAPEC-88",
        name="OS Command Injection",
        description="Attacker manipulates application input that flows to OS command execution functions, injecting additional commands.",
        cwe_ids=["CWE-78"],
        attack_steps=[
            "Identify inputs passed to shell commands (filenames, search terms, identifiers)",
            "Inject shell metacharacters: semicolon, pipe, backtick, $(...)",
            "Execute reconnaissance commands (id, whoami, uname -a)",
            "Establish reverse shell or read sensitive files",
            "Pivot to other systems on the internal network",
        ],
        prerequisites=["Application calls os.system/subprocess with shell=True using user input", "Web server process has shell access"],
        mitigations=["subprocess with list args and shell=False", "shlex.quote() for shell string contexts", "Allowlist-based input validation"],
        severity="HIGH",
        likelihood="MEDIUM",
    ),
    "CAPEC-126": CAPECEntry(
        capec_id="CAPEC-126",
        name="Path Traversal",
        description="Attacker uses ../ sequences or URL encoding to navigate outside the intended directory and access unauthorized files.",
        cwe_ids=["CWE-22"],
        attack_steps=[
            "Identify file-serving endpoints that accept user-supplied filenames or paths",
            "Try ../../../etc/passwd to check for traversal",
            "Test URL-encoded variants (%2e%2e%2f) and double-encoding to bypass naive filters",
            "Read sensitive files: /etc/passwd, /proc/self/environ, application config with credentials",
            "If write access, overwrite web server config or upload webshell",
        ],
        prerequisites=["Application joins user-supplied path with a base directory without normalizing first"],
        mitigations=["os.path.realpath() + startswith() base check", "pathlib Path.resolve() + is_relative_to()", "Chroot / containerization"],
        severity="HIGH",
        likelihood="MEDIUM",
    ),
    "CAPEC-407": CAPECEntry(
        capec_id="CAPEC-407",
        name="Exploiting Incorrectly Configured SSL/TLS",
        description="Attacker exploits weak cipher suites, expired certificates, or missing validation to intercept or forge TLS connections.",
        cwe_ids=["CWE-295", "CWE-326", "CWE-327"],
        attack_steps=[
            "Scan target for weak TLS versions (SSLv3, TLSv1.0/1.1) or cipher suites (RC4, DES, export)",
            "Perform MITM to downgrade connection or strip to plaintext",
            "Capture and decrypt traffic to extract session tokens or credentials",
        ],
        prerequisites=["Server accepts weak TLS configurations", "Attacker can intercept network traffic"],
        mitigations=["Enforce TLS 1.2+ with strong cipher suites", "HSTS header with long max-age", "Certificate pinning for mobile clients"],
        severity="HIGH",
        likelihood="MEDIUM",
    ),
}


# ---------------------------------------------------------------------------
# CWE Entries
# ---------------------------------------------------------------------------

CWE_ENTRIES: dict[str, CWEEntry] = {
    "CWE-89": CWEEntry(
        cwe_id="CWE-89",
        name="Improper Neutralization of Special Elements used in an SQL Command ('SQL Injection')",
        description="The software constructs all or part of an SQL command using externally-influenced input from an upstream component, but it does not neutralize or incorrectly neutralizes special elements that could modify the intended SQL command.",
        extended_description=(
            "Without sufficient removal or quoting of SQL syntax, the generated SQL query can cause the "
            "database to return unexpected results or execute unintended commands. Depending on the database "
            "and context, an attacker may be able to exfiltrate data, bypass authentication, modify records, "
            "or in some configurations execute OS commands."
        ),
        detection_methods=[
            "Taint analysis: trace untrusted data from sources (request params, headers) to SQL sinks",
            "Regex scan for execute/query calls with string concatenation or %-formatting",
            "Dynamic fuzzing with SQL metacharacters and blind boolean/timing techniques",
        ],
        mitigations=[
            "Use parameterized queries (DB-API 2.0 style: execute(sql, params))",
            "Use ORM query builders that never interpolate raw input",
            "Apply input validation / allowlist where parameterization is not possible",
            "Run DB accounts with least privilege (SELECT-only where writes not needed)",
        ],
        capec_ids=["CAPEC-66"],
        related_cwes=["CWE-564", "CWE-943"],
        owasp_categories=["A03:2021"],
        severity_typical="CRITICAL",
        exploit_patterns=["SQLI-CONCAT", "SQLI-FORMAT"],
        fix_patterns=["SQLI-PARAMETERIZED"],
    ),
    "CWE-79": CWEEntry(
        cwe_id="CWE-79",
        name="Improper Neutralization of Input During Web Page Generation ('Cross-site Scripting')",
        description="The software does not neutralize or incorrectly neutralizes user-controllable input before it is placed in output that is used as a web page that is served to other users.",
        extended_description=(
            "Cross-site scripting allows attackers to inject client-side scripts into pages viewed by "
            "other users. Reflected XSS executes immediately; stored XSS persists in the database and "
            "fires for every user who views the page. DOM-based XSS occurs when client-side JS writes "
            "attacker-controlled data to an unsafe sink."
        ),
        detection_methods=[
            "Taint analysis: trace user input to HTML output sinks (return statements, Jinja2 template rendering)",
            "Regex scan for unescaped variable insertion into HTML strings",
            "Dynamic testing: inject <script>alert(1)</script> and observe echo",
        ],
        mitigations=[
            "HTML-encode all output: html.escape(), MarkupSafe, or Jinja2 autoescape=True",
            "Content-Security-Policy header to restrict script execution",
            "HttpOnly and Secure flags on session cookies",
            "For rich HTML input: use a library like bleach with an allowlist",
        ],
        capec_ids=["CAPEC-86"],
        related_cwes=["CWE-80", "CWE-116"],
        owasp_categories=["A03:2021"],
        severity_typical="HIGH",
        exploit_patterns=["XSS-UNESCAPED-CONCAT"],
        fix_patterns=["XSS-HTML-ESCAPE"],
    ),
    "CWE-78": CWEEntry(
        cwe_id="CWE-78",
        name="Improper Neutralization of Special Elements used in an OS Command ('OS Command Injection')",
        description="The software constructs all or part of an OS command using externally-influenced input from an upstream component, but it does not neutralize or incorrectly neutralizes special elements that could modify the intended OS command.",
        extended_description=(
            "Shell metacharacters (; | & ` $(...) > < ) allow attackers to inject additional commands. "
            "The injected commands run with the same privileges as the web application, often enabling "
            "full remote code execution, reverse shells, and lateral movement."
        ),
        detection_methods=[
            "Taint analysis from request sources to os.system / subprocess / eval sinks",
            "Regex scan for shell=True in subprocess calls with concatenated strings",
            "Dynamic fuzzing with ; id and similar metacharacter sequences",
        ],
        mitigations=[
            "Use subprocess with a list of arguments and shell=False",
            "shlex.quote() when shell string construction is unavoidable",
            "Allowlist-validate all inputs that influence command construction",
            "Containerize or sandbox processes with seccomp/AppArmor",
        ],
        capec_ids=["CAPEC-88"],
        related_cwes=["CWE-77", "CWE-88"],
        owasp_categories=["A03:2021"],
        severity_typical="CRITICAL",
        exploit_patterns=["CMDI-SYSTEM"],
        fix_patterns=["CMDI-LIST-ARGS"],
    ),
    "CWE-22": CWEEntry(
        cwe_id="CWE-22",
        name="Improper Limitation of a Pathname to a Restricted Directory ('Path Traversal')",
        description="The software uses external input to construct a pathname that is intended to identify a file or directory that is located underneath a restricted parent directory, but the software does not properly neutralize special elements within the pathname.",
        extended_description=(
            "../ sequences, absolute paths, null bytes, and URL encoding can be used to escape the "
            "intended directory. Successful exploitation can lead to reading configuration files with "
            "credentials, source code, private keys, or — if write access exists — overwriting files."
        ),
        detection_methods=[
            "Taint analysis from request parameters to file-open sinks (open, Path, send_file)",
            "Regex scan for os.path.join with user-supplied second argument",
            "Dynamic testing with ../../../../etc/passwd",
        ],
        mitigations=[
            "os.path.realpath() followed by startswith(base_dir) assertion",
            "pathlib Path.resolve().is_relative_to(base_dir)",
            "Chroot jail or mount-namespace isolation for file-serving components",
        ],
        capec_ids=["CAPEC-126"],
        related_cwes=["CWE-23", "CWE-36"],
        owasp_categories=["A01:2021"],
        severity_typical="HIGH",
        exploit_patterns=["PATH-TRAVERSAL-OPEN"],
        fix_patterns=["PATH-REALPATH"],
    ),
    "CWE-798": CWEEntry(
        cwe_id="CWE-798",
        name="Use of Hard-coded Credentials",
        description="The software contains hard-coded credentials, such as a password or cryptographic key, that it uses for its own inbound authentication or for authentication with external components.",
        extended_description=(
            "Hard-coded credentials appear in source code, binary files, or configuration files. "
            "Once discovered — through source code access, binary analysis, or repository history — "
            "an attacker can authenticate to the system without limitation. Rotating hard-coded "
            "credentials requires a code change and redeployment."
        ),
        detection_methods=[
            "Regex scan for assignment of string literals to credential-named variables",
            "Entropy analysis to detect high-entropy strings (API keys, tokens)",
            "Secret scanning tools (truffleHog, git-secrets, GitHub secret scanning)",
        ],
        mitigations=[
            "Store credentials in environment variables or a secrets manager (Vault, AWS Secrets Manager)",
            "Use IAM roles and short-lived tokens instead of long-lived passwords",
            "Rotate any secrets that have ever appeared in code or version history",
            "Pre-commit hooks to block secret commits (detect-secrets, git-secrets)",
        ],
        capec_ids=[],
        related_cwes=["CWE-259", "CWE-321"],
        owasp_categories=["A07:2021"],
        severity_typical="CRITICAL",
        exploit_patterns=["HARDCODED-SECRET"],
        fix_patterns=[],
    ),
    "CWE-918": CWEEntry(
        cwe_id="CWE-918",
        name="Server-Side Request Forgery (SSRF)",
        description="The web server receives a URL or similar request from an upstream component and retrieves the contents of this URL, but it does not sufficiently ensure that the request is being sent to the expected destination.",
        extended_description=(
            "SSRF allows attackers to make the server issue requests to internal services, cloud metadata "
            "endpoints (169.254.169.254), localhost, or arbitrary external hosts. Critical in cloud "
            "environments where IMDSv1 leaks IAM credentials. Can escalate to full AWS/GCP account takeover."
        ),
        detection_methods=[
            "Taint analysis from user-supplied URL parameters to HTTP client calls",
            "Regex scan for requests.get/urllib.urlopen called with variables",
            "Dynamic testing with out-of-band DNS/HTTP callbacks (Burp Collaborator)",
        ],
        mitigations=[
            "Allowlist of permitted hosts/IP ranges",
            "Validate scheme (only http/https), netloc, and port",
            "Block access to link-local (169.254.x.x) and private (RFC1918) ranges",
            "Use IMDSv2 (token-based) in AWS to mitigate metadata endpoint exposure",
        ],
        capec_ids=[],
        related_cwes=["CWE-441", "CWE-610"],
        owasp_categories=["A10:2021"],
        severity_typical="HIGH",
        exploit_patterns=["SSRF-URLOPEN"],
        fix_patterns=["SSRF-ALLOWLIST"],
    ),
    "CWE-327": CWEEntry(
        cwe_id="CWE-327",
        name="Use of a Broken or Risky Cryptographic Algorithm",
        description="The use of a non-standard or known-broken cryptographic algorithm introduces confidentiality or integrity risks.",
        extended_description=(
            "MD5 and SHA-1 are collision-vulnerable and must not be used for integrity or password hashing. "
            "DES and RC4 are weak encryption algorithms broken by modern computing. ECB mode leaks "
            "patterns in ciphertext. Passwords must use memory-hard KDFs: bcrypt, scrypt, Argon2."
        ),
        detection_methods=[
            "AST/regex scan for hashlib.md5, hashlib.sha1, Crypto.Cipher.DES, ARC4",
            "Detection of MODE_ECB in AES usage",
            "Detection of base64 used as encryption substitute",
        ],
        mitigations=[
            "Use SHA-256/SHA-3 for integrity; bcrypt/scrypt/Argon2 for passwords",
            "AES-256-GCM for authenticated encryption",
            "TLS 1.3 with strong cipher suites for transport",
        ],
        capec_ids=["CAPEC-407"],
        related_cwes=["CWE-326", "CWE-916"],
        owasp_categories=["A02:2021"],
        severity_typical="HIGH",
        exploit_patterns=[],
        fix_patterns=[],
    ),
    "CWE-502": CWEEntry(
        cwe_id="CWE-502",
        name="Deserialization of Untrusted Data",
        description="The application deserializes untrusted data without sufficiently verifying that the resulting data will be valid.",
        extended_description=(
            "Python's pickle/marshal modules execute arbitrary code during deserialization. An attacker "
            "who can supply a crafted payload to any pickle.loads() call achieves remote code execution. "
            "yaml.load() with the default Loader also allows RCE via Python object construction."
        ),
        detection_methods=[
            "Regex/AST scan for pickle.loads, marshal.loads, yaml.load (without SafeLoader)",
            "Taint analysis from network/file sources to deserialization sinks",
        ],
        mitigations=[
            "Use json.loads() or ast.literal_eval() for data exchange",
            "yaml.safe_load() instead of yaml.load()",
            "If pickle is unavoidable: sign serialized data with HMAC before deserializing",
        ],
        capec_ids=[],
        related_cwes=["CWE-913"],
        owasp_categories=["A08:2021"],
        severity_typical="CRITICAL",
        exploit_patterns=[],
        fix_patterns=[],
    ),
}


# ---------------------------------------------------------------------------
# Representative CVE corpus
# ---------------------------------------------------------------------------

CVE_ENTRIES: list[CVEEntry] = [
    CVEEntry(
        cve_id="CVE-2021-44228",
        description="Log4Shell: JNDI injection in Apache Log4j 2.x allows unauthenticated RCE by logging attacker-controlled strings containing ${jndi:ldap://...}.",
        cvss_v3=10.0,
        severity="CRITICAL",
        published="2021-12-10",
        cwe_ids=["CWE-917", "CWE-78"],
        capec_ids=["CAPEC-88"],
        affected_software=["Apache Log4j 2.0-beta9 through 2.14.1"],
        exploit_available=True,
        patch_available=True,
        epss_score=0.97597,
        is_kev=True,
        code_patterns=[r'\$\{jndi:', r'log\..*\(.*\$\{'],
        references=["https://nvd.nist.gov/vuln/detail/CVE-2021-44228"],
    ),
    CVEEntry(
        cve_id="CVE-2017-5638",
        description="Apache Struts2 REST plugin: Content-Type header with OGNL expression enables RCE without authentication.",
        cvss_v3=10.0,
        severity="CRITICAL",
        published="2017-03-10",
        cwe_ids=["CWE-78"],
        capec_ids=["CAPEC-88"],
        affected_software=["Apache Struts 2.3.5 through 2.3.31", "Apache Struts 2.5 through 2.5.10"],
        exploit_available=True,
        patch_available=True,
        epss_score=0.97531,
        is_kev=True,
        code_patterns=[r'Content-Type.*#', r'OgnlValueStack'],
        references=["https://nvd.nist.gov/vuln/detail/CVE-2017-5638"],
    ),
    CVEEntry(
        cve_id="CVE-2019-0708",
        description="BlueKeep: Pre-auth RCE in Windows Remote Desktop Services via crafted requests to ms-rdp protocol.",
        cvss_v3=9.8,
        severity="CRITICAL",
        published="2019-05-14",
        cwe_ids=["CWE-416"],
        capec_ids=[],
        affected_software=["Windows 7", "Windows Server 2008", "Windows XP"],
        exploit_available=True,
        patch_available=True,
        epss_score=0.97314,
        is_kev=True,
        code_patterns=[],
        references=["https://nvd.nist.gov/vuln/detail/CVE-2019-0708"],
    ),
    CVEEntry(
        cve_id="CVE-2022-22965",
        description="Spring4Shell: ClassLoader manipulation via DataBinder in Spring Framework allows RCE on JDK9+ with Tomcat.",
        cvss_v3=9.8,
        severity="CRITICAL",
        published="2022-04-01",
        cwe_ids=["CWE-94"],
        capec_ids=[],
        affected_software=["Spring Framework 5.3.0-17", "Spring Framework 5.2.0-19"],
        exploit_available=True,
        patch_available=True,
        epss_score=0.97456,
        is_kev=True,
        code_patterns=[r'class\.module\.classLoader', r'DataBinder'],
        references=["https://nvd.nist.gov/vuln/detail/CVE-2022-22965"],
    ),
    CVEEntry(
        cve_id="CVE-2021-26855",
        description="ProxyLogon: SSRF in Microsoft Exchange Server allows unauthenticated bypass of authentication and reading email.",
        cvss_v3=9.8,
        severity="CRITICAL",
        published="2021-03-02",
        cwe_ids=["CWE-918"],
        capec_ids=[],
        affected_software=["Microsoft Exchange Server 2013/2016/2019"],
        exploit_available=True,
        patch_available=True,
        epss_score=0.97542,
        is_kev=True,
        code_patterns=[r'X-AnonResource-Backend', r'X-BEResource'],
        references=["https://nvd.nist.gov/vuln/detail/CVE-2021-26855"],
    ),
    CVEEntry(
        cve_id="CVE-2020-1472",
        description="Zerologon: Cryptographic flaw in MS-NRPC allows unauthenticated attacker to set computer account password to empty string, enabling domain controller compromise.",
        cvss_v3=10.0,
        severity="CRITICAL",
        published="2020-08-11",
        cwe_ids=["CWE-330", "CWE-327"],
        capec_ids=["CAPEC-407"],
        affected_software=["Windows Server 2008 R2 through 2019"],
        exploit_available=True,
        patch_available=True,
        epss_score=0.97571,
        is_kev=True,
        code_patterns=[r'NetrServerAuthenticate', r'AES-CFB8.*all-zero'],
        references=["https://nvd.nist.gov/vuln/detail/CVE-2020-1472"],
    ),
    CVEEntry(
        cve_id="CVE-2018-11776",
        description="Apache Struts2: Namespace OGNL injection via URL when both namespace and actionChaining are configured, enabling RCE.",
        cvss_v3=8.1,
        severity="HIGH",
        published="2018-08-22",
        cwe_ids=["CWE-20"],
        capec_ids=["CAPEC-88"],
        affected_software=["Apache Struts 2.3-2.5.16"],
        exploit_available=True,
        patch_available=True,
        epss_score=0.96887,
        is_kev=True,
        code_patterns=[r'\$\{.*\..*\(', r'namespace.*OGNL'],
        references=["https://nvd.nist.gov/vuln/detail/CVE-2018-11776"],
    ),
    CVEEntry(
        cve_id="CVE-2014-0160",
        description="Heartbleed: Buffer over-read in OpenSSL TLS heartbeat extension leaks up to 64KB of server memory per request, potentially exposing private keys.",
        cvss_v3=7.5,
        severity="HIGH",
        published="2014-04-07",
        cwe_ids=["CWE-125"],
        capec_ids=[],
        affected_software=["OpenSSL 1.0.1 through 1.0.1f", "OpenSSL 1.0.2-beta"],
        exploit_available=True,
        patch_available=True,
        epss_score=0.97285,
        is_kev=True,
        code_patterns=[],
        references=["https://nvd.nist.gov/vuln/detail/CVE-2014-0160"],
    ),
]


# ---------------------------------------------------------------------------
# Unified VulnerabilityKnowledge corpus
# ---------------------------------------------------------------------------

def _build_knowledge() -> dict[str, VulnerabilityKnowledge]:
    sqli_cves = [e for e in CVE_ENTRIES if "CWE-89" in e.cwe_ids]
    cmdi_cves = [e for e in CVE_ENTRIES if "CWE-78" in e.cwe_ids]
    ssrf_cves = [e for e in CVE_ENTRIES if "CWE-918" in e.cwe_ids]
    crypto_cves = [e for e in CVE_ENTRIES if "CWE-327" in e.cwe_ids or "CWE-330" in e.cwe_ids]

    return {
        "VULN-SQLI": VulnerabilityKnowledge(
            knowledge_id="VULN-SQLI",
            cwe=CWE_ENTRIES["CWE-89"],
            related_cves=sqli_cves,
            capecs=[CAPEC_ENTRIES["CAPEC-66"]],
            exploit_patterns=[EXPLOIT_PATTERNS["SQLI-CONCAT"], EXPLOIT_PATTERNS["SQLI-FORMAT"]],
            fix_patterns=[FIX_PATTERNS["SQLI-PARAMETERIZED"]],
            similar_cwe_ids=["CWE-564", "CWE-943"],
            owasp_category="A03:2021",
            risk_score=92.0,
        ),
        "VULN-XSS": VulnerabilityKnowledge(
            knowledge_id="VULN-XSS",
            cwe=CWE_ENTRIES["CWE-79"],
            related_cves=[],
            capecs=[CAPEC_ENTRIES["CAPEC-86"]],
            exploit_patterns=[EXPLOIT_PATTERNS["XSS-UNESCAPED-CONCAT"]],
            fix_patterns=[FIX_PATTERNS["XSS-HTML-ESCAPE"]],
            similar_cwe_ids=["CWE-80", "CWE-116"],
            owasp_category="A03:2021",
            risk_score=78.0,
        ),
        "VULN-CMDI": VulnerabilityKnowledge(
            knowledge_id="VULN-CMDI",
            cwe=CWE_ENTRIES["CWE-78"],
            related_cves=cmdi_cves,
            capecs=[CAPEC_ENTRIES["CAPEC-88"]],
            exploit_patterns=[EXPLOIT_PATTERNS["CMDI-SYSTEM"]],
            fix_patterns=[FIX_PATTERNS["CMDI-LIST-ARGS"]],
            similar_cwe_ids=["CWE-77", "CWE-88"],
            owasp_category="A03:2021",
            risk_score=95.0,
        ),
        "VULN-PATH-TRAVERSAL": VulnerabilityKnowledge(
            knowledge_id="VULN-PATH-TRAVERSAL",
            cwe=CWE_ENTRIES["CWE-22"],
            related_cves=[],
            capecs=[CAPEC_ENTRIES["CAPEC-126"]],
            exploit_patterns=[EXPLOIT_PATTERNS["PATH-TRAVERSAL-OPEN"]],
            fix_patterns=[FIX_PATTERNS["PATH-REALPATH"]],
            similar_cwe_ids=["CWE-23", "CWE-36"],
            owasp_category="A01:2021",
            risk_score=74.0,
        ),
        "VULN-HARDCODED-SECRET": VulnerabilityKnowledge(
            knowledge_id="VULN-HARDCODED-SECRET",
            cwe=CWE_ENTRIES["CWE-798"],
            related_cves=[],
            capecs=[],
            exploit_patterns=[EXPLOIT_PATTERNS["HARDCODED-SECRET"]],
            fix_patterns=[],
            similar_cwe_ids=["CWE-259", "CWE-321"],
            owasp_category="A07:2021",
            risk_score=88.0,
        ),
        "VULN-SSRF": VulnerabilityKnowledge(
            knowledge_id="VULN-SSRF",
            cwe=CWE_ENTRIES["CWE-918"],
            related_cves=ssrf_cves,
            capecs=[],
            exploit_patterns=[EXPLOIT_PATTERNS["SSRF-URLOPEN"]],
            fix_patterns=[FIX_PATTERNS["SSRF-ALLOWLIST"]],
            similar_cwe_ids=["CWE-441", "CWE-610"],
            owasp_category="A10:2021",
            risk_score=83.0,
        ),
        "VULN-WEAK-CRYPTO": VulnerabilityKnowledge(
            knowledge_id="VULN-WEAK-CRYPTO",
            cwe=CWE_ENTRIES["CWE-327"],
            related_cves=crypto_cves,
            capecs=[CAPEC_ENTRIES["CAPEC-407"]],
            exploit_patterns=[],
            fix_patterns=[],
            similar_cwe_ids=["CWE-326", "CWE-916"],
            owasp_category="A02:2021",
            risk_score=72.0,
        ),
        "VULN-DESERIALIZE": VulnerabilityKnowledge(
            knowledge_id="VULN-DESERIALIZE",
            cwe=CWE_ENTRIES["CWE-502"],
            related_cves=[],
            capecs=[],
            exploit_patterns=[],
            fix_patterns=[],
            similar_cwe_ids=["CWE-913"],
            owasp_category="A08:2021",
            risk_score=90.0,
        ),
        "VULN-SSTI": VulnerabilityKnowledge(
            knowledge_id="VULN-SSTI",
            cwe=CWEEntry(
                cwe_id="CWE-94",
                name="Improper Control of Generation of Code ('Code Injection')",
                description="The software constructs all or part of a code segment using externally-influenced input, but does not properly neutralize special elements that could modify the syntax or behavior of the intended code segment.",
                extended_description="SSTI allows an attacker to inject template syntax that the server-side engine interprets. In Python Jinja2, {{ ''.__class__.__mro__[2].__subclasses__() }} can lead to reading /etc/passwd or RCE.",
                detection_methods=["Taint analysis to render_template_string or Template()", "Regex scan for Template class instantiation with user data"],
                mitigations=["Never pass user input as a template string; use render_template with static template names", "Sandbox mode in Jinja2"],
                capec_ids=[],
                related_cwes=["CWE-95", "CWE-96"],
                owasp_categories=["A03:2021"],
                severity_typical="CRITICAL",
                exploit_patterns=["SSTI-RENDER"],
                fix_patterns=[],
            ),
            related_cves=[e for e in CVE_ENTRIES if "CWE-94" in e.cwe_ids],
            capecs=[],
            exploit_patterns=[EXPLOIT_PATTERNS["SSTI-RENDER"]],
            fix_patterns=[],
            similar_cwe_ids=["CWE-95", "CWE-96"],
            owasp_category="A03:2021",
            risk_score=93.0,
        ),
    }


BUILT_IN_KNOWLEDGE: dict[str, VulnerabilityKnowledge] = _build_knowledge()
