"""
backend/core/knowledge/models.py — Normalized vulnerability knowledge models.

Unified data model linking CVE -> CWE -> CAPEC -> Exploit Pattern -> Fix Pattern.
Each vulnerability entry is self-contained and machine-queryable.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class ExploitPattern:
    """Describes a code-level exploit pattern that can be detected statically."""

    pattern_id: str          # "SQLI-CONCAT", "CMD-SYSTEM", etc.
    name: str
    cwe_id: str
    code_pattern: str        # regex or code snippet that triggers the vuln
    payload_examples: List[str]
    detection_hint: str      # how to detect it statically
    cvss_vector: str         # CVSS v3 vector string


@dataclass
class FixPattern:
    """Describes how to remediate a specific exploit pattern."""

    pattern_id: str
    cwe_id: str
    name: str
    description: str
    before_code: str         # vulnerable code snippet
    after_code: str          # fixed code snippet
    why_safe: str            # explanation of why the fix is secure


@dataclass
class CAPECEntry:
    """CAPEC (Common Attack Pattern Enumeration and Classification) entry."""

    capec_id: str            # "CAPEC-66"
    name: str
    description: str
    cwe_ids: List[str]
    attack_steps: List[str]
    prerequisites: List[str]
    mitigations: List[str]
    severity: str            # HIGH/MEDIUM/LOW
    likelihood: str          # HIGH/MEDIUM/LOW


@dataclass
class CWEEntry:
    """CWE (Common Weakness Enumeration) entry with full context."""

    cwe_id: str              # "CWE-89"
    name: str
    description: str
    extended_description: str
    detection_methods: List[str]
    mitigations: List[str]
    capec_ids: List[str]
    related_cwes: List[str]
    owasp_categories: List[str]  # ["A03:2021", ...]
    severity_typical: str
    exploit_patterns: List[str]  # ExploitPattern pattern_ids
    fix_patterns: List[str]      # FixPattern pattern_ids


@dataclass
class CVEEntry:
    """CVE (Common Vulnerabilities and Exposures) entry with enriched metadata."""

    cve_id: str              # "CVE-2021-44228"
    description: str
    cvss_v3: float
    severity: str
    published: str           # ISO date string
    cwe_ids: List[str]
    capec_ids: List[str]
    affected_software: List[str]
    exploit_available: bool
    patch_available: bool
    epss_score: float        # 0.0-1.0
    is_kev: bool             # CISA Known Exploited Vulnerability
    code_patterns: List[str] # code signatures for this CVE
    references: List[str]


@dataclass
class VulnerabilityKnowledge:
    """Unified entry linking all knowledge about one vulnerability class."""

    knowledge_id: str
    cwe: CWEEntry
    related_cves: List[CVEEntry]
    capecs: List[CAPECEntry]
    exploit_patterns: List[ExploitPattern]
    fix_patterns: List[FixPattern]
    similar_cwe_ids: List[str]
    owasp_category: str
    risk_score: float        # composite 0-100
