"""
OWASP Benchmark corpus for TythanAI.

Contains real vulnerable and safe Python code samples mapped to OWASP categories.
Each sample has: code, expected vulnerabilities (True/False), CWE, severity.

Based on the OWASP Benchmark project patterns adapted for Python.
Reference: https://owasp.org/www-project-benchmark/
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class OWASPCase:
    case_id: str              # "OWASP-SQLI-001"
    category: str             # "A01:2021", "A03:2021", etc.
    cwe_id: str
    is_vulnerable: bool
    code: str                 # Python code snippet
    description: str
    language: str = "python"


# ---------------------------------------------------------------------------
# A01:2021 — Broken Access Control (CWE-22, CWE-284)
# ---------------------------------------------------------------------------

_A01_CASES: List[OWASPCase] = [
    # ── Vulnerable: path traversal via user-supplied filename ─────────────────
    OWASPCase(
        case_id="OWASP-A01-001",
        category="A01:2021",
        cwe_id="CWE-22",
        is_vulnerable=True,
        description="Path traversal: user-controlled filename used directly in open()",
        code="""
from flask import Flask, request, send_file
import os

app = Flask(__name__)
BASE_DIR = "/var/app/uploads"

@app.route("/download")
def download():
    filename = request.args.get("file")
    # VULNERABLE: no path sanitisation
    filepath = os.path.join(BASE_DIR, filename)
    return send_file(filepath)
""",
    ),
    OWASPCase(
        case_id="OWASP-A01-002",
        category="A01:2021",
        cwe_id="CWE-22",
        is_vulnerable=True,
        description="Path traversal: directory listing with user-supplied path",
        code="""
from flask import Flask, request
import os

app = Flask(__name__)

@app.route("/files")
def list_files():
    user_path = request.args.get("path", "")
    # VULNERABLE: arbitrary path listing
    full_path = "/srv/data/" + user_path
    return str(os.listdir(full_path))
""",
    ),
    OWASPCase(
        case_id="OWASP-A01-003",
        category="A01:2021",
        cwe_id="CWE-284",
        is_vulnerable=True,
        description="Missing access control: admin endpoint accessible without auth check",
        code="""
from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

@app.route("/admin/users")
def list_all_users():
    # VULNERABLE: no authentication check before returning sensitive data
    conn = sqlite3.connect("app.db")
    rows = conn.execute("SELECT id, username, email, password_hash FROM users").fetchall()
    return jsonify(rows)
""",
    ),
    # ── Safe: path traversal mitigated ───────────────────────────────────────
    OWASPCase(
        case_id="OWASP-A01-004",
        category="A01:2021",
        cwe_id="CWE-22",
        is_vulnerable=False,
        description="Path traversal mitigated: realpath + base directory check",
        code="""
from flask import Flask, request, send_file, abort
import os

app = Flask(__name__)
BASE_DIR = os.path.realpath("/var/app/uploads")

@app.route("/download")
def download():
    filename = request.args.get("file", "")
    # SAFE: resolve and verify the path stays within BASE_DIR
    requested = os.path.realpath(os.path.join(BASE_DIR, filename))
    if not requested.startswith(BASE_DIR + os.sep):
        abort(403)
    return send_file(requested)
""",
    ),
    OWASPCase(
        case_id="OWASP-A01-005",
        category="A01:2021",
        cwe_id="CWE-22",
        is_vulnerable=False,
        description="Path traversal mitigated: basename strips directory components",
        code="""
from flask import Flask, request, send_from_directory

app = Flask(__name__)
UPLOAD_FOLDER = "/var/app/uploads"

@app.route("/download")
def download():
    filename = request.args.get("file", "")
    # SAFE: send_from_directory restricts to UPLOAD_FOLDER
    import os
    safe_name = os.path.basename(filename)
    return send_from_directory(UPLOAD_FOLDER, safe_name)
""",
    ),
    OWASPCase(
        case_id="OWASP-A01-006",
        category="A01:2021",
        cwe_id="CWE-284",
        is_vulnerable=False,
        description="Access control enforced: admin decorator validates JWT role",
        code="""
from flask import Flask, request, jsonify, abort
import functools
import jwt

app = Flask(__name__)
SECRET = "supersecretkey"

def require_admin(f):
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("Authorization", "").removeprefix("Bearer ")
        try:
            payload = jwt.decode(token, SECRET, algorithms=["HS256"])
        except jwt.PyJWTError:
            abort(401)
        if payload.get("role") != "admin":
            abort(403)
        return f(*args, **kwargs)
    return decorated

@app.route("/admin/users")
@require_admin
def list_all_users():
    return jsonify({"users": []})
""",
    ),
]

# ---------------------------------------------------------------------------
# A02:2021 — Cryptographic Failures (CWE-327, CWE-798)
# ---------------------------------------------------------------------------

_A02_CASES: List[OWASPCase] = [
    OWASPCase(
        case_id="OWASP-A02-001",
        category="A02:2021",
        cwe_id="CWE-327",
        is_vulnerable=True,
        description="Weak cipher: MD5 used to hash passwords",
        code="""
import hashlib

def hash_password(password: str) -> str:
    # VULNERABLE: MD5 is cryptographically broken for password hashing
    return hashlib.md5(password.encode()).hexdigest()

def verify_password(stored_hash: str, input_password: str) -> bool:
    return stored_hash == hashlib.md5(input_password.encode()).hexdigest()
""",
    ),
    OWASPCase(
        case_id="OWASP-A02-002",
        category="A02:2021",
        cwe_id="CWE-327",
        is_vulnerable=True,
        description="Weak cipher: DES encryption used for sensitive data",
        code="""
from Crypto.Cipher import DES
import os

def encrypt_credit_card(card_number: str) -> bytes:
    # VULNERABLE: DES is a 56-bit cipher — trivially broken
    key = b"8bytekey"
    cipher = DES.new(key, DES.MODE_ECB)
    padded = card_number.encode().ljust(8, b"\\x00")
    return cipher.encrypt(padded)
""",
    ),
    OWASPCase(
        case_id="OWASP-A02-003",
        category="A02:2021",
        cwe_id="CWE-798",
        is_vulnerable=True,
        description="Hardcoded secret key used for JWT signing",
        code="""
import jwt

SECRET_KEY = "hardcoded_jwt_secret_12345"

def generate_token(user_id: int) -> str:
    # VULNERABLE: secret key is hardcoded in source
    return jwt.encode({"user_id": user_id}, SECRET_KEY, algorithm="HS256")

def verify_token(token: str) -> dict:
    return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
""",
    ),
    OWASPCase(
        case_id="OWASP-A02-004",
        category="A02:2021",
        cwe_id="CWE-327",
        is_vulnerable=False,
        description="Strong password hashing: bcrypt with cost factor",
        code="""
import bcrypt

def hash_password(password: str) -> bytes:
    # SAFE: bcrypt with work factor 12
    salt = bcrypt.gensalt(rounds=12)
    return bcrypt.hashpw(password.encode(), salt)

def verify_password(stored_hash: bytes, input_password: str) -> bool:
    return bcrypt.checkpw(input_password.encode(), stored_hash)
""",
    ),
    OWASPCase(
        case_id="OWASP-A02-005",
        category="A02:2021",
        cwe_id="CWE-327",
        is_vulnerable=False,
        description="Strong encryption: AES-256-GCM for sensitive data",
        code="""
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os

def encrypt_data(plaintext: bytes, key: bytes) -> bytes:
    # SAFE: AES-256-GCM provides authenticated encryption
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)
    ciphertext = aesgcm.encrypt(nonce, plaintext, None)
    return nonce + ciphertext

def decrypt_data(ciphertext: bytes, key: bytes) -> bytes:
    aesgcm = AESGCM(key)
    nonce, ct = ciphertext[:12], ciphertext[12:]
    return aesgcm.decrypt(nonce, ct, None)
""",
    ),
    OWASPCase(
        case_id="OWASP-A02-006",
        category="A02:2021",
        cwe_id="CWE-798",
        is_vulnerable=False,
        description="Secret loaded from environment, not hardcoded",
        code="""
import os
import jwt

def get_secret() -> str:
    # SAFE: secret loaded from environment variable
    secret = os.environ.get("JWT_SECRET_KEY")
    if not secret:
        raise RuntimeError("JWT_SECRET_KEY environment variable is not set")
    return secret

def generate_token(user_id: int) -> str:
    return jwt.encode({"user_id": user_id}, get_secret(), algorithm="HS256")
""",
    ),
]

# ---------------------------------------------------------------------------
# A03:2021 — Injection (CWE-89, CWE-78, CWE-79, CWE-94)
# ---------------------------------------------------------------------------

_A03_CASES: List[OWASPCase] = [
    OWASPCase(
        case_id="OWASP-A03-001",
        category="A03:2021",
        cwe_id="CWE-89",
        is_vulnerable=True,
        description="SQL injection: user input concatenated into query string",
        code="""
from flask import Flask, request
import sqlite3

app = Flask(__name__)

@app.route("/user")
def get_user():
    username = request.args.get("username")
    conn = sqlite3.connect("app.db")
    # VULNERABLE: direct string concatenation into SQL
    query = "SELECT * FROM users WHERE username = '" + username + "'"
    row = conn.execute(query).fetchone()
    return str(row)
""",
    ),
    OWASPCase(
        case_id="OWASP-A03-002",
        category="A03:2021",
        cwe_id="CWE-78",
        is_vulnerable=True,
        description="Command injection: user input passed to subprocess shell=True",
        code="""
from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/ping")
def ping():
    host = request.args.get("host", "localhost")
    # VULNERABLE: shell=True with user-controlled input
    result = subprocess.run(
        f"ping -c 1 {host}",
        shell=True, capture_output=True, text=True
    )
    return result.stdout
""",
    ),
    OWASPCase(
        case_id="OWASP-A03-003",
        category="A03:2021",
        cwe_id="CWE-79",
        is_vulnerable=True,
        description="XSS: user input reflected in HTML response without escaping",
        code="""
from flask import Flask, request, make_response

app = Flask(__name__)

@app.route("/search")
def search():
    query = request.args.get("q", "")
    # VULNERABLE: user input directly embedded in HTML
    html = f"<html><body><h1>Results for: {query}</h1></body></html>"
    return make_response(html)
""",
    ),
    OWASPCase(
        case_id="OWASP-A03-004",
        category="A03:2021",
        cwe_id="CWE-94",
        is_vulnerable=True,
        description="Code injection: eval() on user-supplied expression",
        code="""
from flask import Flask, request

app = Flask(__name__)

@app.route("/calc")
def calc():
    expr = request.args.get("expr", "1+1")
    # VULNERABLE: eval() on user input enables arbitrary code execution
    result = eval(expr)
    return str(result)
""",
    ),
    OWASPCase(
        case_id="OWASP-A03-005",
        category="A03:2021",
        cwe_id="CWE-89",
        is_vulnerable=False,
        description="SQL injection mitigated: parameterized query with placeholders",
        code="""
from flask import Flask, request
import sqlite3

app = Flask(__name__)

@app.route("/user")
def get_user():
    username = request.args.get("username", "")
    conn = sqlite3.connect("app.db")
    # SAFE: parameterized query
    row = conn.execute(
        "SELECT id, username, email FROM users WHERE username = ?",
        (username,)
    ).fetchone()
    return str(row)
""",
    ),
    OWASPCase(
        case_id="OWASP-A03-006",
        category="A03:2021",
        cwe_id="CWE-78",
        is_vulnerable=False,
        description="Command injection mitigated: args list without shell=True",
        code="""
from flask import Flask, request, abort
import subprocess
import re

app = Flask(__name__)
_VALID_HOST = re.compile(r"^[a-zA-Z0-9._-]{1,253}$")

@app.route("/ping")
def ping():
    host = request.args.get("host", "localhost")
    # SAFE: whitelist validation + list form (no shell=True)
    if not _VALID_HOST.match(host):
        abort(400)
    result = subprocess.run(
        ["ping", "-c", "1", host],
        capture_output=True, text=True, timeout=5
    )
    return result.stdout
""",
    ),
    OWASPCase(
        case_id="OWASP-A03-007",
        category="A03:2021",
        cwe_id="CWE-79",
        is_vulnerable=False,
        description="XSS mitigated: Jinja2 auto-escaping with render_template",
        code="""
from flask import Flask, request, render_template_string

app = Flask(__name__)

@app.route("/search")
def search():
    query = request.args.get("q", "")
    # SAFE: Jinja2 auto-escaping prevents XSS
    return render_template_string(
        "<html><body><h1>Results for: {{ q }}</h1></body></html>",
        q=query
    )
""",
    ),
    OWASPCase(
        case_id="OWASP-A03-008",
        category="A03:2021",
        cwe_id="CWE-94",
        is_vulnerable=False,
        description="Code injection mitigated: safe expression evaluator with ast.literal_eval",
        code="""
from flask import Flask, request, abort
import ast
import operator

app = Flask(__name__)

_SAFE_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
}

def _safe_eval(expr: str):
    tree = ast.parse(expr, mode='eval')
    def _eval(node):
        if isinstance(node, ast.Expression):
            return _eval(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _SAFE_OPS:
            return _SAFE_OPS[type(node.op)](_eval(node.left), _eval(node.right))
        raise ValueError("Unsafe expression")
    return _eval(tree)

@app.route("/calc")
def calc():
    expr = request.args.get("expr", "1+1")
    try:
        result = _safe_eval(expr)
    except Exception:
        abort(400)
    return str(result)
""",
    ),
]

# ---------------------------------------------------------------------------
# A04:2021 — Insecure Design (CWE-272, CWE-311)
# ---------------------------------------------------------------------------

_A04_CASES: List[OWASPCase] = [
    OWASPCase(
        case_id="OWASP-A04-001",
        category="A04:2021",
        cwe_id="CWE-311",
        is_vulnerable=True,
        description="Insecure design: password reset token sent in URL (logged by servers)",
        code="""
from flask import Flask, request, redirect
import secrets
import sqlite3

app = Flask(__name__)

@app.route("/reset-password", methods=["GET"])
def reset_password():
    email = request.args.get("email")
    token = secrets.token_urlsafe(32)
    conn = sqlite3.connect("app.db")
    conn.execute(
        "INSERT INTO password_resets (email, token) VALUES (?, ?)", (email, token)
    )
    conn.commit()
    # VULNERABLE: token in URL — will appear in access logs and Referer headers
    reset_url = f"https://example.com/reset?token={token}&email={email}"
    # send_email(email, reset_url)  # sent via plaintext email link
    return f"Reset link: {reset_url}"
""",
    ),
    OWASPCase(
        case_id="OWASP-A04-002",
        category="A04:2021",
        cwe_id="CWE-272",
        is_vulnerable=True,
        description="Insecure design: running database operations with superuser privileges",
        code="""
import psycopg2

def get_db():
    # VULNERABLE: connecting as postgres superuser for all app operations
    return psycopg2.connect(
        host="localhost",
        database="appdb",
        user="postgres",      # superuser
        password="postgres"
    )

def get_user_by_id(user_id: int):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    return cur.fetchone()
""",
    ),
    OWASPCase(
        case_id="OWASP-A04-003",
        category="A04:2021",
        cwe_id="CWE-311",
        is_vulnerable=True,
        description="Insecure design: sensitive PII stored in client-readable cookie",
        code="""
from flask import Flask, request, make_response
import json

app = Flask(__name__)

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username")
    # VULNERABLE: full user record (including email, role) stored unencrypted in cookie
    user_data = {"username": username, "email": f"{username}@example.com", "role": "admin"}
    resp = make_response("Logged in")
    resp.set_cookie("user_session", json.dumps(user_data), httponly=False, secure=False)
    return resp
""",
    ),
    OWASPCase(
        case_id="OWASP-A04-004",
        category="A04:2021",
        cwe_id="CWE-311",
        is_vulnerable=False,
        description="Secure design: password reset via email with short-lived token stored server-side",
        code="""
from flask import Flask, request
import secrets
import sqlite3
from datetime import datetime, timedelta

app = Flask(__name__)

@app.route("/reset-password", methods=["POST"])
def reset_password():
    email = request.form.get("email", "").strip().lower()
    token = secrets.token_urlsafe(32)
    expires_at = datetime.utcnow() + timedelta(minutes=15)
    conn = sqlite3.connect("app.db")
    conn.execute(
        "INSERT INTO password_resets (email, token_hash, expires_at) VALUES (?, ?, ?)",
        (email, __import__("hashlib").sha256(token.encode()).hexdigest(), expires_at)
    )
    conn.commit()
    # SAFE: token sent via email body (not URL), short-lived, hashed in DB
    # send_email(email, body=f"Your reset code: {token}")
    return "If that email exists, a reset link has been sent."
""",
    ),
    OWASPCase(
        case_id="OWASP-A04-005",
        category="A04:2021",
        cwe_id="CWE-272",
        is_vulnerable=False,
        description="Secure design: least-privilege database user for application",
        code="""
import psycopg2

def get_db():
    # SAFE: dedicated app user with only SELECT/INSERT/UPDATE on needed tables
    return psycopg2.connect(
        host="localhost",
        database="appdb",
        user="app_readonly",   # least-privilege role
        password=__import__("os").environ["DB_PASSWORD"]
    )
""",
    ),
    OWASPCase(
        case_id="OWASP-A04-006",
        category="A04:2021",
        cwe_id="CWE-311",
        is_vulnerable=False,
        description="Secure design: session stored server-side, only session ID in signed cookie",
        code="""
from flask import Flask, session
from flask_session import Session

app = Flask(__name__)
app.config["SECRET_KEY"] = __import__("os").environ["FLASK_SECRET"]
app.config["SESSION_TYPE"] = "redis"
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SECURE"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
Session(app)

@app.route("/login", methods=["POST"])
def login():
    # SAFE: only user_id stored in server-side session; cookie is signed and HttpOnly
    session["user_id"] = 42
    return "Logged in"
""",
    ),
]

# ---------------------------------------------------------------------------
# A05:2021 — Security Misconfiguration (CWE-16, CWE-732)
# ---------------------------------------------------------------------------

_A05_CASES: List[OWASPCase] = [
    OWASPCase(
        case_id="OWASP-A05-001",
        category="A05:2021",
        cwe_id="CWE-16",
        is_vulnerable=True,
        description="Security misconfiguration: Flask debug mode enabled in production",
        code="""
from flask import Flask

app = Flask(__name__)
app.config["DEBUG"] = True       # VULNERABLE: debug mode exposes interactive debugger
app.config["TESTING"] = True     # allows PIN bypass

if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)  # VULNERABLE: listening on all interfaces
""",
    ),
    OWASPCase(
        case_id="OWASP-A05-002",
        category="A05:2021",
        cwe_id="CWE-732",
        is_vulnerable=True,
        description="Security misconfiguration: world-writable file permissions on secrets",
        code="""
import os
import stat

def write_secret(path: str, secret: str) -> None:
    with open(path, "w") as f:
        f.write(secret)
    # VULNERABLE: world-readable permissions on secret file
    os.chmod(path, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 0777
""",
    ),
    OWASPCase(
        case_id="OWASP-A05-003",
        category="A05:2021",
        cwe_id="CWE-16",
        is_vulnerable=True,
        description="Security misconfiguration: CORS allows all origins with credentials",
        code="""
from flask import Flask
from flask_cors import CORS

app = Flask(__name__)
# VULNERABLE: wildcard origin with credentials allows any site to make authenticated requests
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)

@app.route("/api/profile")
def profile():
    return {"user": "admin", "email": "admin@example.com"}
""",
    ),
    OWASPCase(
        case_id="OWASP-A05-004",
        category="A05:2021",
        cwe_id="CWE-16",
        is_vulnerable=False,
        description="Secure config: Flask debug disabled, production-hardened settings",
        code="""
import os
from flask import Flask

app = Flask(__name__)
app.config.update(
    DEBUG=False,
    TESTING=False,
    SECRET_KEY=os.environ["FLASK_SECRET_KEY"],
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    WTF_CSRF_ENABLED=True,
)

if __name__ == "__main__":
    # SAFE: bind to localhost only behind a reverse proxy
    app.run(host="127.0.0.1", port=5000, debug=False)
""",
    ),
    OWASPCase(
        case_id="OWASP-A05-005",
        category="A05:2021",
        cwe_id="CWE-732",
        is_vulnerable=False,
        description="Secure file permissions: secrets written with owner-only permissions",
        code="""
import os
import stat

def write_secret(path: str, secret: str) -> None:
    # SAFE: owner-only read/write (0600)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(secret)
""",
    ),
    OWASPCase(
        case_id="OWASP-A05-006",
        category="A05:2021",
        cwe_id="CWE-16",
        is_vulnerable=False,
        description="Secure CORS: specific trusted origins only",
        code="""
from flask import Flask
from flask_cors import CORS

app = Flask(__name__)
ALLOWED_ORIGINS = ["https://app.example.com", "https://admin.example.com"]
# SAFE: explicit allow-list of origins, no wildcard
CORS(app, resources={r"/api/*": {"origins": ALLOWED_ORIGINS}}, supports_credentials=True)
""",
    ),
]

# ---------------------------------------------------------------------------
# A06:2021 — Vulnerable and Outdated Components (CWE-1035, CWE-1104)
# ---------------------------------------------------------------------------

_A06_CASES: List[OWASPCase] = [
    OWASPCase(
        case_id="OWASP-A06-001",
        category="A06:2021",
        cwe_id="CWE-1035",
        is_vulnerable=True,
        description="Vulnerable component: using PyYAML yaml.load() without Loader (arbitrary code exec)",
        code="""
import yaml

def parse_config(config_str: str) -> dict:
    # VULNERABLE: yaml.load without Loader allows arbitrary Python object instantiation
    return yaml.load(config_str)
""",
    ),
    OWASPCase(
        case_id="OWASP-A06-002",
        category="A06:2021",
        cwe_id="CWE-1104",
        is_vulnerable=True,
        description="Vulnerable component: using pickle to deserialize untrusted data",
        code="""
import pickle
from flask import Flask, request

app = Flask(__name__)

@app.route("/load", methods=["POST"])
def load_session():
    # VULNERABLE: pickle deserialization of user-controlled data
    data = request.get_data()
    obj = pickle.loads(data)
    return str(obj)
""",
    ),
    OWASPCase(
        case_id="OWASP-A06-003",
        category="A06:2021",
        cwe_id="CWE-1035",
        is_vulnerable=True,
        description="Vulnerable component: xmlrpc.server exposed without authentication",
        code="""
from xmlrpc.server import SimpleXMLRPCServer

def dangerous_exec(cmd: str) -> str:
    import subprocess
    return subprocess.check_output(cmd, shell=True).decode()

# VULNERABLE: unauthenticated RPC server exposing shell execution
server = SimpleXMLRPCServer(("0.0.0.0", 8000))
server.register_function(dangerous_exec, "exec")
server.serve_forever()
""",
    ),
    OWASPCase(
        case_id="OWASP-A06-004",
        category="A06:2021",
        cwe_id="CWE-1035",
        is_vulnerable=False,
        description="Safe YAML loading: yaml.safe_load prevents code execution",
        code="""
import yaml

def parse_config(config_str: str) -> dict:
    # SAFE: yaml.safe_load only deserializes basic Python types
    return yaml.safe_load(config_str)
""",
    ),
    OWASPCase(
        case_id="OWASP-A06-005",
        category="A06:2021",
        cwe_id="CWE-1104",
        is_vulnerable=False,
        description="Safe serialization: JSON instead of pickle for session data",
        code="""
import json
import base64
import hmac
import hashlib
import os
from flask import Flask, request

app = Flask(__name__)
_SECRET = os.environb.get(b"SESSION_SECRET", b"changeme")

def _sign(data: str) -> str:
    sig = hmac.new(_SECRET, data.encode(), hashlib.sha256).hexdigest()
    return f"{data}.{sig}"

def _verify_and_load(signed: str) -> dict:
    parts = signed.rsplit(".", 1)
    if len(parts) != 2:
        raise ValueError("invalid")
    data, sig = parts
    expected = hmac.new(_SECRET, data.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig, expected):
        raise ValueError("tampered")
    return json.loads(base64.b64decode(data))

@app.route("/load", methods=["POST"])
def load_session():
    # SAFE: JSON deserialization with HMAC signature verification
    token = request.get_json().get("token", "")
    obj = _verify_and_load(token)
    return str(obj)
""",
    ),
    OWASPCase(
        case_id="OWASP-A06-006",
        category="A06:2021",
        cwe_id="CWE-1035",
        is_vulnerable=False,
        description="Safe component usage: defusedxml prevents XXE in XML parsing",
        code="""
import defusedxml.ElementTree as ET

def parse_xml(xml_string: str):
    # SAFE: defusedxml disables entity expansion, DTD processing, and external references
    return ET.fromstring(xml_string)
""",
    ),
]

# ---------------------------------------------------------------------------
# A07:2021 — Identification and Authentication Failures (CWE-287, CWE-306, CWE-798)
# ---------------------------------------------------------------------------

_A07_CASES: List[OWASPCase] = [
    OWASPCase(
        case_id="OWASP-A07-001",
        category="A07:2021",
        cwe_id="CWE-287",
        is_vulnerable=True,
        description="Auth failure: SQL injection bypasses login check",
        code="""
import sqlite3
from flask import Flask, request

app = Flask(__name__)

@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"]
    password = request.form["password"]
    conn = sqlite3.connect("app.db")
    # VULNERABLE: SQL injection auth bypass with ' OR '1'='1
    query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
    user = conn.execute(query).fetchone()
    if user:
        return "Login successful"
    return "Invalid credentials", 401
""",
    ),
    OWASPCase(
        case_id="OWASP-A07-002",
        category="A07:2021",
        cwe_id="CWE-306",
        is_vulnerable=True,
        description="Auth failure: password reset with no rate limiting (brute-force of OTP)",
        code="""
from flask import Flask, request
import sqlite3

app = Flask(__name__)

@app.route("/verify-otp", methods=["POST"])
def verify_otp():
    email = request.form["email"]
    otp = request.form["otp"]
    conn = sqlite3.connect("app.db")
    # VULNERABLE: no rate limiting, 6-digit OTP brutable in <1M attempts
    row = conn.execute(
        "SELECT * FROM otp_tokens WHERE email=? AND token=? AND expires_at > datetime('now')",
        (email, otp)
    ).fetchone()
    if row:
        return "OTP verified"
    return "Invalid OTP", 401
""",
    ),
    OWASPCase(
        case_id="OWASP-A07-003",
        category="A07:2021",
        cwe_id="CWE-798",
        is_vulnerable=True,
        description="Auth failure: default admin credentials hardcoded",
        code="""
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"   # VULNERABLE: hardcoded default credentials

def check_admin(username: str, password: str) -> bool:
    return username == ADMIN_USERNAME and password == ADMIN_PASSWORD
""",
    ),
    OWASPCase(
        case_id="OWASP-A07-004",
        category="A07:2021",
        cwe_id="CWE-287",
        is_vulnerable=False,
        description="Secure login: parameterized query + timing-safe comparison",
        code="""
import sqlite3
import hmac
import hashlib
from flask import Flask, request

app = Flask(__name__)

def _hash_pw(pw: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 260000).hex()

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    conn = sqlite3.connect("app.db")
    # SAFE: parameterized query + constant-time comparison
    row = conn.execute(
        "SELECT password_hash, salt FROM users WHERE username = ?", (username,)
    ).fetchone()
    if row is None:
        return "Invalid credentials", 401
    stored_hash, salt = row
    candidate = _hash_pw(password, bytes.fromhex(salt))
    if not hmac.compare_digest(stored_hash, candidate):
        return "Invalid credentials", 401
    return "Login successful"
""",
    ),
    OWASPCase(
        case_id="OWASP-A07-005",
        category="A07:2021",
        cwe_id="CWE-306",
        is_vulnerable=False,
        description="Secure OTP: rate limiting with lockout after N failures",
        code="""
from flask import Flask, request, abort
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import sqlite3

app = Flask(__name__)
limiter = Limiter(get_remote_address, app=app)

@app.route("/verify-otp", methods=["POST"])
@limiter.limit("5 per minute")    # SAFE: rate limited
def verify_otp():
    email = request.form.get("email", "")
    otp = request.form.get("otp", "")
    conn = sqlite3.connect("app.db")
    row = conn.execute(
        "SELECT * FROM otp_tokens WHERE email=? AND token=? AND expires_at > datetime('now')",
        (email, otp)
    ).fetchone()
    if row:
        return "OTP verified"
    return "Invalid OTP", 401
""",
    ),
    OWASPCase(
        case_id="OWASP-A07-006",
        category="A07:2021",
        cwe_id="CWE-798",
        is_vulnerable=False,
        description="Secure auth: credentials loaded from environment, not hardcoded",
        code="""
import os
import hmac

_ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "")
_ADMIN_PASSWORD_HASH = os.environ.get("ADMIN_PASSWORD_HASH", "")

def check_admin(username: str, password_hash: str) -> bool:
    # SAFE: credentials come from environment, compared in constant time
    return (
        hmac.compare_digest(username, _ADMIN_USERNAME)
        and hmac.compare_digest(password_hash, _ADMIN_PASSWORD_HASH)
    )
""",
    ),
]

# ---------------------------------------------------------------------------
# A08:2021 — Software and Data Integrity Failures (CWE-502, CWE-829)
# ---------------------------------------------------------------------------

_A08_CASES: List[OWASPCase] = [
    OWASPCase(
        case_id="OWASP-A08-001",
        category="A08:2021",
        cwe_id="CWE-502",
        is_vulnerable=True,
        description="Deserialization: pickle.loads on user-supplied POST body",
        code="""
import pickle
from flask import Flask, request

app = Flask(__name__)

@app.route("/api/restore", methods=["POST"])
def restore_state():
    # VULNERABLE: arbitrary deserialization of user-controlled bytes
    state = pickle.loads(request.data)
    return str(state)
""",
    ),
    OWASPCase(
        case_id="OWASP-A08-002",
        category="A08:2021",
        cwe_id="CWE-829",
        is_vulnerable=True,
        description="Inclusion of functionality from untrusted source: dynamic import of user-supplied module",
        code="""
from flask import Flask, request
import importlib

app = Flask(__name__)

@app.route("/plugin")
def load_plugin():
    plugin_name = request.args.get("plugin")
    # VULNERABLE: user controls which module gets imported
    mod = importlib.import_module(f"plugins.{plugin_name}")
    return str(mod.run())
""",
    ),
    OWASPCase(
        case_id="OWASP-A08-003",
        category="A08:2021",
        cwe_id="CWE-502",
        is_vulnerable=True,
        description="Deserialization: marshal.loads on network data",
        code="""
import marshal
import socket

def receive_and_execute():
    sock = socket.socket()
    sock.bind(("0.0.0.0", 9999))
    sock.listen(1)
    conn, _ = sock.accept()
    data = conn.recv(4096)
    # VULNERABLE: marshal can execute arbitrary bytecode
    code_obj = marshal.loads(data)
    exec(compile(code_obj, "<network>", "exec"))
""",
    ),
    OWASPCase(
        case_id="OWASP-A08-004",
        category="A08:2021",
        cwe_id="CWE-502",
        is_vulnerable=False,
        description="Safe deserialization: JSON schema validation instead of pickle",
        code="""
import json
from jsonschema import validate, ValidationError
from flask import Flask, request, abort

app = Flask(__name__)

_STATE_SCHEMA = {
    "type": "object",
    "properties": {
        "user_id": {"type": "integer"},
        "preferences": {"type": "object"},
    },
    "required": ["user_id"],
    "additionalProperties": False,
}

@app.route("/api/restore", methods=["POST"])
def restore_state():
    # SAFE: JSON only, strict schema validation
    try:
        state = request.get_json(force=True)
        validate(instance=state, schema=_STATE_SCHEMA)
    except (ValidationError, Exception):
        abort(400)
    return str(state)
""",
    ),
    OWASPCase(
        case_id="OWASP-A08-005",
        category="A08:2021",
        cwe_id="CWE-829",
        is_vulnerable=False,
        description="Safe plugin loading: allowlist of permitted module names",
        code="""
from flask import Flask, request, abort
import importlib

app = Flask(__name__)
_ALLOWED_PLUGINS = frozenset(["pdf_exporter", "csv_exporter", "json_exporter"])

@app.route("/plugin")
def load_plugin():
    plugin_name = request.args.get("plugin", "")
    # SAFE: strict allowlist of permitted plugin names
    if plugin_name not in _ALLOWED_PLUGINS:
        abort(400)
    mod = importlib.import_module(f"plugins.{plugin_name}")
    return str(mod.run())
""",
    ),
    OWASPCase(
        case_id="OWASP-A08-006",
        category="A08:2021",
        cwe_id="CWE-502",
        is_vulnerable=False,
        description="Safe serialization: msgpack with type validation",
        code="""
import msgpack
from flask import Flask, request, abort

app = Flask(__name__)

def _validate_state(obj: dict) -> bool:
    if not isinstance(obj, dict):
        return False
    allowed_keys = {"user_id", "session_data", "flags"}
    return set(obj.keys()).issubset(allowed_keys) and isinstance(obj.get("user_id"), int)

@app.route("/api/restore", methods=["POST"])
def restore_state():
    try:
        # SAFE: msgpack doesn't execute code; strict type validation follows
        state = msgpack.unpackb(request.data, raw=False)
        if not _validate_state(state):
            abort(400)
    except Exception:
        abort(400)
    return str(state)
""",
    ),
]

# ---------------------------------------------------------------------------
# A09:2021 — Security Logging and Monitoring Failures (CWE-778, CWE-117)
# ---------------------------------------------------------------------------

_A09_CASES: List[OWASPCase] = [
    OWASPCase(
        case_id="OWASP-A09-001",
        category="A09:2021",
        cwe_id="CWE-778",
        is_vulnerable=True,
        description="Logging failure: failed login attempts not logged",
        code="""
import sqlite3
from flask import Flask, request

app = Flask(__name__)

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    conn = sqlite3.connect("app.db")
    row = conn.execute(
        "SELECT id FROM users WHERE username=? AND password=?", (username, password)
    ).fetchone()
    if row:
        return "OK"
    # VULNERABLE: failed login not logged — brute-force attacks invisible to monitoring
    return "Unauthorized", 401
""",
    ),
    OWASPCase(
        case_id="OWASP-A09-002",
        category="A09:2021",
        cwe_id="CWE-117",
        is_vulnerable=True,
        description="Log injection: user input written to log without sanitization",
        code="""
import logging
from flask import Flask, request

app = Flask(__name__)
logger = logging.getLogger("app")

@app.route("/transfer")
def transfer():
    amount = request.args.get("amount", "")
    dest = request.args.get("dest", "")
    # VULNERABLE: attacker can inject newlines to forge log entries
    logger.info(f"Transfer requested: amount={amount} dest={dest}")
    return "Processing"
""",
    ),
    OWASPCase(
        case_id="OWASP-A09-003",
        category="A09:2021",
        cwe_id="CWE-778",
        is_vulnerable=True,
        description="Logging failure: privilege escalation event not audited",
        code="""
from flask import Flask, request, session
import sqlite3

app = Flask(__name__)

@app.route("/admin/promote", methods=["POST"])
def promote_user():
    target_id = request.form.get("user_id")
    conn = sqlite3.connect("app.db")
    # VULNERABLE: role change with no audit log
    conn.execute("UPDATE users SET role='admin' WHERE id=?", (target_id,))
    conn.commit()
    return "User promoted"
""",
    ),
    OWASPCase(
        case_id="OWASP-A09-004",
        category="A09:2021",
        cwe_id="CWE-778",
        is_vulnerable=False,
        description="Secure logging: failed logins logged with IP and timestamp",
        code="""
import logging
import sqlite3
from flask import Flask, request

app = Flask(__name__)
audit_logger = logging.getLogger("audit")

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    ip = request.remote_addr
    conn = sqlite3.connect("app.db")
    row = conn.execute(
        "SELECT id FROM users WHERE username=? AND password=?", (username, password)
    ).fetchone()
    if row:
        audit_logger.info("LOGIN_SUCCESS user=%s ip=%s", username, ip)
        return "OK"
    # SAFE: failure event logged for SIEM/alerting
    audit_logger.warning("LOGIN_FAILURE user=%s ip=%s", username, ip)
    return "Unauthorized", 401
""",
    ),
    OWASPCase(
        case_id="OWASP-A09-005",
        category="A09:2021",
        cwe_id="CWE-117",
        is_vulnerable=False,
        description="Log injection mitigated: input sanitized before logging",
        code="""
import logging
import re
from flask import Flask, request

app = Flask(__name__)
logger = logging.getLogger("app")

def _sanitize_for_log(value: str) -> str:
    # SAFE: strip newlines and carriage returns to prevent log forging
    return re.sub(r"[\\r\\n\\t]", "_", str(value))[:200]

@app.route("/transfer")
def transfer():
    amount = _sanitize_for_log(request.args.get("amount", ""))
    dest = _sanitize_for_log(request.args.get("dest", ""))
    logger.info("Transfer requested: amount=%s dest=%s", amount, dest)
    return "Processing"
""",
    ),
    OWASPCase(
        case_id="OWASP-A09-006",
        category="A09:2021",
        cwe_id="CWE-778",
        is_vulnerable=False,
        description="Secure audit logging: privilege changes logged with actor and timestamp",
        code="""
import logging
import sqlite3
from flask import Flask, request, session
from datetime import datetime, timezone

app = Flask(__name__)
audit = logging.getLogger("audit.access_control")

@app.route("/admin/promote", methods=["POST"])
def promote_user():
    actor_id = session.get("user_id")
    target_id = request.form.get("user_id")
    conn = sqlite3.connect("app.db")
    conn.execute("UPDATE users SET role='admin' WHERE id=?", (target_id,))
    conn.commit()
    # SAFE: audit event with actor, target, and timestamp
    audit.warning(
        "PRIVILEGE_CHANGE actor=%s target=%s new_role=admin ts=%s",
        actor_id, target_id, datetime.now(timezone.utc).isoformat()
    )
    return "User promoted"
""",
    ),
]

# ---------------------------------------------------------------------------
# A10:2021 — Server-Side Request Forgery (CWE-918)
# ---------------------------------------------------------------------------

_A10_CASES: List[OWASPCase] = [
    OWASPCase(
        case_id="OWASP-A10-001",
        category="A10:2021",
        cwe_id="CWE-918",
        is_vulnerable=True,
        description="SSRF: user-supplied URL fetched without validation",
        code="""
import requests
from flask import Flask, request

app = Flask(__name__)

@app.route("/fetch")
def fetch():
    url = request.args.get("url")
    # VULNERABLE: arbitrary URL including internal metadata endpoints
    resp = requests.get(url, timeout=5)
    return resp.text
""",
    ),
    OWASPCase(
        case_id="OWASP-A10-002",
        category="A10:2021",
        cwe_id="CWE-918",
        is_vulnerable=True,
        description="SSRF: webhook URL user-controlled — can reach internal services",
        code="""
import requests
from flask import Flask, request

app = Flask(__name__)

@app.route("/webhook/register", methods=["POST"])
def register_webhook():
    data = request.get_json()
    callback_url = data.get("callback_url")
    # VULNERABLE: webhook fires to attacker-controlled URL pointing to internal service
    requests.post(callback_url, json={"event": "test"}, timeout=3)
    return "Registered"
""",
    ),
    OWASPCase(
        case_id="OWASP-A10-003",
        category="A10:2021",
        cwe_id="CWE-918",
        is_vulnerable=True,
        description="SSRF via urllib: user-supplied URL used with urlopen",
        code="""
from urllib.request import urlopen
from flask import Flask, request

app = Flask(__name__)

@app.route("/proxy")
def proxy():
    target = request.args.get("target")
    # VULNERABLE: urlopen with user-controlled URL
    with urlopen(target) as resp:
        return resp.read().decode("utf-8", errors="replace")
""",
    ),
    OWASPCase(
        case_id="OWASP-A10-004",
        category="A10:2021",
        cwe_id="CWE-918",
        is_vulnerable=False,
        description="SSRF mitigated: URL validated against allowlist of trusted domains",
        code="""
import re
import requests
from flask import Flask, request, abort
from urllib.parse import urlparse

app = Flask(__name__)
_ALLOWED_HOSTS = frozenset(["api.trusted-partner.com", "cdn.example.com"])

def _validate_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
        return (
            parsed.scheme in ("http", "https")
            and parsed.hostname in _ALLOWED_HOSTS
        )
    except Exception:
        return False

@app.route("/fetch")
def fetch():
    url = request.args.get("url", "")
    # SAFE: strict allowlist of approved external hosts
    if not _validate_url(url):
        abort(400)
    resp = requests.get(url, timeout=5)
    return resp.text
""",
    ),
    OWASPCase(
        case_id="OWASP-A10-005",
        category="A10:2021",
        cwe_id="CWE-918",
        is_vulnerable=False,
        description="SSRF mitigated: blocks private/loopback IP ranges via ipaddress module",
        code="""
import ipaddress
import socket
import requests
from flask import Flask, request, abort
from urllib.parse import urlparse

app = Flask(__name__)

def _is_safe_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return False
        hostname = parsed.hostname
        if not hostname:
            return False
        ip = socket.gethostbyname(hostname)
        addr = ipaddress.ip_address(ip)
        # SAFE: block RFC-1918, loopback, link-local and cloud metadata ranges
        return not (
            addr.is_private
            or addr.is_loopback
            or addr.is_link_local
            or str(addr).startswith("169.254.")  # AWS IMDSv1
        )
    except Exception:
        return False

@app.route("/fetch")
def fetch():
    url = request.args.get("url", "")
    if not _is_safe_url(url):
        abort(400)
    resp = requests.get(url, timeout=5)
    return resp.text
""",
    ),
    OWASPCase(
        case_id="OWASP-A10-006",
        category="A10:2021",
        cwe_id="CWE-918",
        is_vulnerable=False,
        description="SSRF mitigated: webhook URLs stored and validated before execution",
        code="""
import ipaddress
import socket
from urllib.parse import urlparse
import requests
from flask import Flask, request, abort

app = Flask(__name__)

def _validate_webhook(url: str) -> bool:
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("https",):   # HTTPS only
            return False
        hostname = parsed.hostname
        ip = socket.gethostbyname(hostname)
        addr = ipaddress.ip_address(ip)
        return not (addr.is_private or addr.is_loopback or addr.is_link_local)
    except Exception:
        return False

@app.route("/webhook/register", methods=["POST"])
def register_webhook():
    data = request.get_json() or {}
    callback_url = data.get("callback_url", "")
    # SAFE: HTTPS only, no internal IPs allowed
    if not _validate_webhook(callback_url):
        abort(400)
    requests.post(callback_url, json={"event": "test"}, timeout=3)
    return "Registered"
""",
    ),
]


# ---------------------------------------------------------------------------
# Combine all cases
# ---------------------------------------------------------------------------

OWASP_CASES: List[OWASPCase] = (
    _A01_CASES
    + _A02_CASES
    + _A03_CASES
    + _A04_CASES
    + _A05_CASES
    + _A06_CASES
    + _A07_CASES
    + _A08_CASES
    + _A09_CASES
    + _A10_CASES
)

# Sanity assertion: each category covered, at least 60 total
assert len(OWASP_CASES) >= 60, f"Expected >=60 OWASP cases, got {len(OWASP_CASES)}"
_categories = {c.category for c in OWASP_CASES}
_expected = {
    "A01:2021", "A02:2021", "A03:2021", "A04:2021", "A05:2021",
    "A06:2021", "A07:2021", "A08:2021", "A09:2021", "A10:2021",
}
assert _categories == _expected, f"Missing OWASP categories: {_expected - _categories}"
