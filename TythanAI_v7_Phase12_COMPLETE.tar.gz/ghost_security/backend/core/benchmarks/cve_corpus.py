"""
CVE Corpus — real vulnerable code patterns from known CVEs.

Each case is based on a real CVE with the vulnerable code pattern
and the fix pattern. Used for regression testing and benchmark scoring.

CVEs covered (adapted to Python patterns):
  SQL injection       — parameterized vs. concatenation patterns (CVE-2018 series)
  Command injection   — shell=True vs. list patterns
  Path traversal      — directory escape patterns
  Deserialization     — pickle/yaml unsafe load (CVE-2017-15715 pattern)
  Secrets exposure    — hardcoded keys/tokens
  SSRF                — unvalidated URL fetch
  XXE                 — xml.etree without defusedxml
  Template injection  — Jinja2 render_template_string with user input
  Open redirect       — unvalidated redirect target
  JWT none algorithm  — CVE-2015-9235 pattern
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class CVECase:
    case_id: str
    cve_id: str
    cwe_id: str
    severity: str
    cvss_score: float
    is_vulnerable: bool      # True = vulnerable version, False = fixed version
    code: str
    description: str
    language: str = "python"


# ---------------------------------------------------------------------------
# SQL Injection (CVE-2018-series patterns)
# ---------------------------------------------------------------------------

_SQLI_CASES: List[CVECase] = [
    CVECase(
        case_id="CVE-SQLI-001-VULN",
        cve_id="CVE-2018-1000001",
        cwe_id="CWE-89",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=True,
        description="SQL injection via string format in login endpoint",
        code="""
import sqlite3

def get_user_by_credentials(username: str, password: str):
    conn = sqlite3.connect("app.db")
    # VULNERABLE: format string injection — ' OR '1'='1 bypasses auth
    query = "SELECT * FROM users WHERE username='%s' AND password='%s'" % (username, password)
    return conn.execute(query).fetchone()
""",
    ),
    CVECase(
        case_id="CVE-SQLI-001-FIXED",
        cve_id="CVE-2018-1000001",
        cwe_id="CWE-89",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=False,
        description="SQL injection fixed with parameterized query",
        code="""
import sqlite3

def get_user_by_credentials(username: str, password: str):
    conn = sqlite3.connect("app.db")
    # FIXED: parameterized query prevents injection
    return conn.execute(
        "SELECT * FROM users WHERE username=? AND password=?",
        (username, password)
    ).fetchone()
""",
    ),
    CVECase(
        case_id="CVE-SQLI-002-VULN",
        cve_id="CVE-2018-1000002",
        cwe_id="CWE-89",
        severity="HIGH",
        cvss_score=8.1,
        is_vulnerable=True,
        description="SQL injection in search endpoint via f-string",
        code="""
import psycopg2
from flask import Flask, request

app = Flask(__name__)

@app.route("/search")
def search():
    term = request.args.get("q", "")
    conn = psycopg2.connect(dsn="dbname=app")
    cur = conn.cursor()
    # VULNERABLE: f-string builds SQL with unsanitized user input
    cur.execute(f"SELECT title, body FROM posts WHERE title ILIKE '%{term}%'")
    return str(cur.fetchall())
""",
    ),
    CVECase(
        case_id="CVE-SQLI-002-FIXED",
        cve_id="CVE-2018-1000002",
        cwe_id="CWE-89",
        severity="HIGH",
        cvss_score=8.1,
        is_vulnerable=False,
        description="SQL injection fixed with psycopg2 parameterized query",
        code="""
import psycopg2
from flask import Flask, request

app = Flask(__name__)

@app.route("/search")
def search():
    term = request.args.get("q", "")
    conn = psycopg2.connect(dsn="dbname=app")
    cur = conn.cursor()
    # FIXED: %s placeholder with tuple argument
    cur.execute("SELECT title, body FROM posts WHERE title ILIKE %s", (f"%{term}%",))
    return str(cur.fetchall())
""",
    ),
    CVECase(
        case_id="CVE-SQLI-003-VULN",
        cve_id="CVE-2018-1000003",
        cwe_id="CWE-89",
        severity="CRITICAL",
        cvss_score=9.1,
        is_vulnerable=True,
        description="Second-order SQL injection: stored value later concatenated",
        code="""
import sqlite3

def update_profile(user_id: int, new_username: str) -> None:
    conn = sqlite3.connect("app.db")
    # Stores potentially malicious value
    conn.execute("UPDATE users SET username=? WHERE id=?", (new_username, user_id))
    conn.commit()

def get_profile_by_username(username: str):
    conn = sqlite3.connect("app.db")
    # VULNERABLE: later retrieval concatenates stored (attacker-controlled) value
    query = "SELECT * FROM profiles WHERE owner='" + username + "'"
    return conn.execute(query).fetchone()
""",
    ),
    CVECase(
        case_id="CVE-SQLI-003-FIXED",
        cve_id="CVE-2018-1000003",
        cwe_id="CWE-89",
        severity="CRITICAL",
        cvss_score=9.1,
        is_vulnerable=False,
        description="Second-order SQL injection fixed: parameterize all queries",
        code="""
import sqlite3

def update_profile(user_id: int, new_username: str) -> None:
    conn = sqlite3.connect("app.db")
    conn.execute("UPDATE users SET username=? WHERE id=?", (new_username, user_id))
    conn.commit()

def get_profile_by_username(username: str):
    conn = sqlite3.connect("app.db")
    # FIXED: parameterized regardless of where value came from
    return conn.execute(
        "SELECT * FROM profiles WHERE owner=?", (username,)
    ).fetchone()
""",
    ),
]

# ---------------------------------------------------------------------------
# Command Injection
# ---------------------------------------------------------------------------

_CMDI_CASES: List[CVECase] = [
    CVECase(
        case_id="CVE-CMDI-001-VULN",
        cve_id="CVE-2019-10758",
        cwe_id="CWE-78",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=True,
        description="Command injection via os.system with user-controlled filename",
        code="""
import os
from flask import Flask, request

app = Flask(__name__)

@app.route("/convert", methods=["POST"])
def convert_image():
    filename = request.form.get("filename", "")
    output = request.form.get("output", "output.png")
    # VULNERABLE: os.system with unescaped user input
    os.system(f"convert {filename} {output}")
    return "Done"
""",
    ),
    CVECase(
        case_id="CVE-CMDI-001-FIXED",
        cve_id="CVE-2019-10758",
        cwe_id="CWE-78",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=False,
        description="Command injection fixed: subprocess with list args, no shell",
        code="""
import subprocess
import os
import re
from flask import Flask, request, abort

app = Flask(__name__)
_SAFE_NAME = re.compile(r"^[a-zA-Z0-9_.-]{1,64}$")

@app.route("/convert", methods=["POST"])
def convert_image():
    filename = request.form.get("filename", "")
    output = request.form.get("output", "output.png")
    # FIXED: validate inputs, list form, no shell interpolation
    if not _SAFE_NAME.match(filename) or not _SAFE_NAME.match(output):
        abort(400)
    subprocess.run(["convert", filename, output], check=True, timeout=30)
    return "Done"
""",
    ),
    CVECase(
        case_id="CVE-CMDI-002-VULN",
        cve_id="CVE-2020-11651",
        cwe_id="CWE-78",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=True,
        description="Command injection via subprocess.Popen with shell=True",
        code="""
import subprocess
from flask import Flask, request

app = Flask(__name__)

@app.route("/dns-lookup")
def dns_lookup():
    domain = request.args.get("domain", "example.com")
    # VULNERABLE: shell=True with user-controlled domain
    proc = subprocess.Popen(
        f"nslookup {domain}", shell=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    out, _ = proc.communicate(timeout=5)
    return out.decode()
""",
    ),
    CVECase(
        case_id="CVE-CMDI-002-FIXED",
        cve_id="CVE-2020-11651",
        cwe_id="CWE-78",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=False,
        description="Command injection fixed: list args without shell expansion",
        code="""
import subprocess
import re
from flask import Flask, request, abort

app = Flask(__name__)
_HOSTNAME_RE = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]{2,})+$")

@app.route("/dns-lookup")
def dns_lookup():
    domain = request.args.get("domain", "example.com")
    if not _HOSTNAME_RE.match(domain):
        abort(400)
    proc = subprocess.run(
        ["nslookup", domain],
        capture_output=True, text=True, timeout=5
    )
    return proc.stdout
""",
    ),
]

# ---------------------------------------------------------------------------
# Path Traversal
# ---------------------------------------------------------------------------

_PATH_TRAV_CASES: List[CVECase] = [
    CVECase(
        case_id="CVE-PATH-001-VULN",
        cve_id="CVE-2018-14574",
        cwe_id="CWE-22",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=True,
        description="Path traversal: user-supplied filename allows reading arbitrary files",
        code="""
from flask import Flask, request
import os

app = Flask(__name__)
DATA_DIR = "/var/app/data"

@app.route("/read")
def read_file():
    filename = request.args.get("file", "")
    # VULNERABLE: ../../etc/passwd traverses out of DATA_DIR
    path = os.path.join(DATA_DIR, filename)
    with open(path) as f:
        return f.read()
""",
    ),
    CVECase(
        case_id="CVE-PATH-001-FIXED",
        cve_id="CVE-2018-14574",
        cwe_id="CWE-22",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=False,
        description="Path traversal fixed: realpath normalization + prefix check",
        code="""
from flask import Flask, request, abort
import os

app = Flask(__name__)
DATA_DIR = os.path.realpath("/var/app/data")

@app.route("/read")
def read_file():
    filename = request.args.get("file", "")
    # FIXED: realpath removes .. sequences; prefix check enforces boundary
    requested = os.path.realpath(os.path.join(DATA_DIR, filename))
    if not requested.startswith(DATA_DIR + os.sep):
        abort(403)
    with open(requested) as f:
        return f.read()
""",
    ),
    CVECase(
        case_id="CVE-PATH-002-VULN",
        cve_id="CVE-2019-1010083",
        cwe_id="CWE-22",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=True,
        description="Path traversal in zip extraction (zip-slip vulnerability)",
        code="""
import zipfile
import os

def extract_archive(zip_path: str, dest_dir: str) -> None:
    with zipfile.ZipFile(zip_path) as zf:
        for member in zf.namelist():
            # VULNERABLE: member name like ../../etc/cron.d/evil escapes dest_dir
            zf.extract(member, dest_dir)
""",
    ),
    CVECase(
        case_id="CVE-PATH-002-FIXED",
        cve_id="CVE-2019-1010083",
        cwe_id="CWE-22",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=False,
        description="Zip-slip fixed: validate each member path before extraction",
        code="""
import zipfile
import os

def extract_archive(zip_path: str, dest_dir: str) -> None:
    dest_dir = os.path.realpath(dest_dir)
    with zipfile.ZipFile(zip_path) as zf:
        for member in zf.namelist():
            target = os.path.realpath(os.path.join(dest_dir, member))
            # FIXED: reject any path that escapes the destination directory
            if not target.startswith(dest_dir + os.sep):
                raise ValueError(f"Zip-slip detected: {member}")
            zf.extract(member, dest_dir)
""",
    ),
]

# ---------------------------------------------------------------------------
# Deserialization (CVE-2017-15715 pattern — pickle/yaml)
# ---------------------------------------------------------------------------

_DESERIAL_CASES: List[CVECase] = [
    CVECase(
        case_id="CVE-DESER-001-VULN",
        cve_id="CVE-2017-15715",
        cwe_id="CWE-502",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=True,
        description="Insecure deserialization: pickle.loads on session cookie data",
        code="""
import pickle
import base64
from flask import Flask, request

app = Flask(__name__)

@app.route("/api/session")
def restore_session():
    encoded = request.cookies.get("session_data", "")
    # VULNERABLE: attacker crafts malicious pickle payload in cookie
    data = pickle.loads(base64.b64decode(encoded))
    return str(data.get("user"))
""",
    ),
    CVECase(
        case_id="CVE-DESER-001-FIXED",
        cve_id="CVE-2017-15715",
        cwe_id="CWE-502",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=False,
        description="Deserialization fixed: itsdangerous signed token instead of raw pickle",
        code="""
import json
import os
from itsdangerous import URLSafeTimedSerializer, BadSignature
from flask import Flask, request, abort

app = Flask(__name__)
_s = URLSafeTimedSerializer(os.environ["SESSION_SECRET"])

@app.route("/api/session")
def restore_session():
    token = request.cookies.get("session_data", "")
    try:
        # FIXED: cryptographically signed token — tampering detected
        data = _s.loads(token, max_age=3600)
    except BadSignature:
        abort(401)
    return str(data.get("user"))
""",
    ),
    CVECase(
        case_id="CVE-DESER-002-VULN",
        cve_id="CVE-2017-18342",
        cwe_id="CWE-502",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=True,
        description="Insecure YAML deserialization: yaml.load without Loader",
        code="""
import yaml
from flask import Flask, request

app = Flask(__name__)

@app.route("/config", methods=["POST"])
def load_config():
    body = request.data.decode()
    # VULNERABLE: yaml.load allows !!python/object// tags for RCE
    config = yaml.load(body)
    return str(config)
""",
    ),
    CVECase(
        case_id="CVE-DESER-002-FIXED",
        cve_id="CVE-2017-18342",
        cwe_id="CWE-502",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=False,
        description="YAML deserialization fixed: yaml.safe_load restricts to basic types",
        code="""
import yaml
from flask import Flask, request

app = Flask(__name__)

@app.route("/config", methods=["POST"])
def load_config():
    body = request.data.decode()
    # FIXED: safe_load disallows !!python/* tags
    config = yaml.safe_load(body)
    return str(config)
""",
    ),
]

# ---------------------------------------------------------------------------
# Secrets Exposure
# ---------------------------------------------------------------------------

_SECRETS_CASES: List[CVECase] = [
    CVECase(
        case_id="CVE-SECRETS-001-VULN",
        cve_id="CVE-2021-44228",
        cwe_id="CWE-312",
        severity="CRITICAL",
        cvss_score=10.0,
        is_vulnerable=True,
        description="Hardcoded AWS credentials in source code",
        code="""
import boto3

AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

def upload_to_s3(bucket: str, key: str, data: bytes) -> None:
    # VULNERABLE: AWS keys hardcoded — committed credentials
    s3 = boto3.client(
        "s3",
        aws_access_key_id=AWS_ACCESS_KEY,
        aws_secret_access_key=AWS_SECRET_KEY,
        region_name="us-east-1",
    )
    s3.put_object(Bucket=bucket, Key=key, Body=data)
""",
    ),
    CVECase(
        case_id="CVE-SECRETS-001-FIXED",
        cve_id="CVE-2021-44228",
        cwe_id="CWE-312",
        severity="CRITICAL",
        cvss_score=10.0,
        is_vulnerable=False,
        description="AWS credentials loaded from IAM role / environment",
        code="""
import boto3
import os

def upload_to_s3(bucket: str, key: str, data: bytes) -> None:
    # FIXED: boto3 uses IAM instance role or environment vars — no hardcoded keys
    s3 = boto3.client("s3", region_name=os.environ.get("AWS_REGION", "us-east-1"))
    s3.put_object(Bucket=bucket, Key=key, Body=data)
""",
    ),
    CVECase(
        case_id="CVE-SECRETS-002-VULN",
        cve_id="CVE-2019-14234",
        cwe_id="CWE-798",
        severity="HIGH",
        cvss_score=8.0,
        is_vulnerable=True,
        description="Hardcoded database password in connection string",
        code="""
import psycopg2

DB_URL = "postgresql://admin:SuperSecret123!@db.internal:5432/production"

def get_connection():
    # VULNERABLE: credentials in source code string
    return psycopg2.connect(DB_URL)
""",
    ),
    CVECase(
        case_id="CVE-SECRETS-002-FIXED",
        cve_id="CVE-2019-14234",
        cwe_id="CWE-798",
        severity="HIGH",
        cvss_score=8.0,
        is_vulnerable=False,
        description="Database credentials loaded from environment variables",
        code="""
import psycopg2
import os

def get_connection():
    # FIXED: all credentials from environment variables
    return psycopg2.connect(
        host=os.environ["DB_HOST"],
        dbname=os.environ["DB_NAME"],
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
    )
""",
    ),
]

# ---------------------------------------------------------------------------
# SSRF
# ---------------------------------------------------------------------------

_SSRF_CASES: List[CVECase] = [
    CVECase(
        case_id="CVE-SSRF-001-VULN",
        cve_id="CVE-2021-21985",
        cwe_id="CWE-918",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=True,
        description="SSRF: fetches user-supplied URL to AWS metadata endpoint",
        code="""
import requests
from flask import Flask, request

app = Flask(__name__)

@app.route("/preview")
def url_preview():
    url = request.args.get("url", "")
    # VULNERABLE: attacker supplies http://169.254.169.254/latest/meta-data/iam/...
    resp = requests.get(url, timeout=3)
    return resp.text[:500]
""",
    ),
    CVECase(
        case_id="CVE-SSRF-001-FIXED",
        cve_id="CVE-2021-21985",
        cwe_id="CWE-918",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=False,
        description="SSRF fixed: private IP ranges and metadata IPs blocked",
        code="""
import ipaddress
import socket
from urllib.parse import urlparse
import requests
from flask import Flask, request, abort

app = Flask(__name__)

_BLOCKED_PREFIXES = ("169.254.", "10.", "192.168.", "172.16.", "172.17.", "172.18.",
                     "172.19.", "172.20.", "172.21.", "172.22.", "172.23.",
                     "172.24.", "172.25.", "172.26.", "172.27.", "172.28.",
                     "172.29.", "172.30.", "172.31.", "127.", "::1", "fc", "fd")

def _is_safe(url: str) -> bool:
    try:
        h = urlparse(url).hostname
        ip = socket.gethostbyname(h)
        return not any(ip.startswith(p) for p in _BLOCKED_PREFIXES)
    except Exception:
        return False

@app.route("/preview")
def url_preview():
    url = request.args.get("url", "")
    if not _is_safe(url):
        abort(400)
    resp = requests.get(url, timeout=3)
    return resp.text[:500]
""",
    ),
    CVECase(
        case_id="CVE-SSRF-002-VULN",
        cve_id="CVE-2021-29447",
        cwe_id="CWE-918",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=True,
        description="SSRF in image processing: httpx fetch of user-supplied image URL",
        code="""
import httpx
from PIL import Image
from io import BytesIO
from flask import Flask, request

app = Flask(__name__)

@app.route("/thumbnail", methods=["POST"])
def make_thumbnail():
    image_url = request.json.get("image_url", "")
    # VULNERABLE: arbitrary URL including internal services
    resp = httpx.get(image_url, follow_redirects=True)
    img = Image.open(BytesIO(resp.content))
    img.thumbnail((128, 128))
    buf = BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue(), 200, {"Content-Type": "image/png"}
""",
    ),
    CVECase(
        case_id="CVE-SSRF-002-FIXED",
        cve_id="CVE-2021-29447",
        cwe_id="CWE-918",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=False,
        description="SSRF fixed: URL validated against allowlist before image fetch",
        code="""
import httpx
import ipaddress
import socket
from urllib.parse import urlparse
from PIL import Image
from io import BytesIO
from flask import Flask, request, abort

app = Flask(__name__)

def _safe_external_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return False
        ip = socket.gethostbyname(parsed.hostname)
        addr = ipaddress.ip_address(ip)
        return not (addr.is_private or addr.is_loopback or addr.is_link_local)
    except Exception:
        return False

@app.route("/thumbnail", methods=["POST"])
def make_thumbnail():
    image_url = request.json.get("image_url", "")
    if not _safe_external_url(image_url):
        abort(400)
    resp = httpx.get(image_url, follow_redirects=False, timeout=5)
    img = Image.open(BytesIO(resp.content))
    img.thumbnail((128, 128))
    buf = BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue(), 200, {"Content-Type": "image/png"}
""",
    ),
]

# ---------------------------------------------------------------------------
# XXE — adapted to Python xml.etree
# ---------------------------------------------------------------------------

_XXE_CASES: List[CVECase] = [
    CVECase(
        case_id="CVE-XXE-001-VULN",
        cve_id="CVE-2019-20907",
        cwe_id="CWE-611",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=True,
        description="XXE: xml.etree.ElementTree parses user XML (Python < 3.8 expands external entities)",
        code="""
import xml.etree.ElementTree as ET
from flask import Flask, request

app = Flask(__name__)

@app.route("/parse-xml", methods=["POST"])
def parse_xml():
    # VULNERABLE: standard ET can be exploited with billion-laughs or entity-based XXE
    # on Python versions that haven't hardened the parser by default.
    xml_data = request.data
    root = ET.fromstring(xml_data)
    return root.tag
""",
    ),
    CVECase(
        case_id="CVE-XXE-001-FIXED",
        cve_id="CVE-2019-20907",
        cwe_id="CWE-611",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=False,
        description="XXE fixed: defusedxml prevents entity expansion and external DTD loading",
        code="""
import defusedxml.ElementTree as ET
from flask import Flask, request

app = Flask(__name__)

@app.route("/parse-xml", methods=["POST"])
def parse_xml():
    # FIXED: defusedxml raises on entity expansion, external entities, and billion-laughs
    xml_data = request.data
    root = ET.fromstring(xml_data)
    return root.tag
""",
    ),
    CVECase(
        case_id="CVE-XXE-002-VULN",
        cve_id="CVE-2021-28965",
        cwe_id="CWE-611",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=True,
        description="XXE via lxml without resolve_entities=False",
        code="""
from lxml import etree
from flask import Flask, request

app = Flask(__name__)

@app.route("/transform", methods=["POST"])
def transform():
    xml_data = request.data
    # VULNERABLE: lxml by default resolves entities and may load external resources
    parser = etree.XMLParser()
    root = etree.fromstring(xml_data, parser)
    return etree.tostring(root).decode()
""",
    ),
    CVECase(
        case_id="CVE-XXE-002-FIXED",
        cve_id="CVE-2021-28965",
        cwe_id="CWE-611",
        severity="HIGH",
        cvss_score=7.5,
        is_vulnerable=False,
        description="XXE fixed: lxml parser with resolve_entities and no_network disabled",
        code="""
from lxml import etree
from flask import Flask, request

app = Flask(__name__)

@app.route("/transform", methods=["POST"])
def transform():
    xml_data = request.data
    # FIXED: disable entity resolution and network access
    parser = etree.XMLParser(
        resolve_entities=False,
        no_network=True,
        load_dtd=False,
    )
    root = etree.fromstring(xml_data, parser)
    return etree.tostring(root).decode()
""",
    ),
]

# ---------------------------------------------------------------------------
# Template Injection (Jinja2 — CVE-2016-10516 pattern)
# ---------------------------------------------------------------------------

_SSTI_CASES: List[CVECase] = [
    CVECase(
        case_id="CVE-SSTI-001-VULN",
        cve_id="CVE-2016-10516",
        cwe_id="CWE-94",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=True,
        description="Server-Side Template Injection: user input inside Jinja2 template string",
        code="""
from flask import Flask, request, render_template_string

app = Flask(__name__)

@app.route("/greet")
def greet():
    name = request.args.get("name", "World")
    # VULNERABLE: user controls the template content — {{7*7}} → 49, {{config}} leaks secrets
    template = f"Hello {name}!"
    return render_template_string(template)
""",
    ),
    CVECase(
        case_id="CVE-SSTI-001-FIXED",
        cve_id="CVE-2016-10516",
        cwe_id="CWE-94",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=False,
        description="SSTI fixed: user input passed as template variable, not in template string",
        code="""
from flask import Flask, request, render_template_string

app = Flask(__name__)

@app.route("/greet")
def greet():
    name = request.args.get("name", "World")
    # FIXED: user value is a template variable (auto-escaped), not part of the template
    return render_template_string("Hello {{ name }}!", name=name)
""",
    ),
    CVECase(
        case_id="CVE-SSTI-002-VULN",
        cve_id="CVE-2019-8341",
        cwe_id="CWE-94",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=True,
        description="SSTI via Jinja2 Environment with user-controlled template source",
        code="""
from jinja2 import Environment
from flask import Flask, request

app = Flask(__name__)
jinja_env = Environment()

@app.route("/render", methods=["POST"])
def render():
    template_src = request.form.get("template", "")
    # VULNERABLE: user supplies the full template source — sandbox bypass possible
    tmpl = jinja_env.from_string(template_src)
    return tmpl.render()
""",
    ),
    CVECase(
        case_id="CVE-SSTI-002-FIXED",
        cve_id="CVE-2019-8341",
        cwe_id="CWE-94",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=False,
        description="SSTI fixed: use SandboxedEnvironment and restrict template loading to file system",
        code="""
from jinja2.sandbox import SandboxedEnvironment
from flask import Flask, request, abort

app = Flask(__name__)
# FIXED: SandboxedEnvironment limits access to Python internals
jinja_env = SandboxedEnvironment()
_ALLOWED_TEMPLATES = frozenset(["welcome", "invoice", "notification"])

@app.route("/render", methods=["POST"])
def render():
    template_name = request.form.get("template_name", "")
    data = request.form.get("data", {})
    if template_name not in _ALLOWED_TEMPLATES:
        abort(400)
    # Template loaded from controlled file, user supplies only context data
    tmpl = jinja_env.from_string(open(f"templates/{template_name}.html").read())
    return tmpl.render(data=data)
""",
    ),
]

# ---------------------------------------------------------------------------
# Open Redirect
# ---------------------------------------------------------------------------

_REDIRECT_CASES: List[CVECase] = [
    CVECase(
        case_id="CVE-REDIRECT-001-VULN",
        cve_id="CVE-2018-0489",
        cwe_id="CWE-601",
        severity="MEDIUM",
        cvss_score=6.1,
        is_vulnerable=True,
        description="Open redirect: user-controlled 'next' parameter used directly in redirect",
        code="""
from flask import Flask, request, redirect

app = Flask(__name__)

@app.route("/login", methods=["POST"])
def login():
    next_url = request.args.get("next", "/dashboard")
    # VULNERABLE: attacker supplies next=https://evil.com for phishing
    return redirect(next_url)
""",
    ),
    CVECase(
        case_id="CVE-REDIRECT-001-FIXED",
        cve_id="CVE-2018-0489",
        cwe_id="CWE-601",
        severity="MEDIUM",
        cvss_score=6.1,
        is_vulnerable=False,
        description="Open redirect fixed: only relative paths allowed, external URLs rejected",
        code="""
from flask import Flask, request, redirect, url_for, abort
from urllib.parse import urlparse, urljoin

app = Flask(__name__)

def _is_safe_redirect(url: str) -> bool:
    # SAFE: allow only relative paths or same-host URLs
    parsed = urlparse(url)
    return not parsed.netloc  # no host component means relative

@app.route("/login", methods=["POST"])
def login():
    next_url = request.args.get("next", "/dashboard")
    if not _is_safe_redirect(next_url):
        next_url = "/dashboard"
    return redirect(next_url)
""",
    ),
]

# ---------------------------------------------------------------------------
# JWT None Algorithm (CVE-2015-9235)
# ---------------------------------------------------------------------------

_JWT_CASES: List[CVECase] = [
    CVECase(
        case_id="CVE-JWT-001-VULN",
        cve_id="CVE-2015-9235",
        cwe_id="CWE-327",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=True,
        description="JWT none algorithm accepted: allows token forgery without a secret",
        code="""
import jwt
from flask import Flask, request, jsonify

app = Flask(__name__)
SECRET = "my_secret"

@app.route("/verify")
def verify():
    token = request.headers.get("Authorization", "").removeprefix("Bearer ")
    # VULNERABLE: algorithms not restricted — attacker can set alg:none and forge tokens
    payload = jwt.decode(token, SECRET, algorithms=["HS256", "none"])
    return jsonify(payload)
""",
    ),
    CVECase(
        case_id="CVE-JWT-001-FIXED",
        cve_id="CVE-2015-9235",
        cwe_id="CWE-327",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=False,
        description="JWT none algorithm fixed: explicit algorithm list excludes 'none'",
        code="""
import jwt
import os
from flask import Flask, request, jsonify, abort

app = Flask(__name__)
SECRET = os.environ["JWT_SECRET"]

@app.route("/verify")
def verify():
    token = request.headers.get("Authorization", "").removeprefix("Bearer ")
    try:
        # FIXED: only HS256 allowed — 'none' and algorithm confusion prevented
        payload = jwt.decode(token, SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        abort(401)
    return jsonify(payload)
""",
    ),
    CVECase(
        case_id="CVE-JWT-002-VULN",
        cve_id="CVE-2022-21449",
        cwe_id="CWE-347",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=True,
        description="JWT signature not verified: decode called without verification",
        code="""
import jwt
from flask import Flask, request

app = Flask(__name__)

@app.route("/profile")
def profile():
    token = request.cookies.get("auth_token", "")
    # VULNERABLE: verify=False skips signature check entirely
    payload = jwt.decode(token, options={"verify_signature": False})
    user_id = payload.get("sub")
    return f"User: {user_id}"
""",
    ),
    CVECase(
        case_id="CVE-JWT-002-FIXED",
        cve_id="CVE-2022-21449",
        cwe_id="CWE-347",
        severity="CRITICAL",
        cvss_score=9.8,
        is_vulnerable=False,
        description="JWT signature properly verified with secret and algorithm",
        code="""
import jwt
import os
from flask import Flask, request, abort

app = Flask(__name__)
_SECRET = os.environ["JWT_SECRET"]

@app.route("/profile")
def profile():
    token = request.cookies.get("auth_token", "")
    try:
        # FIXED: signature verified with correct secret and algorithm
        payload = jwt.decode(token, _SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        abort(401)
    user_id = payload.get("sub")
    return f"User: {user_id}"
""",
    ),
]


# ---------------------------------------------------------------------------
# Combine all CVE cases
# ---------------------------------------------------------------------------

CVE_CASES: List[CVECase] = (
    _SQLI_CASES
    + _CMDI_CASES
    + _PATH_TRAV_CASES
    + _DESERIAL_CASES
    + _SECRETS_CASES
    + _SSRF_CASES
    + _XXE_CASES
    + _SSTI_CASES
    + _REDIRECT_CASES
    + _JWT_CASES
)

# Sanity check: at least 30 cases with both vulnerable and fixed variants
assert len(CVE_CASES) >= 30, f"Expected >=30 CVE cases, got {len(CVE_CASES)}"
_vuln_ids = {c.cve_id for c in CVE_CASES if c.is_vulnerable}
_fixed_ids = {c.cve_id for c in CVE_CASES if not c.is_vulnerable}
assert _vuln_ids == _fixed_ids, (
    f"CVE IDs without both versions — vuln_only={_vuln_ids - _fixed_ids}, "
    f"fixed_only={_fixed_ids - _vuln_ids}"
)
