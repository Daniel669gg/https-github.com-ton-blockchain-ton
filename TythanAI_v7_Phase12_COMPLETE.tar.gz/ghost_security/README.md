# TythanAI — Security Scanner

**Real-time SAST/SCA for developers who ship fast.**  
Semgrep · OSV.dev · EPSS · SARIF · GitHub Actions · Docker

[![PyPI version](https://img.shields.io/pypi/v/tythanai.svg?color=purple)](https://pypi.org/project/tythanai/)
[![Python](https://img.shields.io/pypi/pyversions/tythanai.svg)](https://pypi.org/project/tythanai/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![GitHub Action](https://img.shields.io/badge/GitHub-Action-blue?logo=github-actions)](action.yml)

---

## What TythanAI does

TythanAI scans your codebase in seconds and tells you exactly which vulnerabilities matter:

- **SAST** — static analysis via Semgrep 1.164.0 (3 000+ rules, 15 languages)
- **SCA** — dependency CVEs via OSV.dev (500 000+ known vulnerabilities, real-time)
- **EPSS** — exploit probability scores so you fix the right HIGH before the wrong CRITICAL
- **Secrets** — API keys, tokens, private keys in source code
- **SARIF** — output compatible with GitHub Code Scanning, SonarQube, VS Code

---

## Quick start

```bash
pip install tythanai
tythanai scan ./myproject
```

**That's it.** No account. No API key. No upload.

---

## Terminal demo

```
$ tythanai scan ./backend

  TythanAI v6.5  — scanning ./backend
  ────────────────────────────────────────────────────
  Semgrep      ✓  47 rules matched
  OSV.dev      ✓  3 vulnerable deps found (online)
  EPSS         ✓  scores fetched
  Secrets      ✓  1 pattern matched
  ────────────────────────────────────────────────────
  Scan duration: 4.2s   Files: 183   Deps checked: 42

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │  CRITICAL  1   ████████████████████████████████  CVSS 9.8, EPSS 0.94       │
  │  HIGH      6   ████████████████                                             │
  │  MEDIUM   12   ████████                                                     │
  │  LOW       8   ████                                                         │
  └─────────────────────────────────────────────────────────────────────────────┘

  #1  CRITICAL  CWE-89 · SQL Injection
      backend/api/users.py:142
      f"SELECT * FROM users WHERE id = {user_id}"
      Fix: Use parameterized queries. EPSS: 0.94 (actively exploited)

  #2  HIGH  CWE-798 · Hard-coded credential
      backend/config.py:17
      SECRET_KEY = "my-super-secret-key-1234"
      Fix: Load from environment variable

  #3  HIGH  CVE-2024-35195 · requests 2.31.0
      GHSA-9wx4-h78v-vm56  CVSS 5.6
      Fix: pip install requests>=2.32.0

  ... 25 more findings (run with --all to see)

  Risk score: 78 / 100  ██████████████████████░░░░  HIGH
```

---

## GitHub Actions

Add TythanAI to any repository in 5 lines:

```yaml
# .github/workflows/security.yml
name: Security Scan
on: [push, pull_request]

jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: tythanai/scan-action@v1
```

Results appear automatically in the **Security → Code Scanning** tab.

### Full options

```yaml
- uses: tythanai/scan-action@v1
  with:
    target: "./src"          # what to scan (default: whole repo)
    severity: "HIGH"         # minimum severity to report
    fail_on: "HIGH"          # fail the build on HIGH or CRITICAL
    format: "sarif"          # sarif | json | markdown
    enable_osv: "true"       # CVE dependency check via OSV.dev
    enable_epss: "true"      # EPSS exploit probability enrichment
    upload_sarif: "true"     # auto-upload to GitHub Code Scanning
```

---

## Docker

```bash
# Scan current directory
docker run --rm -v $(pwd):/scan ghcr.io/tythanai/scanner:latest scan /scan

# Output SARIF file
docker run --rm -v $(pwd):/scan ghcr.io/tythanai/scanner:latest \
  scan /scan --format sarif --output /scan/results.sarif

# Quick scan — only CRITICAL/HIGH
docker run --rm -v $(pwd):/scan ghcr.io/tythanai/scanner:latest \
  scan /scan --quick --severity HIGH
```

---

## CLI reference

```
Usage: tythanai [OPTIONS] COMMAND

Commands:
  scan     Scan a directory or file
  version  Show version
  status   Show available scanners

Options for scan:
  --format       text | json | sarif | markdown | html | csv  (default: text)
  --output       Write results to file instead of stdout
  --severity     Minimum severity: LOW | MEDIUM | HIGH | CRITICAL
  --quick        Fast scan (Semgrep only, no OSV/EPSS)
  --no-semgrep   Skip Semgrep SAST
  --no-osv       Skip OSV.dev dependency check
  --no-epss      Skip EPSS enrichment
  --max-findings Maximum findings to return (default: 500)
  --timeout      Scan timeout in seconds (default: 120)
```

---

## Supported languages

| Language | SAST rules | Secrets | Web3 |
|----------|-----------|---------|------|
| Python | 800+ | ✓ | — |
| JavaScript / TypeScript | 600+ | ✓ | — |
| Java | 400+ | ✓ | — |
| Go | 350+ | ✓ | — |
| Ruby | 200+ | ✓ | — |
| PHP | 150+ | ✓ | — |
| C / C++ | 180+ | — | — |
| Solidity | 80+ | — | ✓ |
| TON FunC | 28 | — | ✓ |
| TON Tact | 20 | — | ✓ |
| Kotlin, Scala, Swift, Rust | 100+ each | ✓ | — |

---

## How TythanAI compares

| Feature | TythanAI | Snyk | Semgrep OSS | CodeQL |
|---------|----------|------|-------------|--------|
| SAST (static analysis) | ✓ | partial | ✓ | ✓ |
| SCA (CVE dependencies) | ✓ OSV.dev | ✓ | ✗ | ✗ |
| EPSS exploit probability | ✓ | ✗ | ✗ | ✗ |
| CISA KEV flag | ✓ | partial | ✗ | ✗ |
| SARIF output | ✓ | ✓ | ✓ | ✓ |
| Secrets detection | ✓ | ✓ | partial | ✗ |
| Web3 / TON / Solidity | ✓ | ✗ | ✗ | ✗ |
| GitHub Actions | ✓ | ✓ | ✓ | ✓ |
| Docker image | ✓ | ✓ | ✓ | ✓ |
| Pip install | ✓ | ✗ | ✓ | ✗ |
| No account required | ✓ | ✗ | ✓ | ✗ |
| Auto-generated rules | ✓ | ✗ | ✗ | ✗ |
| Knowledge graph | ✓ | ✗ | ✗ | partial |
| Price (open source) | **Free** | Free tier | Free | Free |
| Price (team) | **$0–$49/mo** | $98/dev/mo | $40/dev/mo | $19/dev/mo |

---

## Architecture

```
tythanai scan ./target
        │
        ├─► Semgrep 1.164.0 ──── 3000+ rules ──► NormalizedFinding
        ├─► AST Engine ─────────────────────────► NormalizedFinding
        ├─► Secrets Scanner ────────────────────► NormalizedFinding
        ├─► OSV.dev API ─────── CVEs + GHSAs ──► NormalizedFinding
        ├─► EPSS Enricher ───── exploit score ──► NormalizedFinding
        │
        ├─► DeduplicatorFilter (SHA-256 IDs)
        ├─► PriorityScorer (CVSS + EPSS + KEV)
        │
        ├─► FixBridge ────────────────────────── suggested fixes
        ├─► RuleGenerator ───────────────────── auto Semgrep rules
        │
        └─► ReportGenerator
                ├─ SARIF 2.1.0
                ├─ JSON
                ├─ Markdown
                ├─ HTML
                └─ CSV
```

---

## Pricing

| Plan | Price | For |
|------|-------|-----|
| **Free** | $0 forever | Open source, personal projects |
| **Pro** | $19/month | Solo developers, freelancers |
| **Team** | $49/month | Up to 10 developers |
| **Enterprise** | Custom | Unlimited devs, on-prem, SLA |

All plans include: full SAST, OSV.dev SCA, EPSS, SARIF, GitHub Actions.  
Pro/Team add: priority support, historical trends, Slack/Jira integrations.

---

## Installation

**pip (recommended):**
```bash
pip install tythanai
tythanai scan .
```

**Docker:**
```bash
docker pull ghcr.io/tythanai/scanner:latest
docker run --rm -v $(pwd):/scan ghcr.io/tythanai/scanner:latest scan /scan
```

**From source:**
```bash
git clone https://github.com/tythanai/platform
cd platform
pip install -e ".[full]"
tythanai scan .
```

---

## Requirements

- Python 3.10+
- Internet access for OSV.dev and EPSS (optional — scans work offline without CVE enrichment)

---

## License

MIT. See [LICENSE](LICENSE).

---

## Contributing

Issues and PRs welcome. See [CONTRIBUTING.md](CONTRIBUTING.md).

For security vulnerabilities in TythanAI itself, see [SECURITY.md](SECURITY.md).
