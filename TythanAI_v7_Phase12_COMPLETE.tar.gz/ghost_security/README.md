# TythanAI — Security Scanner

**The only scanner with native TON FunC/Tolk, Solana Anchor, and CosmWasm support — plus SAST, SCA, secrets, IaC, and AutoPR in one tool.**

[![License: BSL 1.1](https://img.shields.io/badge/License-BSL%201.1-orange.svg)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/)
[![Tests](https://img.shields.io/badge/tests-3596%20passing-brightgreen)]()
[![GitHub Action](https://img.shields.io/badge/GitHub-Action-blue?logo=github-actions)](action.yml)

---

## What it does

TythanAI scans your codebase and tells you which vulnerabilities matter:

- **SAST** — static analysis with 3 462 custom rules across 12 languages
- **SCA** — dependency CVEs via OSV.dev with EPSS exploit-probability scoring
- **Secrets** — API keys, tokens, private keys in source and git history
- **IaC** — Terraform, CloudFormation, Kubernetes misconfigurations
- **Web3 audit** — TON FunC/Tolk, Solidity, Solana/Anchor, CosmWasm
- **AutoPR** — auto-generated fix pull requests for HIGH/CRITICAL findings
- **SBOM** — SPDX 2.3 and CycloneDX 1.4 output
- **SARIF** — compatible with GitHub Code Scanning and SonarQube

---

## Quick start (from source)

```bash
git clone https://github.com/tythanai/platform
cd platform
pip install -e ".[full]"
python ghost_cli_main.py scan ./myproject
```

> **PyPI package and Docker image are not yet published.** Follow this repo for the release announcement.

---

## GitHub Actions

```yaml
# .github/workflows/security.yml
name: Security Scan
on: [push, pull_request]

jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: tythanai/scan-action@v1
        with:
          target: "./src"
          severity: "HIGH"
          fail_on: "HIGH"
          format: "sarif"
          upload_sarif: "true"
```

---

## CLI reference

```
python ghost_cli_main.py scan [OPTIONS] TARGET

Options:
  --format       text | json | sarif | html  (default: text)
  --output       Write results to file
  --severity     Minimum severity: LOW | MEDIUM | HIGH | CRITICAL
  --quality      Include code quality analysis
  --multichain   Include Solana + CosmWasm auditor
  --dast URL     Passive DAST scan against URL (requires ZAP)
  --auto-fix     Generate fix PRs (dry-run without --github-token)
```

---

## Supported languages and rule counts

| Language | Rules | Notes |
|----------|-------|-------|
| Python | 359 | Taint analysis + custom rules |
| JavaScript / TypeScript | 231 | |
| Java | 102 | CPG taint analysis |
| Go | 65 | CPG taint analysis |
| Rust | 45 | CPG + unsafe block detection |
| PHP | 65 | |
| Ruby | 30 | |
| Solidity (EVM) | 121 | DeFi patterns, reentrancy, oracle |
| TON FunC / Tolk | 46 | Reentrancy, replay, weak random, bounce |
| Solana / Anchor | 49 | Signer check, CPI validation, PDA |
| CosmWasm | 15 | Admin check, reply ID, submsg ordering |
| Secrets (all languages) | 416 | Git history + live |
| IaC / Cloud / CI-CD | 274 | Terraform, K8s, CloudFormation |

---

## How TythanAI compares

| Feature | TythanAI | Semgrep OSS | Snyk | GitHub GHAS |
|---------|----------|-------------|------|-------------|
| SAST | ✓ | ✓ | partial | ✓ |
| SCA (OSV.dev) | ✓ | ✗ | ✓ | ✓ |
| EPSS scoring | ✓ | ✗ | ✗ | ✗ |
| Secrets | ✓ | partial | ✓ | ✓ |
| TON FunC / Tolk | ✓ | ✗ | ✗ | ✗ |
| Solana / Anchor | ✓ | ✗ | ✗ | ✗ |
| CosmWasm | ✓ | ✗ | ✗ | ✗ |
| AutoPR fix PRs | ✓ | ✗ | ✗ | ✗ |
| SBOM (SPDX+CycloneDX) | ✓ | ✗ | partial | ✗ |
| No account required | ✓ | ✓ | ✗ | ✗ |

---

## Accuracy

Measured on a 98-case Python corpus (Juliet-style, 65 vulnerable / 33 safe):

| Metric | Score |
|--------|-------|
| Precision | 90.0 % |
| Recall | 83.1 % |
| F1 | 86.4 % |

This measures only the TaintAnalyzer engine on Python taint cases. See [BENCHMARK_REPORT.md](BENCHMARK_REPORT.md) for per-CWE breakdown and limitations.

---

## Architecture

```
tythanai scan ./target
        │
        ├─► Semgrep + 3 462 custom rules ──► NormalizedFinding
        ├─► CPG TaintAnalyzer (Python/JS/Go/Java/Rust)
        ├─► Secrets Scanner (live + git history)
        ├─► OSV.dev SCA ──── CVEs + GHSAs ──► EPSS enrichment
        ├─► IaC / Container Scanner
        ├─► Web3 Auditors (TON / Solana / CosmWasm / Solidity)
        │
        ├─► FP Reducer (confidence scoring)
        ├─► AutoPR Agent (optional fix PRs)
        │
        └─► ReportGenerator
                ├─ SARIF 2.1.0
                ├─ JSON / HTML / Markdown
                └─ SBOM (SPDX 2.3, CycloneDX 1.4)
```

---

## Requirements

- Python 3.10+
- Optional: Semgrep (`pip install semgrep`) for SAST rules
- Optional: ZAP for DAST
- Optional: ChromaDB for rules marketplace vector search

---

## License

[Business Source License 1.1](LICENSE) — source available, free for non-production and evaluation use. Commercial production use requires a licence. Converts to Apache 2.0 on 2029-06-01.

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Security issues: [SECURITY.md](SECURITY.md).
