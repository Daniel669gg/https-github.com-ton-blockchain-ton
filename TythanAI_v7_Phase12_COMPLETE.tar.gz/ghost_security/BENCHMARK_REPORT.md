# TythanAI — Accuracy Benchmark Report

**Suite:** Juliet+OWASP-style Python Corpus v1.0
**Run:** 2026-06-03
**Scanner:** TythanAI TaintAnalyzer (default engine)
**Corpus:** 98 hand-labelled cases — 65 vulnerable, 33 safe — across 9 CWE classes

> Reproduce locally:
> ```bash
> python -c "from backend.core.benchmarks.runner import run_real_benchmark, print_benchmark_report; print_benchmark_report(run_real_benchmark())"
> ```
> The runner writes each case to a temp file and invokes the real scanner — no
> precomputed or hand-tuned results.

---

## Aggregate Metrics

| Metric | Score |
|--------|-------|
| Precision | **90.0 %** |
| Recall    | **83.1 %** |
| F1 Score  | **86.4 %** |
| Specificity | 81.8 % |
| TP / FP / TN / FN | 54 / 6 / 27 / 11 |

Precision 90 % means ~1 in 10 flagged items on this corpus is a false positive.
Recall 83 % means the scanner misses ~1 in 6 real vulnerabilities — primarily
indirect, multi-step taint flows (see Limitations).

---

## Per-CWE Breakdown

| CWE | Class | Precision | Recall | F1 | TP | FP | TN | FN |
|-----|-------|-----------|--------|----|----|----|----|----|
| CWE-89  | SQL Injection         | 92.9 % | 92.9 %  | 92.9 % | 13 | 1 | 5 | 1 |
| CWE-94  | Code Injection        | 87.5 % | 100.0 % | 93.3 % | 7  | 1 | 2 | 0 |
| CWE-327 | Weak Crypto           | 100.0 %| 80.0 %  | 88.9 % | 4  | 0 | 4 | 1 |
| CWE-117 | Log Injection         | 85.7 % | 85.7 %  | 85.7 % | 6  | 1 | 2 | 1 |
| CWE-22  | Path Traversal        | 100.0 %| 71.4 %  | 83.3 % | 5  | 0 | 3 | 2 |
| CWE-78  | OS Command Injection  | 81.8 % | 81.8 %  | 81.8 % | 9  | 2 | 3 | 2 |
| CWE-79  | Cross-Site Scripting  | 80.0 % | 80.0 %  | 80.0 % | 4  | 1 | 2 | 1 |
| CWE-502 | Unsafe Deserialization| 100.0 %| 66.7 %  | 80.0 % | 4  | 0 | 3 | 2 |
| CWE-798 | Hardcoded Credentials | 100.0 %| 66.7 %  | 80.0 % | 2  | 0 | 3 | 1 |

---

## Limitations (read this)

- **This corpus is small (98 cases) and Python-only.** It is an internal
  regression/smoke benchmark, **not** an industry-standard run of the full NIST
  Juliet 1.3 suite or the OWASP Benchmark project. Do not read these numbers as
  comparable to published third-party SAST benchmarks.
- **Recall gaps are real and intentional.** The TaintAnalyzer optimises for
  precision; it misses some indirect multi-step flows (CWE-22, CWE-502) and has
  limited literal-secret reasoning (CWE-798). Dedicated detectors
  (`git_secrets`, Semgrep rules) cover some of these gaps in a full scan but are
  not part of this single-engine benchmark.
- **Other engines are not measured here.** TythanAI runs Semgrep, OSV.dev SCA,
  secrets, IaC, container, and Web3 auditors in addition to the TaintAnalyzer.
  This report measures only the TaintAnalyzer on Python taint cases.

A larger, multi-language benchmark against the full Juliet 1.3 and OWASP
Benchmark corpora is on the roadmap. We will publish those numbers — including
the unflattering ones — when they are run.

---
*TythanAI Labs — internal accuracy benchmark. Methodology and corpus are in
`backend/core/benchmarks/`.*
