"""
Tests for:
  - DASTScanner   (backend/scanners/dast_scanner.py)
  - AutoPRAgent   (backend/agents/auto_pr_agent.py)
  - SwiftScanner  (scanners/swift_scanner.py)
"""
from __future__ import annotations

import io
import json
import sys
import types
import urllib.error
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import pytest

# ── resolve project root ───────────────────────────────────────────────────────
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

# ── imports under test ─────────────────────────────────────────────────────────
from backend.scanners.dast_scanner import DASTScanner, _alert_dict_to_finding_dict
from backend.agents.auto_pr_agent import AutoPRAgent, AutoPRResult, _PR_TIMESTAMPS
from scanners.swift_scanner import SwiftScanner


# =============================================================================
# DASTScanner
# =============================================================================

class TestDASTScanner:

    # -- helpers ---------------------------------------------------------------

    @staticmethod
    def _make_sqli_alert(**overrides) -> dict:
        """Return a minimal ZAP SQLi alert dict."""
        base = {
            "alert":       "SQL Injection",
            "name":        "SQL Injection",
            "risk":        3,          # HIGH
            "confidence":  "High",
            "url":         "http://example.com/search?q=1",
            "method":      "GET",
            "description": "SQL Injection vulnerability",
            "solution":    "Use parameterised queries",
            "reference":   "",
            "cweid":       "89",
            "wascid":      "19",
            "pluginId":    "40018",
            "param":       "q",
            "attack":      "1 OR 1=1",
            "evidence":    "",
            "other":       "",
        }
        base.update(overrides)
        return base

    # -- tests -----------------------------------------------------------------

    def test_sqli_alert_becomes_high_finding(self):
        """ZAP SQLi alert (risk=3) → severity=HIGH after confidence check."""
        scanner = DASTScanner()

        sqli_alert = self._make_sqli_alert()

        with patch.object(scanner._client, "is_alive", return_value=True), \
             patch.object(scanner._client, "new_session", return_value=True), \
             patch.object(scanner._client, "start_spider", return_value="1"), \
             patch.object(scanner._client, "spider_progress", return_value=100), \
             patch.object(scanner._client, "start_active_scan", return_value="1"), \
             patch.object(scanner._client, "wait_active_scan"), \
             patch.object(scanner._client, "get_alerts", return_value=[sqli_alert]):

            findings = scanner.scan_url("http://example.com")

        assert len(findings) == 1
        assert findings[0]["severity"] == "HIGH"
        assert "SQL" in findings[0]["title"]

    def test_zap_unreachable_returns_empty_list(self):
        """When ZAP is not alive, scan_url returns [] without raising."""
        scanner = DASTScanner()
        with patch.object(scanner._client, "is_alive", return_value=False):
            result = scanner.scan_url("http://example.com")
        assert result == []

    def test_connection_error_returns_empty_list(self):
        """ConnectionError during scan returns [] without raising."""
        scanner = DASTScanner()
        with patch.object(scanner._client, "is_alive",
                          side_effect=ConnectionError("refused")):
            result = scanner.scan_url("http://example.com")
        assert result == []

    def test_risk_zero_becomes_info(self):
        """ZAP alert with risk=0 (Informational) → severity=INFO."""
        alert = self._make_sqli_alert(risk=0, confidence="High")
        finding = _alert_dict_to_finding_dict(alert)
        assert finding is not None
        assert finding["severity"] == "INFO"

    def test_risk_1_becomes_low(self):
        alert = self._make_sqli_alert(risk=1, confidence="High")
        finding = _alert_dict_to_finding_dict(alert)
        assert finding["severity"] == "LOW"

    def test_risk_2_becomes_medium(self):
        alert = self._make_sqli_alert(risk=2, confidence="Medium")
        finding = _alert_dict_to_finding_dict(alert)
        assert finding["severity"] == "MEDIUM"

    def test_risk_3_becomes_high(self):
        alert = self._make_sqli_alert(risk=3, confidence="High")
        finding = _alert_dict_to_finding_dict(alert)
        assert finding["severity"] == "HIGH"

    def test_risk_4_becomes_critical(self):
        alert = self._make_sqli_alert(risk=4, confidence="High")
        finding = _alert_dict_to_finding_dict(alert)
        assert finding["severity"] == "CRITICAL"

    def test_low_confidence_skipped(self):
        """Confidence='Low' → finding skipped (returns None)."""
        alert = self._make_sqli_alert(confidence="Low")
        finding = _alert_dict_to_finding_dict(alert)
        assert finding is None

    def test_passive_scan_unreachable_returns_empty(self):
        scanner = DASTScanner()
        with patch.object(scanner._client, "is_alive", return_value=False):
            result = scanner.passive_scan("http://example.com")
        assert result == []

    def test_spider_unreachable_returns_empty(self):
        scanner = DASTScanner()
        with patch.object(scanner._client, "is_alive", return_value=False):
            result = scanner.spider("http://example.com")
        assert result == []

    def test_scan_openapi_unreachable_returns_empty(self):
        scanner = DASTScanner()
        with patch.object(scanner._client, "is_alive", return_value=False):
            result = scanner.scan_openapi("http://example.com/openapi.json")
        assert result == []

    def test_passive_scan_returns_findings(self):
        """Passive scan calls correct ZAP methods and returns findings."""
        scanner = DASTScanner()
        alert = self._make_sqli_alert(risk=2, confidence="High")

        with patch.object(scanner._client, "is_alive", return_value=True), \
             patch.object(scanner._client, "new_session", return_value=True), \
             patch.object(scanner._client, "start_spider", return_value="1"), \
             patch.object(scanner._client, "spider_progress", return_value=100), \
             patch.object(scanner._client, "wait_passive_scan"), \
             patch.object(scanner._client, "get_alerts", return_value=[alert]):

            findings = scanner.passive_scan("http://example.com")

        assert len(findings) == 1
        assert findings[0]["severity"] == "MEDIUM"


# =============================================================================
# AutoPRAgent
# =============================================================================

class TestAutoPRAgent:

    def setup_method(self):
        """Clear global rate-limit counter before each test."""
        _PR_TIMESTAMPS.clear()

    # -- dry run ---------------------------------------------------------------

    def test_dry_run_no_github_calls(self, tmp_path, capsys):
        """dry_run=True must not make any GitHub API calls."""
        # Create a simple Python file with a hardcoded password
        vuln_file = tmp_path / "app.py"
        vuln_file.write_text('password = "s3cr3t"\n')

        findings = [
            {
                "rule_id":  "HARDCODED-SECRET",
                "file":     "app.py",
                "line":     1,
                "severity": "HIGH",
                "cwe":      "CWE-798",
                "description": "Hardcoded password",
                "recommendation": "Use env var",
                "source":   "sast",
            }
        ]

        agent = AutoPRAgent()

        with patch("backend.agents.auto_pr_agent._gh_request") as mock_gh:
            result = agent.run(
                findings=findings,
                project_path=str(tmp_path),
                github_token="ghp_fake",
                owner="acme",
                repo="app",
                dry_run=True,
            )
            mock_gh.assert_not_called()

        assert result.dry_run is True
        # diff should have been printed to stdout
        captured = capsys.readouterr()
        # Diff may or may not be non-empty depending on patch success;
        # what matters is that no GitHub calls were made.

    def test_dry_run_returns_autopresult_dry_run_true(self, tmp_path):
        agent = AutoPRAgent()
        result = agent.run(
            findings=[],
            project_path=str(tmp_path),
            github_token="ghp_fake",
            owner="acme",
            repo="app",
            dry_run=True,
        )
        assert result.dry_run is True
        assert isinstance(result, AutoPRResult)

    # -- real mode -------------------------------------------------------------

    def test_real_mode_returns_pr_url(self, tmp_path):
        """Mock GitHub API → AutoPRResult.pr_url is populated."""
        vuln_file = tmp_path / "main.py"
        vuln_file.write_text('password = "hunter2"\n')

        findings = [
            {
                "rule_id":  "HARDCODED-SECRET",
                "file":     "main.py",
                "line":     1,
                "severity": "CRITICAL",
                "cwe":      "CWE-798",
                "description": "Hardcoded password",
                "recommendation": "Use env var",
                "source":   "sast",
            }
        ]

        # Stub every GitHub REST call
        def fake_gh_request(method, url, token, payload=None):
            if method == "GET" and "/repos/" in url and "/git/refs/" not in url and "/contents/" not in url:
                return {"default_branch": "main"}
            if method == "GET" and "/git/refs/" in url:
                return {"object": {"sha": "deadbeef"}}
            if method == "POST" and "/git/refs" in url:
                return {"ref": "refs/heads/tythanai/auto-fix-123"}
            if method == "GET" and "/contents/" in url:
                return {"sha": "abc123"}
            if method == "PUT" and "/contents/" in url:
                return {"commit": {"sha": "newsha1"}}
            if method == "POST" and "/pulls" in url:
                return {"html_url": "https://github.com/acme/app/pull/42"}
            return {}

        agent = AutoPRAgent()

        with patch("backend.agents.auto_pr_agent._gh_request", side_effect=fake_gh_request):
            result = agent.run(
                findings=findings,
                project_path=str(tmp_path),
                github_token="ghp_fake",
                owner="acme",
                repo="app",
                dry_run=False,
                scan_id="123",
            )

        assert result.pr_url == "https://github.com/acme/app/pull/42"
        assert result.dry_run is False
        assert "tythanai/auto-fix-123" in result.branch

    def test_no_findings_returns_empty_result(self, tmp_path):
        agent = AutoPRAgent()
        result = agent.run(
            findings=[],
            project_path=str(tmp_path),
            github_token="ghp_fake",
            owner="acme",
            repo="app",
        )
        assert result.fixed_count == 0
        assert result.pr_url == ""

    def test_rate_limit_blocks_after_5_prs(self, tmp_path):
        """Creating a 6th PR within an hour should raise RuntimeError."""
        from backend.agents.auto_pr_agent import _PR_TIMESTAMPS, _ONE_HOUR
        import time as _time

        now = _time.time()
        # Simulate 5 recent PRs
        for _ in range(5):
            _PR_TIMESTAMPS.append(now)

        agent = AutoPRAgent()

        def fake_gh_request(method, url, token, payload=None):
            if method == "GET":
                if "/git/refs/" in url:
                    return {"object": {"sha": "deadbeef"}}
                return {"default_branch": "main"}
            if method == "POST" and "/git/refs" in url:
                return {}
            if method == "PUT":
                return {"commit": {"sha": "abc"}}
            if method == "POST" and "/pulls" in url:
                return {"html_url": "https://github.com/acme/app/pull/99"}
            return {}

        vuln_file = tmp_path / "x.py"
        vuln_file.write_text('password = "x"\n')

        with patch("backend.agents.auto_pr_agent._gh_request", side_effect=fake_gh_request):
            with pytest.raises(RuntimeError, match="Rate limit"):
                agent.run(
                    findings=[{
                        "rule_id": "HARDCODED-SECRET",
                        "file": "x.py",
                        "line": 1,
                        "severity": "HIGH",
                        "cwe": "CWE-798",
                        "description": "test",
                        "recommendation": "",
                        "source": "sast",
                    }],
                    project_path=str(tmp_path),
                    github_token="ghp_fake",
                    owner="acme",
                    repo="app",
                    dry_run=False,
                )


# =============================================================================
# SwiftScanner
# =============================================================================

class TestSwiftScanner:

    # -- hardcoded credentials -------------------------------------------------

    def test_hardcoded_password_detected(self):
        source = 'let password = "super_secret_password"\n'
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="Auth.swift")
        rule_ids = [f["rule_id"] for f in findings]
        assert "SWIFT-001" in rule_ids

    def test_hardcoded_apiKey_detected(self):
        source = 'let apiKey = "AKIA1234567890ABCDEF"\n'
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="Config.swift")
        rule_ids = [f["rule_id"] for f in findings]
        assert "SWIFT-001" in rule_ids

    def test_hardcoded_secret_severity_critical(self):
        source = 'let secret = "top_secret_value"\n'
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="App.swift")
        cred_findings = [f for f in findings if f["rule_id"] == "SWIFT-001"]
        assert cred_findings
        assert cred_findings[0]["severity"] == "CRITICAL"

    # -- TLS validation --------------------------------------------------------

    def test_tls_disabled_detected(self):
        source = (
            "func urlSession(_ session: URLSession,\n"
            "    didReceive challenge: URLAuthenticationChallenge,\n"
            "    completionHandler: @escaping (URLSession.AuthChallengeDisposition,\n"
            "    URLCredential?) -> Void) {\n"
            "        completionHandler(.useCredential, URLCredential(trust: challenge.protectionSpace.serverTrust!))\n"
            "}\n"
        )
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="NetworkManager.swift")
        rule_ids = [f["rule_id"] for f in findings]
        assert "SWIFT-003" in rule_ids

    def test_tls_disabled_severity_high(self):
        source = (
            "func urlSession(_ session: URLSession,\n"
            "    didReceive challenge: URLAuthenticationChallenge,\n"
            "    completionHandler: @escaping (URLSession.AuthChallengeDisposition,\n"
            "    URLCredential?) -> Void) {\n"
            "        completionHandler(.useCredential, URLCredential(trust: challenge.protectionSpace.serverTrust!))\n"
            "}\n"
        )
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="NetworkManager.swift")
        tls_findings = [f for f in findings if f["rule_id"] == "SWIFT-003"]
        assert tls_findings
        assert tls_findings[0]["severity"] == "HIGH"

    # -- SQL injection ---------------------------------------------------------

    def test_sql_injection_detected(self):
        source = r'sqlite3_exec(db, "SELECT * FROM users WHERE id = \(userId)", nil, nil, nil)' + "\n"
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="DB.swift")
        rule_ids = [f["rule_id"] for f in findings]
        assert "SWIFT-004" in rule_ids

    # -- weak crypto -----------------------------------------------------------

    def test_weak_crypto_des_detected(self):
        source = "let algo = kCCAlgorithmDES\n"
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="Crypto.swift")
        rule_ids = [f["rule_id"] for f in findings]
        assert "SWIFT-005" in rule_ids

    def test_weak_crypto_3des_detected(self):
        source = "let algo = kCCAlgorithm3DES\n"
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="Crypto.swift")
        rule_ids = [f["rule_id"] for f in findings]
        assert "SWIFT-005" in rule_ids

    # -- logging sensitive data ------------------------------------------------

    def test_logging_password_detected(self):
        source = 'NSLog("User password: %@", password)\n'
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="Auth.swift")
        rule_ids = [f["rule_id"] for f in findings]
        assert "SWIFT-006" in rule_ids

    def test_logging_token_print_detected(self):
        source = 'print("Auth token: \\(token)")\n'
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="Auth.swift")
        rule_ids = [f["rule_id"] for f in findings]
        assert "SWIFT-006" in rule_ids

    # -- insecure UserDefaults -------------------------------------------------

    def test_insecure_userdefaults_detected(self):
        source = 'UserDefaults.standard.set(authToken, forKey: "userToken")\n'
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="Prefs.swift")
        rule_ids = [f["rule_id"] for f in findings]
        assert "SWIFT-008" in rule_ids

    # -- clean code produces no findings ---------------------------------------

    def test_clean_code_no_findings(self):
        source = (
            "import Foundation\n\n"
            "struct Greeting {\n"
            "    let message: String\n"
            "    func greet() -> String { return message }\n"
            "}\n"
        )
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="Greeting.swift")
        assert findings == []

    # -- file scanning ---------------------------------------------------------

    def test_scan_file_not_found_returns_empty(self):
        scanner = SwiftScanner()
        result = scanner.scan_file("/nonexistent/path/File.swift")
        assert result == []

    def test_scan_file_detects_finding(self, tmp_path):
        swift_file = tmp_path / "Secrets.swift"
        swift_file.write_text('let password = "topsecret"\n')
        scanner = SwiftScanner()
        findings = scanner.scan_file(str(swift_file))
        assert any(f["rule_id"] == "SWIFT-001" for f in findings)

    def test_scan_directory_returns_summary(self, tmp_path):
        (tmp_path / "A.swift").write_text('let apiKey = "AKIAIOSFODNN7EXAMPLE"\n')
        (tmp_path / "B.swift").write_text("import Foundation\n")
        scanner = SwiftScanner()
        result = scanner.scan_directory(str(tmp_path))
        assert "findings" in result
        assert result["files_scanned"] == 2
        assert any(f["rule_id"] == "SWIFT-001" for f in result["findings"])

    # -- finding structure -----------------------------------------------------

    def test_finding_has_required_fields(self):
        source = 'let secret = "my_secret_value"\n'
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="Secret.swift")
        assert findings
        f = findings[0]
        for key in ("rule_id", "severity", "category", "title",
                    "description", "file", "line", "evidence", "cwe", "remediation"):
            assert key in f, f"Missing field: {key}"

    def test_finding_line_number_correct(self):
        source = "import Foundation\n\nlet password = \"badpass\"\n"
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="App.swift")
        cred = [f for f in findings if f["rule_id"] == "SWIFT-001"]
        assert cred
        assert cred[0]["line"] == 3

    def test_finding_cwe_set(self):
        source = 'let password = "pw"\n'
        scanner = SwiftScanner()
        findings = scanner.scan_source(source, virtual_path="A.swift")
        cred = [f for f in findings if f["rule_id"] == "SWIFT-001"]
        assert cred
        assert cred[0]["cwe"] == "CWE-798"
