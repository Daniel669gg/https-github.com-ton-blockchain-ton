"""
Tests for the Attack Chain Builder.
15 tests covering chain construction, steps, MITRE mapping, and narrative generation.
"""
import sys
import pathlib

_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pytest

from backend.analysis.attack_chain import AttackChainBuilder, AttackChain, AttackStep
from backend.core.confidence import Finding


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_finding(**kwargs):
    defaults = dict(
        rule_id="TAINT-SQL_INJECTION", file="/tmp/test.py", line=5,
        severity="HIGH", confidence=0.85, cwe_id="CWE-89",
        description="SQL injection detected",
        recommendation="Use parameterized queries", sources=["flask_request"],
    )
    defaults.update(kwargs)
    return Finding(**defaults)


def _sqli_finding(**kwargs):
    return _make_finding(cwe_id="CWE-89", severity="CRITICAL", **kwargs)


def _cmdi_finding(**kwargs):
    return _make_finding(
        rule_id="TAINT-CMDI", cwe_id="CWE-78",
        description="Command injection", severity="CRITICAL", **kwargs,
    )


def _ssrf_finding(**kwargs):
    return _make_finding(
        rule_id="TAINT-SSRF", cwe_id="CWE-918",
        description="SSRF detected", severity="HIGH", **kwargs,
    )


def _path_traversal_finding(**kwargs):
    return _make_finding(
        rule_id="TAINT-PATH_TRAVERSAL", cwe_id="CWE-22",
        description="Path traversal", severity="HIGH", **kwargs,
    )


# ---------------------------------------------------------------------------
# TestAttackChainBuilder
# ---------------------------------------------------------------------------

class TestAttackChainBuilder:
    def test_builds_chains_from_sqli(self):
        """SQL injection finding must produce at least one attack chain."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_sqli_finding()])
        assert isinstance(chains, list)
        assert len(chains) >= 1

    def test_sqli_chain_has_steps(self):
        """Each attack chain from SQL injection must have at least one step."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_sqli_finding()])
        for chain in chains:
            assert isinstance(chain.steps, list)
            assert len(chain.steps) >= 1

    def test_cmdi_chain_built(self):
        """CWE-78 command injection finding must produce an attack chain."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_cmdi_finding()])
        assert len(chains) >= 1

    def test_ssrf_chain_built(self):
        """CWE-918 SSRF finding must produce an attack chain."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_ssrf_finding()])
        assert len(chains) >= 1

    def test_chain_probability_in_range(self):
        """total_probability must be in [0.0, 1.0] for every chain."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_sqli_finding()])
        for chain in chains:
            assert 0.0 <= chain.total_probability <= 1.0

    def test_chain_has_initial_access_step(self):
        """First step in the chain must have step_type 'initial_access'."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_sqli_finding()])
        assert chains
        first_chain = chains[0]
        assert first_chain.steps
        assert first_chain.steps[0].step_type == "initial_access"

    def test_chain_cvss_in_range(self):
        """cvss_score must be in [0.0, 10.0] for every chain."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_sqli_finding()])
        for chain in chains:
            assert 0.0 <= chain.cvss_score <= 10.0

    def test_affected_assets_non_empty(self):
        """affected_assets must be a non-empty list for every chain."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_sqli_finding()])
        for chain in chains:
            assert isinstance(chain.affected_assets, list)
            assert len(chain.affected_assets) >= 1

    def test_empty_findings_no_chains(self):
        """Empty findings list must return an empty chains list."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([])
        assert chains == []

    def test_format_narrative_non_empty(self):
        """format_narrative() must return a string of at least 50 characters."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_sqli_finding()])
        assert chains
        narrative = AttackChainBuilder.format_narrative(chains[0])
        assert isinstance(narrative, str)
        assert len(narrative) > 50

    def test_narrative_has_step_numbers(self):
        """The narrative must include numbered steps like '1.' or 'Step 1'."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_sqli_finding()])
        narrative = AttackChainBuilder.format_narrative(chains[0])
        has_numbered = "1." in narrative or "Step 1" in narrative
        assert has_numbered

    def test_mitre_technique_format(self):
        """Every AttackStep's mitre_technique must start with 'T'."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_sqli_finding()])
        for chain in chains:
            for step in chain.steps:
                assert step.mitre_technique.startswith("T"), (
                    f"Expected MITRE technique starting with T, got {step.mitre_technique!r}"
                )

    def test_chain_kill_chain_stage(self):
        """kill_chain_stage must be a non-empty string for every chain."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_sqli_finding()])
        for chain in chains:
            assert isinstance(chain.kill_chain_stage, str)
            assert len(chain.kill_chain_stage) > 0

    def test_path_traversal_chain_built(self):
        """CWE-22 path traversal combined with CWE-78 must produce an attack chain."""
        builder = AttackChainBuilder()
        # CWE-22 alone doesn't build a chain (not in _INITIAL_ACCESS_CWES);
        # pair it with a CWE-78 finding which IS an initial access point
        chains = builder.build_chains([_cmdi_finding(), _path_traversal_finding()])
        assert len(chains) >= 1

    def test_chain_has_mitre_tactic_sequence(self):
        """mitre_tactic_sequence must be non-empty for every chain."""
        builder = AttackChainBuilder()
        chains = builder.build_chains([_sqli_finding()])
        for chain in chains:
            assert isinstance(chain.mitre_tactic_sequence, list)
            assert len(chain.mitre_tactic_sequence) >= 1
