"""
Tests for the reasoning agent system.
20 tests for RootCause, Exploit, Verification, Critic, Risk, and Orchestrator agents.
Modules that don't exist skip gracefully via pytest.importorskip / try/except.
"""
import sys
import pathlib

_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pytest

# ---------------------------------------------------------------------------
# Shared code snippets
# ---------------------------------------------------------------------------

SQLI_CODE = """
from flask import request
import sqlite3
def get_user(db):
    uid = request.args.get('id')
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE id = " + uid)
    return cursor.fetchone()
"""

SAFE_XSS_CODE = """
import html
from flask import request
def render_greeting():
    name = request.args.get('name')
    safe_name = html.escape(name)
    return f"<h1>Hello, {safe_name}!</h1>"
"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_finding(**kwargs):
    from backend.core.confidence import Finding
    defaults = dict(
        rule_id="TAINT-SQL_INJECTION", file="/tmp/test.py", line=5,
        severity="HIGH", confidence=0.85, cwe_id="CWE-89",
        description="SQL injection detected",
        recommendation="Use parameterized queries", sources=["flask_request"],
    )
    defaults.update(kwargs)
    return Finding(**defaults)


def _make_sqli_finding():
    return _make_finding(severity="CRITICAL", confidence=0.9, cwe_id="CWE-89")


def _make_xss_finding():
    return _make_finding(
        rule_id="TAINT-XSS", cwe_id="CWE-79",
        description="XSS detected", severity="MEDIUM",
    )


# ---------------------------------------------------------------------------
# TestRootCauseAgent
# ---------------------------------------------------------------------------

class TestRootCauseAgent:
    @pytest.fixture(autouse=True)
    def import_agent(self):
        self.mod = pytest.importorskip("backend.agents.reasoning.root_cause_agent")

    def test_analyzes_sqli_finding(self):
        """analyze() must return a RootCause dataclass with a non-empty summary."""
        from backend.agents.reasoning.models import RootCause
        agent = self.mod.RootCauseAgent()
        finding = _make_sqli_finding()
        result = agent.analyze(finding, SQLI_CODE)
        assert isinstance(result, RootCause)
        assert len(result.summary) > 0

    def test_sqli_root_cause_mentions_concat(self):
        """vulnerable_construct must mention string concatenation or 'string'."""
        agent = self.mod.RootCauseAgent()
        finding = _make_sqli_finding()
        result = agent.analyze(finding, SQLI_CODE)
        construct_lower = result.vulnerable_construct.lower()
        assert "concatenation" in construct_lower or "string" in construct_lower

    def test_root_cause_has_cwe_explanation(self):
        """cwe_explanation must be a non-empty string."""
        agent = self.mod.RootCauseAgent()
        finding = _make_sqli_finding()
        result = agent.analyze(finding, SQLI_CODE)
        assert isinstance(result.cwe_explanation, str)
        assert len(result.cwe_explanation) > 0

    def test_introduced_at_has_file(self):
        """introduced_at must reference the file path from the finding."""
        agent = self.mod.RootCauseAgent()
        finding = _make_sqli_finding()
        result = agent.analyze(finding, SQLI_CODE)
        # introduced_at should contain something file/line related
        assert result.introduced_at is not None
        assert len(result.introduced_at) > 0


# ---------------------------------------------------------------------------
# TestExploitAgent
# ---------------------------------------------------------------------------

class TestExploitAgent:
    @pytest.fixture(autouse=True)
    def import_agents(self):
        self.exploit_mod = pytest.importorskip("backend.agents.reasoning.exploit_agent")
        self.root_mod = pytest.importorskip("backend.agents.reasoning.root_cause_agent")

    def _get_scenario(self):
        from backend.agents.reasoning.models import ExploitScenario
        rc_agent = self.root_mod.RootCauseAgent()
        exploit_agent = self.exploit_mod.ExploitAgent()
        finding = _make_sqli_finding()
        root_cause = rc_agent.analyze(finding, SQLI_CODE)
        return exploit_agent.build_scenario(finding, root_cause)

    def test_builds_sqli_scenario(self):
        """build_scenario() must return an ExploitScenario dataclass."""
        from backend.agents.reasoning.models import ExploitScenario
        scenario = self._get_scenario()
        assert isinstance(scenario, ExploitScenario)

    def test_scenario_has_attack_steps(self):
        """ExploitScenario.attack_steps must have at least 2 steps."""
        scenario = self._get_scenario()
        assert isinstance(scenario.attack_steps, list)
        assert len(scenario.attack_steps) >= 2

    def test_scenario_payload_non_empty(self):
        """payload_example must be a non-empty string."""
        scenario = self._get_scenario()
        assert isinstance(scenario.payload_example, str)
        assert len(scenario.payload_example) > 0

    def test_cvss_score_in_range(self):
        """cvss_score must be in [0.0, 10.0]."""
        scenario = self._get_scenario()
        assert 0.0 <= scenario.cvss_score <= 10.0

    def test_exploitability_valid(self):
        """exploitability must be one of HIGH, MEDIUM, LOW."""
        scenario = self._get_scenario()
        assert scenario.exploitability in {"HIGH", "MEDIUM", "LOW"}


# ---------------------------------------------------------------------------
# TestVerificationAgent
# ---------------------------------------------------------------------------

class TestVerificationAgent:
    @pytest.fixture(autouse=True)
    def import_agent(self):
        self.mod = pytest.importorskip("backend.agents.reasoning.verification_agent")

    def test_returns_three_tuple(self):
        """verify() must return a 3-tuple of (str, float, str)."""
        agent = self.mod.VerificationAgent()
        finding = _make_sqli_finding()
        result = agent.verify(finding, SQLI_CODE)
        assert isinstance(result, tuple)
        assert len(result) == 3
        status, confidence, rationale = result
        assert isinstance(status, str)
        assert isinstance(confidence, float)
        assert isinstance(rationale, str)

    def test_status_is_valid(self):
        """status must be one of the known VerificationStatus values."""
        agent = self.mod.VerificationAgent()
        finding = _make_sqli_finding()
        status, _, _ = agent.verify(finding, SQLI_CODE)
        valid = {"CONFIRMED", "LIKELY", "POSSIBLE", "UNLIKELY", "REPRODUCED"}
        assert status.upper() in valid

    def test_confidence_in_range(self):
        """confidence returned by verify() must be in [0.0, 1.0]."""
        agent = self.mod.VerificationAgent()
        finding = _make_sqli_finding()
        _, confidence, _ = agent.verify(finding, SQLI_CODE)
        assert 0.0 <= confidence <= 1.0

    def test_unlikely_for_escaped_xss(self):
        """SAFE_XSS_CODE with XSS finding should lean toward UNLIKELY."""
        agent = self.mod.VerificationAgent()
        finding = _make_xss_finding()
        status, confidence, _ = agent.verify(finding, SAFE_XSS_CODE)
        # Either UNLIKELY or low confidence
        assert status.upper() == "UNLIKELY" or confidence < 0.5


# ---------------------------------------------------------------------------
# TestCriticAgent
# ---------------------------------------------------------------------------

class TestCriticAgent:
    @pytest.fixture(autouse=True)
    def import_agents(self):
        self.critic_mod = pytest.importorskip("backend.agents.reasoning.critic_agent")
        self.root_mod = pytest.importorskip("backend.agents.reasoning.root_cause_agent")
        self.exploit_mod = pytest.importorskip("backend.agents.reasoning.exploit_agent")

    def _get_assessment(self, patch_code):
        from backend.agents.reasoning.models import PatchAssessment
        critic_agent = self.critic_mod.CriticAgent()
        finding = _make_sqli_finding()
        original_code = SQLI_CODE
        return critic_agent.critique(finding, original_code, patch_code, "parameterized query fix")

    def test_approves_parameterized_patch(self):
        """A patch using parameterized queries (%s) must yield is_correct=True."""
        from backend.agents.reasoning.models import PatchAssessment
        GOOD_PATCH = """
from flask import request
import sqlite3
def get_user(db):
    uid = request.args.get('id')
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE id = %s", (uid,))
    return cursor.fetchone()
"""
        assessment = self._get_assessment(GOOD_PATCH)
        assert isinstance(assessment, PatchAssessment)
        assert assessment.is_correct is True

    def test_patch_assessment_has_explanation(self):
        """correctness_explanation must be non-empty."""
        GOOD_PATCH = """
from flask import request
import sqlite3
def get_user(db):
    uid = request.args.get('id')
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE id = %s", (uid,))
    return cursor.fetchone()
"""
        assessment = self._get_assessment(GOOD_PATCH)
        assert isinstance(assessment.correctness_explanation, str)
        assert len(assessment.correctness_explanation) > 0


# ---------------------------------------------------------------------------
# TestRiskAgent
# ---------------------------------------------------------------------------

class TestRiskAgent:
    @pytest.fixture(autouse=True)
    def import_agents(self):
        self.risk_mod = pytest.importorskip("backend.agents.reasoning.risk_agent")
        self.exploit_mod = pytest.importorskip("backend.agents.reasoning.exploit_agent")
        self.root_mod = pytest.importorskip("backend.agents.reasoning.root_cause_agent")

    def _get_risk(self, finding):
        from backend.agents.reasoning.models import RiskAssessment
        rc_agent = self.root_mod.RootCauseAgent()
        exploit_agent = self.exploit_mod.ExploitAgent()
        risk_agent = self.risk_mod.RiskAgent()
        root_cause = rc_agent.analyze(finding, SQLI_CODE)
        exploit_scenario = exploit_agent.build_scenario(finding, root_cause)
        return risk_agent.assess(finding, exploit_scenario)

    def test_assess_returns_risk_assessment(self):
        """assess() must return a RiskAssessment dataclass."""
        from backend.agents.reasoning.models import RiskAssessment
        finding = _make_sqli_finding()
        result = self._get_risk(finding)
        assert isinstance(result, RiskAssessment)

    def test_sqli_risk_score_high(self):
        """CRITICAL SQLi finding must produce a risk_score >= 50."""
        finding = _make_sqli_finding()
        result = self._get_risk(finding)
        assert result.risk_score >= 50

    def test_sla_hours_for_critical(self):
        """CRITICAL severity must produce sla_hours <= 24."""
        finding = _make_sqli_finding()
        result = self._get_risk(finding)
        assert result.sla_hours <= 24

    def test_regulatory_implications_for_sqli(self):
        """CWE-89 SQLi must have at least 1 regulatory implication."""
        finding = _make_sqli_finding()
        result = self._get_risk(finding)
        assert isinstance(result.regulatory_implications, list)
        assert len(result.regulatory_implications) >= 1


# ---------------------------------------------------------------------------
# TestReasoningOrchestrator
# ---------------------------------------------------------------------------

class TestReasoningOrchestrator:
    @pytest.fixture(autouse=True)
    def import_orchestrator(self):
        self.mod = pytest.importorskip("backend.agents.reasoning.orchestrator")

    def test_reason_returns_result(self):
        """reason() must return a ReasoningResult with all required fields."""
        from backend.agents.reasoning.models import ReasoningResult
        orchestrator = self.mod.ReasoningOrchestrator()
        finding = _make_sqli_finding()
        result = orchestrator.reason(finding, SQLI_CODE)
        assert isinstance(result, ReasoningResult)
        # Check all required fields are populated
        assert result.finding_id
        assert result.root_cause is not None
        assert result.exploit_scenario is not None
        assert result.verification_status
        assert result.patch_assessment is not None
        assert result.risk_assessment is not None

    def test_full_narrative_non_empty(self):
        """full_narrative must be a string of at least 100 characters."""
        orchestrator = self.mod.ReasoningOrchestrator()
        finding = _make_sqli_finding()
        result = orchestrator.reason(finding, SQLI_CODE)
        assert isinstance(result.full_narrative, str)
        assert len(result.full_narrative) > 100
