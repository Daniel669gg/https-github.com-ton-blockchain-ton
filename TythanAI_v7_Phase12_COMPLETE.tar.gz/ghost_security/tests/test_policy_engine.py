"""
Tests for the Policy-as-Code engine.
20 tests covering PolicyModels, PolicyEngine, BuiltInPolicies, and YAML round-trip.
"""
import sys
import pathlib

_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pytest

from backend.core.policy import (
    PolicyEngine,
    PolicyRule,
    PolicyResult,
    PolicyAction,
    PolicySeverity,
    PolicyCondition,
    PolicyViolation,
    BuiltInPolicies,
)
from backend.core.confidence import Finding


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _make_finding(**kwargs):
    defaults = dict(
        rule_id="TAINT-SQL_INJECTION", file="/tmp/test.py", line=5,
        severity="HIGH", confidence=0.85, cwe_id="CWE-89",
        description="SQL injection detected",
        recommendation="Use parameterized queries", sources=["flask_request"],
    )
    defaults.update(kwargs)
    return Finding(**defaults)


# ---------------------------------------------------------------------------
# TestPolicyModels
# ---------------------------------------------------------------------------

class TestPolicyModels:
    def test_policy_rule_has_conditions(self):
        """PolicyRule can be instantiated with a conditions list."""
        condition = PolicyCondition(field="severity", operator="eq", value="CRITICAL")
        rule = PolicyRule(
            rule_id="TEST-001",
            name="Test Rule",
            description="Test",
            conditions=[condition],
            action=PolicyAction.BLOCK,
            message="Blocked",
        )
        assert isinstance(rule.conditions, list)
        assert len(rule.conditions) == 1

    def test_policy_condition_has_operator(self):
        """PolicyCondition must expose field, operator, and value."""
        cond = PolicyCondition(field="confidence", operator="gte", value=0.85)
        assert cond.field == "confidence"
        assert cond.operator == "gte"
        assert cond.value == 0.85

    def test_policy_result_has_violations(self):
        """PolicyResult must expose a violations list attribute."""
        engine = PolicyEngine()
        finding = _make_finding(severity="CRITICAL")
        result = engine.evaluate([finding])
        assert isinstance(result, PolicyResult)
        assert isinstance(result.violations, list)


# ---------------------------------------------------------------------------
# TestPolicyEngine
# ---------------------------------------------------------------------------

class TestPolicyEngine:
    def test_blocks_critical_finding(self):
        """CRITICAL severity finding must set PolicyResult.blocked=True."""
        engine = PolicyEngine()
        finding = _make_finding(severity="CRITICAL")
        result = engine.evaluate([finding])
        assert result.blocked is True

    def test_warns_medium_finding(self):
        """MEDIUM severity finding must produce at least one WARN violation."""
        engine = PolicyEngine()
        finding = _make_finding(severity="MEDIUM", confidence=0.6)
        result = engine.evaluate([finding])
        warn_violations = [v for v in result.violations if v.action == PolicyAction.WARN]
        assert len(warn_violations) >= 1

    def test_blocks_hardcoded_secret(self):
        """Finding with cwe_id=CWE-798 must be blocked."""
        engine = PolicyEngine()
        finding = _make_finding(
            rule_id="SEC-HARDCODED_SECRET", cwe_id="CWE-798",
            severity="CRITICAL", confidence=0.95,
        )
        result = engine.evaluate([finding])
        assert result.blocked is True

    def test_no_block_low_confidence(self):
        """Finding with confidence=0.3 and a non-blocked CWE must not trigger a block."""
        engine = PolicyEngine()
        # Use CWE-400 (resource exhaustion) — no specific block rule for this CWE
        # and MEDIUM severity should only warn, not block
        finding = _make_finding(severity="MEDIUM", confidence=0.3, cwe_id="CWE-400")
        result = engine.evaluate([finding])
        # Medium severity + low confidence + non-blocked CWE should not block
        assert result.blocked is False

    def test_empty_findings_no_violations(self):
        """Empty findings list must produce a PolicyResult with 0 violations."""
        engine = PolicyEngine()
        result = engine.evaluate([])
        assert len(result.violations) == 0
        assert result.blocked is False

    def test_multiple_findings_counted(self):
        """3 critical findings must produce at least 3 evaluations (violations)."""
        engine = PolicyEngine()
        findings = [
            _make_finding(severity="CRITICAL", line=i, file=f"/tmp/f{i}.py")
            for i in range(1, 4)
        ]
        result = engine.evaluate(findings)
        assert result.findings_evaluated == 3

    def test_compliance_pci_dss_fails(self):
        """CRITICAL finding with CWE-89 must fail PCI-DSS compliance."""
        engine = PolicyEngine()
        finding = _make_finding(severity="CRITICAL", cwe_id="CWE-89")
        result = engine.evaluate([finding])
        assert "pci-dss" in result.compliance_status
        assert result.compliance_status["pci-dss"] is False

    def test_compliance_clean_code_passes(self):
        """No findings → all compliance frameworks should pass."""
        engine = PolicyEngine()
        result = engine.evaluate([])
        for status in result.compliance_status.values():
            assert status is True

    def test_add_custom_rule(self):
        """add_rule() must make a custom rule available for evaluation."""
        engine = PolicyEngine(rules=[])  # Start with no built-in rules
        custom_rule = PolicyRule(
            rule_id="CUSTOM-001",
            name="Custom Block Rule",
            description="Block anything from /tmp",
            conditions=[
                PolicyCondition(field="file", operator="contains", value="/tmp"),
            ],
            action=PolicyAction.BLOCK,
            message="Custom block triggered",
            enabled=True,
        )
        engine.add_rule(custom_rule)
        finding = _make_finding(file="/tmp/test.py")
        result = engine.evaluate([finding])
        assert result.blocked is True

    def test_disabled_rule_not_triggered(self):
        """A rule with enabled=False must not appear in violations."""
        disabled_rule = PolicyRule(
            rule_id="DISABLED-001",
            name="Disabled Rule",
            description="Should never fire",
            conditions=[
                PolicyCondition(field="severity", operator="eq", value="HIGH"),
            ],
            action=PolicyAction.BLOCK,
            message="Should not appear",
            enabled=False,
        )
        engine = PolicyEngine(rules=[disabled_rule])
        finding = _make_finding(severity="HIGH")
        result = engine.evaluate([finding])
        assert result.blocked is False
        assert len(result.violations) == 0


# ---------------------------------------------------------------------------
# TestBuiltInPolicies
# ---------------------------------------------------------------------------

class TestBuiltInPolicies:
    def test_enough_built_in_rules(self):
        """There must be at least 8 built-in policy rules."""
        rules = BuiltInPolicies.all_rules()
        assert len(rules) >= 8

    def test_all_rules_have_conditions(self):
        """Every built-in rule must have a non-empty conditions list."""
        rules = BuiltInPolicies.all_rules()
        for rule in rules:
            assert isinstance(rule.conditions, list), f"Rule {rule.rule_id} has no conditions list"
            assert len(rule.conditions) > 0, f"Rule {rule.rule_id} has empty conditions"

    def test_critical_block_rule_present(self):
        """There must be a built-in rule with action=BLOCK for CRITICAL severity."""
        rules = BuiltInPolicies.all_rules()
        critical_block_rules = [
            r for r in rules
            if r.action == PolicyAction.BLOCK
            and any(c.value == "CRITICAL" for c in r.conditions)
        ]
        assert len(critical_block_rules) >= 1

    def test_secrets_rule_present(self):
        """There must be a built-in rule that targets CWE-798 (hardcoded secrets)."""
        rules = BuiltInPolicies.all_rules()
        secret_rules = [
            r for r in rules
            if any(c.value == "CWE-798" for c in r.conditions)
        ]
        assert len(secret_rules) >= 1


# ---------------------------------------------------------------------------
# TestPolicyYaml
# ---------------------------------------------------------------------------

class TestPolicyYaml:
    def test_export_yaml_non_empty(self):
        """export_to_yaml() must return a non-empty YAML string."""
        engine = PolicyEngine()
        yaml_str = engine.export_to_yaml()
        assert isinstance(yaml_str, str)
        assert len(yaml_str) > 0

    def test_load_yaml_returns_rules(self):
        """load_from_yaml() must return a list of PolicyRule objects."""
        engine = PolicyEngine()
        yaml_str = engine.export_to_yaml()
        loaded = engine.load_from_yaml(yaml_str)
        assert isinstance(loaded, list)
        assert len(loaded) > 0
        for rule in loaded:
            assert isinstance(rule, PolicyRule)

    def test_yaml_roundtrip(self):
        """Rules must survive export → import with same rule_ids."""
        engine = PolicyEngine()
        original_rules = engine._rules
        original_ids = {r.rule_id for r in original_rules}

        yaml_str = engine.export_to_yaml()
        loaded_rules = engine.load_from_yaml(yaml_str)
        loaded_ids = {r.rule_id for r in loaded_rules}

        # All original rule IDs should appear in the round-tripped set
        assert original_ids == loaded_ids
