"""
Tests for the CPG (Code Property Graph) engine.
20 tests covering CPGBuilder, CPGQueryEngine, CodePropertyGraph, and RepoAnalyzer.
"""
import sys
import json
import pathlib
import tempfile
import os

_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pytest

from backend.core.cpg import (
    CPGBuilder,
    CPGQueryEngine,
    CodePropertyGraph,
    CPGNode,
    CPGEdge,
    CPGNodeType,
    CPGEdgeType,
    TaintPath,
    RepoAnalyzer,
    RepoAnalysisResult,
)

# ---------------------------------------------------------------------------
# Shared test code snippets
# ---------------------------------------------------------------------------

VULN_CODE = """
from flask import request
import sqlite3

def get_user(db):
    user_id = request.args.get('id')
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE id = " + user_id)
    return cursor.fetchone()
"""

SAFE_CODE = """
from flask import request
import sqlite3

def get_user(db):
    user_id = request.args.get('id')
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    return cursor.fetchone()
"""

CMD_INJECT_CODE = """
import os
from flask import request

def run_cmd():
    user_input = request.args.get('cmd')
    os.system(user_input)
"""

HARDCODED_SECRET_CODE = """
API_KEY = "sk-abc123def456789012345678901234"
import requests

def call_api():
    return requests.get("https://api.example.com", headers={"Authorization": API_KEY})
"""


# ---------------------------------------------------------------------------
# TestCPGBuilder
# ---------------------------------------------------------------------------

class TestCPGBuilder:
    def test_build_from_source_returns_cpg(self):
        """build_source(VULN_CODE) must return a CodePropertyGraph instance."""
        builder = CPGBuilder()
        cpg = builder.build_source(VULN_CODE, file_path="test_vuln.py")
        assert isinstance(cpg, CodePropertyGraph)

    def test_cpg_has_nodes(self):
        """The built CPG must contain a non-empty nodes dict."""
        builder = CPGBuilder()
        cpg = builder.build_source(VULN_CODE, file_path="test_vuln.py")
        assert isinstance(cpg.nodes, dict)
        assert len(cpg.nodes) > 0

    def test_cpg_has_edges(self):
        """The built CPG must contain at least one edge."""
        builder = CPGBuilder()
        cpg = builder.build_source(VULN_CODE, file_path="test_vuln.py")
        assert isinstance(cpg.edges, list)
        assert len(cpg.edges) > 0

    def test_ast_nodes_have_types(self):
        """Every CPGNode in the graph must have a non-empty ast_type."""
        builder = CPGBuilder()
        cpg = builder.build_source(VULN_CODE, file_path="test_vuln.py")
        for node in cpg.nodes.values():
            assert isinstance(node, CPGNode)
            assert node.ast_type  # must be non-empty string

    def test_cfg_entry_nodes_exist(self):
        """There must be at least one CFG_ENTRY node for function boundaries."""
        builder = CPGBuilder()
        cpg = builder.build_source(VULN_CODE, file_path="test_vuln.py")
        entry_nodes = [n for n in cpg.nodes.values() if n.node_type == CPGNodeType.CFG_ENTRY]
        assert len(entry_nodes) >= 1

    def test_dfg_edges_exist(self):
        """There must be at least one DFG_FLOW edge (data flow edge)."""
        builder = CPGBuilder()
        cpg = builder.build_source(VULN_CODE, file_path="test_vuln.py")
        dfg_edges = [e for e in cpg.edges if e.edge_type == CPGEdgeType.DFG_FLOW]
        assert len(dfg_edges) >= 1

    def test_cg_call_edge_for_intrafile_call(self):
        """CG_CALL edge must exist when one local function calls another local function."""
        builder = CPGBuilder()
        code_with_local_call = """
def helper(db, uid):
    db.execute("SELECT * FROM t WHERE id = " + uid)

def get_user(db, user_id):
    return helper(db, user_id)
"""
        cpg = builder.build_source(code_with_local_call, file_path="test_intra.py")
        cg_call_edges = [e for e in cpg.edges if e.edge_type == CPGEdgeType.CG_CALL]
        assert len(cg_call_edges) >= 1, "Expected at least one CG_CALL edge for intra-file call"

    def test_merge_two_cpgs(self):
        """merge() must produce a CPG whose node count is at least as large as either source."""
        builder = CPGBuilder()
        cpg_a = builder.build_source(VULN_CODE, file_path="file_a.py")
        cpg_b = builder.build_source(SAFE_CODE, file_path="file_b.py")
        nodes_before = len(cpg_a.nodes)
        cpg_a.merge(cpg_b)
        assert len(cpg_a.nodes) >= nodes_before


# ---------------------------------------------------------------------------
# TestCPGQueryEngine
# ---------------------------------------------------------------------------

class TestCPGQueryEngine:
    def _build(self, code, filename="test.py"):
        builder = CPGBuilder()
        cpg = builder.build_source(code, file_path=filename)
        return CPGQueryEngine(cpg)

    def test_finds_sqli_in_vuln_code(self):
        """find_sql_injection() on VULN_CODE must return at least one TaintPath."""
        engine = self._build(VULN_CODE)
        paths = engine.find_sql_injection()
        assert isinstance(paths, list)
        assert len(paths) >= 1

    def test_sqli_lower_confidence_for_parameterized(self):
        """find_sql_injection() on SAFE_CODE (parameterized) should have lower confidence than vulnerable code."""
        engine_safe = self._build(SAFE_CODE)
        engine_vuln = self._build(VULN_CODE)
        safe_paths = engine_safe.find_sql_injection()
        vuln_paths = engine_vuln.find_sql_injection()
        # Vulnerable code should be detected with higher overall confidence
        if safe_paths and vuln_paths:
            avg_safe_conf = sum(p.confidence for p in safe_paths) / len(safe_paths)
            avg_vuln_conf = sum(p.confidence for p in vuln_paths) / len(vuln_paths)
            assert avg_vuln_conf >= avg_safe_conf, (
                f"Vulnerable code ({avg_vuln_conf:.2f}) should have >= confidence than safe ({avg_safe_conf:.2f})"
            )

    def test_finds_command_injection(self):
        """os.system(user_input) pattern must be detected."""
        engine = self._build(CMD_INJECT_CODE)
        paths = engine.find_command_injection()
        assert isinstance(paths, list)
        assert len(paths) >= 1

    def test_finds_hardcoded_secrets(self):
        """API_KEY = 'sk-abc123...' must be detected as a hardcoded secret."""
        builder = CPGBuilder()
        cpg = builder.build_source(HARDCODED_SECRET_CODE, file_path="secrets_test.py")
        engine = CPGQueryEngine(cpg)
        secrets = engine.find_hardcoded_secrets()
        assert isinstance(secrets, list)
        assert len(secrets) >= 1

    def test_run_all_queries_returns_dict(self):
        """run_all_queries() must return a dict keyed by query name."""
        engine = self._build(VULN_CODE)
        results = engine.run_all_queries()
        assert isinstance(results, dict)
        assert len(results) > 0

    def test_taint_path_has_confidence(self):
        """Each TaintPath returned by find_sql_injection() must have confidence in [0.0, 1.0]."""
        engine = self._build(VULN_CODE)
        paths = engine.find_sql_injection()
        assert paths, "Expected at least one taint path"
        for path in paths:
            assert isinstance(path, TaintPath)
            assert 0.0 <= path.confidence <= 1.0

    def test_taint_path_has_src_dst(self):
        """Each TaintPath must have non-None src_node and dst_node."""
        engine = self._build(VULN_CODE)
        paths = engine.find_sql_injection()
        assert paths
        for path in paths:
            assert path.src_node is not None
            assert path.dst_node is not None


# ---------------------------------------------------------------------------
# TestCPGGraph
# ---------------------------------------------------------------------------

class TestCPGGraph:
    def _make_two_node_graph(self):
        """Build a minimal two-node connected graph for traversal tests."""
        cpg = CodePropertyGraph()
        n1 = CPGNode(
            node_id="n1", node_type=CPGNodeType.CFG_ENTRY,
            ast_type="FunctionDef", code="def foo():", file="x.py", line=1, col=0,
        )
        n2 = CPGNode(
            node_id="n2", node_type=CPGNodeType.CFG_BLOCK,
            ast_type="Assign", code="x = 1", file="x.py", line=2, col=4,
        )
        n3 = CPGNode(
            node_id="n3", node_type=CPGNodeType.CFG_EXIT,
            ast_type="Return", code="return x", file="x.py", line=3, col=4,
        )
        cpg.add_node(n1)
        cpg.add_node(n2)
        cpg.add_node(n3)
        cpg.add_edge(CPGEdge(edge_id="e1", src_id="n1", dst_id="n2", edge_type=CPGEdgeType.CFG_NEXT))
        cpg.add_edge(CPGEdge(edge_id="e2", src_id="n2", dst_id="n3", edge_type=CPGEdgeType.CFG_NEXT))
        return cpg

    def test_reachable_finds_connected(self):
        """reachable('n1') must include n2 and n3 via CFG_NEXT edges."""
        cpg = self._make_two_node_graph()
        reachable = cpg.reachable("n1")
        assert "n2" in reachable
        assert "n3" in reachable

    def test_all_paths_finds_path(self):
        """all_paths('n1', 'n3') must return at least one path."""
        cpg = self._make_two_node_graph()
        paths = cpg.all_paths("n1", "n3")
        assert len(paths) >= 1
        # The path must be a sequence of node IDs
        for path in paths:
            assert "n1" in path
            assert "n3" in path

    def test_to_dict_serializable(self):
        """to_dict() must return a JSON-serializable dictionary."""
        builder = CPGBuilder()
        cpg = builder.build_source(VULN_CODE, file_path="test.py")
        d = cpg.to_dict()
        # This should not raise
        serialized = json.dumps(d)
        assert len(serialized) > 0
        parsed = json.loads(serialized)
        assert "nodes" in parsed
        assert "edges" in parsed


# ---------------------------------------------------------------------------
# TestRepoAnalyzer
# ---------------------------------------------------------------------------

class TestRepoAnalyzer:
    def test_analyze_temp_dir(self):
        """Create a temp dir with 2 .py files, analyze() must return RepoAnalysisResult."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file1 = os.path.join(tmpdir, "app.py")
            file2 = os.path.join(tmpdir, "utils.py")
            with open(file1, "w") as f:
                f.write(VULN_CODE)
            with open(file2, "w") as f:
                f.write(SAFE_CODE)

            analyzer = RepoAnalyzer(root=tmpdir)
            result = analyzer.analyze()
            assert isinstance(result, RepoAnalysisResult)

    def test_result_has_node_counts(self):
        """RepoAnalysisResult.total_nodes and total_edges must be positive."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file1 = os.path.join(tmpdir, "vuln.py")
            file2 = os.path.join(tmpdir, "safe.py")
            with open(file1, "w") as f:
                f.write(VULN_CODE)
            with open(file2, "w") as f:
                f.write(SAFE_CODE)

            analyzer = RepoAnalyzer(root=tmpdir)
            result = analyzer.analyze()
            assert result.total_nodes > 0
            assert result.total_edges > 0
