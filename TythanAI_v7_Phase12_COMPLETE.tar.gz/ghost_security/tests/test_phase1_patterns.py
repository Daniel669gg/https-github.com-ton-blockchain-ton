"""
tests/test_phase1_patterns.py — Tests for the unified pattern registry.
15 tests covering source/sink/sanitizer classification and CWE metadata.
"""
import sys
import pathlib
import re

_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pytest
from backend.core.patterns import (
    get_sources, get_sinks, get_sanitizers, get_cwe_meta,
    all_cwe_ids, classify_node_as_source, classify_node_as_sink,
    classify_node_as_sanitizer, SOURCE_PATTERNS, SINK_PATTERNS,
    SANITIZER_PATTERNS, CWE_META,
)


class TestPatternRegistry:
    def test_all_owasp_cwes_registered(self):
        """All OWASP Top 10 relevant CWEs must be registered."""
        required = {"CWE-89", "CWE-79", "CWE-78", "CWE-22", "CWE-798", "CWE-918"}
        assert required.issubset(set(all_cwe_ids()))

    def test_get_sources_returns_compiled_patterns(self):
        """get_sources() must return list of (Pattern, float) tuples."""
        sources = get_sources("CWE-89")
        assert len(sources) >= 5
        for pat, conf in sources:
            assert hasattr(pat, "search"), "Expected compiled re.Pattern"
            assert 0.0 < conf <= 1.0

    def test_get_sinks_returns_compiled_patterns(self):
        """get_sinks() must return list of compiled Patterns."""
        sinks = get_sinks("CWE-89")
        assert len(sinks) >= 2
        for pat in sinks:
            assert hasattr(pat, "search"), "Expected compiled re.Pattern"

    def test_get_sanitizers_returns_name_tuples(self):
        """get_sanitizers() must return list of (Pattern, name) tuples."""
        sans = get_sanitizers("CWE-89")
        assert len(sans) >= 3
        for pat, name in sans:
            assert hasattr(pat, "search")
            assert isinstance(name, str) and len(name) > 0

    def test_classify_source_flask_request(self):
        """request.args.get() must be classified as source for CWE-89."""
        result = classify_node_as_source('uid = request.args.get("id")')
        assert result is not None
        cwe_id, conf = result
        assert cwe_id == "CWE-89"
        assert conf > 0.5

    def test_classify_source_returns_none_for_safe_code(self):
        """A hardcoded string must NOT be classified as a taint source."""
        result = classify_node_as_source('uid = "12345"')
        assert result is None

    def test_classify_sink_sql_concat(self):
        """SQL string concatenation must be classified as CWE-89 sink."""
        code = 'cursor.execute("SELECT * FROM t WHERE id=" + uid)'
        result = classify_node_as_sink(code)
        assert result == "CWE-89"

    def test_classify_sink_os_system(self):
        """os.system() must be classified as CWE-78 sink."""
        result = classify_node_as_sink("os.system(user_cmd)")
        assert result == "CWE-78"

    def test_classify_sink_returns_none_for_safe(self):
        """A safe assignment must not be classified as a sink."""
        result = classify_node_as_sink('x = 42')
        assert result is None

    def test_classify_sanitizer_html_escape(self):
        """html.escape() must be classified as sanitizer for CWE-79."""
        result = classify_node_as_sanitizer("safe = html.escape(name)", "CWE-79")
        assert result is not None
        assert isinstance(result, str)

    def test_classify_sanitizer_parameterized_query(self):
        """Parameterized cursor.execute must be classified as sanitizer for CWE-89."""
        code = 'cursor.execute("SELECT * FROM t WHERE id=%s", (uid,))'
        result = classify_node_as_sanitizer(code, "CWE-89")
        assert result is not None

    def test_cwe_meta_has_owasp(self):
        """Every CWE in CWE_META must have an owasp field."""
        for cwe_id in all_cwe_ids():
            meta = get_cwe_meta(cwe_id)
            assert "owasp" in meta, f"CWE {cwe_id} missing owasp in CWE_META"

    def test_cwe_meta_has_severity(self):
        """Every CWE must have a severity field."""
        for cwe_id in all_cwe_ids():
            meta = get_cwe_meta(cwe_id)
            assert "severity" in meta
            assert meta["severity"] in {"CRITICAL", "HIGH", "MEDIUM", "LOW"}

    def test_cwe_meta_has_mitre(self):
        """At least 5 CWEs must have mitre_technique mapping."""
        with_mitre = [c for c in all_cwe_ids() if get_cwe_meta(c).get("mitre_technique")]
        assert len(with_mitre) >= 5

    def test_unknown_cwe_returns_empty(self):
        """Unknown CWE must return empty lists without raising."""
        assert get_sources("CWE-9999") == []
        assert get_sinks("CWE-9999") == []
        assert get_sanitizers("CWE-9999") == []
