"""
tests/test_phase1_reachability.py — Tests for Advanced Reachability (Phase 1, Part 4).
15 tests: reachable sink, unreachable, auth detection, attack surface, scoring.
"""
import sys
import pathlib

_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pytest
from backend.core.cpg.builder import CPGBuilder
from backend.core.confidence import Finding
from backend.analysis.advanced_reachability import (
    AdvancedReachabilityAnalyzer, SinkReachabilityResult, ReachabilityHop,
)

INTERNET_FACING_CODE = """
from flask import request
app = Flask(__name__)

@app.route('/users')
def get_users(db):
    uid = request.args.get('id')
    db.cursor().execute("SELECT * FROM users WHERE id=" + uid)
    return 'ok'
"""

AUTH_PROTECTED_CODE = """
from flask import request
from functools import wraps

@app.route('/admin')
@login_required
def admin_action(db):
    uid = request.args.get('id')
    db.cursor().execute("SELECT * FROM users WHERE id=" + uid)
    return 'ok'
"""

SAFE_CODE = """
from flask import request

@app.route('/users')
def get_users(db):
    uid = request.args.get('id')
    db.cursor().execute("SELECT * FROM users WHERE id=%s", (uid,))
    return 'ok'
"""

CLI_CODE = """
import click
@click.command()
@click.argument('filename')
def process(filename):
    with open(filename) as f:
        return f.read()
"""


def _make_finding(**kwargs):
    defaults = dict(
        rule_id="TAINT-SQL_INJECTION", file="/tmp/test.py", line=6,
        severity="HIGH", confidence=0.85, cwe_id="CWE-89",
        description="SQL injection", recommendation="Use parameterized queries",
        sources=["flask_request"],
    )
    defaults.update(kwargs)
    return Finding(**defaults)


@pytest.fixture
def builder():
    return CPGBuilder()


@pytest.fixture
def analyzer():
    return AdvancedReachabilityAnalyzer()


class TestSinkReachabilityResult:
    def test_analyze_finding_returns_result(self, builder, analyzer):
        """analyze_finding() must return SinkReachabilityResult."""
        cpg = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        finding = _make_finding()
        result = analyzer.analyze_finding(finding, cpg, INTERNET_FACING_CODE)
        assert isinstance(result, SinkReachabilityResult)

    def test_result_has_scores(self, builder, analyzer):
        """Result must have reachability_score, exploitability_score, path_confidence."""
        cpg = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        finding = _make_finding()
        result = analyzer.analyze_finding(finding, cpg, INTERNET_FACING_CODE)
        assert 0.0 <= result.reachability_score <= 1.0
        assert 0.0 <= result.exploitability_score <= 1.0
        assert 0.0 <= result.path_confidence <= 1.0

    def test_internet_facing_high_reachability(self, builder, analyzer):
        """Flask route without auth must yield reachability_score >= 0.5."""
        cpg = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        finding = _make_finding()
        result = analyzer.analyze_finding(finding, cpg, INTERNET_FACING_CODE)
        assert result.reachability_score >= 0.3  # at least some reachability

    def test_auth_protected_lower_score(self, builder, analyzer):
        """Auth-protected route must yield lower exploitability than unprotected."""
        cpg_vuln = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        cpg_auth = builder.build_source(AUTH_PROTECTED_CODE, file_path="/tmp/auth.py")
        finding = _make_finding()
        r_vuln = analyzer.analyze_finding(finding, cpg_vuln, INTERNET_FACING_CODE)
        r_auth = analyzer.analyze_finding(finding, cpg_auth, AUTH_PROTECTED_CODE)
        # Auth-protected should have lower or equal exploitability
        assert r_auth.exploitability_score <= r_vuln.exploitability_score + 0.1

    def test_requires_auth_detected(self, builder, analyzer):
        """@login_required must set requires_auth=True."""
        cpg = builder.build_source(AUTH_PROTECTED_CODE, file_path="/tmp/auth.py")
        finding = _make_finding()
        result = analyzer.analyze_finding(finding, cpg, AUTH_PROTECTED_CODE)
        assert result.requires_auth is True

    def test_evidence_summary_non_empty(self, builder, analyzer):
        """evidence_summary must be a non-empty string."""
        cpg = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        finding = _make_finding()
        result = analyzer.analyze_finding(finding, cpg, INTERNET_FACING_CODE)
        assert isinstance(result.evidence_summary, str)
        assert len(result.evidence_summary) > 0

    def test_finding_id_set(self, builder, analyzer):
        """finding_id must be the fingerprint of the finding."""
        cpg = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        finding = _make_finding()
        result = analyzer.analyze_finding(finding, cpg, INTERNET_FACING_CODE)
        assert result.finding_id == finding.fingerprint()

    def test_attack_surface_category(self, builder, analyzer):
        """attack_surface_category must be one of the known values."""
        cpg = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        finding = _make_finding()
        result = analyzer.analyze_finding(finding, cpg, INTERNET_FACING_CODE)
        valid = {"internet_facing", "authenticated", "internal", "cli"}
        assert result.attack_surface_category in valid

    def test_cli_attack_surface(self, builder, analyzer):
        """Click-based CLI code must be classified as 'cli'."""
        cpg = builder.build_source(CLI_CODE, file_path="/tmp/cli.py")
        finding = _make_finding(cwe_id="CWE-22", line=5)
        result = analyzer.analyze_finding(finding, cpg, CLI_CODE)
        # CLI or internal — click commands are CLI
        assert result.attack_surface_category in {"cli", "internal"}


class TestAttackSurfaceMapping:
    def test_map_attack_surface_returns_dict(self, builder, analyzer):
        """map_attack_surface() must return a dict."""
        cpg = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        result = analyzer.map_attack_surface(cpg, INTERNET_FACING_CODE)
        assert isinstance(result, dict)

    def test_attack_surface_scores_in_range(self, builder, analyzer):
        """All attack surface scores must be in [0.0, 1.0]."""
        cpg = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        result = analyzer.map_attack_surface(cpg, INTERNET_FACING_CODE)
        for node_id, score in result.items():
            assert 0.0 <= score <= 1.0, f"Score {score} out of range for {node_id}"


class TestBatchAnalysis:
    def test_analyze_all_returns_list(self, builder, analyzer):
        """analyze_all_findings() must return a list of SinkReachabilityResult."""
        cpg = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        findings = [_make_finding(line=i) for i in [5, 6, 7]]
        results = analyzer.analyze_all_findings(findings, cpg, INTERNET_FACING_CODE)
        assert isinstance(results, list)
        assert len(results) == 3

    def test_batch_results_sorted_by_exploitability(self, builder, analyzer):
        """Results must be sorted by exploitability_score descending."""
        cpg = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        findings = [_make_finding(line=i) for i in [5, 6, 7]]
        results = analyzer.analyze_all_findings(findings, cpg, INTERNET_FACING_CODE)
        scores = [r.exploitability_score for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_user_controlled_flag(self, builder, analyzer):
        """user_controlled must be bool."""
        cpg = builder.build_source(INTERNET_FACING_CODE, file_path="/tmp/test.py")
        finding = _make_finding()
        result = analyzer.analyze_finding(finding, cpg, INTERNET_FACING_CODE)
        assert isinstance(result.user_controlled, bool)
