"""
tests/test_cpg_go_java_rust.py — Tests for Go, Java, and Rust CPG builders.

Tests for each language:
- True Positive: source-to-sink taint flow detected (precision >= 0.85)
- True Negative: sanitized code produces no high-severity findings
- build_source() returns a CodePropertyGraph instance
- Nodes are populated
- Tainted paths have confidence >= 0.7
"""
from __future__ import annotations

import pytest

from backend.core.cpg.go_builder import GoCPGBuilder
from backend.core.cpg.java_builder import JavaCPGBuilder
from backend.core.cpg.rust_builder import RustCPGBuilder
from backend.core.cpg.graph import (
    CPGEdgeType,
    CPGNodeType,
    CodePropertyGraph,
)


# =============================================================================
# Go CPG Builder Tests
# =============================================================================

GO_TRUE_POSITIVE_SOURCE = """\
package main

import (
    "database/sql"
    "fmt"
    "net/http"
)

func handleSearch(w http.ResponseWriter, r *http.Request) {
    query := r.FormValue("q")
    sqlStr := "SELECT * FROM users WHERE name = '" + query + "'"
    db.Query(sqlStr)
}
"""

GO_TRUE_POSITIVE_CMDI = """\
package main

import (
    "net/http"
    "os/exec"
)

func runCmd(w http.ResponseWriter, r *http.Request) {
    cmd := r.FormValue("command")
    exec.Command("sh", "-c", cmd).Run()
}
"""

GO_TRUE_NEGATIVE_SANITIZED = """\
package main

import (
    "database/sql"
    "html"
    "net/http"
    "strconv"
)

func safeHandler(w http.ResponseWriter, r *http.Request) {
    idStr := r.FormValue("id")
    id, err := strconv.Atoi(idStr)
    if err != nil {
        return
    }
    db.Query("SELECT * FROM items WHERE id = $1", id)
}
"""

GO_ENV_SOURCE_EXEC_SINK = """\
package main

import (
    "os"
    "os/exec"
)

func runEnvCommand() {
    cmdName := os.Getenv("USER_COMMAND")
    exec.Command(cmdName).Run()
}
"""

GO_SANITIZED_PRINTF = """\
package main

import (
    "html"
    "net/http"
    "fmt"
)

func safeWrite(w http.ResponseWriter, r *http.Request) {
    input := r.FormValue("name")
    safe := html.EscapeString(input)
    fmt.Fprintf(w, "Hello, %s", safe)
}
"""


class TestGoCPGBuilder:
    """Tests for GoCPGBuilder."""

    def setup_method(self):
        self.builder = GoCPGBuilder()

    def test_build_source_returns_cpg_instance(self):
        """build_source() should return a CodePropertyGraph."""
        cpg = self.builder.build_source(GO_TRUE_POSITIVE_SOURCE, file_path="<go>")
        assert isinstance(cpg, CodePropertyGraph)

    def test_nodes_populated(self):
        """Nodes should be populated after building."""
        cpg = self.builder.build_source(GO_TRUE_POSITIVE_SOURCE, file_path="<go>")
        assert len(cpg.nodes) > 0

    def test_sql_injection_taint_detected(self):
        """SQLi: r.FormValue -> db.Query with string concat should be detected."""
        cpg = self.builder.build_source(GO_TRUE_POSITIVE_SOURCE, file_path="<go>")

        source_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_source")
        ]
        sink_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_sink")
        ]

        assert len(source_nodes) >= 1, "Should detect at least one taint source"
        assert len(sink_nodes) >= 1, "Should detect at least one sink"

        # Verify source is from r.FormValue
        source_labels = [n.properties.get("source_label", "") for n in source_nodes]
        assert any("FormValue" in lbl for lbl in source_labels), \
            f"Expected FormValue source, got: {source_labels}"

    def test_cmdi_taint_detected(self):
        """Command injection via exec.Command should be detected."""
        cpg = self.builder.build_source(GO_TRUE_POSITIVE_CMDI, file_path="<go>")

        sink_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_sink")
        ]

        assert len(sink_nodes) >= 1, "Should detect exec.Command as sink"
        sink_cwes = [n.properties.get("sink_cwe", "") for n in sink_nodes]
        assert any("CWE-78" in c for c in sink_cwes), \
            f"Expected CWE-78 sink, got: {sink_cwes}"

    def test_taint_flow_edges_created(self):
        """DFG_FLOW edges should connect source to sink nodes."""
        cpg = self.builder.build_source(GO_TRUE_POSITIVE_SOURCE, file_path="<go>")

        dfg_edges = [
            e for edges in cpg._adj.values()
            for e in edges
            if e.edge_type == CPGEdgeType.DFG_FLOW
        ]

        assert len(dfg_edges) >= 1, "Should have at least one DFG_FLOW edge"

    def test_taint_flow_has_high_confidence(self):
        """Tainted paths should have source confidence >= 0.7."""
        cpg = self.builder.build_source(GO_TRUE_POSITIVE_SOURCE, file_path="<go>")

        source_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_source")
        ]

        for src_node in source_nodes:
            conf = src_node.properties.get("source_confidence", 0.0)
            assert conf >= 0.7, \
                f"Source node confidence {conf} is below 0.7: {src_node.code}"

    def test_sanitized_code_no_high_severity_sink(self):
        """Sanitized code should produce no taint flow from source to sink."""
        cpg = self.builder.build_source(GO_TRUE_NEGATIVE_SANITIZED, file_path="<go>")

        # With strconv.Atoi as sanitizer, the tainted var goes through integer conversion
        # Check that any sink nodes that exist are not connected to sources via taint
        source_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_source")
        ]
        sink_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_sink")
        ]

        # Either no source/sink pair exists, or no direct taint flow between them
        if source_nodes and sink_nodes:
            taint_flow_edges = [
                e for edges in cpg._adj.values()
                for e in edges
                if e.edge_type == CPGEdgeType.DFG_FLOW
                and e.properties.get("taint_flow")
            ]
            # With proper sanitization, taint flows should be 0 or only through safe path
            # The sanitized version should not have source->sink taint paths
            source_ids = {n.node_id for n in source_nodes}
            sink_ids = {n.node_id for n in sink_nodes}
            direct_taint = [
                e for e in taint_flow_edges
                if e.src_id in source_ids and e.dst_id in sink_ids
            ]
            assert len(direct_taint) == 0, \
                f"Sanitized code should not have direct source->sink taint, found: {len(direct_taint)}"

    def test_env_source_exec_sink(self):
        """os.Getenv source flowing to exec.Command sink."""
        cpg = self.builder.build_source(GO_ENV_SOURCE_EXEC_SINK, file_path="<go>")

        source_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_source")
        ]
        assert len(source_nodes) >= 1

        source_labels = [n.properties.get("source_label", "") for n in source_nodes]
        assert any("Getenv" in lbl for lbl in source_labels)

    def test_build_file_nonexistent_returns_cpg(self):
        """build_file on nonexistent path should return CPG with error node."""
        cpg = self.builder.build_file("/nonexistent/path/test.go")
        assert isinstance(cpg, CodePropertyGraph)
        assert len(cpg.nodes) >= 1

    def test_cfg_edges_present(self):
        """CFG_NEXT edges should be created between statements."""
        cpg = self.builder.build_source(GO_TRUE_POSITIVE_SOURCE, file_path="<go>")

        cfg_edges = [
            e for edges in cpg._adj.values()
            for e in edges
            if e.edge_type == CPGEdgeType.CFG_NEXT
        ]
        assert len(cfg_edges) >= 1, "Should have CFG_NEXT edges"

    def test_entry_exit_nodes_created(self):
        """CFG_ENTRY and CFG_EXIT nodes should be created for functions."""
        cpg = self.builder.build_source(GO_TRUE_POSITIVE_SOURCE, file_path="<go>")

        entry_nodes = [
            n for n in cpg.nodes.values()
            if n.node_type == CPGNodeType.CFG_ENTRY
        ]
        exit_nodes = [
            n for n in cpg.nodes.values()
            if n.node_type == CPGNodeType.CFG_EXIT
        ]

        assert len(entry_nodes) >= 1, "Should have CFG_ENTRY node"
        assert len(exit_nodes) >= 1, "Should have CFG_EXIT node"

    def test_fmt_fprintf_sink_detected(self):
        """fmt.Fprintf(w ...) should be detected as XSS sink."""
        tainted_source = """\
package main

import (
    "fmt"
    "net/http"
)

func vulnerableWrite(w http.ResponseWriter, r *http.Request) {
    name := r.FormValue("name")
    fmt.Fprintf(w, "<h1>Hello " + name + "</h1>")
}
"""
        cpg = self.builder.build_source(tainted_source, file_path="<go>")
        sink_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_sink")
        ]
        assert len(sink_nodes) >= 1
        sink_cwes = [n.properties.get("sink_cwe", "") for n in sink_nodes]
        assert any("CWE-79" in c for c in sink_cwes), \
            f"Expected CWE-79 (XSS) sink, got: {sink_cwes}"

    def test_precision_on_true_positives(self):
        """Detection precision should be >= 0.85 on clear TP cases."""
        tp_sources = [GO_TRUE_POSITIVE_SOURCE, GO_TRUE_POSITIVE_CMDI, GO_ENV_SOURCE_EXEC_SINK]
        detected = 0
        for src in tp_sources:
            cpg = self.builder.build_source(src, file_path="<go>")
            source_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_source")]
            sink_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_sink")]
            if source_nodes and sink_nodes:
                detected += 1

        precision = detected / len(tp_sources)
        assert precision >= 0.85, \
            f"Precision {precision:.2f} < 0.85 on Go true positives ({detected}/{len(tp_sources)})"


# =============================================================================
# Java CPG Builder Tests
# =============================================================================

JAVA_TRUE_POSITIVE_SOURCE = """\
import javax.servlet.http.*;

public class SearchServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String userInput = request.getParameter("search");
        String sql = "SELECT * FROM products WHERE name = '" + userInput + "'";
        Statement stmt = conn.createStatement();
        stmt.execute(sql);
    }
}
"""

JAVA_TRUE_POSITIVE_CMDI = """\
import javax.servlet.http.*;
import java.io.*;

public class CommandServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String cmd = request.getParameter("command");
        Runtime.getRuntime().exec(cmd);
    }
}
"""

JAVA_TRUE_POSITIVE_PATH = """\
import javax.servlet.http.*;
import java.io.*;

public class FileServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String fileName = request.getParameter("file");
        File f = new File("/data/" + fileName);
    }
}
"""

JAVA_TRUE_NEGATIVE_SANITIZED = """\
import javax.servlet.http.*;
import java.sql.*;
import org.owasp.encoder.Encode;

public class SafeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        String userInput = request.getParameter("search");
        PreparedStatement ps = conn.prepareStatement("SELECT * FROM products WHERE name = ?");
        ps.setString(1, userInput);
        ps.execute();
    }
}
"""

JAVA_SPRING_SOURCE = """\
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class UserController {

    @GetMapping("/user")
    public String getUser(@RequestParam String userId, @PathVariable String name) {
        String query = "SELECT * FROM users WHERE id = '" + userId + "'";
        return jdbcTemplate.queryForObject(query, String.class);
    }
}
"""

JAVA_XSS_SOURCE = """\
import javax.servlet.http.*;
import java.io.*;

public class XSSServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String name = request.getParameter("name");
        PrintWriter out = response.getWriter();
        out.println("<html><body>Hello " + name + "</body></html>");
    }
}
"""


class TestJavaCPGBuilder:
    """Tests for JavaCPGBuilder."""

    def setup_method(self):
        self.builder = JavaCPGBuilder()

    def test_build_source_returns_cpg_instance(self):
        """build_source() should return a CodePropertyGraph."""
        cpg = self.builder.build_source(JAVA_TRUE_POSITIVE_SOURCE, file_path="<java>")
        assert isinstance(cpg, CodePropertyGraph)

    def test_nodes_populated(self):
        """Nodes should be populated after building."""
        cpg = self.builder.build_source(JAVA_TRUE_POSITIVE_SOURCE, file_path="<java>")
        assert len(cpg.nodes) > 0

    def test_sqli_detected(self):
        """SQL injection via request.getParameter -> Statement.execute should be detected."""
        cpg = self.builder.build_source(JAVA_TRUE_POSITIVE_SOURCE, file_path="<java>")

        source_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_source")
        ]
        sink_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_sink")
        ]

        assert len(source_nodes) >= 1, "Should detect request.getParameter as source"
        assert len(sink_nodes) >= 1, "Should detect Statement.execute as sink"

        source_labels = [n.properties.get("source_label", "") for n in source_nodes]
        assert any("getParameter" in lbl for lbl in source_labels), \
            f"Expected getParameter source, got: {source_labels}"

    def test_cmdi_detected(self):
        """Command injection via Runtime.exec should be detected."""
        cpg = self.builder.build_source(JAVA_TRUE_POSITIVE_CMDI, file_path="<java>")

        sink_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_sink")
        ]

        assert len(sink_nodes) >= 1, "Should detect Runtime.exec as sink"
        sink_cwes = [n.properties.get("sink_cwe", "") for n in sink_nodes]
        assert any("CWE-78" in c for c in sink_cwes), \
            f"Expected CWE-78 sink, got: {sink_cwes}"

    def test_path_traversal_detected(self):
        """Path traversal via new File() should be detected."""
        cpg = self.builder.build_source(JAVA_TRUE_POSITIVE_PATH, file_path="<java>")

        sink_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_sink")
        ]

        assert len(sink_nodes) >= 1
        sink_cwes = [n.properties.get("sink_cwe", "") for n in sink_nodes]
        assert any("CWE-22" in c for c in sink_cwes), \
            f"Expected CWE-22 sink, got: {sink_cwes}"

    def test_taint_flow_edges_created(self):
        """DFG_FLOW edges should be created."""
        cpg = self.builder.build_source(JAVA_TRUE_POSITIVE_SOURCE, file_path="<java>")

        dfg_edges = [
            e for edges in cpg._adj.values()
            for e in edges
            if e.edge_type == CPGEdgeType.DFG_FLOW
        ]

        assert len(dfg_edges) >= 1, "Should have DFG_FLOW edges"

    def test_source_confidence_above_threshold(self):
        """Source nodes should have confidence >= 0.7."""
        cpg = self.builder.build_source(JAVA_TRUE_POSITIVE_SOURCE, file_path="<java>")

        source_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_taint_source")
        ]

        for src_node in source_nodes:
            conf = src_node.properties.get("source_confidence", 0.0)
            assert conf >= 0.7, \
                f"Source confidence {conf} below 0.7: {src_node.code}"

    def test_sanitized_code_no_taint_path(self):
        """PreparedStatement with ? placeholder should prevent taint to sink."""
        cpg = self.builder.build_source(JAVA_TRUE_NEGATIVE_SANITIZED, file_path="<java>")

        # Should not detect sink nodes when PreparedStatement is used properly
        # (or if detected, no direct taint flow from source to sink)
        source_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_source")]
        sink_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_sink")]

        if source_nodes and sink_nodes:
            taint_flow_edges = [
                e for edges in cpg._adj.values()
                for e in edges
                if e.edge_type == CPGEdgeType.DFG_FLOW
                and e.properties.get("taint_flow")
            ]
            source_ids = {n.node_id for n in source_nodes}
            sink_ids = {n.node_id for n in sink_nodes}
            direct_taint = [
                e for e in taint_flow_edges
                if e.src_id in source_ids and e.dst_id in sink_ids
            ]
            assert len(direct_taint) == 0, \
                f"Sanitized code should not have direct source->sink taint: {len(direct_taint)}"

    def test_cfg_edges_present(self):
        """CFG_NEXT edges should be created."""
        cpg = self.builder.build_source(JAVA_TRUE_POSITIVE_SOURCE, file_path="<java>")

        cfg_edges = [
            e for edges in cpg._adj.values()
            for e in edges
            if e.edge_type == CPGEdgeType.CFG_NEXT
        ]
        assert len(cfg_edges) >= 1

    def test_entry_exit_nodes_created(self):
        """CFG_ENTRY and CFG_EXIT nodes should be created."""
        cpg = self.builder.build_source(JAVA_TRUE_POSITIVE_SOURCE, file_path="<java>")

        entry_nodes = [n for n in cpg.nodes.values() if n.node_type == CPGNodeType.CFG_ENTRY]
        exit_nodes = [n for n in cpg.nodes.values() if n.node_type == CPGNodeType.CFG_EXIT]

        assert len(entry_nodes) >= 1
        assert len(exit_nodes) >= 1

    def test_xss_detected(self):
        """XSS via PrintWriter.println with user input should be detected."""
        cpg = self.builder.build_source(JAVA_XSS_SOURCE, file_path="<java>")

        source_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_source")]
        sink_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_sink")]

        assert len(source_nodes) >= 1
        # We should find XSS or path traversal sink (PrintWriter.println or similar)
        assert len(sink_nodes) >= 1

    def test_build_file_nonexistent_returns_cpg(self):
        """build_file on nonexistent path should return CPG with error node."""
        cpg = self.builder.build_file("/nonexistent/path/Test.java")
        assert isinstance(cpg, CodePropertyGraph)
        assert len(cpg.nodes) >= 1

    def test_spring_requestparam_source_detected(self):
        """Spring @RequestParam annotations should be detected as taint sources."""
        cpg = self.builder.build_source(JAVA_SPRING_SOURCE, file_path="<java>")

        source_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_source")]
        assert len(source_nodes) >= 1, "Should detect Spring @RequestParam as source"

    def test_precision_on_true_positives(self):
        """Detection precision should be >= 0.85 on clear TP cases."""
        tp_sources = [
            JAVA_TRUE_POSITIVE_SOURCE,
            JAVA_TRUE_POSITIVE_CMDI,
            JAVA_TRUE_POSITIVE_PATH,
        ]
        detected = 0
        for src in tp_sources:
            cpg = self.builder.build_source(src, file_path="<java>")
            source_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_source")]
            sink_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_sink")]
            if source_nodes and sink_nodes:
                detected += 1

        precision = detected / len(tp_sources)
        assert precision >= 0.85, \
            f"Precision {precision:.2f} < 0.85 on Java true positives ({detected}/{len(tp_sources)})"


# =============================================================================
# Rust CPG Builder Tests
# =============================================================================

RUST_TRUE_POSITIVE_CLI = """\
use std::env;
use std::process::Command;

fn run_user_command() {
    let args: Vec<String> = env::args().collect();
    let user_cmd = &args[1];
    Command::new(user_cmd).output().expect("failed");
}
"""

RUST_TRUE_POSITIVE_FS = """\
use std::env;
use std::fs;

fn read_user_file() {
    let filename = env::args().nth(1).unwrap_or_default();
    let contents = fs::read_to_string(filename).expect("file error");
    println!("{}", contents);
}
"""

RUST_TRUE_POSITIVE_SQL = """\
use std::env;

async fn query_db(client: &tokio_postgres::Client) {
    let user_id = env::args().nth(1).unwrap_or_default();
    let sql = format!("SELECT * FROM users WHERE id = '{}'", user_id);
    client.execute(&sql, &[]).await.unwrap();
}
"""

RUST_TRUE_NEGATIVE_SANITIZED = """\
use std::env;
use std::path::Path;

fn safe_read() {
    let base_dir = "/safe/data";
    let filename = env::args().nth(1).unwrap_or_default();
    // Use canonicalize to safely resolve and validate path
    let full_path = Path::new(base_dir).join(&filename).canonicalize().unwrap_or_default();
    let _ = std::fs::read_to_string(&full_path);
}
"""

RUST_UNSAFE_BLOCK = """\
fn unsafe_operation(ptr: *const u8) -> u8 {
    unsafe {
        *ptr
    }
}
"""

RUST_UNWRAP_SENSITIVE = """\
use std::env;
use std::fs;

fn risky_unwrap() {
    let path = env::var("FILE_PATH").unwrap();
    let data = fs::read_to_string(&path).unwrap();
    println!("{}", data);
}
"""

RUST_ACTIX_SOURCE = """\
use actix_web::{web, HttpResponse};

async fn handler(query: web::Query<std::collections::HashMap<String, String>>) -> HttpResponse {
    let user_input = query.get("cmd").cloned().unwrap_or_default();
    let output = std::process::Command::new(&user_input).output().unwrap();
    HttpResponse::Ok().body(format!("{:?}", output))
}
"""


class TestRustCPGBuilder:
    """Tests for RustCPGBuilder."""

    def setup_method(self):
        self.builder = RustCPGBuilder()

    def test_build_source_returns_cpg_instance(self):
        """build_source() should return a CodePropertyGraph."""
        cpg = self.builder.build_source(RUST_TRUE_POSITIVE_CLI, file_path="<rust>")
        assert isinstance(cpg, CodePropertyGraph)

    def test_nodes_populated(self):
        """Nodes should be populated after building."""
        cpg = self.builder.build_source(RUST_TRUE_POSITIVE_CLI, file_path="<rust>")
        assert len(cpg.nodes) > 0

    def test_cli_args_to_command_detected(self):
        """env::args -> Command::new taint flow should be detected."""
        cpg = self.builder.build_source(RUST_TRUE_POSITIVE_CLI, file_path="<rust>")

        source_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_source")]
        sink_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_sink")]

        assert len(source_nodes) >= 1, "Should detect env::args as taint source"
        assert len(sink_nodes) >= 1, "Should detect Command::new as sink"

        source_labels = [n.properties.get("source_label", "") for n in source_nodes]
        assert any("args" in lbl.lower() for lbl in source_labels), \
            f"Expected args source, got: {source_labels}"

    def test_path_traversal_detected(self):
        """env::args -> fs::read_to_string taint should be detected."""
        cpg = self.builder.build_source(RUST_TRUE_POSITIVE_FS, file_path="<rust>")

        sink_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_sink")]
        assert len(sink_nodes) >= 1, "Should detect fs::read_to_string as sink"

        sink_cwes = [n.properties.get("sink_cwe", "") for n in sink_nodes]
        assert any("CWE-22" in c for c in sink_cwes), \
            f"Expected CWE-22 path traversal sink, got: {sink_cwes}"

    def test_sql_injection_detected(self):
        """env::args -> format! SQL -> client.execute taint should be detected."""
        cpg = self.builder.build_source(RUST_TRUE_POSITIVE_SQL, file_path="<rust>")

        sink_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_sink")]
        assert len(sink_nodes) >= 1

    def test_unsafe_block_medium_finding(self):
        """unsafe { } blocks should produce medium severity finding (CWE-242)."""
        cpg = self.builder.build_source(RUST_UNSAFE_BLOCK, file_path="<rust>")

        unsafe_nodes = [
            n for n in cpg.nodes.values()
            if n.properties.get("is_unsafe_block")
        ]

        assert len(unsafe_nodes) >= 1, "Should detect unsafe block"
        for node in unsafe_nodes:
            cwe = node.properties.get("sink_cwe", "")
            assert "CWE-242" in cwe, f"Expected CWE-242, got: {cwe}"

    def test_unwrap_on_sensitive_path_medium_finding(self):
        """unwrap() on security-sensitive operations should produce a finding."""
        cpg = self.builder.build_source(RUST_UNWRAP_SENSITIVE, file_path="<rust>")

        # Should detect the env::var source
        source_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_source")]
        assert len(source_nodes) >= 1, "Should detect env::var as source"

    def test_taint_flow_edges_created(self):
        """DFG_FLOW edges should be created between source and sink."""
        cpg = self.builder.build_source(RUST_TRUE_POSITIVE_CLI, file_path="<rust>")

        dfg_edges = [
            e for edges in cpg._adj.values()
            for e in edges
            if e.edge_type == CPGEdgeType.DFG_FLOW
        ]
        assert len(dfg_edges) >= 1

    def test_source_confidence_above_threshold(self):
        """Source nodes should have confidence >= 0.7."""
        cpg = self.builder.build_source(RUST_TRUE_POSITIVE_CLI, file_path="<rust>")

        source_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_source")]

        for src_node in source_nodes:
            conf = src_node.properties.get("source_confidence", 0.0)
            assert conf >= 0.7, \
                f"Source confidence {conf} below 0.7: {src_node.code}"

    def test_sanitized_code_no_direct_taint(self):
        """Code with starts_with() path check should not produce direct source->sink taint."""
        cpg = self.builder.build_source(RUST_TRUE_NEGATIVE_SANITIZED, file_path="<rust>")

        source_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_source")]
        sink_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_sink")]

        if source_nodes and sink_nodes:
            taint_flow_edges = [
                e for edges in cpg._adj.values()
                for e in edges
                if e.edge_type == CPGEdgeType.DFG_FLOW
                and e.properties.get("taint_flow")
            ]
            source_ids = {n.node_id for n in source_nodes}
            sink_ids = {n.node_id for n in sink_nodes}
            direct_taint = [
                e for e in taint_flow_edges
                if e.src_id in source_ids and e.dst_id in sink_ids
            ]
            assert len(direct_taint) == 0, \
                f"Sanitized Rust code should not have direct source->sink taint"

    def test_cfg_edges_present(self):
        """CFG_NEXT edges should be present."""
        cpg = self.builder.build_source(RUST_TRUE_POSITIVE_CLI, file_path="<rust>")

        cfg_edges = [
            e for edges in cpg._adj.values()
            for e in edges
            if e.edge_type == CPGEdgeType.CFG_NEXT
        ]
        assert len(cfg_edges) >= 1

    def test_entry_exit_nodes_created(self):
        """CFG_ENTRY and CFG_EXIT nodes should be created for functions."""
        cpg = self.builder.build_source(RUST_TRUE_POSITIVE_CLI, file_path="<rust>")

        entry_nodes = [n for n in cpg.nodes.values() if n.node_type == CPGNodeType.CFG_ENTRY]
        exit_nodes = [n for n in cpg.nodes.values() if n.node_type == CPGNodeType.CFG_EXIT]

        assert len(entry_nodes) >= 1
        assert len(exit_nodes) >= 1

    def test_actix_web_source_detected(self):
        """actix-web web::Query extractor should be detected as taint source."""
        cpg = self.builder.build_source(RUST_ACTIX_SOURCE, file_path="<rust>")

        source_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_source")]
        assert len(source_nodes) >= 1, "Should detect actix-web extractor as source"

    def test_build_file_nonexistent_returns_cpg(self):
        """build_file on nonexistent path should return CPG with error node."""
        cpg = self.builder.build_file("/nonexistent/path/test.rs")
        assert isinstance(cpg, CodePropertyGraph)
        assert len(cpg.nodes) >= 1

    def test_precision_on_true_positives(self):
        """Detection precision should be >= 0.85 on clear TP cases."""
        tp_sources = [
            RUST_TRUE_POSITIVE_CLI,
            RUST_TRUE_POSITIVE_FS,
            RUST_TRUE_POSITIVE_SQL,
        ]
        detected = 0
        for src in tp_sources:
            cpg = self.builder.build_source(src, file_path="<rust>")
            source_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_source")]
            sink_nodes = [n for n in cpg.nodes.values() if n.properties.get("is_taint_sink")]
            if source_nodes and sink_nodes:
                detected += 1

        precision = detected / len(tp_sources)
        assert precision >= 0.85, \
            f"Precision {precision:.2f} < 0.85 on Rust true positives ({detected}/{len(tp_sources)})"


# =============================================================================
# Cross-language integration tests
# =============================================================================

class TestCPGBuilderIntegration:
    """Cross-language integration tests checking consistent interface."""

    def test_all_builders_return_cpg_on_empty_source(self):
        """All builders should return a CodePropertyGraph even for empty source."""
        builders = [
            (GoCPGBuilder(), "<go>"),
            (JavaCPGBuilder(), "<java>"),
            (RustCPGBuilder(), "<rust>"),
        ]
        for builder, fp in builders:
            cpg = builder.build_source("", file_path=fp)
            assert isinstance(cpg, CodePropertyGraph), \
                f"{type(builder).__name__} should return CPG on empty source"

    def test_all_builders_have_consistent_interface(self):
        """All builders should implement build_source and build_file."""
        builders = [GoCPGBuilder(), JavaCPGBuilder(), RustCPGBuilder()]
        for builder in builders:
            assert hasattr(builder, "build_source"), \
                f"{type(builder).__name__} missing build_source"
            assert hasattr(builder, "build_file"), \
                f"{type(builder).__name__} missing build_file"
            assert callable(builder.build_source), \
                f"{type(builder).__name__}.build_source not callable"
            assert callable(builder.build_file), \
                f"{type(builder).__name__}.build_file not callable"

    def test_cpg_graph_stats(self):
        """stats() should return valid counts for all builders."""
        builders_and_sources = [
            (GoCPGBuilder(), GO_TRUE_POSITIVE_SOURCE, "<go>"),
            (JavaCPGBuilder(), JAVA_TRUE_POSITIVE_SOURCE, "<java>"),
            (RustCPGBuilder(), RUST_TRUE_POSITIVE_CLI, "<rust>"),
        ]
        for builder, source, fp in builders_and_sources:
            cpg = builder.build_source(source, file_path=fp)
            stats = cpg.stats()
            assert stats["nodes"] > 0, \
                f"{type(builder).__name__} CPG should have nodes"
            assert stats["edges"] >= 0, \
                f"{type(builder).__name__} CPG edges count should be non-negative"

    def test_cpg_reachability_works(self):
        """CPG.reachable() should function on all builder outputs."""
        builders_and_sources = [
            (GoCPGBuilder(), GO_TRUE_POSITIVE_SOURCE, "<go>"),
            (JavaCPGBuilder(), JAVA_TRUE_POSITIVE_SOURCE, "<java>"),
            (RustCPGBuilder(), RUST_TRUE_POSITIVE_CLI, "<rust>"),
        ]
        for builder, source, fp in builders_and_sources:
            cpg = builder.build_source(source, file_path=fp)
            # Pick any node and check reachability doesn't crash
            if cpg.nodes:
                any_node_id = next(iter(cpg.nodes))
                reachable = cpg.reachable(any_node_id)
                assert isinstance(reachable, set), \
                    f"{type(builder).__name__} reachable() should return a set"
