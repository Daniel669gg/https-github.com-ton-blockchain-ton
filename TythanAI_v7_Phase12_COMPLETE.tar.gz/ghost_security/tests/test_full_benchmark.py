"""
Tests for the full benchmark runner, OWASP corpus, and CVE corpus.
15 tests validating corpus integrity and benchmark metrics computation.
"""
import sys
import pathlib

_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pytest

from backend.core.benchmarks.owasp_corpus import OWASP_CASES, OWASPCase
from backend.core.benchmarks.cve_corpus import CVE_CASES, CVECase
from backend.core.benchmarks.full_benchmark import FullBenchmarkRunner, BenchmarkMetrics
from backend.core.confidence import Finding


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_finding(**kwargs):
    defaults = dict(
        rule_id="TAINT-SQL_INJECTION", file="/tmp/test.py", line=5,
        severity="HIGH", confidence=0.85, cwe_id="CWE-89",
        description="SQL injection detected",
        recommendation="Use parameterized queries", sources=["flask_request"],
    )
    defaults.update(kwargs)
    return Finding(**defaults)


def _one_finding():
    return [_make_finding()]


# ---------------------------------------------------------------------------
# TestOWASPCorpus
# ---------------------------------------------------------------------------

class TestOWASPCorpus:
    def test_owasp_corpus_has_cases(self):
        """OWASP corpus must have at least 30 test cases."""
        assert len(OWASP_CASES) >= 30, (
            f"Expected >= 30 OWASP cases, got {len(OWASP_CASES)}"
        )

    def test_covers_multiple_categories(self):
        """OWASP corpus must cover at least 5 distinct OWASP categories."""
        categories = {case.category for case in OWASP_CASES}
        assert len(categories) >= 5, (
            f"Expected >= 5 categories, got {len(categories)}: {categories}"
        )

    def test_has_vulnerable_cases(self):
        """There must be at least one case with is_vulnerable=True."""
        vulnerable = [c for c in OWASP_CASES if c.is_vulnerable]
        assert len(vulnerable) >= 1

    def test_has_safe_cases(self):
        """There must be at least one case with is_vulnerable=False."""
        safe = [c for c in OWASP_CASES if not c.is_vulnerable]
        assert len(safe) >= 1

    def test_cases_have_code(self):
        """Every OWASP case must have a non-empty code field."""
        for case in OWASP_CASES:
            assert isinstance(case, OWASPCase)
            assert isinstance(case.code, str)
            assert len(case.code.strip()) > 0, (
                f"Case {case.case_id} has empty code"
            )


# ---------------------------------------------------------------------------
# TestCVECorpus
# ---------------------------------------------------------------------------

class TestCVECorpus:
    def test_cve_corpus_has_cases(self):
        """CVE corpus must have at least 20 test cases."""
        assert len(CVE_CASES) >= 20, (
            f"Expected >= 20 CVE cases, got {len(CVE_CASES)}"
        )

    def test_has_both_versions(self):
        """CVE corpus must have both is_vulnerable=True and False cases."""
        vuln = [c for c in CVE_CASES if c.is_vulnerable]
        safe = [c for c in CVE_CASES if not c.is_vulnerable]
        assert len(vuln) >= 1, "No vulnerable CVE cases found"
        assert len(safe) >= 1, "No safe CVE cases found"

    def test_cvss_scores_realistic(self):
        """All cvss_score values must be between 0.0 and 10.0."""
        for case in CVE_CASES:
            assert isinstance(case, CVECase)
            assert 0.0 <= case.cvss_score <= 10.0, (
                f"Case {case.case_id} has unrealistic CVSS score: {case.cvss_score}"
            )

    def test_cases_have_cve_id(self):
        """Every CVE case must have a non-empty cve_id."""
        for case in CVE_CASES:
            assert isinstance(case.cve_id, str)
            assert len(case.cve_id) > 0, (
                f"CVE case {case.case_id} has empty cve_id"
            )


# ---------------------------------------------------------------------------
# TestFullBenchmarkRunner
# ---------------------------------------------------------------------------

class TestFullBenchmarkRunner:
    """Tests for FullBenchmarkRunner scoring and metrics computation."""

    def test_score_case_tp(self):
        """is_vulnerable=True + findings → TP."""
        label = FullBenchmarkRunner._score_case(
            is_vulnerable=True,
            findings=_one_finding(),
        )
        assert label == "TP"

    def test_score_case_tn(self):
        """is_vulnerable=False + empty findings → TN."""
        label = FullBenchmarkRunner._score_case(
            is_vulnerable=False,
            findings=[],
        )
        assert label == "TN"

    def test_score_case_fp(self):
        """is_vulnerable=False + findings → FP."""
        label = FullBenchmarkRunner._score_case(
            is_vulnerable=False,
            findings=_one_finding(),
        )
        assert label == "FP"

    def test_score_case_fn(self):
        """is_vulnerable=True + empty findings → FN."""
        label = FullBenchmarkRunner._score_case(
            is_vulnerable=True,
            findings=[],
        )
        assert label == "FN"

    def test_compute_metrics_precision(self):
        """tp=8, fp=2, tn=8, fn=2 → precision=0.8."""
        metrics = FullBenchmarkRunner._compute_metrics(
            tp=8, fp=2, tn=8, fn=2, sample_size=20
        )
        assert isinstance(metrics, BenchmarkMetrics)
        assert abs(metrics.precision - 0.8) < 0.001, (
            f"Expected precision=0.8, got {metrics.precision}"
        )

    def test_compute_metrics_f1(self):
        """tp=8, fp=2, tn=8, fn=2 → f1≈0.8."""
        metrics = FullBenchmarkRunner._compute_metrics(
            tp=8, fp=2, tn=8, fn=2, sample_size=20
        )
        # recall = 8/(8+2) = 0.8, precision = 0.8, so F1 = 0.8
        assert abs(metrics.f1_score - 0.8) < 0.001, (
            f"Expected f1≈0.8, got {metrics.f1_score}"
        )

    def test_run_owasp_returns_dict(self):
        """run_owasp() must return a dict with category keys."""
        runner = FullBenchmarkRunner()
        result = runner.run_owasp()
        assert isinstance(result, dict)
        assert len(result) >= 1
        # Keys should be category strings like "A01:2021"
        for key in result:
            assert isinstance(key, str)
            assert len(key) > 0
