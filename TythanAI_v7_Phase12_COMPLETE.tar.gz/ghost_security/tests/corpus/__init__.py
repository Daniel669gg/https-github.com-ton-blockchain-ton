"""TythanAI — benchmark corpus package."""
