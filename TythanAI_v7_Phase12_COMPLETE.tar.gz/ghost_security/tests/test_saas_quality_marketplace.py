"""
tests/test_saas_quality_marketplace.py
Tests for: CodeQualityScanner, TransitiveReachabilityAnalyzer, RulesMarketplace,
           OnboardingFlow, WebhookManager, UsageDashboard.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import sqlite3
import tempfile
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, List
from unittest.mock import MagicMock, patch

import pytest

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _write(tmp_path: Path, name: str, content: str) -> Path:
    p = tmp_path / name
    p.write_text(content, encoding="utf-8")
    return p


# ═══════════════════════════════════════════════════════════════════════════════
# File 1: CodeQualityScanner
# ═══════════════════════════════════════════════════════════════════════════════

class TestCodeQualityScanner:
    """Tests for backend/scanners/code_quality.py"""

    def _scanner(self):
        from backend.scanners.code_quality import CodeQualityScanner
        return CodeQualityScanner()

    def test_complex_function_has_cc_gt_1(self, tmp_path):
        """A function with many branches should have CC > 1."""
        src = _write(tmp_path, "complex.py", """\
def process(x, y, z):
    if x > 0:
        for i in range(x):
            if i % 2 == 0:
                result = i * y
            elif i % 3 == 0:
                result = i + z
            else:
                result = i
    while y > 0:
        y -= 1
        if y == 5:
            break
    try:
        result = x / z
    except ZeroDivisionError:
        result = 0
    return result
""")
        report = self._scanner().scan_file(str(src))
        assert report.cyclomatic_complexity > 1, (
            f"Expected CC > 1, got {report.cyclomatic_complexity}"
        )
        assert report.language == "python"

    def test_clean_simple_file_gets_grade_a(self, tmp_path):
        """A trivially simple file should grade A."""
        src = _write(tmp_path, "simple.py", """\
# Simple utility
def add(a, b):
    return a + b

result = add(1, 2)
""")
        report = self._scanner().scan_file(str(src))
        assert report.grade == "A", (
            f"Expected grade A, got {report.grade} (debt={report.technical_debt_minutes}, CC={report.cyclomatic_complexity})"
        )

    def test_technical_debt_calculated(self, tmp_path):
        """Technical debt should be a non-negative integer."""
        src = _write(tmp_path, "debt.py", """\
def foo(a, b, c, d, e):
    if a:
        if b:
            if c:
                if d:
                    return e
    return None
""")
        report = self._scanner().scan_file(str(src))
        assert isinstance(report.technical_debt_minutes, int)
        assert report.technical_debt_minutes >= 0

    def test_loc_counts_non_blank_non_comment_lines(self, tmp_path):
        """LOC should exclude blank lines and comment lines."""
        src = _write(tmp_path, "loc_test.py", """\
# This is a comment

x = 1
y = 2

# Another comment
z = x + y
""")
        report = self._scanner().scan_file(str(src))
        assert report.loc == 3  # x=1, y=2, z=x+y

    def test_comment_ratio_computed(self, tmp_path):
        """Comment ratio should be between 0 and 1."""
        src = _write(tmp_path, "ratio.py", """\
# comment
# comment
x = 1
y = 2
""")
        report = self._scanner().scan_file(str(src))
        assert 0.0 <= report.comment_ratio <= 1.0

    def test_dead_code_detected(self, tmp_path):
        """Functions defined but never called should be flagged as dead code."""
        src = _write(tmp_path, "dead.py", """\
def used_func():
    return 1

def dead_func():
    return 999

result = used_func()
""")
        report = self._scanner().scan_file(str(src))
        assert report.dead_code_count >= 1, (
            f"Expected dead_code_count >= 1, got {report.dead_code_count}"
        )

    def test_duplication_score_for_repeated_blocks(self, tmp_path):
        """Files with duplicate 6-line windows should have duplication_score > 0."""
        block = "\n".join([f"    line_{i} = {i}" for i in range(6)])
        src = _write(tmp_path, "dup.py", f"""\
def foo():
{block}

def bar():
{block}
""")
        report = self._scanner().scan_file(str(src))
        assert report.duplication_score > 0.0

    def test_javascript_file_scanned(self, tmp_path):
        """JavaScript files should be recognised and scanned."""
        src = _write(tmp_path, "app.js", """\
function greet(name) {
    if (name) {
        return 'Hello, ' + name;
    } else {
        return 'Hello, World';
    }
}
""")
        report = self._scanner().scan_file(str(src))
        assert report.language == "javascript"
        assert report.cyclomatic_complexity >= 1

    def test_scan_directory_returns_dict(self, tmp_path):
        """scan_directory should return a dict keyed by file path."""
        _write(tmp_path, "a.py", "x = 1\n")
        _write(tmp_path, "b.py", "y = 2\n")
        _write(tmp_path, "c.txt", "ignored\n")
        results = self._scanner().scan_directory(str(tmp_path))
        assert isinstance(results, dict)
        # Should have 2 Python files, txt is excluded
        py_results = {k: v for k, v in results.items() if k.endswith(".py")}
        assert len(py_results) == 2

    def test_grade_range(self, tmp_path):
        """Grade must be one of A, B, C, D, F."""
        src = _write(tmp_path, "graded.py", "def f(): return 1\n")
        report = self._scanner().scan_file(str(src))
        assert report.grade in ("A", "B", "C", "D", "F")


# ═══════════════════════════════════════════════════════════════════════════════
# File 2: TransitiveReachabilityAnalyzer
# ═══════════════════════════════════════════════════════════════════════════════

class TestTransitiveReachabilityAnalyzer:
    """Tests for backend/scanners/transitive_reachability.py"""

    def _analyzer(self):
        from backend.scanners.transitive_reachability import TransitiveReachabilityAnalyzer
        return TransitiveReachabilityAnalyzer()

    def _build_project(self, tmp_path: Path) -> Path:
        """Build a small Python project with import dependencies."""
        (tmp_path / "main.py").write_text(
            "import utils\n\nif __name__ == '__main__':\n    utils.run()\n",
            encoding="utf-8",
        )
        (tmp_path / "utils.py").write_text(
            "import helpers\n\ndef run(): pass\n",
            encoding="utf-8",
        )
        (tmp_path / "helpers.py").write_text(
            "def helper(): pass\n",
            encoding="utf-8",
        )
        (tmp_path / "orphan.py").write_text(
            "# standalone module, not imported anywhere\ndef orphan_func(): pass\n",
            encoding="utf-8",
        )
        return tmp_path

    def test_build_import_graph_returns_dict(self, tmp_path):
        project = self._build_project(tmp_path)
        analyzer = self._analyzer()
        graph = analyzer.build_import_graph(str(project))
        assert isinstance(graph, dict)
        assert len(graph) > 0

    def test_is_reachable_direct_import(self, tmp_path):
        """main imports utils → utils is reachable from main."""
        project = self._build_project(tmp_path)
        analyzer = self._analyzer()
        analyzer.build_import_graph(str(project))
        assert analyzer.is_reachable("main", "utils"), "utils should be reachable from main"

    def test_is_reachable_transitive(self, tmp_path):
        """main → utils → helpers; helpers is transitively reachable from main."""
        project = self._build_project(tmp_path)
        analyzer = self._analyzer()
        analyzer.build_import_graph(str(project))
        assert analyzer.is_reachable("main", "helpers"), (
            "helpers should be transitively reachable from main"
        )

    def test_not_reachable_when_no_import(self, tmp_path):
        """orphan.py is not imported anywhere → not reachable from main."""
        project = self._build_project(tmp_path)
        analyzer = self._analyzer()
        analyzer.build_import_graph(str(project))
        # orphan is not imported by main, utils, or helpers
        reachable = analyzer.reachable_from("main")
        assert "orphan" not in reachable, f"orphan should not be reachable; got: {reachable}"

    def test_reachable_from_returns_set(self, tmp_path):
        project = self._build_project(tmp_path)
        analyzer = self._analyzer()
        analyzer.build_import_graph(str(project))
        result = analyzer.reachable_from("main")
        assert isinstance(result, set)

    def test_entrypoints_detects_main(self, tmp_path):
        """Files with `if __name__ == '__main__'` should be entrypoints."""
        project = self._build_project(tmp_path)
        analyzer = self._analyzer()
        eps = analyzer.entrypoints(str(project))
        assert any("main" in ep for ep in eps), (
            f"Expected 'main' in entrypoints, got: {eps}"
        )

    def test_vex_not_affected_generated(self, tmp_path):
        """Packages not reachable from any entrypoint should get vex_status=not_affected."""
        project = self._build_project(tmp_path)
        analyzer = self._analyzer()
        analyzer.build_import_graph(str(project))

        findings = [
            {"rule_id": "CVE-1234", "package": "orphan", "severity": "HIGH"},
            {"rule_id": "CVE-5678", "package": "requests", "severity": "CRITICAL"},
        ]
        result = analyzer.generate_vex(findings, str(project))
        assert isinstance(result, list)
        assert len(result) == 2

        # Find the orphan finding
        orphan_finding = next(
            (f for f in result if f.get("package") == "orphan"), None
        )
        assert orphan_finding is not None
        assert orphan_finding.get("vex_status") == "not_affected"
        assert orphan_finding.get("justification") == "not_reachable"

    def test_vex_reachable_has_no_vex_status(self, tmp_path):
        """Reachable packages should NOT get vex_status annotation."""
        project = self._build_project(tmp_path)
        analyzer = self._analyzer()
        analyzer.build_import_graph(str(project))

        findings = [
            {"rule_id": "CVE-XXXX", "package": "utils", "severity": "MEDIUM"},
        ]
        result = analyzer.generate_vex(findings, str(project))
        utils_finding = next(
            (f for f in result if f.get("package") == "utils"), None
        )
        # utils IS reachable from main → should not be marked not_affected
        if utils_finding:
            assert utils_finding.get("vex_status") != "not_affected"


# ═══════════════════════════════════════════════════════════════════════════════
# File 3: RulesMarketplace
# ═══════════════════════════════════════════════════════════════════════════════

class TestRulesMarketplace:
    """Tests for integrations/rules_marketplace.py"""

    def _marketplace(self, tmp_path: Path):
        from integrations.rules_marketplace import RulesMarketplace
        return RulesMarketplace(base_dir=str(tmp_path / "rules"))

    def test_publish_and_search(self, tmp_path):
        """A published rule should be searchable."""
        mp = self._marketplace(tmp_path)
        rule_file = tmp_path / "test_rule.yaml"
        rule_file.write_text("id: test-xss\nname: XSS Detector\n", encoding="utf-8")

        entry = mp.publish(
            str(rule_file),
            {
                "id": "test-xss-001",
                "name": "XSS Detector",
                "language": "javascript",
                "category": "security",
                "severity": "HIGH",
                "author": "tythanai",
                "description": "Detects cross-site scripting vulnerabilities",
            },
        )
        assert entry.id == "test-xss-001"
        assert entry.name == "XSS Detector"

        results = mp.search("XSS")
        assert any(r.id == "test-xss-001" for r in results), (
            f"Published rule not found in search results: {results}"
        )

    def test_search_by_language(self, tmp_path):
        """Search filtered by language should return matching rules."""
        mp = self._marketplace(tmp_path)
        rule_file = tmp_path / "py_rule.yaml"
        rule_file.write_text("id: py-rule\n", encoding="utf-8")

        mp.publish(
            str(rule_file),
            {
                "id": "py-sqli-001",
                "name": "SQL Injection Python",
                "language": "python",
                "category": "injection",
                "severity": "CRITICAL",
                "author": "dev",
                "description": "Python SQL injection detector",
            },
        )

        results = mp.search("", language="python")
        assert any(r.language == "python" for r in results)

    def test_install_creates_file(self, tmp_path):
        """Installing a rule should create a file in the target directory."""
        mp = self._marketplace(tmp_path)
        rule_file = tmp_path / "install_test.yaml"
        rule_file.write_text("id: install-test\nname: Test\n", encoding="utf-8")

        entry = mp.publish(
            str(rule_file),
            {
                "id": "install-test-001",
                "name": "Install Test Rule",
                "language": "python",
                "category": "test",
                "severity": "LOW",
                "author": "tester",
                "description": "A test rule for installation",
            },
        )

        install_dir = tmp_path / "installed_rules"
        success = mp.install("install-test-001", target_dir=str(install_dir))
        assert success is True
        assert install_dir.exists()
        installed_files = list(install_dir.iterdir())
        assert len(installed_files) >= 1, "No files created in install directory"

    def test_list_installed(self, tmp_path):
        """list_installed should return all published rules."""
        mp = self._marketplace(tmp_path)
        rule_file = tmp_path / "r.yaml"
        rule_file.write_text("id: r\n", encoding="utf-8")

        mp.publish(str(rule_file), {"id": "r-001", "name": "Rule One",
                                    "description": "desc", "language": "python",
                                    "category": "test", "severity": "LOW", "author": "a"})
        mp.publish(str(rule_file), {"id": "r-002", "name": "Rule Two",
                                    "description": "desc", "language": "go",
                                    "category": "test", "severity": "MEDIUM", "author": "b"})

        listing = mp.list_installed()
        ids = {r.id for r in listing}
        assert "r-001" in ids
        assert "r-002" in ids

    def test_update_all_returns_dict(self, tmp_path):
        """update_all should return {updated: N, skipped: M}."""
        mp = self._marketplace(tmp_path)
        result = mp.update_all()
        assert "updated" in result
        assert "skipped" in result
        assert isinstance(result["updated"], int)
        assert isinstance(result["skipped"], int)

    def test_rule_entry_dataclass_fields(self, tmp_path):
        """RuleEntry should have all required fields."""
        from integrations.rules_marketplace import RuleEntry
        entry = RuleEntry(
            id="x", name="n", language="py", category="sec", severity="HIGH",
            author="a", downloads=10, rating=4.5, path="/tmp/r.yaml",
            description="d",
        )
        assert entry.id == "x"
        assert entry.rating == 4.5
        assert entry.downloads == 10


# ═══════════════════════════════════════════════════════════════════════════════
# File 4: OnboardingFlow
# ═══════════════════════════════════════════════════════════════════════════════

class TestOnboardingFlow:
    """Tests for backend/saas/onboarding.py"""

    def _flow(self, tmp_path: Path):
        from backend.saas.onboarding import OnboardingFlow
        db = tmp_path / "data" / "onboarding.db"
        return OnboardingFlow(db_path=str(db))

    def test_complete_returns_onboarding_result(self, tmp_path):
        """complete() should return an OnboardingResult."""
        from backend.saas.onboarding import OnboardingResult
        flow = self._flow(tmp_path)
        result = flow.complete(email="test@example.com", repo_url="/tmp", plan="free")
        assert isinstance(result, OnboardingResult)

    def test_complete_generates_api_key(self, tmp_path):
        """complete() should generate a non-empty api_key."""
        flow = self._flow(tmp_path)
        result = flow.complete(email="user@example.com", repo_url="/tmp")
        assert result.api_key
        assert len(result.api_key) > 10

    def test_complete_generates_account_id(self, tmp_path):
        """complete() should generate a UUID account_id."""
        flow = self._flow(tmp_path)
        result = flow.complete(email="user@example.com", repo_url="/tmp")
        assert result.account_id
        # Should be a valid UUID
        parsed = uuid.UUID(result.account_id)
        assert str(parsed) == result.account_id

    def test_complete_generates_project_id(self, tmp_path):
        """complete() should generate a UUID project_id."""
        flow = self._flow(tmp_path)
        result = flow.complete(email="user@example.com", repo_url="/tmp")
        assert result.project_id
        parsed = uuid.UUID(result.project_id)
        assert str(parsed) == result.project_id

    def test_complete_generates_session_id(self, tmp_path):
        """complete() should generate a session_id."""
        flow = self._flow(tmp_path)
        result = flow.complete(email="user@example.com", repo_url="/tmp")
        assert result.session_id
        assert len(result.session_id) > 0

    def test_get_status_returns_session(self, tmp_path):
        """get_status() should return session data for a valid session_id."""
        flow = self._flow(tmp_path)
        result = flow.complete(email="status@example.com", repo_url="/tmp", plan="developer")
        status = flow.get_status(result.session_id)
        assert status["session_id"] == result.session_id
        assert status["account_id"] == result.account_id
        assert status["plan"] == "developer"
        assert status["email"] == "status@example.com"

    def test_get_status_missing_session(self, tmp_path):
        """get_status() with unknown session_id should return an error dict."""
        flow = self._flow(tmp_path)
        status = flow.get_status("nonexistent-session-id")
        assert "error" in status

    def test_scan_summary_is_dict(self, tmp_path):
        """scan_summary in OnboardingResult should be a dict."""
        flow = self._flow(tmp_path)
        result = flow.complete(email="scan@example.com", repo_url="/nonexistent_repo")
        assert isinstance(result.scan_summary, dict)

    def test_welcome_email_no_smtp_doesnt_raise(self, tmp_path):
        """If SMTP is not configured, complete() should succeed without raising."""
        env = {k: v for k, v in os.environ.items() if k not in ("SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASS")}
        with patch.dict(os.environ, env, clear=True):
            flow = self._flow(tmp_path)
            result = flow.complete(email="no_smtp@example.com", repo_url="/tmp")
        assert result.api_key  # Should still succeed


# ═══════════════════════════════════════════════════════════════════════════════
# File 5: WebhookManager
# ═══════════════════════════════════════════════════════════════════════════════

class _MockWebhookHandler(BaseHTTPRequestHandler):
    """Minimal HTTP handler that records requests and returns 200."""

    received: List[Dict] = []

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        _MockWebhookHandler.received.append({
            "path": self.path,
            "headers": dict(self.headers),
            "body": body,
        })
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"OK")

    def log_message(self, *args):  # suppress output
        pass


@pytest.fixture()
def mock_http_server():
    """Spin up a local HTTP server on a random port; yield its URL; then shut down."""
    _MockWebhookHandler.received = []
    server = HTTPServer(("127.0.0.1", 0), _MockWebhookHandler)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}/webhook", _MockWebhookHandler
    server.shutdown()


class TestWebhookManager:
    """Tests for backend/saas/webhook_manager.py"""

    def _manager(self, tmp_path: Path):
        from backend.saas.webhook_manager import WebhookManager
        db = tmp_path / "data" / "webhooks.db"
        return WebhookManager(db_path=str(db))

    def test_register_returns_dict(self, tmp_path):
        """register() should return a webhook dict with an id."""
        mgr = self._manager(tmp_path)
        result = mgr.register(
            account_id="acc-1",
            url="https://example.com/hook",
            events=["scan.completed"],
        )
        assert "id" in result
        assert result["url"] == "https://example.com/hook"
        assert result["events"] == ["scan.completed"]

    def test_list_webhooks_shows_registered(self, tmp_path):
        """After registration, list_webhooks() should show the webhook."""
        mgr = self._manager(tmp_path)
        mgr.register(
            account_id="acc-list",
            url="https://example.com/hook1",
            events=["scan.completed", "finding.critical"],
        )
        listing = mgr.list_webhooks("acc-list")
        assert len(listing) >= 1
        assert any(w["url"] == "https://example.com/hook1" for w in listing)

    def test_delete_webhook(self, tmp_path):
        """Deleted webhooks should be inactive."""
        mgr = self._manager(tmp_path)
        reg = mgr.register(
            account_id="acc-del",
            url="https://example.com/hook",
            events=["scan.completed"],
        )
        result = mgr.delete_webhook(reg["id"])
        assert result is True
        listing = mgr.list_webhooks("acc-del")
        active = [w for w in listing if w["active"]]
        assert all(w["id"] != reg["id"] for w in active)

    def test_dispatch_delivers_to_mock_server(self, tmp_path, mock_http_server):
        """dispatch() should POST to the registered URL."""
        url, handler_cls = mock_http_server
        mgr = self._manager(tmp_path)
        mgr.register(
            account_id="acc-dispatch",
            url=url,
            events=["scan.completed"],
            secret=None,
        )
        result = mgr.dispatch(
            event_type="scan.completed",
            payload={"project": "myapp", "findings": 3},
            account_id="acc-dispatch",
        )
        # Give the server a moment to process
        time.sleep(0.2)
        assert result["delivered"] >= 1
        assert result["failed"] == 0

    def test_dispatch_hmac_signature_header(self, tmp_path, mock_http_server):
        """When a secret is set, dispatched requests should carry HMAC signature."""
        url, handler_cls = mock_http_server
        mgr = self._manager(tmp_path)
        secret = "super_secret_key"
        mgr.register(
            account_id="acc-hmac",
            url=url,
            events=["finding.critical"],
            secret=secret,
        )
        handler_cls.received = []
        mgr.dispatch(
            event_type="finding.critical",
            payload={"cve": "CVE-2024-9999"},
            account_id="acc-hmac",
        )
        time.sleep(0.3)
        assert len(handler_cls.received) >= 1
        req = handler_cls.received[-1]
        headers = {k.lower(): v for k, v in req["headers"].items()}
        sig_header = headers.get("x-tythanai-signature", "")
        assert sig_header.startswith("sha256="), (
            f"Missing or wrong signature header: {sig_header}"
        )
        # Verify HMAC is correct
        body = req["body"]
        expected_sig = "sha256=" + hmac.new(
            secret.encode(), body, hashlib.sha256
        ).hexdigest()
        assert sig_header == expected_sig

    def test_delivery_log_recorded(self, tmp_path, mock_http_server):
        """After dispatch, get_delivery_log() should return at least one entry."""
        url, _ = mock_http_server
        mgr = self._manager(tmp_path)
        reg = mgr.register(
            account_id="acc-log",
            url=url,
            events=["regression.detected"],
        )
        mgr.dispatch(
            event_type="regression.detected",
            payload={"file": "app.py"},
            account_id="acc-log",
        )
        time.sleep(0.2)
        log = mgr.get_delivery_log(reg["id"], limit=10)
        assert len(log) >= 1
        assert "event_type" in log[0]
        assert "status_code" in log[0]

    def test_dispatch_to_unknown_account_returns_zero(self, tmp_path):
        """dispatch() to an account with no webhooks should return 0 delivered."""
        mgr = self._manager(tmp_path)
        result = mgr.dispatch(
            event_type="scan.completed",
            payload={},
            account_id="no-such-account",
        )
        assert result["delivered"] == 0
        assert result["failed"] == 0


# ═══════════════════════════════════════════════════════════════════════════════
# File 6: UsageDashboard
# ═══════════════════════════════════════════════════════════════════════════════

class TestUsageDashboard:
    """Tests for backend/saas/usage_dashboard.py"""

    def _dashboard(self, tmp_path: Path):
        from backend.saas.usage_dashboard import UsageDashboard
        from cloud.billing.usage_tracker import UsageTracker

        db = tmp_path / "usage.db"
        tracker = UsageTracker(db_path=str(db))
        onboarding_db = tmp_path / "data" / "onboarding.db"
        return UsageDashboard(usage_tracker=tracker, onboarding_db=str(onboarding_db))

    def test_get_account_stats_returns_expected_keys(self, tmp_path):
        """get_account_stats() should return a dict with required keys."""
        dashboard = self._dashboard(tmp_path)
        stats = dashboard.get_account_stats("test-account-123")
        assert "scans_this_month" in stats
        assert "findings_by_severity" in stats
        assert "trend" in stats
        assert "top5_risky_files" in stats

    def test_get_account_stats_scans_is_int(self, tmp_path):
        """scans_this_month should be a non-negative integer."""
        dashboard = self._dashboard(tmp_path)
        stats = dashboard.get_account_stats("acc-zero")
        assert isinstance(stats["scans_this_month"], int)
        assert stats["scans_this_month"] >= 0

    def test_get_account_stats_trend_valid(self, tmp_path):
        """trend should be one of up/down/stable."""
        dashboard = self._dashboard(tmp_path)
        stats = dashboard.get_account_stats("acc-trend")
        assert stats["trend"] in ("up", "down", "stable")

    def test_get_account_stats_findings_by_severity(self, tmp_path):
        """findings_by_severity should have standard severity keys."""
        dashboard = self._dashboard(tmp_path)
        stats = dashboard.get_account_stats("acc-sev")
        sev = stats["findings_by_severity"]
        for key in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
            assert key in sev, f"Missing severity key: {key}"

    def test_get_billing_summary_returns_expected_keys(self, tmp_path):
        """get_billing_summary() should return required billing keys."""
        dashboard = self._dashboard(tmp_path)
        summary = dashboard.get_billing_summary("acc-billing")
        assert "current_plan" in summary
        assert "usage_pct" in summary
        assert "next_payment_date" in summary

    def test_get_billing_summary_usage_pct_range(self, tmp_path):
        """usage_pct should be between 0 and 100."""
        dashboard = self._dashboard(tmp_path)
        summary = dashboard.get_billing_summary("acc-pct")
        assert 0.0 <= summary["usage_pct"] <= 100.0

    def test_get_team_activity_returns_list(self, tmp_path):
        """get_team_activity() should return a list."""
        dashboard = self._dashboard(tmp_path)
        activity = dashboard.get_team_activity("acc-activity", limit=5)
        assert isinstance(activity, list)

    def test_get_team_activity_respects_limit(self, tmp_path):
        """get_team_activity() should not return more items than limit."""
        dashboard = self._dashboard(tmp_path)
        activity = dashboard.get_team_activity("acc-limit", limit=3)
        assert len(activity) <= 3

    def test_usage_dashboard_imports_plans_correctly(self, tmp_path):
        """UsageDashboard should correctly import PLANS and use them."""
        from cloud.billing.plan_enforcer import PLANS
        assert "free" in PLANS
        assert "enterprise" in PLANS
        dashboard = self._dashboard(tmp_path)
        # Free plan should have scans_per_month set
        summary = dashboard.get_billing_summary("acc-plans")
        assert summary["current_plan"] in PLANS or summary["current_plan"] == "free"
