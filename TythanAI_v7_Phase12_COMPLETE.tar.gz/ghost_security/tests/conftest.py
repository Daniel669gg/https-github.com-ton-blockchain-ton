"""
tests/conftest.py — shared fixtures and helpers for TythanAI test suite.

Provides InMemoryDatabase: a Database subclass that keeps a single
persistent SQLite connection so that schema created in one call is
visible in subsequent calls (the default :memory: would give a fresh
blank database for every sqlite3.connect() call).
"""
from __future__ import annotations

import itertools
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

from backend.core.db import Database

_counter = itertools.count(1)


class InMemoryDatabase(Database):
    """Database backed by a single, persistent in-memory SQLite connection.

    All calls to get_conn() share the same underlying connection, so tables
    created during init_schema() are visible in subsequent operations.

    Each instance gets a unique named shared-cache URI so that separate
    test fixtures don't bleed into each other.
    """

    def __init__(self) -> None:
        # Bypass parent __init__ — no filesystem path needed
        self.db_path = Path(":memory:")
        # Unique name per instance prevents cross-test contamination
        name = f"testdb_{next(_counter)}"
        uri = f"file:{name}?mode=memory&cache=shared"
        self._conn: sqlite3.Connection = sqlite3.connect(
            uri,
            check_same_thread=False,
            uri=True,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=MEMORY")
        self._conn.execute("PRAGMA foreign_keys=ON")

    @contextmanager
    def get_conn(self) -> Generator[sqlite3.Connection, None, None]:
        """Yield the shared persistent connection; do not close it."""
        try:
            yield self._conn
        except Exception:
            try:
                self._conn.rollback()
            except Exception:
                pass
            raise

    def close(self) -> None:
        """Explicitly close the shared connection."""
        try:
            self._conn.close()
        except Exception:
            pass
