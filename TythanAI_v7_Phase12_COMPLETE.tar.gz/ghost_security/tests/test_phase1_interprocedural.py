"""
tests/test_phase1_interprocedural.py — Tests for Interprocedural Dataflow (Phase 1, Part 3).
15 tests: multi-hop taint, cross-module taint, sanitization on path, result types.
"""
import sys
import pathlib

_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pytest
from backend.core.cpg.builder import CPGBuilder
from backend.core.cpg.interprocedural import (
    InterproceduralDataflow, InterproceduralTaintPath,
    InterproceduralAnalysisResult, TaintHop,
)


SQLI_CODE = """
from flask import request
import sqlite3

def get_user(db):
    uid = request.args.get('id')
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE id = " + uid)
    return cursor.fetchone()
"""

MULTIHOP_CODE = """
from flask import request

def get_param():
    return request.args.get('q')

def build_query(param):
    return "SELECT * FROM t WHERE val=" + param

def run_query(db):
    p = get_param()
    q = build_query(p)
    db.cursor().execute(q)
"""

SAFE_CODE = """
from flask import request
import sqlite3
def get_user(db):
    uid = request.args.get('id')
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE id=%s", (uid,))
    return cursor.fetchone()
"""

CMDI_CODE = """
from flask import request
import os
def run_cmd():
    cmd = request.args.get('cmd')
    os.system(cmd)
"""


@pytest.fixture
def builder():
    return CPGBuilder()


class TestInterproceduralDataflow:
    def test_analyze_returns_result(self, builder):
        """analyze() must return an InterproceduralAnalysisResult."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        result = ida.analyze()
        assert isinstance(result, InterproceduralAnalysisResult)

    def test_result_has_taint_paths_list(self, builder):
        """result.taint_paths must be a list."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        result = ida.analyze()
        assert isinstance(result.taint_paths, list)

    def test_result_has_by_cwe(self, builder):
        """result.by_cwe must be a dict."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        result = ida.analyze()
        assert isinstance(result.by_cwe, dict)

    def test_result_has_duration(self, builder):
        """result.analysis_duration_ms must be a non-negative float."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        result = ida.analyze()
        assert isinstance(result.analysis_duration_ms, float)
        assert result.analysis_duration_ms >= 0.0

    def test_find_paths_for_cwe89(self, builder):
        """find_paths_for_cwe('CWE-89') must return a list."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        paths = ida.find_paths_for_cwe("CWE-89")
        assert isinstance(paths, list)
        for p in paths:
            assert isinstance(p, InterproceduralTaintPath)

    def test_find_paths_for_cwe78(self, builder):
        """find_paths_for_cwe('CWE-78') must return list for CMDi code."""
        cpg = builder.build_source(CMDI_CODE, file_path="/tmp/cmdi.py")
        ida = InterproceduralDataflow(cpg)
        paths = ida.find_paths_for_cwe("CWE-78")
        assert isinstance(paths, list)

    def test_taint_path_has_hops(self, builder):
        """Each InterproceduralTaintPath must have a hops list."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        paths = ida.find_paths_for_cwe("CWE-89")
        for path in paths:
            assert isinstance(path.hops, list)
            assert len(path.hops) >= 2  # at least source + sink

    def test_taint_path_confidence_range(self, builder):
        """total_confidence must be in [0.0, 1.0]."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        paths = ida.find_paths_for_cwe("CWE-89")
        for path in paths:
            assert 0.0 <= path.total_confidence <= 1.0

    def test_taint_path_source_sink_ids(self, builder):
        """path must have non-empty source_node_id and sink_node_id."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        paths = ida.find_paths_for_cwe("CWE-89")
        for path in paths:
            assert isinstance(path.source_node_id, str)
            assert isinstance(path.sink_node_id, str)

    def test_sanitized_path_detected(self, builder):
        """Paths through parameterized query should be marked is_sanitized_on_path=True."""
        cpg = builder.build_source(SAFE_CODE, file_path="/tmp/safe.py")
        ida = InterproceduralDataflow(cpg)
        paths = ida.find_paths_for_cwe("CWE-89")
        # If any paths found, at least some should be sanitized
        sanitized = [p for p in paths if p.is_sanitized_on_path]
        # Safe code: either no paths or all paths sanitized
        for p in paths:
            if p.is_sanitized_on_path:
                assert len(p.sanitizers_found) >= 1

    def test_propagation_evidence_non_empty(self, builder):
        """propagation_evidence must be a non-empty string."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        paths = ida.find_paths_for_cwe("CWE-89")
        for path in paths:
            assert isinstance(path.propagation_evidence, str)
            assert len(path.propagation_evidence) > 0

    def test_trace_from_node(self, builder):
        """trace_from_node() must return a list of paths."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        sources = ida._find_source_nodes("CWE-89")
        if sources:
            result = ida.trace_from_node(sources[0], "CWE-89")
            assert isinstance(result, list)

    def test_unknown_cwe_returns_empty(self, builder):
        """find_paths_for_cwe with unknown CWE must return empty list."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        paths = ida.find_paths_for_cwe("CWE-9999")
        assert paths == []

    def test_high_confidence_paths_subset(self, builder):
        """high_confidence_paths must be a subset of all taint_paths."""
        cpg = builder.build_source(MULTIHOP_CODE, file_path="/tmp/multi.py")
        ida = InterproceduralDataflow(cpg)
        result = ida.analyze()
        all_ids = {p.path_id for p in result.taint_paths}
        hc_ids = {p.path_id for p in result.high_confidence_paths}
        assert hc_ids.issubset(all_ids)

    def test_cross_function_count_correct(self, builder):
        """cross_function_count must equal the number of CG_CALL hops."""
        cpg = builder.build_source(SQLI_CODE, file_path="/tmp/test.py")
        ida = InterproceduralDataflow(cpg)
        paths = ida.find_paths_for_cwe("CWE-89")
        for path in paths:
            call_hops = sum(1 for h in path.hops if h.hop_type in ("call_arg", "return_value"))
            assert path.cross_function_count == call_hops
