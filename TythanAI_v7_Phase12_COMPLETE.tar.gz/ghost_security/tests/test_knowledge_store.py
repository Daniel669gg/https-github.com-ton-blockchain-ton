"""
Tests for the Security Knowledge Base (KnowledgeStore, BuiltInData, ResearchPipeline).
25 tests.
"""
import sys
import pathlib

_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pytest

from backend.core.knowledge import (
    KnowledgeStore, ResearchPipeline, PipelineResult, SynthesizedRule,
    VulnerabilityKnowledge, CWEEntry, CVEEntry, ExploitPattern,
)
from backend.core.knowledge.built_in_data import (
    BUILT_IN_KNOWLEDGE, CWE_ENTRIES, CVE_ENTRIES, EXPLOIT_PATTERNS, FIX_PATTERNS,
)


class TestBuiltInData:
    def test_built_in_has_all_owasp_top10_cwes(self):
        required = {"CWE-89", "CWE-79", "CWE-78", "CWE-22", "CWE-798", "CWE-918", "CWE-327", "CWE-502"}
        assert required.issubset(set(CWE_ENTRIES.keys()))

    def test_cwe_entries_have_mitigations(self):
        for cwe_id, entry in CWE_ENTRIES.items():
            assert len(entry.mitigations) >= 1, f"{cwe_id} has no mitigations"

    def test_exploit_patterns_have_payloads(self):
        for pid, ep in EXPLOIT_PATTERNS.items():
            assert len(ep.payload_examples) >= 1, f"{pid} has no payloads"

    def test_fix_patterns_have_before_after(self):
        for pid, fp in FIX_PATTERNS.items():
            assert len(fp.before_code) > 0, f"{pid} missing before_code"
            assert len(fp.after_code) > 0, f"{pid} missing after_code"

    def test_cve_entries_non_empty(self):
        assert len(CVE_ENTRIES) >= 5

    def test_kev_cves_present(self):
        kev_count = sum(1 for c in CVE_ENTRIES if c.is_kev)
        assert kev_count >= 3

    def test_built_in_knowledge_covers_sqli(self):
        assert "VULN-SQLI" in BUILT_IN_KNOWLEDGE

    def test_sqli_knowledge_has_exploit_patterns(self):
        sqli = BUILT_IN_KNOWLEDGE["VULN-SQLI"]
        assert len(sqli.exploit_patterns) >= 1

    def test_sqli_knowledge_has_fix_patterns(self):
        sqli = BUILT_IN_KNOWLEDGE["VULN-SQLI"]
        assert len(sqli.fix_patterns) >= 1


class TestKnowledgeStore:
    def test_store_seeds_built_in(self):
        store = KnowledgeStore()
        assert len(store) >= 8

    def test_get_by_cwe_sqli(self):
        store = KnowledgeStore()
        entries = store.get_by_cwe("CWE-89")
        assert len(entries) >= 1
        assert all(isinstance(e, VulnerabilityKnowledge) for e in entries)

    def test_get_by_owasp_a03(self):
        store = KnowledgeStore()
        entries = store.get_by_owasp("A03:2021")
        assert len(entries) >= 1

    def test_get_exploit_patterns_for_cwe89(self):
        store = KnowledgeStore()
        patterns = store.get_exploit_patterns("CWE-89")
        assert len(patterns) >= 1
        assert all(isinstance(p, ExploitPattern) for p in patterns)

    def test_get_fix_patterns_for_cwe89(self):
        store = KnowledgeStore()
        fixes = store.get_fix_patterns("CWE-89")
        assert len(fixes) >= 1

    def test_search_sqli(self):
        store = KnowledgeStore()
        results = store.search("sql injection")
        cwe_ids = [r.cwe.cwe_id for r in results]
        assert "CWE-89" in cwe_ids

    def test_search_cwe_id_exact(self):
        store = KnowledgeStore()
        results = store.search("CWE-79")
        assert len(results) >= 1
        assert results[0].cwe.cwe_id == "CWE-79"

    def test_get_high_risk(self):
        store = KnowledgeStore()
        high = store.get_high_risk(80.0)
        assert len(high) >= 1
        for entry in high:
            assert entry.risk_score >= 80.0

    def test_get_kev_cves(self):
        store = KnowledgeStore()
        kevs = store.get_kev_cves()
        assert len(kevs) >= 3

    def test_add_custom_entry(self):
        store = KnowledgeStore()
        new_entry = VulnerabilityKnowledge(
            knowledge_id="CUSTOM-TEST-CWE400",
            cwe=CWEEntry(
                cwe_id="CWE-400",
                name="Uncontrolled Resource Consumption",
                description="Resource exhaustion",
                extended_description="",
                detection_methods=[],
                mitigations=["rate limiting"],
                capec_ids=[],
                related_cwes=[],
                owasp_categories=["A05:2021"],
                severity_typical="MEDIUM",
                exploit_patterns=[],
                fix_patterns=[],
            ),
            related_cves=[],
            capecs=[],
            exploit_patterns=[],
            fix_patterns=[],
            similar_cwe_ids=[],
            owasp_category="A05:2021",
            risk_score=45.0,
        )
        store.add(new_entry)
        assert store.get("CUSTOM-TEST-CWE400") is not None
        assert len(store.get_by_cwe("CWE-400")) >= 1

    def test_remove_entry(self):
        store = KnowledgeStore()
        initial_len = len(store)
        result = store.remove("VULN-SQLI")
        assert result is True
        assert len(store) == initial_len - 1
        assert store.get("VULN-SQLI") is None

    def test_stats(self):
        store = KnowledgeStore()
        s = store.stats()
        assert "total_knowledge_entries" in s
        assert "total_cve_entries" in s
        assert s["total_knowledge_entries"] >= 8


class TestResearchPipeline:
    def test_process_sqli_cve(self):
        pipeline = ResearchPipeline()
        result = pipeline.process_cve(
            cve_id="CVE-2022-99999",
            description="SQL injection vulnerability in the login form: user input is concatenated directly into the SQL query via cursor.execute. An attacker can extract all user credentials.",
            cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
            cwe_ids=["CWE-89"],
        )
        assert isinstance(result, PipelineResult)
        assert result.cve_id == "CVE-2022-99999"

    def test_pipeline_synthesizes_rules(self):
        pipeline = ResearchPipeline()
        result = pipeline.process_cve(
            cve_id="CVE-2022-88888",
            description="OS command injection via user-supplied filename passed to os.system(). An attacker can inject shell metacharacters.",
            cwe_ids=["CWE-78"],
        )
        assert len(result.rules) >= 1
        for rule in result.rules:
            assert isinstance(rule, SynthesizedRule)
            assert len(rule.sink_patterns) >= 1

    def test_pipeline_validation_passes_for_clean_rules(self):
        pipeline = ResearchPipeline()
        result = pipeline.process_cve(
            cve_id="CVE-2022-77777",
            description="XSS via unescaped user input in HTML response. An attacker injects script tags.",
            cwe_ids=["CWE-79"],
        )
        for rule in result.rules:
            assert rule.validation_fp == 0, f"Rule {rule.rule_id} has FPs: {rule.validation_fp}"

    def test_pipeline_batch_processing(self):
        pipeline = ResearchPipeline()
        batch = [
            {"cve_id": "CVE-2023-10001", "description": "SQL injection via login", "cwe_ids": ["CWE-89"]},
            {"cve_id": "CVE-2023-10002", "description": "Path traversal via filename parameter", "cwe_ids": ["CWE-22"]},
        ]
        results = pipeline.process_batch(batch)
        assert len(results) == 2
        assert all(isinstance(r, PipelineResult) for r in results)
