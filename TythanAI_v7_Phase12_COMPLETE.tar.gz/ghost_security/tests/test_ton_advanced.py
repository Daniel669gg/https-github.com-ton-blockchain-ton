"""
Advanced tests for TON smart contract analysis.
25 tests covering TVMStateExplorer, CrossContractAnalyzer, FormalVerifier, and OwnershipChecker.
"""
import sys
import pathlib

_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pytest

from scanners.ton_scanner.tvm_state import TVMStateExplorer, TVMExecutionState
from scanners.ton_scanner.cross_contract import (
    CrossContractAnalyzer,
    ContractInterface,
    CrossContractResult,
)
from scanners.ton_scanner.formal_verifier import FormalVerifier, FormalVerificationResult
from scanners.ton_scanner.ownership_checker import OwnershipChecker, OwnershipFinding

# ---------------------------------------------------------------------------
# Contract snippets
# ---------------------------------------------------------------------------

VULN_FUNC_CONTRACT = """;; Vulnerable FunC contract - missing auth on state write
() recv_internal(int msg_value, cell in_msg_full, slice in_msg_body) impure {
    slice cs = in_msg_full.begin_parse();
    int flags = cs~load_uint(4);
    if (flags & 1) { return (); }
    slice sender_address = cs~load_msg_addr();
    int op = in_msg_body~load_uint(32);

    if (op == 0x11223344) {
        ;; VULNERABLE: No auth check - anyone can update owner
        slice new_owner = in_msg_body~load_msg_addr();
        set_data(begin_cell()
            .store_slice(new_owner)
        .end_cell());
    }

    if (op == 0x55667788) {
        ;; VULNERABLE: Send before state update (reentrancy risk)
        int amount = in_msg_body~load_coins();
        send_raw_message(begin_cell()
            .store_uint(0x18, 6)
            .store_slice(sender_address)
            .store_coins(amount)
        .end_cell(), 64);
        set_data(begin_cell().store_uint(0, 64).end_cell());
    }
}
"""

VULN_TACT_CONTRACT = """
contract VulnerableWallet {
    owner: Address;
    balance: Int as coins = 0;

    receive("transfer") {
        // VULNERABLE: no sender check
        self.owner = sender();
    }

    receive("withdraw") {
        // VULNERABLE: can underflow
        let amount: Int = context().value;
        self.balance = self.balance - amount;
        send(SendParameters{to: sender(), value: amount, bounce: false});
    }
}
"""

SAFE_FUNC_CONTRACT = """;; Safe FunC contract with proper auth
() recv_internal(int msg_value, cell in_msg_full, slice in_msg_body) impure {
    slice cs = in_msg_full.begin_parse();
    int flags = cs~load_uint(4);
    if (flags & 1) { return (); }
    slice sender_address = cs~load_msg_addr();
    int op = in_msg_body~load_uint(32);

    slice stored_owner = get_owner();

    if (op == 0x11223344) {
        throw_unless(401, equal_slices(sender_address, stored_owner));
        slice new_owner = in_msg_body~load_msg_addr();
        set_data(begin_cell().store_slice(new_owner).end_cell());
    }
}
"""

RECV_EXTERNAL_NO_CHECK = """;; Missing signature check in recv_external
() recv_external(slice in_msg) impure {
    accept_message();
    int op = in_msg~load_uint(32);
    if (op == 1) {
        set_data(begin_cell().store_uint(0, 64).end_cell());
    }
}
"""


# ---------------------------------------------------------------------------
# TestTVMStateExplorer
# ---------------------------------------------------------------------------

class TestTVMStateExplorer:
    def test_detects_unauth_storage_write(self):
        """VULN_FUNC_CONTRACT must trigger at least one TVM finding (any type)."""
        explorer = TVMStateExplorer(VULN_FUNC_CONTRACT, language="func")
        findings = explorer.get_findings()
        assert isinstance(findings, list)
        # Contract has send_raw_message without bounce flag → BOUNCE_UNHANDLED at minimum
        assert len(findings) >= 1
        # Verify finding structure is valid
        for f in findings:
            assert "severity" in f
            assert "description" in f

    def test_detects_reentrancy_pattern(self):
        """VULN_FUNC_CONTRACT findings must include a bounce/reentrancy related warning."""
        explorer = TVMStateExplorer(VULN_FUNC_CONTRACT, language="func")
        findings = explorer.get_findings()
        # The contract has send_raw_message before set_data (reentrancy) and no bounce check
        bounce_or_reentrant = [
            f for f in findings
            if "BOUNCE" in f.get("rule_id", "")
            or "reentr" in f.get("description", "").lower()
            or "bounce" in f.get("description", "").lower()
        ]
        assert len(bounce_or_reentrant) >= 1

    def test_safe_contract_no_critical(self):
        """SAFE_FUNC_CONTRACT must not produce CRITICAL severity findings."""
        explorer = TVMStateExplorer(SAFE_FUNC_CONTRACT, language="func")
        findings = explorer.get_findings()
        critical_findings = [
            f for f in findings
            if f.get("severity") == "CRITICAL"
        ]
        assert len(critical_findings) == 0

    def test_explorer_returns_states(self):
        """explore() must return a list (possibly empty or populated) of TVMExecutionState objects."""
        explorer = TVMStateExplorer(VULN_FUNC_CONTRACT, language="func")
        states = explorer.explore()
        assert isinstance(states, list)
        for state in states:
            assert isinstance(state, TVMExecutionState)

    def test_tact_analysis_works(self):
        """TVMStateExplorer must handle Tact syntax without raising an exception."""
        explorer = TVMStateExplorer(VULN_TACT_CONTRACT, language="tact")
        # Must not crash
        states = explorer.explore()
        assert isinstance(states, list)

    def test_findings_have_severity(self):
        """All findings returned by get_findings() must have a severity field."""
        explorer = TVMStateExplorer(VULN_FUNC_CONTRACT, language="func")
        findings = explorer.get_findings()
        for finding in findings:
            assert "severity" in finding, f"Missing severity in finding: {finding}"
            assert finding["severity"] in {"CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"}


# ---------------------------------------------------------------------------
# TestCrossContractAnalyzer
# ---------------------------------------------------------------------------

class TestCrossContractAnalyzer:
    def test_builds_interface_from_func(self):
        """_build_interface() must return a ContractInterface."""
        analyzer = CrossContractAnalyzer()
        interface = analyzer._build_interface(VULN_FUNC_CONTRACT, "vuln.fc")
        assert isinstance(interface, ContractInterface)

    def test_interface_has_handlers(self):
        """ContractInterface must have a receive_handlers list (possibly empty)."""
        analyzer = CrossContractAnalyzer()
        interface = analyzer._build_interface(VULN_FUNC_CONTRACT, "vuln.fc")
        assert isinstance(interface.receive_handlers, list)

    def test_detects_ownership_takeover(self):
        """VULN_FUNC_CONTRACT must produce at least one ownership_takeover_paths entry."""
        analyzer = CrossContractAnalyzer()
        result = analyzer.analyze_contracts(
            [(VULN_FUNC_CONTRACT, "vuln.fc"), (SAFE_FUNC_CONTRACT, "safe.fc")]
        )
        assert isinstance(result, CrossContractResult)
        # Either in ownership_takeover_paths or all_findings with matching type
        takeover_findings = (
            result.ownership_takeover_paths
            + [f for f in result.all_findings if "owner" in str(f).lower() or "takeover" in str(f).lower()]
        )
        assert len(takeover_findings) >= 1

    def test_analyze_multiple_contracts(self):
        """analyze_contracts() with 2 contracts must return a CrossContractResult."""
        analyzer = CrossContractAnalyzer()
        result = analyzer.analyze_contracts(
            [(VULN_FUNC_CONTRACT, "a.fc"), (SAFE_FUNC_CONTRACT, "b.fc")]
        )
        assert isinstance(result, CrossContractResult)

    def test_result_has_contract_count(self):
        """contracts_analyzed must be > 0 when contracts were provided."""
        analyzer = CrossContractAnalyzer()
        result = analyzer.analyze_contracts(
            [(VULN_FUNC_CONTRACT, "vuln.fc"), (SAFE_FUNC_CONTRACT, "safe.fc")]
        )
        assert result.contracts_analyzed > 0

    def test_result_has_findings(self):
        """all_findings attribute of CrossContractResult must be a list."""
        analyzer = CrossContractAnalyzer()
        result = analyzer.analyze_contracts([(VULN_FUNC_CONTRACT, "vuln.fc")])
        assert isinstance(result.all_findings, list)

    def test_language_detection(self):
        """.fc files must be detected as 'func', .tact files as 'tact'."""
        analyzer = CrossContractAnalyzer()
        func_interface = analyzer._build_interface(VULN_FUNC_CONTRACT, "contract.fc")
        tact_interface = analyzer._build_interface(VULN_TACT_CONTRACT, "wallet.tact")
        assert func_interface.language == "func"
        assert tact_interface.language == "tact"


# ---------------------------------------------------------------------------
# TestFormalVerifier
# ---------------------------------------------------------------------------

class TestFormalVerifier:
    def test_verify_returns_result(self):
        """verify_contract() must return a FormalVerificationResult."""
        verifier = FormalVerifier()
        result = verifier.verify_contract(VULN_FUNC_CONTRACT, language="func")
        assert isinstance(result, FormalVerificationResult)

    def test_catches_ownership_violation(self):
        """VULN_FUNC_CONTRACT must produce at least one invariant violation."""
        verifier = FormalVerifier()
        result = verifier.verify_contract(VULN_FUNC_CONTRACT, language="func")
        assert isinstance(result.violations, list)
        assert len(result.violations) >= 1

    def test_safe_contract_fewer_violations(self):
        """SAFE_FUNC_CONTRACT must have fewer violations than VULN_FUNC_CONTRACT."""
        verifier = FormalVerifier()
        vuln_result = verifier.verify_contract(VULN_FUNC_CONTRACT, language="func")
        safe_result = verifier.verify_contract(SAFE_FUNC_CONTRACT, language="func")
        assert len(safe_result.violations) < len(vuln_result.violations)

    def test_confidence_in_range(self):
        """FormalVerificationResult.confidence must be in [0.0, 1.0]."""
        verifier = FormalVerifier()
        result = verifier.verify_contract(VULN_FUNC_CONTRACT, language="func")
        assert 0.0 <= result.confidence <= 1.0

    def test_paths_explored_positive(self):
        """paths_explored must be >= 1."""
        verifier = FormalVerifier()
        result = verifier.verify_contract(VULN_FUNC_CONTRACT, language="func")
        assert result.paths_explored >= 1

    def test_invariants_checked_positive(self):
        """invariants_checked must be >= 1."""
        verifier = FormalVerifier()
        result = verifier.verify_contract(VULN_FUNC_CONTRACT, language="func")
        assert result.invariants_checked >= 1


# ---------------------------------------------------------------------------
# TestOwnershipChecker
# ---------------------------------------------------------------------------

class TestOwnershipChecker:
    def test_detects_missing_auth(self):
        """VULN_FUNC_CONTRACT must produce at least one missing-auth finding."""
        checker = OwnershipChecker()
        findings = checker.check(VULN_FUNC_CONTRACT, language="func")
        assert isinstance(findings, list)
        assert len(findings) >= 1

    def test_detects_missing_sig_check(self):
        """recv_external without check_signature must produce a finding."""
        checker = OwnershipChecker()
        findings = checker.check(RECV_EXTERNAL_NO_CHECK, language="func")
        sig_findings = [
            f for f in findings
            if "sig" in f.finding_type.lower()
            or "sig" in f.description.lower()
            or "MISSING_SIG" in f.finding_type
        ]
        assert len(sig_findings) >= 1

    def test_safe_contract_no_missing_auth(self):
        """SAFE_FUNC_CONTRACT must produce no MISSING_AUTH / CRITICAL findings."""
        checker = OwnershipChecker()
        findings = checker.check(SAFE_FUNC_CONTRACT, language="func")
        missing_auth = [
            f for f in findings
            if "MISSING_AUTH" in f.finding_type or f.severity == "CRITICAL"
        ]
        assert len(missing_auth) == 0

    def test_findings_have_cwe(self):
        """Every OwnershipFinding from VULN_FUNC_CONTRACT must have a non-empty cwe_id."""
        checker = OwnershipChecker()
        findings = checker.check(VULN_FUNC_CONTRACT, language="func")
        for finding in findings:
            assert isinstance(finding, OwnershipFinding)
            assert finding.cwe_id, f"Finding {finding.finding_type} has empty cwe_id"

    def test_findings_have_recommendation(self):
        """Every OwnershipFinding must have a non-empty recommendation."""
        checker = OwnershipChecker()
        findings = checker.check(VULN_FUNC_CONTRACT, language="func")
        for finding in findings:
            assert isinstance(finding.recommendation, str)
            assert len(finding.recommendation) > 0

    def test_check_tact_contract(self):
        """OwnershipChecker must handle Tact contract without crashing and return a list."""
        checker = OwnershipChecker()
        # Must not raise exceptions on Tact input
        findings = checker.check(VULN_TACT_CONTRACT, language="tact")
        assert isinstance(findings, list)
        # Any findings returned must be valid OwnershipFinding objects
        for f in findings:
            assert isinstance(f, OwnershipFinding)
