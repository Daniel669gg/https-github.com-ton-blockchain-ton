#!/usr/bin/env python3
"""
TythanAI — Rules Expander
Generates new YAML security rules and saves them to rules/ subdirectories.
Run: python scripts/rules_expander.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent
RULES_DIR = ROOT / "rules"

# ─── Rule template ────────────────────────────────────────────────────────────

def rule(id_, name, desc, severity, cwe, owasp, langs, patterns,
         fix="", tags=None, confidence=0.88):
    entry = {
        "id": id_, "name": name, "description": desc,
        "severity": severity, "cwe": cwe, "owasp": owasp,
        "languages": langs, "confidence": confidence,
        "patterns": patterns, "fix": fix,
        "tags": tags or [],
    }
    return entry


def _to_yaml_block(rules_list: list) -> str:
    lines = []
    for r in rules_list:
        lines.append(f"- id: {r['id']}")
        lines.append(f"  name: {r['name']}")
        desc = r['description'].replace('"', "'")
        lines.append(f"  description: \"{desc}\"")
        lines.append(f"  severity: {r['severity']}")
        lines.append(f"  cwe: {r['cwe']}")
        lines.append(f"  owasp: {r['owasp']}")
        lines.append(f"  languages:")
        for lang in r["languages"]:
            lines.append(f"  - {lang}")
        lines.append(f"  confidence: {r['confidence']}")
        lines.append(f"  patterns:")
        for p in r["patterns"]:
            lines.append(f"  - type: {p['type']}")
            pat = p['pattern'].replace("\\", "\\\\")
            lines.append(f"    pattern: \"{pat}\"")
            lines.append(f"    confidence: {p.get('confidence', r['confidence'])}")
        if r["fix"]:
            fix = r["fix"].replace('"', "'")
            lines.append(f"  fix: \"{fix}\"")
        if r["tags"]:
            lines.append(f"  tags:")
            for t in r["tags"]:
                lines.append(f"  - {t}")
        lines.append("")
    return "\n".join(lines)


def p(pattern, confidence=0.88):
    return {"type": "regex", "pattern": pattern, "confidence": confidence}


def write_rules(path: Path, rules_list: list):
    path.parent.mkdir(parents=True, exist_ok=True)
    content = _to_yaml_block(rules_list)
    path.write_text(content)
    print(f"  Written {len(rules_list)} rules → {path.relative_to(ROOT)}")


# ─── Python rules ─────────────────────────────────────────────────────────────

PYTHON_EXTENDED = [
    rule("GHOST-PY-EXT-001","Pickle unsafe load","pickle.loads with network/user data",
         "CRITICAL","CWE-502","A08:2021",["python"],
         [p(r"pickle\.loads?\(.*(?:request|data|body|recv)", 0.93),
          p(r"pickle\.loads\(", 0.75)],
         "Use json.loads() or a safe serialization format.", ["pickle","deserialization"]),
    rule("GHOST-PY-EXT-002","YAML unsafe load","yaml.load without safe Loader",
         "HIGH","CWE-20","A03:2021",["python"],
         [p(r"yaml\.load\s*\([^)]*\)(?!\s*#.*safe)", 0.88),
          p(r"yaml\.load\((?!.*Loader\s*=\s*yaml\.(?:Safe|Base)Loader)", 0.85)],
         "Use yaml.safe_load() or yaml.load(data, Loader=yaml.SafeLoader).",["yaml","injection"]),
    rule("GHOST-PY-EXT-003","eval with dynamic argument","eval/exec with non-literal argument",
         "CRITICAL","CWE-95","A03:2021",["python"],
         [p(r"\beval\s*\([^)\"\']+\)", 0.92),
          p(r"\bexec\s*\([^)\"\']+\)", 0.90)],
         "Never use eval/exec with dynamic input. Use ast.literal_eval for safe parsing.",["eval","injection"]),
    rule("GHOST-PY-EXT-004","subprocess shell=True with f-string","Command injection via shell=True",
         "CRITICAL","CWE-78","A03:2021",["python"],
         [p(r"subprocess\.[a-z_]+\s*\(.*shell\s*=\s*True.*f[\"']", 0.95),
          p(r"subprocess\.(?:run|call|Popen)\s*\(f[\"']", 0.90)],
         "Use subprocess with list args and shell=False.",["subprocess","injection"]),
    rule("GHOST-PY-EXT-005","Django raw SQL","Raw SQL in Django ORM",
         "HIGH","CWE-89","A03:2021",["python"],
         [p(r"\.raw\s*\(.*%|\.raw\s*\(.*format|\.extra\s*\(.*where.*%", 0.90)],
         "Use Django ORM parameterized queries.",["django","sql"]),
    rule("GHOST-PY-EXT-006","Django DEBUG=True","Debug mode enabled in production settings",
         "MEDIUM","CWE-215","A05:2021",["python"],
         [p(r"DEBUG\s*=\s*True", 0.80)],
         "Set DEBUG=False in production. Use environment variable.",["django","config"]),
    rule("GHOST-PY-EXT-007","Flask debug mode","Flask running in debug mode",
         "MEDIUM","CWE-215","A05:2021",["python"],
         [p(r"app\.run\s*\(.*debug\s*=\s*True", 0.92),
          p(r"debug\s*=\s*True.*FLASK", 0.80)],
         "Disable debug mode in production.",["flask","config"]),
    rule("GHOST-PY-EXT-008","ECB cipher mode","Symmetric encryption using insecure ECB mode",
         "HIGH","CWE-327","A02:2021",["python"],
         [p(r"MODE_ECB|\.new\s*\(.*ECB|AES\.MODE_ECB", 0.95)],
         "Use AES-GCM or AES-CBC with random IV.",["crypto","ecb"]),
    rule("GHOST-PY-EXT-009","Logging sensitive data","Credentials/tokens logged in plaintext",
         "HIGH","CWE-532","A09:2021",["python"],
         [p(r"(?:log(?:ging|ger)?\.(?:info|debug|warning|error)|print)\s*\(.*(?:password|passwd|secret|token|api_key)", 0.88)],
         "Never log sensitive data. Mask or omit credentials.",["logging","secrets"]),
    rule("GHOST-PY-EXT-010","Timing attack","Comparing secrets with == instead of hmac.compare_digest",
         "MEDIUM","CWE-208","A02:2021",["python"],
         [p(r"(?:password|secret|token|api_key)\s*==\s*\w+(?!\s*#.*constant)", 0.82),
          p(r"==\s*(?:password|secret|token|api_key)", 0.80)],
         "Use hmac.compare_digest() for constant-time comparison.",["timing","crypto"]),
    rule("GHOST-PY-EXT-011","Missing CSRF protection","Django view missing CSRF decorator",
         "HIGH","CWE-352","A01:2021",["python"],
         [p(r"@csrf_exempt", 0.90)],
         "Remove @csrf_exempt or use @ensure_csrf_cookie.",["csrf","django"]),
    rule("GHOST-PY-EXT-012","Weak hash MD5","MD5 used for security purposes",
         "MEDIUM","CWE-327","A02:2021",["python"],
         [p(r"hashlib\.md5\s*\(", 0.85),
          p(r"md5\s*=\s*hashlib\.", 0.80)],
         "Use hashlib.sha256() or better. For passwords use bcrypt/argon2.",["crypto","hash"]),
    rule("GHOST-PY-EXT-013","Hardcoded secret in code","Secrets embedded in source code",
         "CRITICAL","CWE-798","A02:2021",["python"],
         [p(r"(?:password|secret|api_key|token)\s*=\s*[\"'][A-Za-z0-9+/]{12,}[\"']", 0.90)],
         "Use environment variables or secrets manager.",["secrets","hardcoded"]),
    rule("GHOST-PY-EXT-014","SQLAlchemy text() injection","Raw SQL via SQLAlchemy text()",
         "HIGH","CWE-89","A03:2021",["python"],
         [p(r"text\s*\(\s*f[\"']|text\s*\(\s*[\"'][^\"']*%\s*\(", 0.90)],
         "Use parameterized queries with SQLAlchemy.",["sql","sqlalchemy"]),
    rule("GHOST-PY-EXT-015","Insecure deserialization marshal","marshal.loads with untrusted data",
         "HIGH","CWE-502","A08:2021",["python"],
         [p(r"marshal\.loads\s*\(", 0.88)],
         "Avoid marshal for deserialization of untrusted data.",["deserialization"]),
    rule("GHOST-PY-EXT-016","Open redirect","Redirect to user-controlled URL",
         "MEDIUM","CWE-601","A01:2021",["python"],
         [p(r"redirect\s*\(\s*request\.(?:GET|POST|args)\[", 0.85),
          p(r"HttpResponseRedirect\s*\(\s*request\.", 0.85)],
         "Validate redirect URL against allowlist.",["redirect","web"]),
    rule("GHOST-PY-EXT-017","Nonce reuse risk","Static IV/nonce in symmetric encryption",
         "HIGH","CWE-330","A02:2021",["python"],
         [p(r"iv\s*=\s*b[\"'][0-9a-fA-F\\x]+[\"']|nonce\s*=\s*b\"\\x00", 0.88)],
         "Generate a random IV/nonce for each encryption operation.",["crypto","nonce"]),
    rule("GHOST-PY-EXT-018","Short RSA key","RSA key size below 2048 bits",
         "HIGH","CWE-326","A02:2021",["python"],
         [p(r"generate_private_key\s*\(.*key_size\s*=\s*(?:512|1024)\b", 0.92),
          p(r"RSA\.generate\s*\(\s*(?:512|1024)\b", 0.92)],
         "Use RSA keys of at least 2048 bits (4096 recommended).",["crypto","rsa"]),
    rule("GHOST-PY-EXT-019","Flask session no httponly","Flask session cookie without httponly",
         "MEDIUM","CWE-1004","A05:2021",["python"],
         [p(r"SESSION_COOKIE_HTTPONLY\s*=\s*False", 0.92)],
         "Set SESSION_COOKIE_HTTPONLY = True.",["flask","cookie"]),
    rule("GHOST-PY-EXT-020","FastAPI missing response model","FastAPI endpoint without response_model",
         "LOW","CWE-213","A04:2021",["python"],
         [p(r"@(?:app|router)\.(?:get|post|put|delete)\s*\([^)]*\)(?!\s*\n.*response_model)", 0.72)],
         "Add response_model to prevent data leakage.",["fastapi","api"]),
]

# Add 30 more Python rules
PYTHON_EXTENDED += [
    rule(f"GHOST-PY-EXT-{i:03d}", *data)
    for i, data in enumerate([
        ("LDAP injection","LDAP query with user input","HIGH","CWE-90","A03:2021",["python"],
         [p(r"ldap\.search\s*\(.*request\.", 0.88)], "Escape LDAP special chars.",["ldap"]),
        ("XML injection XXE","XML parsing without disabling external entities","HIGH","CWE-611","A05:2021",["python"],
         [p(r"etree\.(?:parse|fromstring)\s*\(", 0.78)], "Use defusedxml.",["xml","xxe"]),
        ("Path traversal open","File open with user-controlled path","HIGH","CWE-22","A01:2021",["python"],
         [p(r"open\s*\(\s*(?:request|input|argv|params)", 0.85)], "Validate and sanitize file paths.",["path","traversal"]),
        ("SSRF via requests","Server-side request forgery via requests","HIGH","CWE-918","A10:2021",["python"],
         [p(r"requests\.(?:get|post)\s*\(\s*(?:request|input|params|args)\.", 0.88)], "Validate and allowlist URLs.",["ssrf"]),
        ("Hardcoded AWS key","AWS access key in source code","CRITICAL","CWE-798","A02:2021",["python"],
         [p(r"AKIA[0-9A-Z]{16}", 0.98)], "Use IAM roles or environment variables.",["aws","secrets"]),
        ("Template injection Jinja2","Jinja2 template from user input","CRITICAL","CWE-94","A03:2021",["python"],
         [p(r"Template\s*\(\s*(?:request|input|f[\"'])", 0.90)], "Never render user input as a template.",["ssti","jinja2"]),
        ("Weak password hash sha1","SHA1 used for password hashing","HIGH","CWE-916","A02:2021",["python"],
         [p(r"hashlib\.sha1\s*\(.*password", 0.90)], "Use bcrypt, argon2, or scrypt.",["crypto","password"]),
        ("Flask CORS wildcard","Flask-CORS allowing all origins","MEDIUM","CWE-346","A05:2021",["python"],
         [p(r"CORS\s*\(.*origins\s*=\s*[\"']\*[\"']", 0.90)], "Restrict CORS to known origins.",["cors","flask"]),
        ("SQLite concat","SQLite query with string concatenation","HIGH","CWE-89","A03:2021",["python"],
         [p(r"cursor\.execute\s*\(\s*[\"'][^\"']*[\"']\s*\+", 0.90)], "Use parameterized queries.",["sql","sqlite"]),
        ("Insecure random","secrets.SystemRandom not used for security","MEDIUM","CWE-338","A02:2021",["python"],
         [p(r"random\.(?:randint|random|choice)\s*\(", 0.75)], "Use secrets module for security purposes.",["random","crypto"]),
    ], start=21)
]

# ─── JavaScript rules ─────────────────────────────────────────────────────────

JS_EXTENDED = [
    rule("GHOST-JS-EXT-001","Prototype pollution","__proto__ or constructor.prototype manipulation",
         "HIGH","CWE-1321","A08:2021",["javascript","typescript"],
         [p(r"__proto__|constructor\.prototype|Object\.assign\s*\(\s*\{\}", 0.88)],
         "Use Object.create(null) and validate input keys.",["prototype","pollution"]),
    rule("GHOST-JS-EXT-002","ReDoS pattern","Vulnerable regex with catastrophic backtracking",
         "MEDIUM","CWE-400","A06:2021",["javascript","typescript"],
         [p(r"new RegExp\s*\(.*\+|RegExp\s*\(.*(?:input|req|user)", 0.82)],
         "Use safe regex libraries or validate patterns.",["regex","redos"]),
    rule("GHOST-JS-EXT-003","JWT no algorithm check","JWT decoded without algorithm verification",
         "CRITICAL","CWE-347","A02:2021",["javascript","typescript"],
         [p(r"jwt\.(?:verify|decode)\s*\([^)]*\)(?!.*algorithms)", 0.85),
          p(r"algorithms:\s*\[\s*[\"']none[\"']", 0.98)],
         "Always specify allowed algorithms: jwt.verify(token, secret, {algorithms:['HS256']}).",["jwt","auth"]),
    rule("GHOST-JS-EXT-004","dangerouslySetInnerHTML","React XSS via dangerouslySetInnerHTML",
         "HIGH","CWE-79","A03:2021",["javascript","typescript"],
         [p(r"dangerouslySetInnerHTML\s*=\s*\{", 0.90)],
         "Sanitize HTML with DOMPurify before using dangerouslySetInnerHTML.",["xss","react"]),
    rule("GHOST-JS-EXT-005","child_process exec user input","Command injection in Node.js",
         "CRITICAL","CWE-78","A03:2021",["javascript","typescript"],
         [p(r"(?:exec|execSync|spawn)\s*\(\s*`[^`]*\$\{|(?:exec|execSync)\s*\([^)]*\+", 0.92)],
         "Use execFile with array args instead of exec with shell string.",["cmd","injection"]),
    rule("GHOST-JS-EXT-006","Path traversal path.join","Path traversal in file operations",
         "HIGH","CWE-22","A01:2021",["javascript","typescript"],
         [p(r"path\.(?:join|resolve)\s*\([^)]*req\.", 0.88)],
         "Validate that resolved path is within expected base directory.",["path","traversal"]),
    rule("GHOST-JS-EXT-007","Express no helmet","Express app missing security headers",
         "MEDIUM","CWE-16","A05:2021",["javascript","typescript"],
         [p(r"express\s*\(\s*\)(?![\s\S]{0,200}helmet)", 0.75)],
         "Add helmet() middleware: app.use(helmet()).",["express","headers"]),
    rule("GHOST-JS-EXT-008","CORS wildcard Express","Express allowing all CORS origins",
         "MEDIUM","CWE-346","A05:2021",["javascript","typescript"],
         [p(r"cors\s*\(\s*\{[^}]*origin\s*:\s*[\"']\*[\"']", 0.92)],
         "Restrict CORS to known origins.",["cors","express"]),
    rule("GHOST-JS-EXT-009","Sensitive data localStorage","Storing credentials in localStorage",
         "MEDIUM","CWE-312","A02:2021",["javascript","typescript"],
         [p(r"localStorage\.setItem\s*\([^)]*(?:password|token|secret|key)", 0.88)],
         "Use httpOnly cookies or secure storage for sensitive data.",["storage","secrets"]),
    rule("GHOST-JS-EXT-010","postMessage no origin check","postMessage without origin validation",
         "MEDIUM","CWE-346","A05:2021",["javascript","typescript"],
         [p(r"addEventListener\s*\(\s*[\"']message[\"'].*\)(?![\s\S]{0,100}origin)", 0.80)],
         "Always validate event.origin in message event handlers.",["postmessage","origin"]),
    rule("GHOST-JS-EXT-011","SQL injection template literal","SQL via template literals in JS",
         "CRITICAL","CWE-89","A03:2021",["javascript","typescript"],
         [p(r"(?:query|execute)\s*\(\s*`[^`]*\$\{", 0.92)],
         "Use parameterized queries.",["sql","injection"]),
    rule("GHOST-JS-EXT-012","eval user input","eval() with user-controlled data",
         "CRITICAL","CWE-95","A03:2021",["javascript","typescript"],
         [p(r"\beval\s*\(\s*(?:req\.|request\.|input|data|body)", 0.95)],
         "Never use eval with user input.",["eval","injection"]),
    rule("GHOST-JS-EXT-013","Hardcoded API key JS","API key hardcoded in JS source",
         "CRITICAL","CWE-798","A02:2021",["javascript","typescript"],
         [p(r"(?:apiKey|api_key|secret|password)\s*[=:]\s*[\"'][A-Za-z0-9+/]{16,}[\"']", 0.88)],
         "Use environment variables.",["secrets","hardcoded"]),
    rule("GHOST-JS-EXT-014","Missing rate limiting","Auth endpoint without rate limiting",
         "MEDIUM","CWE-770","A04:2021",["javascript","typescript"],
         [p(r"router\.(?:post|get)\s*\([\"']/(?:login|auth|signin)[\"'](?![\s\S]{0,300}rateLimit)", 0.75)],
         "Add rate limiting middleware to authentication endpoints.",["ratelimit","auth"]),
    rule("GHOST-JS-EXT-015","Insecure cookie","Cookie without secure/httpOnly flags",
         "MEDIUM","CWE-1004","A05:2021",["javascript","typescript"],
         [p(r"res\.cookie\s*\([^)]*\)(?!.*(?:httpOnly|secure)\s*:\s*true)", 0.82)],
         "Set httpOnly: true and secure: true on cookies.",["cookie","session"]),
    rule("GHOST-JS-EXT-016","SSRF fetch","Server-side request forgery via fetch",
         "HIGH","CWE-918","A10:2021",["javascript","typescript"],
         [p(r"fetch\s*\(\s*(?:req\.|request\.|params\.|query\.)\w+", 0.88)],
         "Validate URLs against allowlist before fetching.",["ssrf","fetch"]),
    rule("GHOST-JS-EXT-017","Open redirect","Redirect to user-controlled URL",
         "MEDIUM","CWE-601","A01:2021",["javascript","typescript"],
         [p(r"res\.redirect\s*\(\s*req\.(?:query|body|params)\.", 0.88)],
         "Validate redirect URLs against allowlist.",["redirect"]),
    rule("GHOST-JS-EXT-018","XXE XML parsing","XXE via XML parsing in Node",
         "HIGH","CWE-611","A05:2021",["javascript","typescript"],
         [p(r"(?:DOMParser|xml2js|xmldom)[\s\S]{0,50}\.parse\s*\(", 0.80)],
         "Disable external entities in XML parser configuration.",["xxe","xml"]),
    rule("GHOST-JS-EXT-019","Prototype pollution merge","Deep merge vulnerability",
         "HIGH","CWE-1321","A08:2021",["javascript","typescript"],
         [p(r"(?:merge|extend|assign)\s*\([^)]*(?:req\.|request\.body)", 0.85)],
         "Use safe merge libraries that prevent prototype pollution.",["prototype"]),
    rule("GHOST-JS-EXT-020","Insecure random Math.random","Math.random() for security",
         "MEDIUM","CWE-338","A02:2021",["javascript","typescript"],
         [p(r"Math\.random\s*\(\s*\)", 0.70)],
         "Use crypto.randomBytes() for security-sensitive randomness.",["random","crypto"]),
]

# ─── Go rules ────────────────────────────────────────────────────────────────

GO_SECURITY = [
    rule("GHOST-GO-001","SQL injection database/sql","SQL injection in Go database/sql",
         "CRITICAL","CWE-89","A03:2021",["go"],
         [p(r'db\.(?:Query|Exec|QueryRow)\s*\(\s*(?:fmt\.Sprintf|"[^"]*"\s*\+)', 0.92)],
         "Use parameterized queries with ? placeholders.",["sql","injection"]),
    rule("GHOST-GO-002","Command injection os/exec","Command injection via exec.Command",
         "CRITICAL","CWE-78","A03:2021",["go"],
         [p(r'exec\.Command\s*\(\s*(?:r\.|req\.|fmt\.Sprintf|input)', 0.90)],
         "Validate and sanitize command arguments. Avoid shell execution.",["cmd","injection"]),
    rule("GHOST-GO-003","Path traversal filepath","Path traversal in file operations",
         "HIGH","CWE-22","A01:2021",["go"],
         [p(r'(?:os\.Open|ioutil\.ReadFile|os\.ReadFile)\s*\(\s*(?:r\.|req\.|path\.Join)', 0.88)],
         "Use filepath.Clean and validate path is within base directory.",["path","traversal"]),
    rule("GHOST-GO-004","SSRF http client","SSRF via http.Get with user input",
         "HIGH","CWE-918","A10:2021",["go"],
         [p(r'http\.(?:Get|Post)\s*\(\s*(?:r\.|req\.|fmt\.Sprintf|input)', 0.88)],
         "Validate URLs against allowlist before making requests.",["ssrf","http"]),
    rule("GHOST-GO-005","Weak crypto MD5","MD5 used for security",
         "MEDIUM","CWE-327","A02:2021",["go"],
         [p(r'crypto/md5|md5\.New\s*\(\s*\)', 0.88)],
         "Use crypto/sha256 or better.",["crypto","hash"]),
    rule("GHOST-GO-006","Weak crypto SHA1","SHA1 used for security",
         "MEDIUM","CWE-327","A02:2021",["go"],
         [p(r'crypto/sha1|sha1\.New\s*\(\s*\)', 0.85)],
         "Use crypto/sha256 or better.",["crypto","hash"]),
    rule("GHOST-GO-007","Hardcoded credentials","Credentials hardcoded in Go source",
         "CRITICAL","CWE-798","A02:2021",["go"],
         [p(r'(?:password|secret|apiKey|token)\s*:?=\s*"[A-Za-z0-9+/!@#]{8,}"', 0.88)],
         "Use environment variables or secrets manager.",["secrets","hardcoded"]),
    rule("GHOST-GO-008","InsecureSkipVerify","TLS verification disabled",
         "HIGH","CWE-295","A02:2021",["go"],
         [p(r'InsecureSkipVerify\s*:\s*true', 0.98)],
         "Never disable TLS verification in production.",["tls","crypto"]),
    rule("GHOST-GO-009","Goroutine leak","Goroutine started without proper cleanup",
         "MEDIUM","CWE-404","A04:2021",["go"],
         [p(r'go\s+func\s*\(\s*\)\s*\{(?![\s\S]{0,200}(?:defer|done|ctx\.Done|close))', 0.75)],
         "Ensure goroutines have proper termination via context or channel.",["goroutine","leak"]),
    rule("GHOST-GO-010","XSS template injection","HTML template with user input",
         "HIGH","CWE-79","A03:2021",["go"],
         [p(r'template\.HTML\s*\(|fmt\.Fprintf\s*\(\s*w.*(?:r\.|req\.)', 0.85)],
         "Use html/template instead of text/template for HTML output.",["xss","template"]),
    rule("GHOST-GO-011","Integer overflow","Integer conversion without bounds check",
         "MEDIUM","CWE-190","A03:2021",["go"],
         [p(r'int\s*\(\s*(?:r\.|req\.|input)\w*\)', 0.82)],
         "Validate integer ranges before conversion.",["overflow","arithmetic"]),
    rule("GHOST-GO-012","HTTP redirect","Redirect to user-controlled URL",
         "MEDIUM","CWE-601","A01:2021",["go"],
         [p(r'http\.Redirect\s*\([^)]*(?:r\.FormValue|r\.URL\.Query)', 0.88)],
         "Validate redirect URLs against allowlist.",["redirect"]),
    rule("GHOST-GO-013","Panic in handler","Unrecovered panic in HTTP handler",
         "LOW","CWE-754","A04:2021",["go"],
         [p(r'func.*(?:Handler|ServeHTTP)[\s\S]{0,200}\bpanic\b', 0.78)],
         "Use defer/recover to handle panics in HTTP handlers.",["panic","stability"]),
    rule("GHOST-GO-014","Race condition global","Global variable accessed without mutex",
         "MEDIUM","CWE-362","A04:2021",["go"],
         [p(r'var\s+\w+\s*=.*\n(?:[\s\S]{0,500})(func\s+\w+)', 0.70)],
         "Use sync.Mutex or sync.RWMutex for shared state.",["race","concurrency"]),
    rule("GHOST-GO-015","Weak password hash","Non-cryptographic hash for passwords",
         "HIGH","CWE-916","A02:2021",["go"],
         [p(r'(?:md5|sha1|sha256)\.Sum.*password', 0.88)],
         "Use bcrypt or argon2 for password hashing.",["password","crypto"]),
    rule("GHOST-GO-016","Unvalidated JSON unmarshal","JSON unmarshal into interface{}",
         "MEDIUM","CWE-20","A08:2021",["go"],
         [p(r'json\.Unmarshal\s*\([^)]*,\s*&?interface\{\}', 0.78)],
         "Unmarshal into a typed struct for validation.",["json","validation"]),
    rule("GHOST-GO-017","Directory listing","ServeFiles with user-controlled path",
         "MEDIUM","CWE-548","A01:2021",["go"],
         [p(r'http\.FileServer\s*\(\s*http\.Dir\s*\(.*(?:r\.|req\.)', 0.85)],
         "Restrict file serving to specific directories.",["directory","listing"]),
    rule("GHOST-GO-018","Printf format injection","Uncontrolled format string",
         "HIGH","CWE-134","A03:2021",["go"],
         [p(r'fmt\.(?:Fprintf|Sprintf)\s*\(\s*\w+,\s*(?:r\.|req\.|input)', 0.88)],
         "Use fmt.Fprintf(w, \"%s\", userInput) with explicit format string.",["format","injection"]),
    rule("GHOST-GO-019","Cookie no secure flag","HTTP cookie without Secure flag",
         "MEDIUM","CWE-614","A05:2021",["go"],
         [p(r'http\.Cookie\s*\{[^}]*(?!Secure)', 0.75)],
         "Set Secure: true on cookies for HTTPS.",["cookie","session"]),
    rule("GHOST-GO-020","Regex from user input","Regex compiled from user input (ReDoS risk)",
         "MEDIUM","CWE-400","A04:2021",["go"],
         [p(r'regexp\.MustCompile\s*\(\s*(?:r\.|req\.|input)', 0.85)],
         "Compile regex from static patterns only, not user input.",["regex","redos"]),
]

# Add 20 more Go rules
GO_SECURITY += [
    rule(f"GHOST-GO-{i:03d}", *data)
    for i, data in enumerate([
        ("CORS all origins","Go CORS middleware allowing all origins","MEDIUM","CWE-346","A05:2021",["go"],
         [p(r'AllowedOrigins.*\[\s*"\*"\s*\]|CORS.*\*', 0.88)], "Restrict CORS origins.",["cors"]),
        ("TLS min version","Old TLS version configured","HIGH","CWE-326","A02:2021",["go"],
         [p(r'MinVersion\s*:\s*tls\.VersionTLS1[01]\b', 0.95)], "Set MinVersion: tls.VersionTLS12 or higher.",["tls"]),
        ("SQL string concat fmt","SQL formatted string","CRITICAL","CWE-89","A03:2021",["go"],
         [p(r'fmt\.Sprintf\s*\(\s*"[^"]*(?:SELECT|INSERT|UPDATE|DELETE)[^"]*%', 0.90)], "Use parameterized queries.",["sql"]),
        ("Unsafe pointer cast","Unsafe pointer conversion","MEDIUM","CWE-242","A04:2021",["go"],
         [p(r'unsafe\.Pointer|uintptr\s*\(.*unsafe', 0.88)], "Avoid unsafe pointer operations.",["unsafe"]),
        ("JWT HS256 weak secret","JWT signed with short secret","HIGH","CWE-330","A02:2021",["go"],
         [p(r'SigningMethodHS256.*(?:jwt\.Parse|jwt\.New)', 0.78)], "Use RS256 or ES256 with proper key management.",["jwt","crypto"]),
        ("Missing rate limit","HTTP handler without rate limiting","MEDIUM","CWE-770","A04:2021",["go"],
         [p(r'(?:HandleFunc|Handle)\s*\(\s*"[^"]*(?:login|auth|signin)', 0.75)], "Add rate limiting middleware.",["ratelimit"]),
        ("Error exposed to client","Internal error sent to HTTP client","MEDIUM","CWE-209","A09:2021",["go"],
         [p(r'http\.Error\s*\(\s*w,\s*err\.Error\(\)', 0.85)], "Use generic error messages for clients.",["error","disclosure"]),
        ("YAML unmarshal untrusted","YAML unmarshal from untrusted source","HIGH","CWE-502","A08:2021",["go"],
         [p(r'yaml\.Unmarshal\s*\([^)]*(?:r\.|req\.|body)', 0.85)], "Validate YAML input structure.",["yaml","deserialization"]),
        ("Weak PBKDF2 iterations","Too few PBKDF2 iterations","MEDIUM","CWE-916","A02:2021",["go"],
         [p(r'pbkdf2\.Key\s*\(.*,\s*(?:[1-9][0-9]{0,3})\s*,', 0.88)], "Use at least 100,000 iterations for PBKDF2.",["crypto","pbkdf2"]),
        ("Struct tag validation missing","Missing validation tags on request struct","LOW","CWE-20","A08:2021",["go"],
         [p(r'type\s+\w+Request\s+struct\s+\{[^}]*\}(?![\s\S]{0,500}validate)', 0.70)], "Add validation tags and use a validation library.",["validation"]),
    ], start=21)
]

# ─── Rust rules ───────────────────────────────────────────────────────────────

RUST_SECURITY = [
    rule("GHOST-RS-001","Unsafe block","Unsafe Rust code block",
         "MEDIUM","CWE-242","A04:2021",["rust"],
         [p(r'\bunsafe\s*\{', 0.90)],
         "Document why unsafe is necessary and minimize its scope.",["unsafe"]),
    rule("GHOST-RS-002","unwrap in production","unwrap() on Result/Option",
         "MEDIUM","CWE-390","A04:2021",["rust"],
         [p(r'\.unwrap\s*\(\s*\)', 0.75)],
         "Use ? operator or match/if let for error handling.",["panic","error"]),
    rule("GHOST-RS-003","SQL injection diesel","SQL injection in Diesel raw query",
         "CRITICAL","CWE-89","A03:2021",["rust"],
         [p(r'sql\s*!\s*\(.*\{.*\}|diesel::sql_query\s*\(\s*format!', 0.90)],
         "Use Diesel parameterized queries.",["sql","injection"]),
    rule("GHOST-RS-004","Command injection","Command injection in process::Command",
         "CRITICAL","CWE-78","A03:2021",["rust"],
         [p(r'Command::new\s*\(\s*(?:&user|&input|args)', 0.88)],
         "Validate and sanitize command arguments.",["cmd","injection"]),
    rule("GHOST-RS-005","Path traversal","Path traversal in file system operations",
         "HIGH","CWE-22","A01:2021",["rust"],
         [p(r'fs::(?:read|write|File::open)\s*\(\s*(?:&user|&path|format!)', 0.88)],
         "Validate paths against allowed base directory.",["path","traversal"]),
    rule("GHOST-RS-006","Hardcoded secret","Secret or credential hardcoded in source",
         "CRITICAL","CWE-798","A02:2021",["rust"],
         [p(r'(?:password|secret|api_key|token)\s*=\s*"[A-Za-z0-9+/!@#]{8,}"', 0.88)],
         "Use environment variables or secrets manager.",["secrets","hardcoded"]),
    rule("GHOST-RS-007","Integer overflow checked","Arithmetic without checked methods",
         "MEDIUM","CWE-190","A04:2021",["rust"],
         [p(r'\b\w+\s*\+=\s*\w+(?!.*checked_add)', 0.75)],
         "Use checked_add/checked_sub or enable overflow-checks.",["overflow","arithmetic"]),
    rule("GHOST-RS-008","Weak TLS","TLS with weak configuration",
         "HIGH","CWE-326","A02:2021",["rust"],
         [p(r'danger_accept_invalid_certs|danger_accept_invalid_hostnames', 0.98)],
         "Never disable TLS verification.",["tls","crypto"]),
    rule("GHOST-RS-009","SQL concat sqlx","SQL injection in sqlx raw query",
         "CRITICAL","CWE-89","A03:2021",["rust"],
         [p(r'sqlx::query\s*\(\s*&format!', 0.90)],
         "Use sqlx query macros with parameterized queries.",["sql","sqlx"]),
    rule("GHOST-RS-010","Println sensitive data","Sensitive data printed to stdout",
         "MEDIUM","CWE-532","A09:2021",["rust"],
         [p(r'println!\s*\(.*(?:password|secret|token|key)', 0.85)],
         "Remove debug prints of sensitive data.",["logging","secrets"]),
    rule("GHOST-RS-011","Transmute unsafe","mem::transmute usage",
         "HIGH","CWE-704","A04:2021",["rust"],
         [p(r'mem::transmute\s*\(', 0.95)],
         "Avoid transmute; use proper type conversions.",["unsafe","transmute"]),
    rule("GHOST-RS-012","Race condition static mut","Mutable static variable access",
         "HIGH","CWE-362","A04:2021",["rust"],
         [p(r'static\s+mut\s+\w+', 0.90)],
         "Use Mutex<T>, RwLock<T>, or atomic types for shared state.",["race","static"]),
    rule("GHOST-RS-013","Actix route no auth","Actix-web route without auth middleware",
         "MEDIUM","CWE-284","A01:2021",["rust"],
         [p(r'\.route\s*\(.*web::(?:post|put|delete)', 0.70)],
         "Add authentication middleware to protected routes.",["auth","actix"]),
    rule("GHOST-RS-014","Env var secret","Secret loaded from env without validation",
         "LOW","CWE-20","A02:2021",["rust"],
         [p(r'std::env::var\s*\(\s*"(?:SECRET|KEY|TOKEN|PASSWORD)', 0.80)],
         "Validate presence and format of secrets at startup.",["env","secrets"]),
    rule("GHOST-RS-015","Panic in release","panic! in application code",
         "LOW","CWE-390","A04:2021",["rust"],
         [p(r'\bpanic!\s*\(', 0.70)],
         "Use Result/Option instead of panicking.",["panic"]),
]

# Add 15 more Rust rules
RUST_SECURITY += [
    rule(f"GHOST-RS-{i:03d}", *data)
    for i, data in enumerate([
        ("Serde deserialize untrusted","Deserializing untrusted JSON without validation","HIGH","CWE-502","A08:2021",["rust"],
         [p(r'serde_json::from_str\s*\(', 0.70)], "Validate deserialized data before use.",["serde","json"]),
        ("Weak hash MD5","MD5 hash function in security context","MEDIUM","CWE-327","A02:2021",["rust"],
         [p(r'md5::compute|Md5::new', 0.88)], "Use SHA-256 or better via sha2 crate.",["crypto","hash"]),
        ("Global state Mutex poison","Mutex::lock() without handling poison","LOW","CWE-390","A04:2021",["rust"],
         [p(r'\.lock\(\)\.unwrap\(\)', 0.78)], "Handle Mutex poison with .lock().unwrap_or_else(|e| e.into_inner()).",["mutex","error"]),
        ("Request smuggling body parse","HTTP body parsing without size limits","MEDIUM","CWE-770","A04:2021",["rust"],
         [p(r'body::to_bytes\s*\(\s*body\s*\)', 0.80)], "Set maximum body size limits.",["http","dos"]),
        ("CORS wildcard axum","Axum CORS allowing all origins","MEDIUM","CWE-346","A05:2021",["rust"],
         [p(r'CorsLayer::permissive\(\)|allow_origin\s*\(Any\)', 0.90)], "Restrict CORS to known origins.",["cors","axum"]),
        ("Tokio spawn no cancel","tokio::spawn without cancellation token","LOW","CWE-404","A04:2021",["rust"],
         [p(r'tokio::spawn\s*\(', 0.72)], "Use CancellationToken for proper task lifecycle.",["tokio","task"]),
        ("Env panic on missing","std::env::var().unwrap() panics if missing","MEDIUM","CWE-390","A04:2021",["rust"],
         [p(r'std::env::var\s*\([^)]+\)\s*\.unwrap\(\)', 0.85)], "Use .expect() with descriptive message or handle absence.",["env","panic"]),
        ("SQL diesel raw","diesel::sql_query with user input","CRITICAL","CWE-89","A03:2021",["rust"],
         [p(r'diesel::sql_query\s*\(', 0.80)], "Use Diesel typed query builder.",["sql","diesel"]),
        ("Crypto weak rng","Non-cryptographic RNG for security purposes","HIGH","CWE-338","A02:2021",["rust"],
         [p(r'SmallRng::from_entropy|StdRng.*seed', 0.78)], "Use OsRng for security-sensitive randomness.",["crypto","rng"]),
        ("Stack overflow recursion","Deep recursion without limit","MEDIUM","CWE-674","A04:2021",["rust"],
         [p(r'fn\s+\w+\s*\([^)]*\)\s*->[^{]*\{[\s\S]{0,200}\bself\.\w+\s*\(', 0.70)], "Add recursion depth limit.",["recursion","stack"]),
    ], start=16)
]

# ─── Blockchain rules ─────────────────────────────────────────────────────────

TON_SECURITY = [
    rule(f"GHOST-TON-{i+1:03d}", name, desc, sev, cwe, "A04:2021", ["func","tolk"], [p(pat, conf)], fix)
    for i, (name, desc, sev, cwe, pat, conf, fix) in enumerate([
        ("Reentrancy send before update","State updated after send_raw_message","CRITICAL","CWE-691",
         r'send_raw_message[\s\S]{0,200}(?:set_data|store_)', 0.85,
         "Update state before sending messages (checks-effects-interactions)."),
        ("Missing bounce handler","No bounced$ handler with outgoing messages","HIGH","CWE-754",
         r'send_raw_message(?![\s\S]{0,500}bounced\$)', 0.80,
         "Implement bounced$ handler to handle failed messages."),
        ("Unbounded loop recv_internal","Loop without iteration bound","HIGH","CWE-400",
         r'\brepeat\s*\(\s*(?!(?:100|50|20|10)\b)', 0.82,
         "Cap all loop iterations with a safe maximum constant."),
        ("FunC integer overflow","Arithmetic without overflow check","MEDIUM","CWE-190",
         r'(?:muldiv|muldivmod|divmod)\s*\(', 0.78,
         "Validate arithmetic operands to prevent overflow."),
        ("Missing sender validation","No load_msg_addr check","HIGH","CWE-284",
         r'recv_internal\s*\((?![\s\S]{0,200}load_msg_addr)', 0.80,
         "Validate sender address before privileged operations."),
        ("Gas griefing no accept","recv_internal without accept_message","MEDIUM","CWE-400",
         r'recv_internal\s*\([^)]*\)\s*impure\s*\{(?![\s\S]{0,100}accept_message)', 0.78,
         "Call accept_message() for external messages to prevent gas griefing."),
        ("Replay attack seqno","No seqno check against stored value","HIGH","CWE-294",
         r'(?:wallet_seqno|get_seqno)(?![\s\S]{0,200}(?:throw_unless|throw_if))', 0.80,
         "Check and increment sequence number to prevent replay attacks."),
        ("Hardcoded admin address","Admin address hardcoded in contract","LOW","CWE-547",
         r'"[EUk][Qq][A-Za-z0-9_\-]{44,48}"', 0.85,
         "Store admin addresses in contract state."),
        ("Weak randomness FunC","random() for security-sensitive logic","HIGH","CWE-338",
         r'\brandom\s*\(\s*\)\s*%', 0.88,
         "Use randomize_lt() and commit-reveal scheme."),
        ("Missing op dispatch","recv_internal without op code dispatch","MEDIUM","CWE-284",
         r'recv_internal[\s\S]{0,100}load_uint\s*\(\s*32', 0.72,
         "Validate operation codes before processing messages."),
    ])
]

SOLANA_SECURITY = [
    rule(f"GHOST-SOL-{i+1:03d}", name, desc, sev, cwe, "A01:2021", ["rust"], [p(pat, conf)], fix)
    for i, (name, desc, sev, cwe, pat, conf, fix) in enumerate([
        ("Missing signer check Anchor","No signer validation","CRITICAL","CWE-284",
         r'process_instruction(?![\s\S]{0,300}is_signer)', 0.85,
         "Check account.is_signer or use Signer<> in Anchor accounts."),
        ("Account confusion","Wrong account type used","HIGH","CWE-345",
         r'try_from_slice_unchecked', 0.90,
         "Validate account discriminator with try_from_slice()."),
        ("Integer overflow no checked","Arithmetic without checked_add","HIGH","CWE-190",
         r'\b\w+\s*\+=\s*\w+(?!.*checked_add)', 0.82,
         "Use checked_add/checked_sub."),
        ("Missing owner check","Account owner not verified","HIGH","CWE-284",
         r'AccountInfo(?![\s\S]{0,200}\.owner)', 0.78,
         "Verify account.owner == &program_id."),
        ("Arbitrary CPI","CPI to unvalidated program","CRITICAL","CWE-284",
         r'invoke\s*\(&\s*\w+_info\.clone\(\)', 0.88,
         "Validate CPI target program key before invocation."),
        ("PDA bump seed","PDA without canonical bump","MEDIUM","CWE-284",
         r'find_program_address(?![\s\S]{0,200}bump)', 0.80,
         "Use and store canonical bump seed."),
        ("Closing account no zero","Account closed without zeroing data","HIGH","CWE-459",
         r'lamports\s*\(\s*\)\s*=\s*0(?![\s\S]{0,100}fill\s*\(\s*0)', 0.85,
         "Zero out account data when closing."),
        ("Missing lamport check","Lamport balance not validated","MEDIUM","CWE-284",
         r'transfer_lamports(?![\s\S]{0,100}lamports\(\))', 0.78,
         "Validate sufficient lamports before transfer."),
        ("Reentrancy Solana","State updated after CPI","HIGH","CWE-691",
         r'invoke[\s\S]{0,200}\.serialize\s*\(', 0.80,
         "Use checks-effects-interactions pattern."),
        ("Missing rent check","Account not checked for rent exemption","LOW","CWE-754",
         r'AccountInfo(?![\s\S]{0,300}rent)', 0.70,
         "Check rent exemption for persistent accounts."),
    ])
]

EVM_SECURITY = [
    rule(f"GHOST-EVM-{i+1:03d}", name, desc, sev, cwe, "A04:2021", ["solidity"], [p(pat, conf)], fix)
    for i, (name, desc, sev, cwe, pat, conf, fix) in enumerate([
        ("tx.origin auth","tx.origin used for authentication","HIGH","CWE-284",
         r'\btx\.origin\b', 0.90,
         "Replace tx.origin with msg.sender."),
        ("Delegatecall user address","delegatecall to user-controlled address","CRITICAL","CWE-829",
         r'\.delegatecall\s*\(', 0.85,
         "Validate delegatecall target address against allowlist."),
        ("Selfdestruct misuse","Unprotected selfdestruct","CRITICAL","CWE-284",
         r'\bselfdestruct\s*\(', 0.88,
         "Guard with onlyOwner or remove."),
        ("Unchecked call return","call() return value not checked","HIGH","CWE-252",
         r'\.call\{[^}]*\}\s*\([^)]*\)(?![\s\S]{0,50}success)', 0.85,
         "Always check (bool success,) = addr.call{...}(...); require(success)."),
        ("Front-running","Block-ordering dependent logic","MEDIUM","CWE-362",
         r'block\.(?:number|timestamp).*(?:winner|prize|reward)', 0.78,
         "Use commit-reveal or VRF for randomness."),
        ("Flash loan attack","Price check without reentrancy guard","HIGH","CWE-841",
         r'getReserves\(\)[\s\S]{0,200}(?:mint|swap)', 0.80,
         "Use TWAP oracle and nonReentrant modifier."),
        ("Oracle manipulation","Single-source price oracle","HIGH","CWE-829",
         r'(?:getPrice|price\(\))(?![\s\S]{0,100}TWAP)', 0.78,
         "Use time-weighted average price (TWAP) oracle."),
        ("Single owner centralization","Single-owner contract without timelock","MEDIUM","CWE-284",
         r'onlyOwner(?![\s\S]{0,500}TimeLock)', 0.75,
         "Implement multisig and timelock for critical operations."),
        ("Integer overflow no SafeMath","Arithmetic without overflow protection","HIGH","CWE-190",
         r'pragma solidity \^0\.[0-6]', 0.88,
         "Upgrade to Solidity >=0.8 or use SafeMath."),
        ("Reentrancy state after call","State written after external call","CRITICAL","CWE-841",
         r'\.call\{[^}]*\}[^;]*;[\s\S]{0,100}\w+\[', 0.88,
         "Apply checks-effects-interactions pattern."),
        ("Timestamp dependency","block.timestamp for game/lottery logic","MEDIUM","CWE-829",
         r'block\.timestamp.*(?:%|==|<=|>=)', 0.82,
         "Use block.number or Chainlink VRF."),
        ("Missing zero address check","Address without zero check","MEDIUM","CWE-20",r"address\s+\w+(?![\s\S]{0,50}!= address\(0\))",
         0.78, "Validate address != address(0)."),
        ("Signature replay","Missing nonce in signature verification","HIGH","CWE-294",
         r'ecrecover\s*\((?![\s\S]{0,200}nonce)', 0.82,
         "Include nonce in signed message to prevent replay."),
        ("Weak randomness block hash","blockhash used for randomness","HIGH","CWE-338",
         r'\bblockhash\s*\(', 0.88,
         "Use Chainlink VRF for verifiable randomness."),
        ("ERC20 approve race","Approve without increaseAllowance","MEDIUM","CWE-362",
         r'function approve\s*\([^)]*\)', 0.75,
         "Use increaseAllowance/decreaseAllowance pattern."),
        ("Unchecked transfer","ERC20 transfer return not checked","HIGH","CWE-252",
         r'token\.transfer\s*\([^;]*\);(?!\s*require)', 0.85,
         "Use SafeERC20 or check return value of transfer()."),
        ("Access control missing","Public function modifying state without auth","HIGH","CWE-284",
         r'function\s+\w+\s*\([^)]*\)\s*public(?![\s\S]{0,50}(?:onlyOwner|onlyAdmin|whenNotPaused))', 0.75,
         "Add access control modifier."),
        ("Denial of service loop","Unbounded loop over array","MEDIUM","CWE-400",
         r'for\s*\([^)]*;\s*\w+\s*<\s*\w+\.length', 0.80,
         "Use pull payment pattern instead of push to avoid DoS."),
        ("Storage slot collision","delegatecall storage slot clash risk","HIGH","CWE-667",
         r'delegatecall[\s\S]{0,100}storage', 0.78,
         "Use EIP-1967 storage slots to avoid collisions."),
        ("Missing event emission","State change without event","LOW","CWE-778",
         r'(?:owner|admin|fee)\s*=\s*\w+(?![\s\S]{0,50}emit)', 0.72,
         "Emit events for all significant state changes."),
    ])
]

# ─── Write all rules ──────────────────────────────────────────────────────────

def main():
    print("TythanAI Rules Expander — generating new rules...")

    # Python
    py_path = RULES_DIR / "python" / "extended2.yaml"
    write_rules(py_path, PYTHON_EXTENDED)

    # JavaScript
    js_path = RULES_DIR / "javascript" / "extended2.yaml"
    write_rules(js_path, JS_EXTENDED)

    # Go
    go_path = RULES_DIR / "go" / "security2.yaml"
    write_rules(go_path, GO_SECURITY)

    # Rust
    rust_path = RULES_DIR / "rust" / "security2.yaml"
    write_rules(rust_path, RUST_SECURITY)

    # TON
    ton_path = RULES_DIR / "ton" / "security.yaml"
    write_rules(ton_path, TON_SECURITY)

    # Solana
    sol_path = RULES_DIR / "solana" / "security.yaml"
    write_rules(sol_path, SOLANA_SECURITY)

    # EVM
    evm_path = RULES_DIR / "evm" / "security2.yaml"
    write_rules(evm_path, EVM_SECURITY)

    total = sum([len(PYTHON_EXTENDED), len(JS_EXTENDED), len(GO_SECURITY),
                 len(RUST_SECURITY), len(TON_SECURITY), len(SOLANA_SECURITY),
                 len(EVM_SECURITY)])
    print(f"\nTotal new rules generated: {total}")

    # Count existing rules
    existing = 0
    for yaml_file in RULES_DIR.rglob("*.yaml"):
        content = yaml_file.read_text()
        count = content.count("\n- id: ") + (1 if content.startswith("- id:") else 0)
        existing += count
    print(f"Total rules in rules/ directory: {existing}")
    return total


if __name__ == "__main__":
    main()
