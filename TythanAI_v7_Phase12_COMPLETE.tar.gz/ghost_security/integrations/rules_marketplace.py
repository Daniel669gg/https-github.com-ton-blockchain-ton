# TythanAI Security Platform
# Copyright (c) 2026 TythanAI Labs
# Licensed under the Business Source License 1.1 (see LICENSE).

"""
integrations/rules_marketplace.py — TythanAI Rules Marketplace
Community rule discovery, installation, and publishing with SQLite + optional ChromaDB.
"""
from __future__ import annotations

import logging
import math
import os
import re
import shutil
import sqlite3
import uuid
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger("tythanai.rules_marketplace")

# ─── Try to import chromadb ────────────────────────────────────────────────────

try:
    import chromadb  # type: ignore
    _CHROMADB_AVAILABLE = True
except ImportError:
    _CHROMADB_AVAILABLE = False
    logger.debug("chromadb not available; falling back to SQLite FTS search")

# ─── Data model ───────────────────────────────────────────────────────────────

@dataclass
class RuleEntry:
    id: str
    name: str
    language: str
    category: str
    severity: str
    author: str
    downloads: int
    rating: float
    path: str
    description: str


# ─── TF-IDF character n-gram embedding (no external ML deps) ──────────────────

def _char_ngrams(text: str, n: int = 3) -> List[str]:
    text = text.lower()
    return [text[i : i + n] for i in range(len(text) - n + 1)]


def _tfidf_vector(text: str, vocab: Optional[Dict[str, int]] = None) -> Dict[str, float]:
    """Compute a simple TF-IDF-like character n-gram vector."""
    ngrams = _char_ngrams(text)
    tf = Counter(ngrams)
    total = sum(tf.values()) or 1
    vec: Dict[str, float] = {ng: count / total for ng, count in tf.items()}
    return vec


def _cosine_sim(a: Dict[str, float], b: Dict[str, float]) -> float:
    keys = set(a) & set(b)
    dot = sum(a[k] * b[k] for k in keys)
    norm_a = math.sqrt(sum(v * v for v in a.values())) or 1.0
    norm_b = math.sqrt(sum(v * v for v in b.values())) or 1.0
    return dot / (norm_a * norm_b)


# ─── Marketplace ──────────────────────────────────────────────────────────────

class RulesMarketplace:
    """
    Community rules marketplace backed by SQLite.
    Optionally uses ChromaDB for semantic search; falls back to LIKE queries.
    """

    _DB_SCHEMA = """
    CREATE TABLE IF NOT EXISTS community_rules (
        id          TEXT PRIMARY KEY,
        name        TEXT NOT NULL,
        language    TEXT NOT NULL DEFAULT '',
        category    TEXT NOT NULL DEFAULT '',
        severity    TEXT NOT NULL DEFAULT 'MEDIUM',
        author      TEXT NOT NULL DEFAULT '',
        downloads   INTEGER NOT NULL DEFAULT 0,
        rating      REAL NOT NULL DEFAULT 0.0,
        path        TEXT NOT NULL DEFAULT '',
        description TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_cr_language ON community_rules(language);
    CREATE INDEX IF NOT EXISTS idx_cr_category ON community_rules(category);
    """

    def __init__(self, base_dir: str = "rules") -> None:
        self._base_dir = Path(base_dir)
        self._base_dir.mkdir(parents=True, exist_ok=True)
        self._db_path = self._base_dir / "marketplace.db"
        self._community_dir = self._base_dir / "community"
        self._community_dir.mkdir(parents=True, exist_ok=True)
        self._init_db()
        self._chroma_client = None
        self._chroma_collection = None
        if _CHROMADB_AVAILABLE:
            self._init_chroma()

    # ── Private helpers ────────────────────────────────────────────────────────

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _init_db(self) -> None:
        with self._conn() as conn:
            for stmt in self._DB_SCHEMA.split(";"):
                stmt = stmt.strip()
                if stmt:
                    conn.execute(stmt)

    def _init_chroma(self) -> None:
        try:
            chroma_path = str(self._base_dir / "chromadb")
            self._chroma_client = chromadb.PersistentClient(path=chroma_path)
            self._chroma_collection = self._chroma_client.get_or_create_collection(
                name="community_rules",
                metadata={"hnsw:space": "cosine"},
            )
        except Exception as exc:
            logger.warning("ChromaDB init failed: %s — using SQLite FTS", exc)
            self._chroma_client = None
            self._chroma_collection = None

    def _row_to_entry(self, row) -> RuleEntry:
        return RuleEntry(
            id=row["id"],
            name=row["name"],
            language=row["language"],
            category=row["category"],
            severity=row["severity"],
            author=row["author"],
            downloads=row["downloads"],
            rating=row["rating"],
            path=row["path"],
            description=row["description"],
        )

    def _embed_and_index(self, entry: RuleEntry) -> None:
        """Index a rule in ChromaDB using character n-gram vectors."""
        if self._chroma_collection is None:
            return
        try:
            text = f"{entry.name} {entry.description} {entry.language} {entry.category}"
            vec = _tfidf_vector(text)
            # ChromaDB needs a list of floats; build a stable vocab from a fixed list
            # or use the dict directly via metadata (embeddings must be dense).
            # Use a deterministic hash-based dense vector of fixed size 256.
            dense = [0.0] * 256
            for ngram, score in vec.items():
                idx = hash(ngram) % 256
                dense[idx] += score
            self._chroma_collection.upsert(
                ids=[entry.id],
                embeddings=[dense],
                metadatas=[{"name": entry.name, "language": entry.language,
                            "category": entry.category, "severity": entry.severity}],
                documents=[text],
            )
        except Exception as exc:
            logger.warning("ChromaDB index failed for %s: %s", entry.id, exc)

    def _search_sqlite(self, query: str, language: Optional[str], category: Optional[str]) -> List[RuleEntry]:
        """SQLite LIKE-based full-text search."""
        conditions = []
        params: list = []

        if query:
            conditions.append("(name LIKE ? OR description LIKE ?)")
            q = f"%{query}%"
            params += [q, q]
        if language:
            conditions.append("language = ?")
            params.append(language)
        if category:
            conditions.append("category = ?")
            params.append(category)

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
        sql = f"SELECT * FROM community_rules {where} ORDER BY downloads DESC, rating DESC LIMIT 50"

        with self._conn() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [self._row_to_entry(r) for r in rows]

    def _search_chroma(self, query: str, language: Optional[str], category: Optional[str]) -> List[RuleEntry]:
        """ChromaDB semantic search using n-gram embeddings."""
        if self._chroma_collection is None:
            return self._search_sqlite(query, language, category)

        try:
            text = query
            dense = [0.0] * 256
            vec = _tfidf_vector(text)
            for ngram, score in vec.items():
                idx = hash(ngram) % 256
                dense[idx] += score

            where_filter: Optional[dict] = None
            if language and category:
                where_filter = {"$and": [{"language": language}, {"category": category}]}
            elif language:
                where_filter = {"language": language}
            elif category:
                where_filter = {"category": category}

            kwargs = {
                "query_embeddings": [dense],
                "n_results": min(50, self._chroma_collection.count() or 1),
            }
            if where_filter:
                kwargs["where"] = where_filter

            results = self._chroma_collection.query(**kwargs)
            ids = results.get("ids", [[]])[0]

            # Fetch full records from SQLite
            if not ids:
                return []
            placeholders = ",".join("?" * len(ids))
            with self._conn() as conn:
                rows = conn.execute(
                    f"SELECT * FROM community_rules WHERE id IN ({placeholders})", ids
                ).fetchall()
            return [self._row_to_entry(r) for r in rows]
        except Exception as exc:
            logger.warning("ChromaDB search failed: %s — falling back to SQLite", exc)
            return self._search_sqlite(query, language, category)

    # ── Public API ─────────────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        language: Optional[str] = None,
        category: Optional[str] = None,
    ) -> List[RuleEntry]:
        """Search for rules. Uses ChromaDB if available, else SQLite LIKE."""
        if _CHROMADB_AVAILABLE and self._chroma_collection is not None and query:
            return self._search_chroma(query, language, category)
        return self._search_sqlite(query, language, category)

    def install(self, rule_id: str, target_dir: Optional[str] = None) -> bool:
        """Copy a rule YAML from marketplace storage to target_dir."""
        target = Path(target_dir) if target_dir else self._community_dir
        target.mkdir(parents=True, exist_ok=True)

        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM community_rules WHERE id = ?", (rule_id,)
            ).fetchone()

        if row is None:
            logger.warning("Rule %s not found in marketplace", rule_id)
            return False

        entry = self._row_to_entry(row)
        src_path = Path(entry.path)

        if src_path.exists():
            dst = target / src_path.name
            shutil.copy2(str(src_path), str(dst))
            logger.info("Installed rule %s to %s", rule_id, dst)
        else:
            # Create a stub YAML if original path doesn't exist
            stub_name = f"{rule_id}.yaml"
            dst = target / stub_name
            dst.write_text(
                f"# Rule: {entry.name}\n"
                f"id: {entry.id}\n"
                f"language: {entry.language}\n"
                f"severity: {entry.severity}\n"
                f"description: {entry.description}\n",
                encoding="utf-8",
            )
            # Update path in DB
            with self._conn() as conn:
                conn.execute(
                    "UPDATE community_rules SET path = ? WHERE id = ?",
                    (str(dst), rule_id),
                )
            logger.info("Created stub for rule %s at %s", rule_id, dst)

        # Update downloads counter
        with self._conn() as conn:
            conn.execute(
                "UPDATE community_rules SET downloads = downloads + 1 WHERE id = ?",
                (rule_id,),
            )
        return True

    def publish(self, rule_path: str, metadata: dict) -> RuleEntry:
        """Validate and publish a new rule to the marketplace."""
        path = Path(rule_path)

        # Validate YAML syntax
        try:
            import yaml  # type: ignore
            with path.open() as fh:
                yaml.safe_load(fh)
        except ImportError:
            # No PyYAML — basic check
            content = path.read_text(errors="replace") if path.exists() else ""
            if not content:
                logger.warning("Rule file is empty: %s", rule_path)
        except Exception as exc:
            raise ValueError(f"Invalid YAML in {rule_path}: {exc}") from exc

        rule_id = metadata.get("id") or str(uuid.uuid4())
        entry = RuleEntry(
            id=rule_id,
            name=metadata.get("name", path.stem),
            language=metadata.get("language", ""),
            category=metadata.get("category", ""),
            severity=metadata.get("severity", "MEDIUM"),
            author=metadata.get("author", ""),
            downloads=metadata.get("downloads", 0),
            rating=float(metadata.get("rating", 0.0)),
            path=str(path),
            description=metadata.get("description", ""),
        )

        with self._conn() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO community_rules
                    (id, name, language, category, severity, author, downloads, rating, path, description)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    entry.id, entry.name, entry.language, entry.category,
                    entry.severity, entry.author, entry.downloads, entry.rating,
                    entry.path, entry.description,
                ),
            )

        if _CHROMADB_AVAILABLE and self._chroma_collection is not None:
            self._embed_and_index(entry)

        logger.info("Published rule %s (%s)", entry.id, entry.name)
        return entry

    def update_all(self) -> dict:
        """
        Check all installed rules for updates.
        In this implementation, re-indexes all rules in ChromaDB if available.
        Returns {updated: N, skipped: M}.
        """
        with self._conn() as conn:
            rows = conn.execute("SELECT * FROM community_rules").fetchall()

        updated = 0
        skipped = 0
        for row in rows:
            entry = self._row_to_entry(row)
            src = Path(entry.path)
            if src.exists():
                if _CHROMADB_AVAILABLE and self._chroma_collection is not None:
                    self._embed_and_index(entry)
                updated += 1
            else:
                skipped += 1

        return {"updated": updated, "skipped": skipped}

    def list_installed(self) -> List[RuleEntry]:
        """Return all rules in the marketplace database."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM community_rules ORDER BY downloads DESC"
            ).fetchall()
        return [self._row_to_entry(r) for r in rows]
