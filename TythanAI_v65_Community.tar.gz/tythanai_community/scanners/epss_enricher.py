"""
TythanAI Community — EPSS Enricher

Enriches CVE findings with EPSS exploit probability scores.

CISA KEV (Known Exploited Vulnerabilities) flag is available in TythanAI Pro.
See https://tythanai.io/#pricing
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from typing import Dict, List, Optional, Set, Tuple

EPSS_API = "https://api.first.org/data/v1/epss"
_TIMEOUT = 10
_BATCH   = 100


class EPSSEnricher:
    """Adds EPSS score and percentile to CVE findings."""

    def __init__(self) -> None:
        self._cache: Dict[str, Tuple[float, float]] = {}

    def is_online(self) -> bool:
        try:
            urllib.request.urlopen(
                f"{EPSS_API}?cve=CVE-2021-44228", timeout=5
            )
            return True
        except Exception:
            return False

    @staticmethod
    def _cve_id(f: dict) -> str:
        """Extract CVE ID from a finding, checking multiple field names."""
        for key in ("cve_id", "cve", "id"):
            val = str(f.get(key, ""))
            if val.startswith("CVE-"):
                return val
        return ""

    def enrich(self, findings: List[dict]) -> List[dict]:
        """Add epss_score, epss_percentile, exploit_status, priority_score to each finding."""
        cves = list({self._cve_id(f) for f in findings if self._cve_id(f)})
        scores = self._fetch_epss(cves) if cves else {}

        for f in findings:
            cve = self._cve_id(f)
            if cve and cve in scores:
                f["epss_score"]      = scores[cve][0]
                f["epss_percentile"] = scores[cve][1]
                f["exploit_status"]  = self._label(scores[cve][0])
            else:
                f.setdefault("epss_score",      0.0)
                f.setdefault("epss_percentile",  0.0)
                f.setdefault("exploit_status",  "unknown")
            f["priority_score"] = self._priority(f)
        return sorted(findings, key=lambda x: x.get("priority_score", 0), reverse=True)

    def enrich_single(self, cve_id: str) -> dict:
        scores = self._fetch_epss([cve_id])
        if cve_id in scores:
            s, p = scores[cve_id]
            return {"epss_score": s, "epss_percentile": p,
                    "exploit_status": self._label(s)}
        return {"epss_score": 0.0, "epss_percentile": 0.0,
                "exploit_status": "unknown"}

    # ── internals ──────────────────────────────────────────────────────
    _SEV_BASE = {"CRITICAL": 100, "HIGH": 60, "MEDIUM": 30, "LOW": 10, "INFO": 0}

    def _priority(self, f: dict) -> float:
        sev   = str(f.get("severity", "")).upper()
        epss  = float(f.get("epss_score", 0.0))
        base  = self._SEV_BASE.get(sev, 0)
        return round(base + epss * 40, 2)
    def _fetch_epss(self, cves: List[str]) -> Dict[str, Tuple[float, float]]:
        result: Dict[str, Tuple[float, float]] = {}
        # Return cached first
        needed = []
        for c in cves:
            if c in self._cache:
                result[c] = self._cache[c]
            else:
                needed.append(c)
        if not needed:
            return result

        for i in range(0, len(needed), _BATCH):
            batch = needed[i:i + _BATCH]
            param = ",".join(batch)
            url   = f"{EPSS_API}?cve={param}"
            try:
                with urllib.request.urlopen(url, timeout=_TIMEOUT) as r:
                    data = json.loads(r.read())
                for item in data.get("data", []):
                    cve   = item.get("cve", "")
                    score = float(item.get("epss", 0))
                    pct   = float(item.get("percentile", 0))
                    self._cache[cve] = (score, pct)
                    result[cve]      = (score, pct)
                time.sleep(0.05)
            except Exception:
                pass
        return result

    @staticmethod
    def _label(score: float) -> str:
        if score >= 0.7:
            return "critical_exploit_risk"
        if score >= 0.4:
            return "high_exploit_risk"
        if score >= 0.1:
            return "moderate_exploit_risk"
        return "low_exploit_risk"
