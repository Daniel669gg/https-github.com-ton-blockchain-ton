"""
TythanAI Community — Fix models + VerifiedFixEngine stub.

Data models (VerifiedFix, FixStatus, FixConfidenceScore) are fully included.
AI-powered automated fix generation and verification is a TythanAI Pro feature.
See https://tythanai.io/#pricing
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Fix lifecycle models (included in Community)
# ---------------------------------------------------------------------------

class FixStatus(str, Enum):
    PROPOSED  = "proposed"
    VALIDATED = "validated"
    REJECTED  = "rejected"
    VERIFIED  = "verified"


@dataclass
class BuildResult:
    language:    str
    success:     bool
    errors:      List[str] = field(default_factory=list)
    warnings:    List[str] = field(default_factory=list)
    duration_ms: float = 0.0

    def to_dict(self) -> dict:
        return {
            "language": self.language,
            "success":  self.success,
            "errors":   self.errors,
            "warnings": self.warnings,
            "duration_ms": self.duration_ms,
        }


@dataclass
class FixTestRunResult:
    tests_run:       int = 0
    tests_passed:    int = 0
    tests_failed:    int = 0
    coverage_delta:  float = 0.0
    new_errors:      List[str] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return self.tests_failed == 0 and not self.new_errors

    def to_dict(self) -> dict:
        return {
            "tests_run":      self.tests_run,
            "tests_passed":   self.tests_passed,
            "tests_failed":   self.tests_failed,
            "coverage_delta": self.coverage_delta,
            "success":        self.success,
            "new_errors":     self.new_errors,
        }


@dataclass
class FixConfidenceScore:
    build_success:        float = 0.0
    test_success:         float = 0.0
    reachability_removed: float = 0.0
    verification_passed:  float = 0.0
    no_regression:        float = 0.0

    _W_BUILD  = 0.15
    _W_TEST   = 0.20
    _W_REACH  = 0.35
    _W_VERIFY = 0.20
    _W_REG    = 0.10

    @property
    def total_score(self) -> float:
        return round(
            self.build_success          * self._W_BUILD
            + self.test_success         * self._W_TEST
            + self.reachability_removed * self._W_REACH
            + self.verification_passed  * self._W_VERIFY
            + self.no_regression        * self._W_REG,
            4,
        )

    def to_dict(self) -> dict:
        return {
            "build_success":        self.build_success,
            "test_success":         self.test_success,
            "reachability_removed": self.reachability_removed,
            "verification_passed":  self.verification_passed,
            "no_regression":        self.no_regression,
            "total_score":          self.total_score,
        }


@dataclass
class VerifiedFix:
    """Fix record tracking the full lifecycle from proposal to verification."""
    fix_id:      str
    finding_id:  str
    cwe_id:      str
    severity:    str
    file_path:   str

    suggested_fix:                  str = ""
    verified_fix:                   Optional[str] = None
    fix_status:                     FixStatus = FixStatus.PROPOSED
    fix_confidence:                 float = 0.0
    build_result:                   Optional[BuildResult] = None
    test_result:                    Optional[FixTestRunResult] = None
    reachability_removed:           bool = False
    regression_detected:            bool = False
    vulnerability_confirmed_fixed:  bool = False
    confidence_score:               Optional[FixConfidenceScore] = None
    attack_paths_removed:           List[str] = field(default_factory=list)
    new_attack_paths:               List[str] = field(default_factory=list)
    validation_notes:               List[str] = field(default_factory=list)
    created_at:                     str = ""
    validated_at:                   str = ""

    def to_dict(self) -> dict:
        return {
            "fix_id":        self.fix_id,
            "finding_id":    self.finding_id,
            "cwe_id":        self.cwe_id,
            "severity":      self.severity,
            "file_path":     self.file_path,
            "fix_status":    self.fix_status.value,
            "fix_confidence": self.fix_confidence,
            "suggested_fix": self.suggested_fix[:500] if self.suggested_fix else "",
            "reachability_removed":          self.reachability_removed,
            "regression_detected":           self.regression_detected,
            "vulnerability_confirmed_fixed": self.vulnerability_confirmed_fixed,
            "attack_paths_removed":   self.attack_paths_removed,
            "build_result":  self.build_result.to_dict() if self.build_result else None,
            "test_result":   self.test_result.to_dict() if self.test_result else None,
            "confidence_score": self.confidence_score.to_dict() if self.confidence_score else None,
            "validation_notes": self.validation_notes,
            "created_at":    self.created_at,
            "validated_at":  self.validated_at,
        }


@dataclass
class RemediationReport:
    report_id:            str
    generated_at:         str
    total_fixes:          int = 0
    verified_count:       int = 0
    validated_count:      int = 0
    rejected_count:       int = 0
    proposed_count:       int = 0
    attack_paths_removed: int = 0
    regressions_detected: int = 0
    average_confidence:   float = 0.0
    fixes:                List[VerifiedFix] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "report_id":            self.report_id,
            "generated_at":         self.generated_at,
            "total_fixes":          self.total_fixes,
            "verified_count":       self.verified_count,
            "validated_count":      self.validated_count,
            "rejected_count":       self.rejected_count,
            "proposed_count":       self.proposed_count,
            "attack_paths_removed": self.attack_paths_removed,
            "regressions_detected": self.regressions_detected,
            "average_confidence":   self.average_confidence,
            "fixes": [f.to_dict() for f in self.fixes],
        }

    def to_markdown(self) -> str:
        lines = [
            f"# Remediation Report — {self.generated_at}",
            f"\nTotal fixes: **{self.total_fixes}**  |  "
            f"Proposed: {self.proposed_count}  |  "
            f"Validated: {self.validated_count}  |  "
            f"Verified: {self.verified_count}",
            "",
        ]
        for fix in self.fixes:
            lines.append(f"## {fix.fix_id} ({fix.cwe_id})")
            lines.append(f"- Status: {fix.fix_status.value}")
            lines.append(f"- Confidence: {fix.fix_confidence:.2f}")
            if fix.suggested_fix:
                lines.append(f"- Fix hint: `{fix.suggested_fix[:120]}`")
            lines.append("")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# VerifiedFixEngine — Community stub
# ---------------------------------------------------------------------------

class VerifiedFixEngine:
    """
    Community stub.

    Template-based fix hints are available via FixBridge.get_template_fix().
    AI-powered automated fix generation and PR creation require TythanAI Pro.
    See https://tythanai.io/#pricing
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        logger.debug("VerifiedFixEngine: community mode (template fixes only)")

    def verify_fix(self, finding: Any, suggested_fix: str = "", original_code: str = "") -> VerifiedFix:
        """Return a template-level VerifiedFix without AI verification."""
        created = datetime.now(timezone.utc).isoformat()
        return VerifiedFix(
            fix_id=f"community_{getattr(finding, 'finding_id', 'unknown')}",
            finding_id=getattr(finding, "finding_id", ""),
            cwe_id=getattr(finding, "cwe_id", ""),
            severity=getattr(finding, "severity", ""),
            file_path=getattr(finding, "file_path", ""),
            suggested_fix=suggested_fix,
            fix_status=FixStatus.PROPOSED,
            fix_confidence=0.5,
            validation_notes=["Template fix — upgrade to Pro for AI-verified auto-fix"],
            created_at=created,
        )

    def batch_fix(self, findings: List[Any]) -> RemediationReport:
        created = datetime.now(timezone.utc).isoformat()
        return RemediationReport(
            report_id=f"community_report_{created}",
            generated_at=created,
            total_fixes=len(findings),
            proposed_count=len(findings),
        )

    def verify_batch(self, findings: List[Any], patches: List[str]) -> List[VerifiedFix]:
        return [
            self.verify_fix(f, p)
            for f, p in zip(findings, patches)
        ]

    def generate_report(self, fixes: List[VerifiedFix]) -> RemediationReport:
        created = datetime.now(timezone.utc).isoformat()
        avg = sum(f.fix_confidence for f in fixes) / len(fixes) if fixes else 0.0
        return RemediationReport(
            report_id=f"community_report_{created}",
            generated_at=created,
            total_fixes=len(fixes),
            proposed_count=sum(1 for f in fixes if f.fix_status == FixStatus.PROPOSED),
            validated_count=sum(1 for f in fixes if f.fix_status == FixStatus.VALIDATED),
            verified_count=sum(1 for f in fixes if f.fix_status == FixStatus.VERIFIED),
            rejected_count=sum(1 for f in fixes if f.fix_status == FixStatus.REJECTED),
            average_confidence=round(avg, 4),
            fixes=fixes,
        )
