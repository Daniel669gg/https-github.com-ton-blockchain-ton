"""TythanAI Platform — core/verifier"""
