# TythanAI Dead Code Report

**Date:** 2026-06-02

## Summary

No definitively dead modules found. All major modules in agents/, runtime/, integrations/
have active references.

## Archived (Phase 3)

Files moved to archive/legacy/ during this refactoring:

| File | Reason |
|------|--------|
| `ghost_cli.py` | Superseded by `cli/tythanai_cli.py` (restored for compat) |
| `ghost_cli_main.py` | Legacy monolithic CLI (restored for compat) |
| `ghost_security_cli.py` | Redundant CLI entry point |
| `sentinelops_cli.py` | Pre-TythanAI branding, superseded |
| `verifier/fp_reducer_v2.py` | Versioned file (restored — actively imported by tests) |
| `runtime/providers/ollama_provider_v2.py` | Versioned file (archived) |

## Candidates for Future Removal

| Module | Why | Action |
|--------|-----|--------|
| `backend/scanners/` | Superseded by `scanners/` | Consolidate in v7 |
| `core/` (root) | Superseded by `backend/core/` | Migrate in v7 |
| `verifier/fp_reducer_v2.py` | Has canonical in `backend/core/fp_reducer.py` | Update tests → remove |
| `remediation/` (root) | Superseded by `backend/core/remediation/` | Migrate in v7 |
