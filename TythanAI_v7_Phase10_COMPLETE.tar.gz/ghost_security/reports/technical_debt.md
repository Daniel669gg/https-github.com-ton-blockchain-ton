# TythanAI Technical Debt Report

**Date:** 2026-06-02

## High Priority

| Issue | Location | Impact |
|-------|----------|--------|
| Dual scanner architecture | `scanners/` vs `backend/scanners/` | Maintenance overhead, confusion |
| Large rule files (2400+ lines) | `backend/scanners/rules/` | Hard to navigate, slow imports |
| Legacy CLI files at root | `ghost_cli.py`, `ghost_cli_main.py` | Confusing entry points |
| Mixed agent generations | `agents/` vs `backend/agents/` | No unified interface |
| `core/` vs `backend/core/` duplication | Multiple paths | Import confusion |

## Medium Priority

| Issue | Location | Impact |
|-------|----------|--------|
| Broad `except Exception` usage | Throughout | Hides real errors |
| Missing type annotations | ~40% of functions | mypy cannot validate |
| FastAPI routes without auth | Several endpoints | Security risk |
| No rate limiting on API | `api/server.py` | DoS risk |

## Low Priority

| Issue | Location | Impact |
|-------|----------|--------|
| Wildcard imports | Several scanners | Name pollution |
| Inconsistent docstring style | Throughout | Developer experience |
| Benchmark corpus mixed with production | `backend/core/benchmarks/` | Confusion |

## Estimated Remediation Effort

| Category | Files | Days |
|----------|-------|------|
| Scanner consolidation | 12 | 3-5 |
| Rule file splitting | 2 | 1-2 |
| Agent unification | 8 | 3-4 |
| Type annotation coverage | 40% of codebase | 5-10 |
| FastAPI hardening | 6 | 2-3 |
| **Total** | | **14-24 days** |
