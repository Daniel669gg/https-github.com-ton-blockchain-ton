# TythanAI Import Cleanup Report

**Date:** 2026-06-02

## Wildcard Imports Found

| File | Import |
|------|--------|
| `cli/ghostsec_cli.py` (shim) | `from cli.tythanai_cli import *` |

The shim is intentional. No other wildcard imports in production code.

## Import Path Normalization (Phase 2 Fix)

During brand consolidation, the replacer incorrectly changed internal import paths:
- `from ghost_security.backend.xyz` → `from tythanai.backend.xyz` (wrong)
- Correct form: `from backend.xyz import ...`

Fixed in 4 files:
- `telemetry/otel_setup.py`
- `backend/sbom/spdx.py`
- `tests/test_cve_intel.py`
- `archive/legacy/ollama_provider_v2.py`

## Unused Import Detection

Run with: `ruff check . --select F401` to get precise unused import list.
Approximate scope based on codebase patterns: ~150-200 unused imports.

## Recommendations

1. Run `ruff check . --select F401 --fix` for automated removal
2. Add `ruff` to CI pipeline to prevent unused import accumulation
3. Convert remaining wildcard imports to explicit (only 1 in shim)
