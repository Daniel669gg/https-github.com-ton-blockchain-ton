# TythanAI Legacy Cleanup Report

**Date:** 2026-06-02

## Files Archived

| Original Path | Archive Path | Reason |
|--------------|-------------|--------|
| `ghost_cli.py` | `archive/legacy/ghost_cli.py` | Superseded by tythanai_cli |
| `ghost_cli_main.py` | `archive/legacy/ghost_cli_main.py` | Legacy monolithic CLI |
| `ghost_security_cli.py` | `archive/legacy/ghost_security_cli.py` | Old brand name |
| `sentinelops_cli.py` | `archive/legacy/sentinelops_cli.py` | Pre-TythanAI era |
| `runtime/providers/ollama_provider_v2.py` | `archive/legacy/` | Versioned, v1 is canonical |

## Files Restored After Archive

| File | Why Restored |
|------|-------------|
| `ghost_cli.py` | `test_eleven_features.py` imports it directly |
| `ghost_cli_main.py` | `test_new_cli_commands.py` imports `cmd_ton`, `cmd_k8s`, etc. |
| `verifier/fp_reducer_v2.py` | `test_fp_reducer_deep.py`, `test_v13_verifier.py` import it |

**Next step:** Update the tests to use modern API, then archive these for good.

## Versioned Files Identified

| File | Active? | Canonical Version |
|------|---------|-----------------|
| `verifier/fp_reducer_v2.py` | Yes (tests) | `backend/core/fp_reducer.py` |
| `runtime/providers/ollama_provider_v2.py` | No | `runtime/providers/ollama_provider.py` |

## Test Migration Required

To fully remove `ghost_cli_main.py` and `ghost_cli.py`:

1. `tests/test_new_cli_commands.py` → update to use `from cli.tythanai_cli import ...`
2. `tests/test_eleven_features.py` → update to use `from cli.tythanai_cli import ...`
3. `tests/test_fp_reducer_deep.py` → update to use `from backend.core.fp_reducer import ...`
4. `tests/test_v13_verifier.py` → update to use `from backend.core.fp_reducer import ...`

This is a pre-condition for clean removal of the legacy files.
