# TythanAI Duplicates Report

**Date:** 2026-06-02

## Duplicate Module Groups

### 1. Supply Chain Scanner (3 implementations)
- `sbom/supply_chain.py`
- `scanners/supply_chain_scanner.py` ← canonical
- `backend/scanners/supply_chain.py`

**Action:** Consolidate to `scanners/supply_chain_scanner.py` in v7.

### 2. Container Scanner (2 implementations)
- `scanners/container_scanner.py` ← canonical
- `backend/scanners/container_scanner.py`

**Action:** Consolidate to `scanners/container_scanner.py` in v7.

### 3. IAC Scanner (2 implementations)
- `scanners/iac_scanner.py` ← canonical
- `backend/scanners/iac_scanner.py`

**Action:** Consolidate to `scanners/iac_scanner.py` in v7.

### 4. CriticAgent (2 implementations)
- `agents/critic_agent.py`
- `backend/agents/reasoning/critic_agent.py` ← canonical

**Action:** Remove root-level `agents/critic_agent.py` in v7.

### 5. Taint Analysis (4 implementations)
- `core/ast_engine/taint_tracker.py`
- `core/taint/taint_engine.py`
- `core/analysis/taint_tracker.py`
- `core/analysis/cross_file_taint.py`

**Action:** Evaluate which is most complete, consolidate in v7.

## FP Reducer Duplication
- `verifier/fp_reducer_v2.py` — legacy v2 implementation
- `backend/core/fp_reducer.py` — canonical implementation

**Action:** Update `test_fp_reducer_deep.py` and `test_v13_verifier.py` to use
`backend/core/fp_reducer.py`, then remove `verifier/fp_reducer_v2.py`.

## Impact

| Duplicate Group | Total Extra Lines | Maintenance Risk |
|----------------|-------------------|-----------------|
| Supply Chain Scanner | ~800 | HIGH |
| Container/IAC Scanner | ~600 | MEDIUM |
| CriticAgent | ~300 | MEDIUM |
| Taint Analysis | ~1200 | HIGH |
| **Total** | **~2900** | |
