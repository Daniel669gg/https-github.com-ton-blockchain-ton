# TythanAI Exception Handling Audit

**Date:** 2026-06-02

## Summary

| Pattern | Occurrences |
|---------|------------|
| `except Exception` (broad) | 1 |
| `except Exception as e` | ~1 |
| Specific exceptions | needs counting |

## Hotspots (files with most broad catches)

Priority files for exception handling improvement:
- `backend/agents/incident_response.py` — incident handling, should be specific
- `api/server.py` — API layer, HTTP exceptions should be explicit
- `scanners/security_pipeline.py` — scanner errors should be typed
- `backend/core/engine/unified_scan_engine.py` — scanner coordination

## Recommended Replacements

| Current | Replace With |
|---------|-------------|
| `except Exception` in HTTP handlers | `except (HTTPException, ValidationError)` |
| `except Exception` in DB operations | `except (sqlite3.OperationalError, KeyError)` |
| `except Exception` in scanner calls | `except (TimeoutError, OSError, subprocess.SubprocessError)` |
| `except Exception` in YAML parsing | `except (yaml.YAMLError, ValueError)` |
| `except Exception` in network calls | `except (urllib.error.URLError, TimeoutError, ConnectionError)` |

## Exceptions to Keep

Broad `except Exception` is acceptable in:
- Plugin loader (unknown plugin types)
- Agent orchestrator top-level (must not crash)
- CLI main() entry point (user-facing error display)

## Action Plan

Phase priority: start with `api/server.py` (security impact), then
`backend/core/engine/unified_scan_engine.py` (reliability impact).
