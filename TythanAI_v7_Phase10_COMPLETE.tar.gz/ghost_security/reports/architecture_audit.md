# TythanAI Architecture Audit

**Date:** 2026-06-02  
**Codebase:** 565 Python files, 2932 tests

## Current Structure

```
tythanai/
├── api/            — FastAPI server + v2_router (2080 + 1342 lines)
├── backend/
│   ├── agents/     — Security agents (12 agents)
│   ├── analysis/   — Attack graph, compliance, dataflow
│   ├── core/       — Engine, CPG, remediation, benchmarks
│   ├── scanners/   — Rules: python_rules.py (1867), js_rules.py (2432)
│   ├── sandbox/    — Malware analyzer
│   └── verification/ — Exploit engine, verifiers
├── blockchain/     — TON, EVM, Solidity, FunC scanners
├── cli/            — tythanai_cli.py (primary), ghostsec_cli.py (shim)
├── cloud/          — AWS, GCP, Azure, K8s scanners
├── config/         — Configuration models
├── core/           — Legacy core (AST, taint, symbolic)
├── integrations/   — CI/CD generators, GitHub, Jira
├── plugins/        — Plugin loader
├── remediation/    — Patch generator (legacy path)
├── reports/        — SARIF, HTML reporters
├── runtime/        — LLM providers, inference cache
├── scanners/       — Primary scanners (Semgrep, OSV, EPSS, AST, OWASP)
├── telemetry/      — OpenTelemetry setup
├── tests/          — 140 test files
└── verifier/       — FP reducer, confidence engine
```

## Duplicate Module Findings

### Critical Duplicates (require consolidation)

| Component | Locations | Recommendation |
|-----------|-----------|----------------|
| SupplyChainScanner | `sbom/supply_chain.py`, `scanners/supply_chain_scanner.py`, `backend/scanners/supply_chain.py` | Consolidate into `scanners/supply_chain_scanner.py` |
| Container Scanner | `scanners/container_scanner.py`, `backend/scanners/container_scanner.py` | Consolidate into `scanners/` |
| IAC Scanner | `scanners/iac_scanner.py`, `backend/scanners/iac_scanner.py` | Consolidate into `scanners/` |
| CriticAgent | `agents/critic_agent.py`, `backend/agents/reasoning/critic_agent.py` | Use `backend/agents/reasoning/critic_agent.py` |
| TaintFlow | 4 locations across `core/` | Consolidate into `backend/analysis/dataflow.py` |

### Dual Scanner Architecture

The codebase has two scanner trees that evolved independently:
- `scanners/` — Phase 6 modern scanners (Semgrep, OSV, EPSS, OWASP)
- `backend/scanners/` — Older scanners with different interfaces

**Recommendation:** Keep `scanners/` as primary, deprecate `backend/scanners/` for next major version.

## Large Files (>800 lines)

| File | Lines | Priority |
|------|-------|----------|
| `backend/scanners/rules/javascript_rules.py` | 2432 | Split by rule category |
| `backend/scanners/rules/python_rules.py` | 1867 | Split by rule category |
| `backend/core/benchmarks/juliet_corpus.py` | 1789 | Archive or split |
| `backend/core/supply_chain/dependency_taint.py` | 1611 | Split into submodules |
| `backend/core/benchmarks/owasp_corpus.py` | 1590 | Archive or split |
| `backend/agents/skills_loader.py` | 1439 | Split by skill domain |
| `backend/agents/incident_response.py` | 1381 | Extract handlers |
| `backend/api/v2_router.py` | 1342 | Split into route modules |
| `backend/agents/multi_agent_orchestrator.py` | 1339 | Split into smaller agents |
| `backend/core/cpg/query_engine.py` | 1325 | Split by query type |

## Circular Import Risk

No direct circular imports detected. Risk areas:
- `backend/core/` ↔ `backend/agents/` (monitor)
- `scanners/` ↔ `backend/core/engine/` (currently safe via lazy imports)

## Recommendations for Phase 7+

1. **Consolidate duplicate scanners** into a single `scanners/` namespace
2. **Split rule files** into domain-specific modules (`python_rules/injection.py`, etc.)
3. **Unify agent interface** behind `BaseAgent` protocol
4. **Move `core/` legacy tree** into `backend/core/` to eliminate dual structure
