# TythanAI Security Hardening Report

**Date:** 2026-06-02

## Findings Summary

| Pattern | Found | Safe | Unsafe | Fixed |
|---------|-------|------|--------|-------|
| `eval()` | 15 refs | 15 | 0 | N/A |
| `exec()` | 8 refs | 8 | 0 | N/A |
| `yaml.load()` | 20 refs | 20 | 0 | N/A |
| `pickle.loads()` | 12 refs | 12 | 0 | N/A |

**Result: No unsafe patterns in production code.** All occurrences of the above
patterns are in one of:
1. String literals describing CVE/vulnerability patterns (not executed)
2. Intentional benchmark corpus files (`backend/core/benchmarks/`) that simulate
   vulnerable code for testing — these MUST remain as-is
3. Rule detection patterns in `backend/scanners/rules/` and `backend/verification/`
4. Comments and documentation explaining what to avoid

## Production yaml.load() Status
All production YAML parsing uses `yaml.safe_load()` throughout the codebase. ✓

## Benchmark Corpus Notes
Files in `backend/core/benchmarks/` intentionally contain vulnerable patterns
(including `yaml.load()`, `pickle.loads()`) as test fixtures. These are:
- Isolated from production paths
- Used only by test suites
- Correctly flagged by TythanAI's own scanner as vulnerable

Do NOT "fix" benchmark corpus files — they test the scanner's detection capability.

## FastAPI Security (preliminary)
See `reports/api_security.md` for full FastAPI endpoint audit.

Key findings:
- Several endpoints lack authentication middleware
- Missing rate limiting on public endpoints
- Request validation is inconsistent (some use Pydantic, some raw dicts)

## Recommendations
1. Add `slowapi` rate limiting to all public API endpoints
2. Enforce `Depends(get_current_user)` on all protected routes
3. Use `yaml.safe_load()` in all config parsing (already done ✓)
4. Add input validation for all scanner targets (path traversal prevention)
