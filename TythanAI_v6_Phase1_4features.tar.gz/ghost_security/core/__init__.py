"""TythanAI Platform — core"""
