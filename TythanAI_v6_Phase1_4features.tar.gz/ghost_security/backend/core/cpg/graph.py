"""
backend/core/cpg/graph.py — Code Property Graph node/edge data structures.

A CPG unifies:
  AST  (syntactic structure)
  CFG  (control flow — dominance, reachability)
  DFG  (data flow — def-use chains)
  CG   (call graph — interprocedural edges)
  PDG  (program dependence — combined control + data deps)

Every node and edge carries typed properties so graph queries
can traverse the unified structure for vulnerability detection.
"""

from __future__ import annotations

import uuid
from collections import deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Set


# ---------------------------------------------------------------------------
# Node and Edge type enumerations
# ---------------------------------------------------------------------------

class CPGNodeType(Enum):
    AST_NODE   = "AST_NODE"    # Generic AST node (expression, statement, …)
    CFG_ENTRY  = "CFG_ENTRY"   # Synthetic function-entry node
    CFG_EXIT   = "CFG_EXIT"    # Synthetic function-exit node
    CFG_BLOCK  = "CFG_BLOCK"   # Basic block (one or more sequential statements)
    DFG_DEF    = "DFG_DEF"     # Variable definition site
    DFG_USE    = "DFG_USE"     # Variable use site
    CG_CALL    = "CG_CALL"     # Call-site node
    CG_RETURN  = "CG_RETURN"   # Return node within a function
    PDG_NODE   = "PDG_NODE"    # Program-dependence node


class CPGEdgeType(Enum):
    AST_CHILD        = "AST_CHILD"        # Parent → child in the AST
    AST_PARENT       = "AST_PARENT"       # Child → parent in the AST
    CFG_NEXT         = "CFG_NEXT"         # Sequential control flow
    CFG_BRANCH_TRUE  = "CFG_BRANCH_TRUE"  # True branch of a conditional
    CFG_BRANCH_FALSE = "CFG_BRANCH_FALSE" # False branch of a conditional
    DFG_FLOW         = "DFG_FLOW"         # Def → use data-flow edge
    DFG_KILL         = "DFG_KILL"         # Definition that kills (overwrites) another
    CG_CALL          = "CG_CALL"          # Call site → function definition
    CG_RETURN        = "CG_RETURN"        # Return site back to call site
    PDG_DATA         = "PDG_DATA"         # Data dependence in PDG
    PDG_CONTROL      = "PDG_CONTROL"      # Control dependence in PDG


# ---------------------------------------------------------------------------
# Core data structures
# ---------------------------------------------------------------------------

@dataclass
class CPGNode:
    """A single node in the Code Property Graph."""

    node_id:   str
    node_type: CPGNodeType
    ast_type:  str                         # Python AST class name, e.g. "Assign"
    code:      str                         # Source-level snippet / pretty text
    file:      str                         # Absolute path of the source file
    line:      int                         # 1-based line number (0 if synthetic)
    col:       int                         # 0-based column offset (0 if synthetic)
    properties: Dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def is_taint_source(self) -> bool:
        """Return True when this node represents a common taint source."""
        taint_source_patterns = (
            "request.args",
            "request.form",
            "request.json",
            "request.data",
            "request.get_json",
            "request.values",
            "request.cookies",
            "request.headers",
            "request.files",
            "input(",
            "sys.stdin",
            "os.environ",
            "environ.get",
            "getenv(",
        )
        c = self.code
        return any(p in c for p in taint_source_patterns)

    def is_taint_sink(self) -> bool:
        """Return True when this node represents a dangerous sink."""
        sink_patterns = (
            "cursor.execute",
            ".execute(",
            "os.system(",
            "subprocess.run(",
            "subprocess.Popen(",
            "subprocess.call(",
            "check_output(",
            "eval(",
            "exec(",
            "open(",
            "pickle.loads(",
            "yaml.load(",
            "shutil.rmtree(",
        )
        c = self.code
        return any(p in c for p in sink_patterns)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_id":    self.node_id,
            "node_type":  self.node_type.value,
            "ast_type":   self.ast_type,
            "code":       self.code,
            "file":       self.file,
            "line":       self.line,
            "col":        self.col,
            "properties": self.properties,
        }


@dataclass
class CPGEdge:
    """A directed edge in the Code Property Graph."""

    edge_id:   str
    src_id:    str
    dst_id:    str
    edge_type: CPGEdgeType
    properties: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "edge_id":    self.edge_id,
            "src_id":     self.src_id,
            "dst_id":     self.dst_id,
            "edge_type":  self.edge_type.value,
            "properties": self.properties,
        }


# ---------------------------------------------------------------------------
# The unified Code Property Graph
# ---------------------------------------------------------------------------

class CodePropertyGraph:
    """
    Unified Code Property Graph.

    Stores nodes in a dict keyed by node_id and edges in a flat list.
    Maintains adjacency lists for O(1) neighbour lookup.
    """

    def __init__(self) -> None:
        self.nodes: Dict[str, CPGNode]        = {}
        self.edges: List[CPGEdge]             = []
        self._adj:  Dict[str, List[CPGEdge]]  = {}   # outgoing
        self._radj: Dict[str, List[CPGEdge]]  = {}   # incoming

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------

    def add_node(self, node: CPGNode) -> None:
        """Insert a node; silently skip if the id already exists."""
        if node.node_id in self.nodes:
            return
        self.nodes[node.node_id] = node
        self._adj.setdefault(node.node_id, [])
        self._radj.setdefault(node.node_id, [])

    def add_edge(self, edge: CPGEdge) -> None:
        """Insert a directed edge; both endpoint nodes must exist."""
        if edge.src_id not in self.nodes:
            raise ValueError(f"Source node {edge.src_id!r} not in graph")
        if edge.dst_id not in self.nodes:
            raise ValueError(f"Destination node {edge.dst_id!r} not in graph")

        self.edges.append(edge)
        self._adj.setdefault(edge.src_id, []).append(edge)
        self._radj.setdefault(edge.dst_id, []).append(edge)

    # ------------------------------------------------------------------
    # Traversal helpers
    # ------------------------------------------------------------------

    def successors(
        self,
        node_id: str,
        edge_type: Optional[CPGEdgeType] = None,
    ) -> List[CPGNode]:
        """Return all nodes reachable via one outgoing edge from *node_id*."""
        result: List[CPGNode] = []
        for edge in self._adj.get(node_id, []):
            if edge_type is None or edge.edge_type == edge_type:
                dst = self.nodes.get(edge.dst_id)
                if dst is not None:
                    result.append(dst)
        return result

    def predecessors(
        self,
        node_id: str,
        edge_type: Optional[CPGEdgeType] = None,
    ) -> List[CPGNode]:
        """Return all nodes with an incoming edge into *node_id*."""
        result: List[CPGNode] = []
        for edge in self._radj.get(node_id, []):
            if edge_type is None or edge.edge_type == edge_type:
                src = self.nodes.get(edge.src_id)
                if src is not None:
                    result.append(src)
        return result

    def reachable(
        self,
        start_id: str,
        edge_types: Optional[List[CPGEdgeType]] = None,
        max_depth: int = 50,
    ) -> Set[str]:
        """
        Return the set of node IDs reachable from *start_id* via BFS.

        *edge_types* restricts which edge kinds are followed; None means all.
        """
        visited: Set[str] = set()
        queue: deque[tuple[str, int]] = deque([(start_id, 0)])

        while queue:
            current_id, depth = queue.popleft()
            if current_id in visited or depth > max_depth:
                continue
            visited.add(current_id)

            for edge in self._adj.get(current_id, []):
                if edge_types is None or edge.edge_type in edge_types:
                    if edge.dst_id not in visited:
                        queue.append((edge.dst_id, depth + 1))

        return visited

    def all_paths(
        self,
        src_id: str,
        dst_id: str,
        edge_types: Optional[List[CPGEdgeType]] = None,
        max_depth: int = 20,
    ) -> List[List[str]]:
        """
        Enumerate all simple paths from *src_id* to *dst_id*.

        Uses iterative DFS to avoid Python recursion limits.
        Returns a list of node-ID sequences (inclusive of endpoints).
        """
        if src_id not in self.nodes or dst_id not in self.nodes:
            return []

        completed: List[List[str]] = []
        # stack items: (current_node_id, path_so_far, visited_set)
        stack: list[tuple[str, List[str], Set[str]]] = [
            (src_id, [src_id], {src_id})
        ]

        while stack:
            current_id, path, visited = stack.pop()

            if current_id == dst_id and len(path) > 1:
                completed.append(list(path))
                continue

            if len(path) >= max_depth:
                continue

            for edge in self._adj.get(current_id, []):
                if edge_types is not None and edge.edge_type not in edge_types:
                    continue
                nxt = edge.dst_id
                if nxt not in visited:
                    stack.append((nxt, path + [nxt], visited | {nxt}))

        return completed

    # ------------------------------------------------------------------
    # Dominance query (simple CFG-level post-dominator via reachability)
    # ------------------------------------------------------------------

    def dominates(self, a_id: str, b_id: str) -> bool:
        """
        Return True if node A *dominates* node B in the CFG.

        Implemented via the classic definition: A dominates B iff every
        path from the CFG entry to B passes through A.

        We approximate this by:
          1. Finding the CFG_ENTRY node in the same function as B.
          2. Computing all paths from ENTRY to B.
          3. Checking that A appears on every such path.

        For large graphs we fall back to a reachability check:
        if B is reachable from A via CFG_NEXT but not when A is removed,
        A dominates B.
        """
        cfg_edge_types = [
            CPGEdgeType.CFG_NEXT,
            CPGEdgeType.CFG_BRANCH_TRUE,
            CPGEdgeType.CFG_BRANCH_FALSE,
        ]

        # Find the entry node for the same function as b_id
        b_node = self.nodes.get(b_id)
        if b_node is None:
            return False
        func_name = b_node.properties.get("function", "")

        entry_id: Optional[str] = None
        for nid, node in self.nodes.items():
            if (
                node.node_type == CPGNodeType.CFG_ENTRY
                and node.properties.get("function", "") == func_name
            ):
                entry_id = nid
                break

        if entry_id is None:
            # Cannot determine dominance without an entry — fall back to
            # simple reachability: A → B exists and B is not reachable
            # without going through A.
            reachable_from_a = self.reachable(a_id, edge_types=cfg_edge_types)
            if b_id not in reachable_from_a:
                return False
            # Remove A temporarily and check reachability from any predecessor of A
            preds_of_a = [
                e.src_id
                for e in self._radj.get(a_id, [])
                if e.edge_type in cfg_edge_types
            ]
            if not preds_of_a:
                # A has no CFG predecessors → A must be the entry itself
                return True
            for pred_id in preds_of_a:
                # BFS excluding a_id
                reachable_without_a: Set[str] = set()
                q: deque[str] = deque([pred_id])
                while q:
                    cur = q.popleft()
                    if cur == a_id or cur in reachable_without_a:
                        continue
                    reachable_without_a.add(cur)
                    for e in self._adj.get(cur, []):
                        if e.edge_type in cfg_edge_types and e.dst_id not in reachable_without_a:
                            q.append(e.dst_id)
                if b_id in reachable_without_a:
                    return False  # B reachable without A → A does not dominate
            return True

        # Full path-based dominance check from entry
        paths = self.all_paths(entry_id, b_id, edge_types=cfg_edge_types, max_depth=30)
        if not paths:
            return False
        return all(a_id in path for path in paths)

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": [n.to_dict() for n in self.nodes.values()],
            "edges": [e.to_dict() for e in self.edges],
            "stats": {
                "node_count": len(self.nodes),
                "edge_count": len(self.edges),
            },
        }

    # ------------------------------------------------------------------
    # Merge (for cross-file / whole-repo analysis)
    # ------------------------------------------------------------------

    def merge(self, other: "CodePropertyGraph") -> None:
        """
        Merge *other* into this graph in-place.

        Nodes with duplicate IDs in *other* are silently skipped.
        Edges whose endpoints already exist are added; edges referencing
        unknown nodes are discarded.
        """
        for node in other.nodes.values():
            self.add_node(node)

        for edge in other.edges:
            if edge.src_id in self.nodes and edge.dst_id in self.nodes:
                # Avoid strict duplicate edges
                duplicate = any(
                    e.src_id == edge.src_id
                    and e.dst_id == edge.dst_id
                    and e.edge_type == edge.edge_type
                    for e in self._adj.get(edge.src_id, [])
                )
                if not duplicate:
                    self.edges.append(edge)
                    self._adj.setdefault(edge.src_id, []).append(edge)
                    self._radj.setdefault(edge.dst_id, []).append(edge)

    # ------------------------------------------------------------------
    # Repr
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"<CodePropertyGraph nodes={len(self.nodes)} edges={len(self.edges)}>"
        )
