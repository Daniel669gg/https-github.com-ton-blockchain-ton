"""
backend/core/cpg/ssa.py — Static Single Assignment (SSA) form for CPG.

Extends the existing CPG with SSA representation:
- Variable versioning (each definition gets a unique version)
- Dominator trees and dominance frontiers (for phi-function placement)
- Post-dominator trees
- Phi-function insertion at join points
- Def-use and use-def chains (indexed by variable@version)
- Alias analysis (simple type-based)
- Constant propagation
- Type propagation

Does NOT recreate the CPG — takes an existing CodePropertyGraph and computes
SSA form as an overlay data structure.
"""

from __future__ import annotations

import re
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

from .graph import (
    CPGEdgeType,
    CPGNode,
    CPGNodeType,
    CodePropertyGraph,
)


# ---------------------------------------------------------------------------
# SSA Data Structures
# ---------------------------------------------------------------------------

@dataclass
class SSAVariable:
    """A single SSA-versioned variable."""
    name: str           # original variable name
    version: int        # SSA version number (0 = original/undefined)
    def_node_id: str    # CPG node_id where this version is defined
    cwe_hint: str = ""  # if this var came from a taint source


@dataclass
class PhiFunction:
    """Phi-function at a join point in the CFG."""
    block_entry_node: str                        # CPG node_id of the block entry
    variable: str                                # variable name
    result_version: int                          # version assigned by this phi
    operand_versions: List[Tuple[str, int]]      # [(pred_block_entry_node_id, version)]


@dataclass
class DominatorTree:
    """Dominator tree for a function's CFG."""
    entry_node: str                               # CFG entry node_id
    idom: Dict[str, str]                          # node_id → immediate dominator node_id
    dominated_by: Dict[str, Set[str]]             # node_id → set of nodes that dominate it
    dominance_frontier: Dict[str, Set[str]]       # node_id → dominance frontier nodes
    post_idom: Dict[str, str]                     # post-dominator tree


@dataclass
class DefUseChain:
    """All uses of a specific SSA variable version."""
    variable: str
    version: int
    def_node_id: str
    use_node_ids: List[str]
    is_tainted: bool = False
    taint_source: str = ""


@dataclass
class AliasSet:
    """Variables that may alias each other."""
    canonical: str           # canonical name
    members: Set[str]        # all variable names in this alias set
    alias_type: str          # "assignment", "parameter", "attribute", "return"


@dataclass
class SSAForm:
    """Complete SSA form overlay for a CodePropertyGraph."""

    # Variable versioning
    variables: Dict[str, List[SSAVariable]]        # name → [versions]
    current_version: Dict[str, int]                 # name → max version

    # Phi functions: block_entry_node_id → list of phi functions in that block
    phi_functions: Dict[str, List[PhiFunction]]

    # Dominance
    dominator_trees: Dict[str, DominatorTree]       # func_entry_node_id → DominatorTree

    # Chains
    def_use_chains: Dict[str, DefUseChain]          # "var@version" → DefUseChain
    use_def_chains: Dict[str, List[str]]            # use_node_id → [def_node_ids ("var@version")]

    # Alias analysis
    alias_sets: List[AliasSet]
    node_aliases: Dict[str, str]                    # node_id → canonical alias name

    # Constant propagation results
    constants: Dict[str, Any]                       # "var@version" → constant value (or None)

    # Type propagation results
    types: Dict[str, str]                           # "var@version" → inferred type string

    # -----------------------------------------------------------------------
    # Query helpers
    # -----------------------------------------------------------------------

    def get_def(self, var: str, version: int) -> Optional[DefUseChain]:
        """Look up def-use chain for var@version."""
        return self.def_use_chains.get(f"{var}@{version}")

    def get_uses(self, def_node_id: str) -> List[str]:
        """Get all use node IDs for a given definition node."""
        result: List[str] = []
        for chain in self.def_use_chains.values():
            if chain.def_node_id == def_node_id:
                result.extend(chain.use_node_ids)
        return result

    def get_constant(self, var: str, version: int) -> Any:
        """Return constant value for var@version, or None if not constant."""
        return self.constants.get(f"{var}@{version}")

    def get_type(self, var: str, version: int) -> str:
        """Return inferred type for var@version, or 'unknown'."""
        return self.types.get(f"{var}@{version}", "unknown")

    def is_tainted(self, var: str, version: int) -> bool:
        """Return True if this SSA variable version is tainted."""
        chain = self.def_use_chains.get(f"{var}@{version}")
        return chain.is_tainted if chain else False

    def tainted_variables(self) -> List[DefUseChain]:
        """Return all tainted SSA variables."""
        return [c for c in self.def_use_chains.values() if c.is_tainted]


# ---------------------------------------------------------------------------
# SSAConverter
# ---------------------------------------------------------------------------

# Assignment pattern: `varname = <something>`
_ASSIGN_RE = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)$")

# String literal patterns
_STR_LITERAL_RE = re.compile(r'''^\s*(?:f?["'].*["']|f?""".*"""|f?'''  + r"'''.*''')\s*$")
_INT_LITERAL_RE = re.compile(r"^\s*-?\d+\s*$")
_BOOL_LITERAL_RE = re.compile(r"^\s*(True|False)\s*$")
_NONE_LITERAL_RE = re.compile(r"^\s*None\s*$")


class SSAConverter:
    """
    Converts a CodePropertyGraph to SSA form.

    Algorithm:
    1. Extract CFG structure from CPG (CFG_ENTRY, CFG_NEXT, CFG_BRANCH_* edges)
    2. Compute dominator trees using iterative algorithm
    3. Compute dominance frontiers
    4. Identify phi-function insertion points
    5. Rename variables to SSA versions
    6. Build def-use and use-def chains
    7. Perform alias analysis
    8. Propagate constants and types
    """

    # Taint source patterns — variables assigned from these are tainted
    _TAINT_SOURCE_PATTERNS = [
        re.compile(r'request\.(args|form|json|data|files|headers|cookies)'),
        re.compile(r'\binput\s*\('),
        re.compile(r'sys\.argv'),
        re.compile(r'os\.environ'),
        re.compile(r'os\.getenv\s*\('),
        re.compile(r'sys\.stdin'),
        re.compile(r'click\.(argument|option)'),
    ]

    # CFG edge types used throughout
    _CFG_EDGE_TYPES = {
        CPGEdgeType.CFG_NEXT,
        CPGEdgeType.CFG_BRANCH_TRUE,
        CPGEdgeType.CFG_BRANCH_FALSE,
    }

    def convert(self, cpg: CodePropertyGraph) -> SSAForm:
        """Main entry point: compute full SSA form for the CPG."""
        # 1. Gather CFG entry nodes
        entry_nodes, _all_cfg_nodes = self._get_cfg_nodes(cpg)

        # 2. Compute dominator trees for each function entry
        dominator_trees: Dict[str, DominatorTree] = {}
        all_frontiers: Dict[str, Set[str]] = {}

        for entry in entry_nodes:
            dt = self._compute_dominator_tree(entry, cpg)
            frontiers = self._compute_dominance_frontiers(dt, cpg)
            dt.dominance_frontier = frontiers
            all_frontiers.update(frontiers)

            # Post-dominator tree: find exit nodes for this function
            func_name = cpg.nodes[entry].properties.get("function", "")
            exit_node = self._find_exit_node(entry, func_name, cpg)
            if exit_node:
                dt.post_idom = self._compute_post_dominator_tree(exit_node, cpg)

            dominator_trees[entry] = dt

        # 3. Collect variable definition sites
        def_sites = self._collect_def_sites(cpg)

        # 4. Insert phi-functions using dominance frontiers
        phi_functions = self._insert_phi_functions(def_sites, all_frontiers, cpg)

        # 5. Rename variables (build SSAVariable records)
        # Use the first dominator tree if multiple functions exist
        primary_dt = next(iter(dominator_trees.values())) if dominator_trees else DominatorTree(
            entry_node="",
            idom={},
            dominated_by={},
            dominance_frontier={},
            post_idom={},
        )
        variables = self._rename_variables(cpg, def_sites, phi_functions, primary_dt)

        # Track max versions
        current_version: Dict[str, int] = {}
        for name, versions in variables.items():
            current_version[name] = max((v.version for v in versions), default=0)

        # 6. Build def-use and use-def chains
        def_use_chains, use_def_chains = self._build_def_use_chains(variables, cpg)

        # 7. Alias analysis
        alias_sets, node_aliases = self._analyze_aliases(cpg, variables)

        # 8. Constant propagation
        constants = self._propagate_constants(variables, cpg)

        # 9. Type propagation
        types = self._propagate_types(variables, cpg, constants)

        # 10. Mark tainted variables
        self._mark_tainted_vars(def_use_chains, cpg)

        return SSAForm(
            variables=variables,
            current_version=current_version,
            phi_functions=phi_functions,
            dominator_trees=dominator_trees,
            def_use_chains=def_use_chains,
            use_def_chains=use_def_chains,
            alias_sets=alias_sets,
            node_aliases=node_aliases,
            constants=constants,
            types=types,
        )

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _get_cfg_nodes(self, cpg: CodePropertyGraph) -> Tuple[List[str], List[str]]:
        """Extract CFG entry nodes and all CFG-relevant nodes from CPG."""
        entry_nodes: List[str] = []
        cfg_nodes: List[str] = []

        for node_id, node in cpg.nodes.items():
            if node.node_type == CPGNodeType.CFG_ENTRY:
                entry_nodes.append(node_id)
            if node.node_type in (
                CPGNodeType.CFG_ENTRY,
                CPGNodeType.CFG_EXIT,
                CPGNodeType.CFG_BLOCK,
                CPGNodeType.DFG_DEF,
                CPGNodeType.DFG_USE,
                CPGNodeType.CG_CALL,
                CPGNodeType.CG_RETURN,
                CPGNodeType.PDG_NODE,
                CPGNodeType.AST_NODE,
            ):
                cfg_nodes.append(node_id)

        return entry_nodes, cfg_nodes

    def _find_exit_node(self, entry_id: str, func_name: str, cpg: CodePropertyGraph) -> Optional[str]:
        """Find the CFG_EXIT node for the given function."""
        for node_id, node in cpg.nodes.items():
            if node.node_type == CPGNodeType.CFG_EXIT:
                if node.properties.get("function", "") == func_name:
                    return node_id
        return None

    def _compute_dominator_tree(self, entry: str, cpg: CodePropertyGraph) -> DominatorTree:
        """
        Compute dominator tree using iterative dataflow algorithm.
        dom(n) = {n} ∪ (∩ dom(p) for p in predecessors(n))
        """
        # BFS to collect all reachable nodes from entry via CFG edges
        cfg_edge_list = list(self._CFG_EDGE_TYPES)
        reachable_ids = cpg.reachable(entry, edge_types=cfg_edge_list, max_depth=200)
        all_nodes = list(reachable_ids)

        if not all_nodes:
            return DominatorTree(
                entry_node=entry,
                idom={},
                dominated_by={},
                dominance_frontier={},
                post_idom={},
            )

        # Initialize: dom(entry) = {entry}, dom(n) = all_nodes for others
        dom: Dict[str, Set[str]] = {}
        all_set = set(all_nodes)
        dom[entry] = {entry}
        for n in all_nodes:
            if n != entry:
                dom[n] = set(all_set)

        # Iterative fixpoint
        changed = True
        while changed:
            changed = False
            for n in all_nodes:
                if n == entry:
                    continue
                # Predecessors via CFG edges
                preds = [
                    p.node_id
                    for et in self._CFG_EDGE_TYPES
                    for p in cpg.predecessors(n, et)
                    if p.node_id in all_set
                ]
                if not preds:
                    continue
                # Intersect dominators of all predecessors, then add n itself
                new_dom = set.intersection(*(dom.get(p, all_set) for p in preds))
                new_dom.add(n)
                if new_dom != dom[n]:
                    dom[n] = new_dom
                    changed = True

        # Build immediate dominator map: for each node n, idom(n) is the
        # node in dom(n) \ {n} that is dominated by all other dominators of n
        idom: Dict[str, str] = {}
        for n in all_nodes:
            if n == entry:
                continue
            strict_doms = dom[n] - {n}
            if not strict_doms:
                continue
            # idom(n) is the unique element of strict_doms not dominated by
            # any other element of strict_doms
            idom_candidate: Optional[str] = None
            for candidate in strict_doms:
                # candidate is idom if every other strict dominator d also dominates candidate
                # i.e., candidate ∈ dom(d) for all d in strict_doms
                if all(candidate in dom.get(d, set()) for d in strict_doms if d != candidate):
                    idom_candidate = candidate
                    break
            if idom_candidate:
                idom[n] = idom_candidate

        # Build dominated_by: node → set of nodes that dominate it
        dominated_by: Dict[str, Set[str]] = {n: dom[n] for n in all_nodes}

        return DominatorTree(
            entry_node=entry,
            idom=idom,
            dominated_by=dominated_by,
            dominance_frontier={},  # filled by _compute_dominance_frontiers
            post_idom={},
        )

    def _compute_dominance_frontiers(
        self, dt: DominatorTree, cpg: CodePropertyGraph
    ) -> Dict[str, Set[str]]:
        """
        Compute dominance frontiers using Cooper et al. algorithm.
        DF(n) = {y | ∃x ∈ pred(y) : n dom x and n does not strictly dom y}
        """
        df: Dict[str, Set[str]] = defaultdict(set)
        idom = dt.idom

        for y in dt.dominated_by:
            # Get all CFG predecessors of y
            preds: List[str] = []
            for et in self._CFG_EDGE_TYPES:
                for p in cpg.predecessors(y, et):
                    if p.node_id in dt.dominated_by:
                        preds.append(p.node_id)

            if len(preds) < 2:
                continue  # y is not a join point

            for x in preds:
                # Walk up the dominator tree from x until we reach idom(y)
                runner = x
                y_idom = idom.get(y)
                while runner != y_idom and runner in idom:
                    df[runner].add(y)
                    runner = idom[runner]

        return dict(df)

    def _compute_post_dominator_tree(
        self, exit_node: str, cpg: CodePropertyGraph
    ) -> Dict[str, str]:
        """Compute post-dominator tree (reverse CFG dominator tree)."""
        # BFS on reversed CFG from exit_node
        all_nodes_set: Set[str] = set()
        queue: deque[str] = deque([exit_node])
        visited: Set[str] = set()
        while queue:
            cur = queue.popleft()
            if cur in visited:
                continue
            visited.add(cur)
            all_nodes_set.add(cur)
            for et in self._CFG_EDGE_TYPES:
                for pred in cpg.predecessors(cur, et):
                    if pred.node_id not in visited:
                        queue.append(pred.node_id)

        all_nodes = list(all_nodes_set)
        if not all_nodes:
            return {}

        # dom on reversed graph = post-dominators
        pdom: Dict[str, Set[str]] = {}
        pdom[exit_node] = {exit_node}
        all_set = set(all_nodes)
        for n in all_nodes:
            if n != exit_node:
                pdom[n] = set(all_set)

        changed = True
        while changed:
            changed = False
            for n in all_nodes:
                if n == exit_node:
                    continue
                # Successors in forward CFG = predecessors in reverse CFG post-dom
                succs: List[str] = []
                for et in self._CFG_EDGE_TYPES:
                    for s in cpg.successors(n, et):
                        if s.node_id in all_set:
                            succs.append(s.node_id)
                if not succs:
                    continue
                new_pdom = set.intersection(*(pdom.get(s, all_set) for s in succs))
                new_pdom.add(n)
                if new_pdom != pdom[n]:
                    pdom[n] = new_pdom
                    changed = True

        # Immediate post-dominator
        post_idom: Dict[str, str] = {}
        for n in all_nodes:
            if n == exit_node:
                continue
            strict_pdoms = pdom[n] - {n}
            if not strict_pdoms:
                continue
            for candidate in strict_pdoms:
                if all(
                    candidate in pdom.get(d, set())
                    for d in strict_pdoms
                    if d != candidate
                ):
                    post_idom[n] = candidate
                    break

        return post_idom

    def _collect_def_sites(self, cpg: CodePropertyGraph) -> Dict[str, List[str]]:
        """
        Collect all variable definition sites from CPG.
        Returns: var_name → [node_id_where_defined]
        Looks at DFG_DEF nodes and nodes with code containing assignments.
        """
        def_sites: Dict[str, List[str]] = defaultdict(list)

        for node_id, node in cpg.nodes.items():
            # Primary: DFG_DEF nodes have a 'defines' property
            if node.node_type == CPGNodeType.DFG_DEF:
                var_name = node.properties.get("defines", "")
                if var_name:
                    if node_id not in def_sites[var_name]:
                        def_sites[var_name].append(node_id)
                    continue

            # Secondary: scan code for assignment patterns
            m = _ASSIGN_RE.match(node.code)
            if m:
                var_name = m.group(1)
                if node_id not in def_sites[var_name]:
                    def_sites[var_name].append(node_id)

        return dict(def_sites)

    def _insert_phi_functions(
        self,
        def_sites: Dict[str, List[str]],
        dominance_frontiers: Dict[str, Set[str]],
        cpg: CodePropertyGraph,
    ) -> Dict[str, List[PhiFunction]]:
        """
        Insert phi-functions at dominance frontiers.
        Standard SSA construction: for each variable with multiple defs,
        insert phi at every node in the iterated dominance frontier.
        """
        phi_functions: Dict[str, List[PhiFunction]] = defaultdict(list)
        # Global phi version counter
        phi_version: Dict[str, int] = {}

        for var_name, sites in def_sites.items():
            if len(sites) < 2:
                continue  # No join points needed for single-def variables

            # Worklist: nodes that need phi inserted due to this var
            worklist: List[str] = list(sites)
            has_phi_already: Set[str] = set()
            phi_inserted: Set[str] = set()

            while worklist:
                site = worklist.pop()
                for frontier_node in dominance_frontiers.get(site, set()):
                    if frontier_node in phi_inserted:
                        continue
                    phi_inserted.add(frontier_node)

                    # Allocate a version for this phi result
                    phi_version[var_name] = phi_version.get(var_name, 0) + 1
                    result_ver = phi_version[var_name]

                    # Gather predecessor block node IDs
                    preds: List[Tuple[str, int]] = []
                    for et in self._CFG_EDGE_TYPES:
                        for pred_node in cpg.predecessors(frontier_node, et):
                            preds.append((pred_node.node_id, 0))  # version resolved later

                    phi = PhiFunction(
                        block_entry_node=frontier_node,
                        variable=var_name,
                        result_version=result_ver,
                        operand_versions=preds,
                    )
                    phi_functions[frontier_node].append(phi)

                    # The phi itself is a new definition site — propagate further
                    if frontier_node not in has_phi_already:
                        has_phi_already.add(frontier_node)
                        worklist.append(frontier_node)

        return dict(phi_functions)

    def _rename_variables(
        self,
        cpg: CodePropertyGraph,
        def_sites: Dict[str, List[str]],
        phi_functions: Dict[str, List[PhiFunction]],
        dominator_tree: DominatorTree,
    ) -> Dict[str, List[SSAVariable]]:
        """
        Rename variable uses to their SSA versions using dominator-tree walk.
        Uses a version counter stack per variable name.
        """
        variables: Dict[str, List[SSAVariable]] = defaultdict(list)

        # Simple linear pass — assign monotonically increasing version per def-site
        version_counter: Dict[str, int] = defaultdict(int)

        for var_name, sites in def_sites.items():
            for node_id in sites:
                node = cpg.nodes.get(node_id)
                if node is None:
                    continue
                version_counter[var_name] += 1
                version = version_counter[var_name]

                # Determine taint hint
                cwe_hint = ""
                for pat in SSAConverter._TAINT_SOURCE_PATTERNS:
                    if pat.search(node.code):
                        cwe_hint = "user_input"
                        break

                ssa_var = SSAVariable(
                    name=var_name,
                    version=version,
                    def_node_id=node_id,
                    cwe_hint=cwe_hint,
                )
                variables[var_name].append(ssa_var)

        # Assign phi-function results as additional SSA versions
        for block_id, phis in phi_functions.items():
            for phi in phis:
                version_counter[phi.variable] += 1
                phi.result_version = version_counter[phi.variable]
                ssa_var = SSAVariable(
                    name=phi.variable,
                    version=phi.result_version,
                    def_node_id=block_id,
                    cwe_hint="",
                )
                variables[phi.variable].append(ssa_var)

        return dict(variables)

    def _build_def_use_chains(
        self,
        variables: Dict[str, List[SSAVariable]],
        cpg: CodePropertyGraph,
    ) -> Tuple[Dict[str, DefUseChain], Dict[str, List[str]]]:
        """Build def→uses and use→defs mappings."""
        def_use_chains: Dict[str, DefUseChain] = {}
        use_def_chains: Dict[str, List[str]] = defaultdict(list)

        # Build a mapping: def_node_id → (var_name, version)
        def_node_to_var: Dict[str, Tuple[str, int]] = {}
        for var_name, versions in variables.items():
            for ssa_var in versions:
                def_node_to_var[ssa_var.def_node_id] = (var_name, ssa_var.version)

        # Initialize chains for every SSA variable
        for var_name, versions in variables.items():
            for ssa_var in versions:
                key = f"{var_name}@{ssa_var.version}"
                def_use_chains[key] = DefUseChain(
                    variable=var_name,
                    version=ssa_var.version,
                    def_node_id=ssa_var.def_node_id,
                    use_node_ids=[],
                )

        # Walk DFG_FLOW edges: src=def, dst=use
        for edge in cpg.edges:
            if edge.edge_type != CPGEdgeType.DFG_FLOW:
                continue

            src_id = edge.src_id
            dst_id = edge.dst_id

            # Find the SSA var for this def node
            var_info = def_node_to_var.get(src_id)
            if var_info is None:
                # Try to infer from edge properties
                var_name = edge.properties.get("var", "")
                if var_name and var_name in variables:
                    # Use the first matching version (rough approximation)
                    ssa_var = variables[var_name][0] if variables[var_name] else None
                    if ssa_var:
                        var_info = (var_name, ssa_var.version)

            if var_info is None:
                continue

            var_name, version = var_info
            key = f"{var_name}@{version}"

            chain = def_use_chains.get(key)
            if chain and dst_id not in chain.use_node_ids:
                chain.use_node_ids.append(dst_id)

            if key not in use_def_chains[dst_id]:
                use_def_chains[dst_id].append(key)

        return def_use_chains, dict(use_def_chains)

    def _analyze_aliases(
        self,
        cpg: CodePropertyGraph,
        variables: Dict[str, List[SSAVariable]],
    ) -> Tuple[List[AliasSet], Dict[str, str]]:
        """
        Simple alias analysis:
        - Direct assignment aliases: x = y → x aliases y
        - Parameter aliases: f(x) where x is tainted → parameter aliases x
        - Attribute aliases: x.field treated as separate alias set
        """
        alias_sets: List[AliasSet] = []
        node_aliases: Dict[str, str] = {}

        # Union-find for grouping aliases
        parent: Dict[str, str] = {}

        def find(v: str) -> str:
            while parent.get(v, v) != v:
                parent[v] = parent.get(parent[v], parent[v])  # path compression
                v = parent[v]
            return v

        def union(a: str, b: str, alias_type: str = "assignment") -> None:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[rb] = ra

        # Initialize all variable names as their own parents
        for var_name in variables:
            parent[var_name] = var_name

        # Scan all nodes for alias-inducing patterns
        for node_id, node in cpg.nodes.items():
            code = node.code.strip()

            # Direct assignment: x = y
            m = _ASSIGN_RE.match(code)
            if m:
                lhs = m.group(1)
                rhs = m.group(2).strip()
                # If RHS is a simple variable name
                if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', rhs) and rhs in variables:
                    if lhs not in parent:
                        parent[lhs] = lhs
                    union(lhs, rhs, "assignment")

            # Attribute alias: x.field = y or x = obj.field
            attr_m = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)$', code)
            if attr_m:
                obj_name = attr_m.group(1)
                field = attr_m.group(2)
                alias_name = f"{obj_name}.{field}"
                if alias_name not in parent:
                    parent[alias_name] = alias_name
                if obj_name in variables and obj_name not in parent:
                    parent[obj_name] = obj_name

        # Collect alias sets
        groups: Dict[str, Set[str]] = defaultdict(set)
        for v in list(parent.keys()):
            groups[find(v)].add(v)

        for canonical, members in groups.items():
            if len(members) >= 1:
                a_type = "assignment"
                alias_set = AliasSet(
                    canonical=canonical,
                    members=members,
                    alias_type=a_type,
                )
                alias_sets.append(alias_set)
                for m_name in members:
                    # Map node IDs of definitions to canonical
                    for var_name, versions in variables.items():
                        if var_name == m_name:
                            for ssa_var in versions:
                                node_aliases[ssa_var.def_node_id] = canonical

        return alias_sets, node_aliases

    def _propagate_constants(
        self,
        variables: Dict[str, List[SSAVariable]],
        cpg: CodePropertyGraph,
    ) -> Dict[str, Any]:
        """
        Constant propagation: if a variable is always assigned a literal,
        record its constant value. Strings, ints, booleans, None.
        """
        constants: Dict[str, Any] = {}

        for var_name, versions in variables.items():
            for ssa_var in versions:
                node = cpg.nodes.get(ssa_var.def_node_id)
                if node is None:
                    continue

                code = node.code.strip()

                # Look for: varname = <literal>
                m = _ASSIGN_RE.match(code)
                if not m or m.group(1) != var_name:
                    # Try to match any assignment where we know the def
                    # If the node defines this var, extract RHS
                    if node.properties.get("defines") == var_name:
                        # Try to get RHS from the code
                        eq_pos = code.find("=")
                        if eq_pos >= 0:
                            rhs = code[eq_pos + 1:].strip()
                        else:
                            continue
                    else:
                        continue
                else:
                    rhs = m.group(2).strip()

                key = f"{var_name}@{ssa_var.version}"

                # Integer literal
                if _INT_LITERAL_RE.match(rhs):
                    try:
                        constants[key] = int(rhs)
                    except ValueError:
                        pass
                    continue

                # Boolean literal
                bm = _BOOL_LITERAL_RE.match(rhs)
                if bm:
                    constants[key] = bm.group(1) == "True"
                    continue

                # None literal
                if _NONE_LITERAL_RE.match(rhs):
                    constants[key] = None
                    continue

                # String literal (single/double quote)
                if (
                    (rhs.startswith('"') and rhs.endswith('"')) or
                    (rhs.startswith("'") and rhs.endswith("'")) or
                    (rhs.startswith('f"') and rhs.endswith('"')) or
                    (rhs.startswith("f'") and rhs.endswith("'"))
                ):
                    # Strip outer quotes
                    inner = rhs[1:-1] if not rhs.startswith("f") else rhs[2:-1]
                    constants[key] = inner

        return constants

    def _propagate_types(
        self,
        variables: Dict[str, List[SSAVariable]],
        cpg: CodePropertyGraph,
        constants: Dict[str, Any],
    ) -> Dict[str, str]:
        """
        Type propagation: infer types from assignments.
        - String literals → 'str'
        - Integer literals → 'int'
        - request.args.get(...) → 'user_input_str'
        - cursor.execute result → 'db_result'
        - os.system result → 'int'
        """
        types: Dict[str, str] = {}

        # Type patterns for RHS expressions
        _TYPE_PATTERNS: List[Tuple[re.Pattern, str]] = [
            (re.compile(r'request\.(args|form|json|data|files|headers|cookies)'), "user_input_str"),
            (re.compile(r'\binput\s*\('), "user_input_str"),
            (re.compile(r'sys\.argv'), "user_input_list"),
            (re.compile(r'os\.environ|os\.getenv'), "user_input_str"),
            (re.compile(r'cursor\.execute|\.execute\s*\('), "db_result"),
            (re.compile(r'os\.system\s*\('), "int"),
            (re.compile(r'subprocess\.(run|Popen|call|check_output)\s*\('), "int"),
            (re.compile(r'open\s*\('), "file_object"),
            (re.compile(r'int\s*\('), "int"),
            (re.compile(r'str\s*\('), "str"),
            (re.compile(r'float\s*\('), "float"),
            (re.compile(r'list\s*\(|\['), "list"),
            (re.compile(r'dict\s*\(|\{'), "dict"),
            (re.compile(r'True|False'), "bool"),
        ]

        for var_name, versions in variables.items():
            for ssa_var in versions:
                key = f"{var_name}@{ssa_var.version}"

                # Use constant propagation result for literals
                if key in constants:
                    val = constants[key]
                    if val is None:
                        types[key] = "NoneType"
                    elif isinstance(val, bool):
                        types[key] = "bool"
                    elif isinstance(val, int):
                        types[key] = "int"
                    elif isinstance(val, str):
                        types[key] = "str"
                    continue

                node = cpg.nodes.get(ssa_var.def_node_id)
                if node is None:
                    types[key] = "unknown"
                    continue

                code = node.code

                # Check RHS expression against known type patterns
                matched_type = "unknown"
                for pat, typ in _TYPE_PATTERNS:
                    if pat.search(code):
                        matched_type = typ
                        break

                types[key] = matched_type

        return types

    def _mark_tainted_vars(
        self,
        def_use_chains: Dict[str, DefUseChain],
        cpg: CodePropertyGraph,
    ) -> None:
        """
        Mark SSA variables as tainted if their definition comes from a user input source.
        Propagates taint through def-use chains.
        """
        # First pass: mark direct taint sources
        directly_tainted: Set[str] = set()
        for key, chain in def_use_chains.items():
            node = cpg.nodes.get(chain.def_node_id)
            if node is None:
                continue
            for pat in SSAConverter._TAINT_SOURCE_PATTERNS:
                if pat.search(node.code):
                    chain.is_tainted = True
                    chain.taint_source = node.code[:120]
                    directly_tainted.add(key)
                    break

        # Second pass: propagate taint through def-use chains (BFS)
        # If a use of a tainted var becomes a def of another var, that var is tainted
        worklist = list(directly_tainted)
        visited: Set[str] = set(directly_tainted)

        while worklist:
            tainted_key = worklist.pop()
            chain = def_use_chains.get(tainted_key)
            if chain is None:
                continue

            # Check if any use node is itself a def node for another chain
            for use_node_id in chain.use_node_ids:
                for other_key, other_chain in def_use_chains.items():
                    if other_chain.def_node_id == use_node_id and other_key not in visited:
                        other_chain.is_tainted = True
                        other_chain.taint_source = chain.taint_source or chain.def_node_id
                        visited.add(other_key)
                        worklist.append(other_key)
