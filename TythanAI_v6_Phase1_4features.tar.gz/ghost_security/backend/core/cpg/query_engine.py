"""
backend/core/cpg/query_engine.py — Graph query engine for vulnerability detection.

Provides typed queries over a CodePropertyGraph for:
  - Taint source → sink path detection
  - SQL injection patterns (string concat in execute() call)
  - Command injection (os.system/subprocess with tainted args)
  - Path traversal
  - Hardcoded secrets
  - Privilege escalation paths
  - Cross-function taint flows
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from .graph import (
    CPGEdgeType,
    CPGNode,
    CPGNodeType,
    CodePropertyGraph,
)


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

@dataclass
class TaintPath:
    """A discovered source-to-sink taint flow."""
    src_node:   CPGNode
    dst_node:   CPGNode
    path:       List[CPGNode]        # ordered list of CPGNodes from source to sink
    confidence: float                # 0.0 – 1.0
    sink_type:  str                  # e.g. "sql_injection", "command_injection"
    vuln_desc:  str = ""
    file:       str = ""
    line:       int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "src_node":   self.src_node.to_dict(),
            "dst_node":   self.dst_node.to_dict(),
            "path":       [n.to_dict() for n in self.path],
            "confidence": self.confidence,
            "sink_type":  self.sink_type,
            "vuln_desc":  self.vuln_desc,
            "file":       self.file,
            "line":       self.line,
        }


# ---------------------------------------------------------------------------
# Source and sink pattern registries
# ---------------------------------------------------------------------------

# Patterns that flag a node's `code` as a taint source
_SQL_SOURCE_PATTERNS: List[str] = [
    r"request\.args",
    r"request\.form",
    r"request\.json",
    r"request\.data",
    r"request\.get_json",
    r"request\.values",
    r"request\.cookies",
    r"request\.headers",
    r"request\.files",
    r"\binput\s*\(",
    r"sys\.stdin",
    r"os\.environ",
    r"environ\.get",
    r"getenv\s*\(",
    r"flask\.request",
    r"bottle\.request",
    r"django\..*request",
    r"urllib\..*read",
    r"urlopen\s*\(",
]

_SQL_SINK_PATTERNS: List[str] = [
    r"cursor\.execute\s*\(",
    r"\.execute\s*\(",
    r"executemany\s*\(",
    r"raw\s*\(",          # Django ORM raw()
    r"extra\s*\(",        # Django ORM extra()
]

_CMD_SINK_PATTERNS: List[str] = [
    r"os\.system\s*\(",
    r"subprocess\.run\s*\(",
    r"subprocess\.Popen\s*\(",
    r"subprocess\.call\s*\(",
    r"subprocess\.check_output\s*\(",
    r"subprocess\.check_call\s*\(",
    r"popen\s*\(",
    r"commands\.getoutput\s*\(",
    r"commands\.getstatusoutput\s*\(",
]

_PATH_SINK_PATTERNS: List[str] = [
    r"\bopen\s*\(",
    r"os\.path\.join\s*\(",
    r"shutil\.copy\s*\(",
    r"shutil\.move\s*\(",
    r"shutil\.rmtree\s*\(",
    r"pathlib\.Path\s*\(",
    r"os\.remove\s*\(",
    r"os\.unlink\s*\(",
    r"os\.makedirs\s*\(",
    r"os\.listdir\s*\(",
]

_EVAL_SINK_PATTERNS: List[str] = [
    r"\beval\s*\(",
    r"\bexec\s*\(",
    r"compile\s*\(",
    r"__import__\s*\(",
    r"importlib\.import_module\s*\(",
    r"pickle\.loads\s*\(",
    r"yaml\.load\s*\(",
    r"marshal\.loads\s*\(",
]

# Hardcoded secret regexes (applied to string literal node code)
_SECRET_PATTERNS: List[tuple[str, str]] = [
    (r"(?i)(password|passwd|pwd)\s*=\s*['\"][^'\"]{4,}['\"]",  "hardcoded_password"),
    (r"(?i)(secret|secret_key|api_secret)\s*=\s*['\"][^'\"]{8,}['\"]", "hardcoded_secret"),
    (r"(?i)(api_key|apikey|access_key)\s*=\s*['\"][^'\"]{8,}['\"]", "hardcoded_api_key"),
    (r"(?i)(token|auth_token|bearer)\s*=\s*['\"][^'\"]{8,}['\"]", "hardcoded_token"),
    (r"(?i)aws_access_key_id\s*=\s*['\"]AKIA[0-9A-Z]{16}['\"]", "aws_access_key"),
    (r"(?i)aws_secret_access_key\s*=\s*['\"][^'\"]{40}['\"]", "aws_secret_key"),
    (r"-----BEGIN (RSA|EC|DSA|OPENSSH) PRIVATE KEY-----", "private_key"),
    (r"(?i)(database_url|db_url|connection_string)\s*=\s*['\"][^'\"]+://[^'\"]+:[^'\"]+@", "db_credentials"),
    (r"(?i)(smtp_password|mail_password)\s*=\s*['\"][^'\"]{4,}['\"]", "mail_credentials"),
    (r"ghp_[0-9A-Za-z]{36}", "github_personal_access_token"),
    (r"sk-[0-9A-Za-z]{48}", "openai_api_key"),
]


def _matches_any(code: str, patterns: List[str]) -> bool:
    return any(re.search(p, code) for p in patterns)


def _match_pattern(code: str, patterns: List[str]) -> Optional[str]:
    for p in patterns:
        if re.search(p, code):
            return p
    return None


# ---------------------------------------------------------------------------
# CPGQueryEngine
# ---------------------------------------------------------------------------

class CPGQueryEngine:
    """
    Runs vulnerability-detection graph queries over a CodePropertyGraph.

    All query methods return lists of TaintPath or Dict findings.
    """

    def __init__(self, cpg: CodePropertyGraph) -> None:
        self.cpg = cpg

    # ------------------------------------------------------------------
    # Core taint-path engine
    # ------------------------------------------------------------------

    def find_taint_paths(
        self,
        sources: List[str],   # list of regex patterns for source nodes
        sinks:   List[str],   # list of regex patterns for sink nodes
        sink_type: str = "generic",
        max_depth: int = 30,
    ) -> List[TaintPath]:
        """
        Find all taint paths from nodes matching *sources* to nodes matching *sinks*.

        Traversal order: DFG_FLOW edges (data propagation) then CFG edges
        (to cross basic-block boundaries), and CG_CALL edges for interprocedural flow.
        """
        flow_edge_types = [
            CPGEdgeType.DFG_FLOW,
            CPGEdgeType.CFG_NEXT,
            CPGEdgeType.CFG_BRANCH_TRUE,
            CPGEdgeType.CFG_BRANCH_FALSE,
            CPGEdgeType.CG_CALL,
        ]

        # Identify source nodes
        source_nodes: List[CPGNode] = []
        for node in self.cpg.nodes.values():
            if _matches_any(node.code, sources):
                source_nodes.append(node)

        # Identify sink nodes
        sink_node_ids: Set[str] = set()
        for node in self.cpg.nodes.values():
            if _matches_any(node.code, sinks):
                sink_node_ids.add(node.node_id)

        results: List[TaintPath] = []
        seen_pairs: Set[tuple[str, str]] = set()

        for src_node in source_nodes:
            # BFS to find all reachable nodes from this source
            reachable = self.cpg.reachable(
                src_node.node_id,
                edge_types=flow_edge_types,
                max_depth=max_depth,
            )

            # Check if any sink is reachable
            reachable_sinks = reachable & sink_node_ids
            if not reachable_sinks:
                continue

            for sink_id in reachable_sinks:
                pair = (src_node.node_id, sink_id)
                if pair in seen_pairs:
                    continue
                seen_pairs.add(pair)

                sink_node = self.cpg.nodes[sink_id]

                # Find concrete paths (limited to first 3 for performance)
                raw_paths = self.cpg.all_paths(
                    src_node.node_id,
                    sink_id,
                    edge_types=flow_edge_types,
                    max_depth=max_depth,
                )

                if raw_paths:
                    for raw_path in raw_paths[:3]:
                        node_path = [
                            self.cpg.nodes[nid]
                            for nid in raw_path
                            if nid in self.cpg.nodes
                        ]
                        confidence = self._compute_confidence(
                            src_node, sink_node, node_path, sink_type
                        )
                        results.append(TaintPath(
                            src_node=src_node,
                            dst_node=sink_node,
                            path=node_path,
                            confidence=confidence,
                            sink_type=sink_type,
                            vuln_desc=self._describe(sink_type, src_node, sink_node),
                            file=src_node.file,
                            line=src_node.line,
                        ))
                else:
                    # Reachable but no explicit path found — report with lower confidence
                    confidence = self._compute_confidence(
                        src_node, sink_node, [], sink_type
                    ) * 0.7
                    results.append(TaintPath(
                        src_node=src_node,
                        dst_node=sink_node,
                        path=[src_node, sink_node],
                        confidence=confidence,
                        sink_type=sink_type,
                        vuln_desc=self._describe(sink_type, src_node, sink_node),
                        file=src_node.file,
                        line=src_node.line,
                    ))

        return results

    def _compute_confidence(
        self,
        src: CPGNode,
        dst: CPGNode,
        path: List[CPGNode],
        sink_type: str,
    ) -> float:
        """
        Heuristic confidence score in [0, 1].

        Factors:
          - Direct DFG flow: +0.4
          - Short path (≤3 hops): +0.2
          - Known high-risk source (request.*): +0.2
          - Known high-risk sink: +0.2
        """
        score = 0.3  # base

        # DFG flow in path?
        if path:
            dfg_hop = any(
                any(
                    e.edge_type == CPGEdgeType.DFG_FLOW
                    for e in self.cpg._adj.get(path[i].node_id, [])
                    if e.dst_id == path[i + 1].node_id
                )
                for i in range(len(path) - 1)
            )
            if dfg_hop:
                score += 0.25

        # Short path bonus
        if 2 <= len(path) <= 4:
            score += 0.15

        # High-value source patterns
        high_risk_sources = [
            "request.args", "request.form", "request.json", "input(",
        ]
        if any(p in src.code for p in high_risk_sources):
            score += 0.15

        # High-value sinks
        high_risk_sinks = {
            "sql_injection": ["execute(", "executemany("],
            "command_injection": ["os.system(", "subprocess.run(", "Popen("],
            "path_traversal": ["open(", "rmtree("],
            "code_injection": ["eval(", "exec("],
        }
        for s_patterns in high_risk_sinks.get(sink_type, []):
            if s_patterns in dst.code:
                score += 0.15
                break

        # Penalize if sink uses parameterized query form (reduces FP for safe code)
        if sink_type == "sql_injection":
            import re as _re
            # Parameterized: execute(sql, params) with tuple argument
            parameterized = bool(_re.search(
                r'execute\s*\([^)]+,\s*[\(\[]', dst.code
            ))
            if parameterized:
                score = max(0.1, score - 0.4)

        # Penalize if command sink uses list args (subprocess with list = safe)
        if sink_type == "command_injection":
            import re as _re
            if _re.search(r'subprocess\.\w+\s*\(\s*\[', dst.code):
                score = max(0.1, score - 0.35)

        return min(score, 1.0)

    def _describe(self, sink_type: str, src: CPGNode, dst: CPGNode) -> str:
        desc_map = {
            "sql_injection": (
                f"User-controlled data from '{src.code[:60]}' "
                f"flows into SQL execution at '{dst.code[:60]}'"
            ),
            "command_injection": (
                f"User-controlled data from '{src.code[:60]}' "
                f"flows into OS command at '{dst.code[:60]}'"
            ),
            "path_traversal": (
                f"User-controlled data from '{src.code[:60]}' "
                f"used in file-system operation at '{dst.code[:60]}'"
            ),
            "code_injection": (
                f"User-controlled data from '{src.code[:60]}' "
                f"flows into code evaluation at '{dst.code[:60]}'"
            ),
        }
        return desc_map.get(
            sink_type,
            f"Taint flows from '{src.code[:60]}' to '{dst.code[:60]}'",
        )

    # ------------------------------------------------------------------
    # Specialised vuln queries
    # ------------------------------------------------------------------

    def find_sql_injection(self) -> List[TaintPath]:
        """Detect SQL injection: tainted data into cursor.execute / ORM raw()."""
        return self.find_taint_paths(
            sources=_SQL_SOURCE_PATTERNS,
            sinks=_SQL_SINK_PATTERNS,
            sink_type="sql_injection",
        )

    def find_command_injection(self) -> List[TaintPath]:
        """Detect OS command injection: tainted data into os.system / subprocess."""
        return self.find_taint_paths(
            sources=_SQL_SOURCE_PATTERNS,
            sinks=_CMD_SINK_PATTERNS,
            sink_type="command_injection",
        )

    def find_path_traversal(self) -> List[TaintPath]:
        """Detect path traversal: tainted data used in file-system ops."""
        return self.find_taint_paths(
            sources=_SQL_SOURCE_PATTERNS,
            sinks=_PATH_SINK_PATTERNS,
            sink_type="path_traversal",
        )

    def find_code_injection(self) -> List[TaintPath]:
        """Detect code injection: tainted data reaching eval/exec."""
        return self.find_taint_paths(
            sources=_SQL_SOURCE_PATTERNS,
            sinks=_EVAL_SINK_PATTERNS,
            sink_type="code_injection",
        )

    # ------------------------------------------------------------------
    # Hardcoded secrets
    # ------------------------------------------------------------------

    def find_hardcoded_secrets(self) -> List[Dict[str, Any]]:
        """
        Scan all AST string-literal nodes and assignment nodes for
        hardcoded credentials / secrets using regex patterns.
        """
        findings: List[Dict[str, Any]] = []
        seen: Set[str] = set()

        for node in self.cpg.nodes.values():
            # Check the node's code text against every secret pattern
            for pattern, secret_type in _SECRET_PATTERNS:
                match = re.search(pattern, node.code)
                if match:
                    # Deduplicate by (file, line, secret_type)
                    dedup_key = f"{node.file}:{node.line}:{secret_type}"
                    if dedup_key in seen:
                        continue
                    seen.add(dedup_key)

                    # Mask the matched value
                    matched_text = match.group(0)
                    masked = re.sub(
                        r"(['\"])(.{2}).+(.{2})\1",
                        r"\1\2****\3\1",
                        matched_text,
                    )

                    findings.append({
                        "type":        secret_type,
                        "file":        node.file,
                        "line":        node.line,
                        "col":         node.col,
                        "code":        node.code[:120],
                        "matched":     masked,
                        "node_id":     node.node_id,
                        "confidence":  0.85,
                        "severity":    "HIGH",
                        "description": (
                            f"Potential {secret_type.replace('_', ' ')} "
                            f"found hardcoded at {node.file}:{node.line}"
                        ),
                    })

        return findings

    # ------------------------------------------------------------------
    # Cross-function taint flows
    # ------------------------------------------------------------------

    def find_cross_function_flows(self) -> List[TaintPath]:
        """
        Detect taint flows that cross function boundaries via CG_CALL edges.

        Strategy:
          1. Find all taint sources.
          2. From each source, follow DFG_FLOW + CG_CALL edges.
          3. Report any path that crosses at least one CG_CALL edge
             and reaches a sink.
        """
        flow_edge_types = [
            CPGEdgeType.DFG_FLOW,
            CPGEdgeType.CG_CALL,
            CPGEdgeType.CFG_NEXT,
            CPGEdgeType.CFG_BRANCH_TRUE,
            CPGEdgeType.CFG_BRANCH_FALSE,
        ]

        all_sink_patterns = (
            _SQL_SINK_PATTERNS
            + _CMD_SINK_PATTERNS
            + _PATH_SINK_PATTERNS
            + _EVAL_SINK_PATTERNS
        )

        source_nodes = [
            n for n in self.cpg.nodes.values()
            if _matches_any(n.code, _SQL_SOURCE_PATTERNS)
        ]
        sink_ids = {
            n.node_id
            for n in self.cpg.nodes.values()
            if _matches_any(n.code, all_sink_patterns)
        }

        results: List[TaintPath] = []
        seen: Set[tuple[str, str]] = set()

        for src in source_nodes:
            reachable = self.cpg.reachable(
                src.node_id,
                edge_types=flow_edge_types,
                max_depth=40,
            )
            for sink_id in reachable & sink_ids:
                pair = (src.node_id, sink_id)
                if pair in seen:
                    continue
                seen.add(pair)

                # Get all paths and keep only those crossing a CG_CALL
                paths = self.cpg.all_paths(
                    src.node_id, sink_id,
                    edge_types=flow_edge_types,
                    max_depth=40,
                )
                cross_paths = [
                    p for p in paths
                    if self._path_crosses_call(p)
                ]
                if not cross_paths:
                    continue

                sink_node = self.cpg.nodes[sink_id]
                for raw_path in cross_paths[:2]:
                    node_path = [
                        self.cpg.nodes[nid]
                        for nid in raw_path
                        if nid in self.cpg.nodes
                    ]
                    # Determine sink type
                    sink_type = self._classify_sink(sink_node.code)
                    results.append(TaintPath(
                        src_node=src,
                        dst_node=sink_node,
                        path=node_path,
                        confidence=0.75,
                        sink_type=f"cross_function_{sink_type}",
                        vuln_desc=(
                            f"Cross-function taint: data from '{src.code[:50]}' "
                            f"reaches '{sink_node.code[:50]}' via function calls"
                        ),
                        file=src.file,
                        line=src.line,
                    ))

        return results

    def _path_crosses_call(self, path: List[str]) -> bool:
        """
        Return True if any edge on this path is a CG_CALL, or if the path
        traverses a DFG_FLOW edge into a CFG_ENTRY node (interprocedural
        argument→parameter binding produced by the builder).
        """
        for i in range(len(path) - 1):
            src_id = path[i]
            dst_id = path[i + 1]
            for edge in self.cpg._adj.get(src_id, []):
                if edge.dst_id != dst_id:
                    continue
                if edge.edge_type == CPGEdgeType.CG_CALL:
                    return True
                # Interprocedural DFG_FLOW: def_site → CFG_ENTRY (argument passing)
                if edge.edge_type == CPGEdgeType.DFG_FLOW:
                    dst_node = self.cpg.nodes.get(dst_id)
                    if dst_node and dst_node.node_type == CPGNodeType.CFG_ENTRY:
                        return True
        return False

    def _classify_sink(self, code: str) -> str:
        if _matches_any(code, _SQL_SINK_PATTERNS):
            return "sql_injection"
        if _matches_any(code, _CMD_SINK_PATTERNS):
            return "command_injection"
        if _matches_any(code, _PATH_SINK_PATTERNS):
            return "path_traversal"
        if _matches_any(code, _EVAL_SINK_PATTERNS):
            return "code_injection"
        return "unknown"

    # ------------------------------------------------------------------
    # Attack path search (endpoints → sensitive assets)
    # ------------------------------------------------------------------

    def attack_path_search(
        self,
        entry_points: List[str],   # regex patterns identifying HTTP entry points
        target_assets: List[str],  # regex patterns identifying sensitive assets
        max_depth: int = 50,
    ) -> List[List[CPGNode]]:
        """
        Find paths from HTTP endpoints (entry_points) to sensitive assets
        (target_assets) using all edge types.

        This models the attacker's perspective: starting from an API endpoint,
        can they reach a database write, file operation, or secret access?
        """
        all_edge_types = [
            CPGEdgeType.DFG_FLOW,
            CPGEdgeType.CFG_NEXT,
            CPGEdgeType.CFG_BRANCH_TRUE,
            CPGEdgeType.CFG_BRANCH_FALSE,
            CPGEdgeType.CG_CALL,
        ]

        entry_nodes = [
            n for n in self.cpg.nodes.values()
            if _matches_any(n.code, entry_points)
        ]
        asset_ids = {
            n.node_id
            for n in self.cpg.nodes.values()
            if _matches_any(n.code, target_assets)
        }

        attack_paths: List[List[CPGNode]] = []
        seen: Set[tuple[str, str]] = set()

        for entry in entry_nodes:
            reachable = self.cpg.reachable(
                entry.node_id,
                edge_types=all_edge_types,
                max_depth=max_depth,
            )
            for asset_id in reachable & asset_ids:
                pair = (entry.node_id, asset_id)
                if pair in seen:
                    continue
                seen.add(pair)

                paths = self.cpg.all_paths(
                    entry.node_id,
                    asset_id,
                    edge_types=all_edge_types,
                    max_depth=max_depth,
                )
                for raw in paths[:2]:
                    node_path = [
                        self.cpg.nodes[nid]
                        for nid in raw
                        if nid in self.cpg.nodes
                    ]
                    attack_paths.append(node_path)

        return attack_paths

    # ------------------------------------------------------------------
    # Combined scan
    # ------------------------------------------------------------------

    def run_all_queries(self) -> Dict[str, Any]:
        """
        Execute every built-in query and return a consolidated findings dict.
        """
        sql_inj    = self.find_sql_injection()
        cmd_inj    = self.find_command_injection()
        path_trav  = self.find_path_traversal()
        code_inj   = self.find_code_injection()
        secrets    = self.find_hardcoded_secrets()
        cross_fn   = self.find_cross_function_flows()

        all_taint = sql_inj + cmd_inj + path_trav + code_inj + cross_fn

        return {
            "sql_injection":     [t.to_dict() for t in sql_inj],
            "command_injection": [t.to_dict() for t in cmd_inj],
            "path_traversal":    [t.to_dict() for t in path_trav],
            "code_injection":    [t.to_dict() for t in code_inj],
            "hardcoded_secrets": secrets,
            "cross_function":    [t.to_dict() for t in cross_fn],
            "summary": {
                "total_taint_paths":   len(all_taint),
                "total_secrets":       len(secrets),
                "high_confidence":     sum(1 for t in all_taint if t.confidence >= 0.7),
                "medium_confidence":   sum(1 for t in all_taint if 0.4 <= t.confidence < 0.7),
            },
        }
